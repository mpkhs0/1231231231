---
agent: ui-regression-checker
run_at: 2026-08-03 13:52:07
verdict: FAIL
summary: 8개 화면 순회 콘솔오류 0건·엔티티 날것 노출 0건으로 프론트 회귀는 없으나, 이번 회차 신규 코드에서 결함 2건 — /api/result/excel 인증이 브라우저 HTTP 캐시로 우회되고, _esc()의 `'`·`\` 추가가 인라인 onclick 12곳을 실제로는 보호하지 못한다.
---

## 판정: FAIL

**회귀(regression)는 0건이다.** 직전 점검(26db067) 대비 8개 화면 전부 정상 렌더 · 콘솔 오류 0건 ·
HTML 엔티티 날것 노출 0건 · `undefined`/`NaN`/`[object Object]` 0건을 확인했다.
FAIL 판정의 근거는 회귀가 아니라 **이번 회차에 새로 들어간 코드의 결함 2건**이다.

### 실행 조건

| 항목 | 값 |
|---|---|
| 서버 | `http://127.0.0.1:8001` · PID **22100** (python, 2026-08-03 13:36:20 기동) |
| 백엔드 최신성 | `main.py` 13:32 / `verify.py` 13:30 / `auth.py` 13:29 / `agents.py` 13:31 수정 → **모두 서버 기동(13:36) 이전**. 서버는 새 백엔드 코드로 동작 중 (`/api/result` 무헤더 401 실측으로 재확인) |
| app.js md5 (디스크) | `59473dae049b519d92072375252eef8f` |
| app.js md5 (서버 응답) | `59473dae049b519d92072375252eef8f` → **일치**. 이하 모든 결과는 실제 서빙 중인 파일에 대한 것 |
| `node --check` | node v24.16.0 · **OK** (문법 오류 없음) |
| 브라우저 | 헤드리스 Edge 151.0.4129.59, 전용 `--user-data-dir`(매 실행 삭제 후 재생성) |
| 구동 방식 | **CDP**(`--remote-debugging-port=9333`) — 문서 §2 경고대로 `--virtual-time-budget` 미사용. `Runtime.exceptionThrown` / `Runtime.consoleAPICalled` / `Log.entryAdded` / `Network.*` 를 페이지 네비게이션 **이전에** attach 해 부팅 시점 오류까지 회수 |
| 인증 | `localStorage.qc_employee_id = A551135` 주입 후 리로드. `/api/result` 19.1MB 정상 수신, `S.result.flags` **5,374건** 적재 확인 |
| 판단 근거 | 문서 §4에 따라 스크린샷 미사용. **DOM 문자열 + 런타임 상태값(innerText/DOM 카운트/캔버스 픽셀 샘플링/CDP 이벤트)만으로 판정** |

### 화면별 결과

| 뷰 | 렌더 | 콘솔오류 | 상호작용 | 비고 |
|---|---|---|---|---|
| `view-upload` | OK | 0 | OK | 업로드 슬롯 3개, `btn-verify` 존재·활성 |
| `view-dashboard` | OK | 0 | OK | KPI 4장 · **Check 카드 14개**(CHECK 1~14, 이름/건수/열 전부 정상) · 토글박스 14개 · bar/donut/trend 캔버스 3개 모두 실제 픽셀 렌더(ink 876/416/389 샘플) |
| `view-results` | OK | 0 | OK | 헤더 17열, 50행/페이지 · 108페이지 페이저 동작 · 행 클릭 → 모달 |
| `view-departments` | OK | 0 | OK | 부서 7개, 표 3개/150행 · **반복 결함 패턴 섹션 존재**(반복 행 50건) · 패턴 클릭 → 모달 |
| `view-dept-dashboard` | OK | 0 | OK | 부서 7 → 팀 10 드릴다운 · Check 카드 14 · 토글이 부서/팀 전환에도 유지 |
| `view-welders` | OK | 0 | OK | KPI 4 · 필터 칩 5개(전체146/반복38/자격미등록43/표본부족39/결함없음23) 전부 행수 변화 확인 · 통합 표 100행 · 상세 팝업 · **월별 추이 그래프 + 추이 판정 배지 정상** |
| `view-agents` | OK | 0 | OK | 카드 5장(전용 2 / 서브 3) · 이력 6행 · 정의 모달 · 리포트 모달(표 3, `<pre>` 20, `<th>` 7 / `<td>` 46) |
| `view-settings` | OK | 0 | OK | 사번 표 렌더, `settings-emp-error` 공란, 입력 4개 |

**미검사 항목 없음.** 문서 §3의 "상호작용까지 확인해야 하는 것" 8개 항목을 전부 실행했다.

#### 이번 회차 중점 확인 항목

1. **`_esc()` 확장 후 엔티티 날것 노출 — 0건.**
   `&#39;` `&amp;` `&lt;` `&gt;` `&quot;` `&#92;` `&#96;` 7종을 8개 화면 · 모든 모달의 `innerText`에서
   3회(pass1/2/3) 전수 스캔 → **전부 0건**. `_esc()` 실측 동작도 확인:
   `_esc("a'b\"c<d>e&f\\g\`h")` → `a&#39;b&quot;c&lt;d&gt;e&amp;f&#92;g&#96;h`.
   유일한 엔티티 검출은 **에이전트 리포트 모달**인데, 이는 이전 `javascript-pro` 리포트가 본문에서
   `_esc` 소스코드(`replace(/&/g,'&amp;')` 등)를 코드블록으로 인용한 것으로 `<pre>` 안에 정상
   렌더된 것이다 — 버그 아님(주변 40자 문맥까지 회수해 확인).
   `textContent`에 `_esc()`를 물린 곳은 `app.js:1192`(`metaEl.textContent = _fbMetaText(...)`) 한 곳뿐이며,
   대입값이 사번+ISO 날짜라 특수문자가 없어 실제 노출은 발생하지 않는다(실측 `"마지막 검토: A551135 · 2026-08-01 21:21"`).
   `app.js:1239`에는 이 함정을 명시한 주석이 이미 달려 있다.
2. **행 템플릿 63곳 `${_esc(x || '—')}` — 누락·`undefined` 0건.**
   8개 화면 + 상세 모달 + Check 목록 모달 + 반복패턴 모달 + 용접사 상세 모달 전부에서
   `undefined` / `NaN` / `[object Object]` **0건**. 값 없는 칸은 `—`로 정상 표시
   (상세 모달 원본 그리드 29칸 중 10칸이 `—`, C14 그룹 뷰의 `Out Dia`/`두께 2`/`재질 2`/`RT`/`UT`/`PT`/
   `용접사 2~4` 등이 모두 `—`).
3. **`downloadExcel()` Blob 전환 — 정상 동작.**
   Blob **3,000,359 bytes**, MIME `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`,
   `<a download="QC_Result.xlsx">` 생성 후 클릭·제거까지 확인(잔여 앵커 0). 다만 실패 경로에 문제가 있다 → **오류 2**.
4. **`loadAgents()` 실패 처리 — 대상 그리드 정상.**
   `ag-grid-project` / `ag-grid-vendor` 두 곳 모두 존재하며 정상 경로에서 카드 2/3장 렌더, `.ag-empty` 0건.

#### 문서 §3 상호작용 체크리스트 실측값

- **Check 카드 body vs 체크박스 — 서로 잡아먹지 않음.**
  카드 본문 클릭 → `Check 3 · 두께 허용범위 초과` 목록 모달(45행) 정상 오픈.
  체크박스 클릭 → 카드에 `ck-off` 부여 + `13/14개 선택됨` 힌트 + "전체 선택으로" 버튼 노출,
  **모달은 열리지 않음**(`stopPropagation` 정상). 집계 영향이 있는 CHECK 5(1,389건)로 재검증:
  결함 행 `3,664 (66.4%)` → `3,144 (57.0%)`, 총 플래그 `5,374` → `3,985`로 KPI 재계산 확인.
  **제외된 카드도 본문 클릭 시 드릴다운은 그대로 동작**(Check 5 off 상태에서 50행 모달 오픈).
- **부서 → 팀 연쇄 반영.** 부서별 대시보드에서 CHECK 6(2,002건) 제외 →
  부서 KPI `3,170 (71.7%)` → `1,761 (39.8%)`. 그대로 팀(`5C1-해양서일`)으로 드릴다운 →
  `ck-off` 상태 유지(`teamOffNum: ["CHECK 6"]`), 팀 KPI `570 (61.9%)`, 다시 켜면 `780 (84.7%)`로 복귀.
  힌트 문구 `13/14개 선택됨 … (부서/팀 전환 시에도 유지)`와 실제 동작 일치.
  참고: 메인 대시보드의 선택은 `S.dashCheckSel`, 부서별은 `S.deptDashCheckSel`로 **의도적으로 분리**되어
  있고(`app.js:60-61`, `app.js:2869-2871` 주석), `renderDepartments()`는 `r.departments` 원본을 쓰므로
  메인 대시보드 토글이 "부서별 결함" 화면 수치를 바꾸지 않는 것은 설계대로다.
- **상세 결과 모달 순서 — 정상.** DOM 순서 실측: `원본 데이터 (엑셀 원문)` → `기준값 / 실측값 비교 및 검토` → `<TEXTAREA>`.
- **"목록으로 돌아가기" 페이지·스크롤 보존 — 정상.** Check 5 목록(28페이지)에서 3페이지 이동 →
  `scrollTop=420` → 행 클릭(`행 2204 · Joint 1H02RB`) → 복귀 시 **page 3 / scrollTop 420 / 첫 행 동일** 복원.
  용접사 상세 모달의 `_wdReopen()` 복귀(`행 7931 …` → `용접사 1102 (차정열)`)도 정상.
- **Check 14 그룹 뷰 — 정상.** 938건 중 행 2142 확인. 도면번호 `1C-CD110-210-10` 표시,
  `중복 등록 그룹 비교` 섹션에 `Joint S03B001 · 2행 중복 · 두께 20 vs 25` 그룹핑,
  WPS/PROCESS 열 분할 표시, `.c14-gjoint` 렌더 확인.
- **용접사 월별 추이 — 그래프·배지 모두 그려짐.** 용접사 `1321`(반복 패턴 4건, 5개월 데이터):
  캔버스 `wd-trend` 1462×220에 실픽셀 778샘플, 스파크 4개(막대 20개),
  추이 배지 4개 = `개선 21%p`(tv-good) / `개선 61%p`(tv-good) / `악화 60%p`(tv-bad) / `유지`(tv-flat),
  각 배지 `title`에 근거 수치(`초기 83% → 최근 63% (결함률 기준, 월 5개)`) 포함.
  *(pass2에서 배지 0개로 보였던 것은 대상 용접사 1102에 반복 패턴이 없어 섹션 자체가 생기지 않은 것 — 설계대로다.)*
- **에이전트 탭 — 정상, `detail-modal`과 간섭 없음.**
  카드 클릭 → `agent-modal` = flex, `detail-modal` = none 유지. 정의 모달에 `<pre>` 11 / `<h*>` 15 / `<li>` 13.
  이력 행 클릭 → 리포트 모달에 `<table>` 3 / `<pre>` 20 / `<th>` 7 / `<td>` 46 → 마크다운 표·코드블록이
  실제 `<table>`/`<pre>`로 렌더됨. HTML 주석(`<!--`) 노출 0건.
- **키보드 — 정상.** ↓ 3회로 선택 이동(상태바 `상세 결과 · 행 345 (3/50)`), ↑ 복귀,
  `/` → `#txt-filter`(placeholder `Joint No / 용접사 번호 / WPS 검색…`) 포커스, `Esc` → 모달 닫힘.
  전 패스(5회 순회, 약 60회 조작)에서 **`e.target.closest is not a function` 오류 0건** — `_closest()` 경유 정상.

---

## 발견된 오류

### 오류 1 (MEDIUM · **이번 회차 신규 코드의 결함**) — `/api/result/excel` 인증이 브라우저 HTTP 캐시로 우회된다

**증상:** `qc_employee_id`를 비운 상태에서 ⬇ Excel을 눌러도 **3,000,359 byte 전체 파일이 그대로 다운로드된다.**
서버는 401을 주고 있으나 요청 자체가 서버에 도달하지 않는다(캐시 히트).

**실측:**

| 요청 | 결과 |
|---|---|
| `curl` 무헤더 / 빈 헤더 / 잘못된 사번 | **401** (서버 인증은 정상 동작) |
| 페이지 내 `fetch('/api/result/excel', {headers:{'X-Employee-Id':''}, cache:'no-store'})` | **401** |
| 페이지 내 `fetch('/api/result/excel?cb=<ts>', {headers:{'X-Employee-Id':''}})` | **401** |
| `downloadExcel()` 실제 호출 (기본 cache 모드, 사번 제거 상태) | **200 · blob 3,000,359 byte · `a.click()` 1회 · alert 없음** |

CDP `Network` 이벤트에도 마지막 케이스의 요청이 **기록되지 않는다** → 네트워크에 나가지 않고 HTTP 캐시에서 응답.

**원인:** 응답 헤더에 `Cache-Control`이 없고 `ETag` / `Last-Modified`만 있다.

```
content-disposition: attachment; filename="QC_Result.xlsx"
content-type: application/vnd.openxmlformats-...spreadsheetml.sheet
etag: "d14ac4a2b9874d1864914c228b5106df"
last-modified: Sun, 02 Aug 2026 14:15:35 GMT
server: uvicorn
            ← Cache-Control / Pragma 없음
```

`Cache-Control`이 없으면 브라우저는 `Last-Modified` 기반 휴리스틱 신선도로 재검증 없이 캐시를 쓴다.
`/static`에는 `_NoCacheStaticFiles`가 `Cache-Control: no-cache`를 붙이지만 **API 응답(FileResponse)에는 붙지 않는다.**
`/api/result`(JSONResponse)는 `ETag`/`Last-Modified`가 없어 이 문제가 없고, **`FileResponse`를 쓰는 경로만 해당**된다.

**영향:** `logout()`은 `localStorage`만 비우고 `location.reload()`한다. 로그아웃 후에도 ⬇ Excel 한 번이면
사번/도면번호/용접사가 든 결과 파일 전체가 다시 열린다 — 이번 회차에 `/api/result/excel`을 인증 대상으로
지정한 목적이 브라우저 단에서 무력화된다. 부수적으로 `downloadExcel()`의 401 → `alert()` 실패 경로도
사용자에게 도달하지 않는다.

- 재현 조작: 로그인 → ⬇ Excel 1회(캐시 적재) → `localStorage.removeItem('qc_employee_id')`(또는 로그아웃) → ⬇ Excel 재클릭
- 의심 코드 위치: `backend/routers/verify.py`(`/api/result/excel`의 `FileResponse` 응답 — `Cache-Control: no-store` 미부여) / 호출부 `frontend/static/js/app.js:1918` (`fetch(...)`에 `cache` 옵션 없음)

### 오류 2 (MEDIUM · **회귀 아님** — 신규 주석이 주장하는 효과가 실제로는 없음) — `_esc()`의 `'`/`\` 추가가 인라인 `onclick` 12곳을 보호하지 못한다

`app.js:1948-1954` 주석은 다음과 같이 주장한다.

> `'`가 빠지면 값 하나로 그 JS 문자열이 끊기고, `\`가 빠지면 `\'`로 닫는 따옴표를 무력화할 수 있다.
> 실제로 수신인에 `o'brien@corp.com`을 넣으면 삭제 버튼이 SyntaxError로 조용히 죽었다.

**그러나 `&#39;` / `&#92;`는 HTML 속성 파싱 단계에서 `'` / `\`로 환원된 뒤 JS 파서에 넘어가므로 효과가 없다.**
브라우저에서 `getAttribute('onclick')` 원문까지 회수해 실측했다.

| 입력값 | `_esc()` 출력 | 속성 원문(파서 통과 후) | 클릭 결과 |
|---|---|---|---|
| `o'brien@corp.com` | `o&#39;brien@corp.com` | `window.__got='o'brien@corp.com'` | **SyntaxError: Unexpected identifier 'brien'** — 핸들러 미실행 |
| `back\slash` | `back&#92;slash` | `window.__got='back\slash'` | 오류는 없으나 값이 **`backslash`로 손상**(`\s` → `s`) |
| `quote"dq` / `` tick`bt `` / `lt<gt>` / `amp&amp` | 정상 | 정상 | **정상 통과** |

실제 렌더 경로로도 재현했다. `renderEmployeeTable([{id:"o'brien", …}])` →
생성된 속성 원문 `deleteEmployee('o'brien')` → 삭제 버튼 클릭 시
**`SyntaxError: missing ) after argument list`, `deleteEmployee`는 호출되지 않음**(스텁 미도달).

**회귀는 아니다.** 변경 전 `_esc()`(`&`/`"`/`<`만 치환)에서도 동일하게 깨졌으며, 두 버전의 최종 JS 소스가
문자 단위로 같다. 즉 이번 변경은 이 경로에서 **개선도 악화도 없는 무효 변경**이고, 주석이 사실과 다르다.

- 재현 조작: 설정 화면에서 사번/수신인에 `'`가 포함된 값을 등록한 뒤 그 행의 삭제 버튼 클릭
- 영향 범위: `onclick="f('${_esc(v)}')"` 형태 12곳 — `deleteEmployee`(`app.js:3258`),
  `selectDepartment`/`toggleDeptSelect`(`app.js:2642,2645`), `selectDeptDashDept`/`Team`(`app.js:2786,2855`),
  `openWelderDetail`(`app.js:2171`), `openRecurringFromWelderTab`(`app.js:2211,2334`), `openRecurringModal`(`app.js:3009`)
- **현재 실데이터에서는 발현하지 않는다** — 부서명/팀명/용접사번/사번에 `'`·`\`가 없음을 5,374건 전수에서 확인.
  발현 가능한 유일한 실입력은 수신인 이메일이다.
- 근본 해결은 인라인 `onclick` 문자열 보간을 버리고 `data-*` 속성 + 이벤트 위임으로 옮기는 것이다.
  (**보고만 하고 수정하지 않았다.**)

### 오류 3 (LOW · **회귀 아님, 기존 문제**) — 숨겨진 화면에서 차트를 다시 그리면 `IndexSizeError`

```
IndexSizeError: Failed to execute 'arc' on 'CanvasRenderingContext2D':
The radius provided (-26) is negative.
    at drawDonutChart (http://127.0.0.1:8001/static/js/app.js:863:9)
```

- 발생 화면: 대시보드(또는 부서별 대시보드)가 **`display:none`인 동안** `renderDashboard()`가 호출될 때
- 재현 조작: `setView('welders')` 로 다른 화면에 있는 상태에서 `renderDashboard(S.result)` 실행
  → 실측 `dash-content.clientWidth = 0`, `donut-chart` 부모 폭 `0`
- 계산: `W = parent.clientWidth - 32 = -32` → `R = min(W,160)/2 - 10 = -26` → `ctx.arc(..., R, ...)`가 음수 반경
- 의심 코드 위치: `frontend/static/js/app.js:830` (`const W = cvs.parentElement.clientWidth - 32;`),
  터지는 지점 `app.js:862-863`
- **이번 변경과 무관하다** — `drawDonutChart()` / `showResult()` / `_redrawVisibleCharts()`는 이번 diff에 포함되지 않았다(diff hunk 확인).
- 보이는 상태에서는 정상(`parent.clientWidth = 505`, 재렌더 무오류). 테마 전환 2회 · resize 2회
  (대시보드/부서별 대시보드 각각)로도 오류 0건 — `_redrawVisibleCharts()`가 `S.view`로 가드하고 있다.
- 실사용 도달 경로: 사용자가 다른 화면에 있는 동안 검증이 완료되면
  `pollStatus()` → `showResult()` → `renderDashboard()`가 숨겨진 컨테이너에 대해 실행된다(`app.js:166-171`, `app.js:413`).
  영향은 그 1회의 차트 그리기가 중단되는 것뿐이며, 대시보드로 돌아가면 `setView()`가 다시 그려 화면은 정상 복구된다.

### 오류 4 (LOW · **회귀 아님, 기존 문제**) — `Esc`가 에이전트 모달을 닫지 않는다

`agent-modal`이 열린 상태에서 `Escape` → `display: flex` 유지. 배경 클릭과 ✕/`closeAgentModal()`은 정상 동작한다.

- 의심 코드 위치: `frontend/static/js/app.js:3395-3400` — `keydown` 핸들러의 `Escape` 분기가 `detail-modal`만 확인하고 `return` 한다
- 이번 diff에 이 핸들러는 포함되지 않았다. 에이전트 탭이 도입된 26db067 시점부터의 갭이며, 콘솔 오류가 아니라 직전 회차에서 잡히지 않았다.

### 오류가 아님으로 확인한 것 (거짓 양성 방지 기록)

- **부팅 시 `net::ERR_ABORTED`(type: Media) 4건** — 배경 영상 2개(`_DS_14.mp4`, `_DS_14_reversed.mp4`)의
  range 요청이 `video.pause()`로 중단된 것. 두 `<video>` 모두 `readyState = 4`, `error = null`. 정상이다.
- **부팅 첫 요청의 `/api/result` 401 2건** — `localStorage`에 사번을 넣기 전의 최초 네비게이션에서 발생.
  지시서에 명시된 정상 동작이며, 사번 주입 후 리로드에서는 200.
- **`favicon.ico` 404** — 리소스 미제공. 기능 영향 없음.
- **에이전트 리포트 모달의 `&#39;`/`&amp;` 등** — 이전 `javascript-pro` 리포트 본문이 `_esc` 소스코드를
  코드블록으로 인용한 것. `<pre>` 안에 정상 렌더된 문서 내용이며 이스케이프 버그가 아니다(문맥 40자 회수해 확인).

---

## 정리

- 생성한 `_test_*.html`: **없음.** 문서 §2의 임시 사본 대신 CDP로 페이지 네비게이션 이전에
  `Runtime`/`Log`/`Network` 도메인을 attach 해 부팅 시점 오류까지 직접 회수했다
  (`--dump-dom` 스냅샷보다 중간 정지 여부를 구분할 수 있어 §2 표의 "8개 화면 전체 순회" 요건에 부합).
  `find frontend -name "_test_*"` → 0건으로 재확인.
- 임시 산출물(CDP 드라이버, 단계 정의, 결과 JSON, Edge 프로필)은 전부 세션 스크래치패드에만 두었고
  저장소에는 남기지 않았다. 헤드리스 Edge 프로세스 종료 완료.
- **코드는 한 줄도 수정하지 않았다.** 검사 전후 `git status` 동일:
  `M backend/main.py`, `M backend/routers/agents.py`, `M backend/routers/auth.py`,
  `M backend/routers/verify.py`, `M frontend/static/js/app.js`, `?? tests/test_agents_router.py`.
- 검사 종료 후 app.js md5 재확인 — 디스크/서버 모두 `59473dae049b519d92072375252eef8f` 유지.
