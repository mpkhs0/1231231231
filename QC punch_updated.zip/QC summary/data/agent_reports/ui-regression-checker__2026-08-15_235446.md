---
agent: ui-regression-checker
run_at: 2026-08-15 23:54:46
verdict: FAIL
summary: 14개 화면 전부 콘솔 오류 0건이나, 판정 항목 식별자가 문자열이 된 뒤 «숫자 vs 문자열» 비교가 어긋나 5곳이 조용히 죽었다 — 프로젝트 세팅 토글·고치기, Check 14 그룹 뷰, 반복 패턴 모달, 상세 모달 강조
---

## 판정: FAIL

콘솔 오류는 **0건**이다. 그래서 더 나쁘다 — 아래 결함은 전부 **예외도 경고도 없이**
동작만 사라진다. 새로 생긴 `_ckSort` / `_ckLabel` / `_ckCategory` 자체는 정상이고,
비지도학습·지도학습 토글과 CSS 수정은 **전부 의도대로 동작한다.**

### 실행 조건

| 항목 | 값 |
|---|---|
| 서버 | 샌드박스 `http://127.0.0.1:8012` (PID 10604, `QC_PROJECT=SANDBOX`) |
| 결과 | TRION FPU · 전체 9,995행 · 판정 대상 5,516 · 플래그 4,321 |
| app.js md5 | 디스크 `1e23c619678de3029ff6877ef8a84830` = 서버 응답 **일치** |
| index.html / style.css md5 | `287e78b1…` / `7fe0b7d0…` — 검사 전후 동일(수정 없음) |
| `node --check app.js` | **통과** (node v24.16.0) |
| 브라우저 | Edge Headless 151.0.4129.86 · **CDP 실시간 구동**(`--remote-debugging-port`) |
| 오류 수집 | `Runtime.exceptionThrown` · `Runtime.consoleAPICalled(error/warning)` · `Log.entryAdded` · `Network.responseReceived(>=400)` — 프로토콜 레벨 |
| 쓰기 호출 | **없음.** `/api/verify` · `POST /api/rules` 미호출. 실서버(8001/8002) 미접속 |

`--virtual-time-budget` / `--screenshot`은 쓰지 않았다. 판단 근거는 전부 실시간 DOM 값과
런타임 상태 값이다.

### 화면별 결과

| 뷰 | 렌더 | 콘솔오류 | 상호작용 | 비고 |
|---|---|---|---|---|
| `view-upload` | OK | 0 | OK | 업로드 슬롯 3(qmg·welder·wps), 검증 버튼 활성, 판정 기준 select 2개 |
| `view-dashboard` | OK | 0 | **일부 FAIL** | KPI 4 · Check 카드 29 · 주요지표 5 · 캔버스 3개 실픽셀. 1C 토글·체크박스 토글·드릴다운 정상. **Check 101~105 배지가 「공통」(§F)** |
| `view-results` | OK | 0 | OK | 50행/4,321 · 페이지 3 이동 · ↑↓ 이동 · `/` 포커스 · Esc 후 페이지·선택 보존 · 모달 원본 위/코멘트 아래 |
| `view-departments` | OK | 0 | **일부 FAIL** | 부서 7 · 결함 50행 · 반복 패턴 표 렌더. **반복 패턴 행 클릭이 무반응(§D)** |
| `view-dept-dashboard` | OK | 0 | **일부 FAIL** | 부서 7 → 팀 6 드릴다운 · Check 토글이 팀 전환에도 유지 · 메인과 독립(28 vs 29) · 1C 토글 청록. **배지 「공통」(§F)** |
| `view-welders` | OK | 0 | **일부 FAIL** | KPI 4 · 칩 5 · 146명 · 상세 팝업 · **월별 추이 `wd-trend` ink 25,879로 실제 그려짐**. **반복 패턴 행 클릭 무반응(§D)** |
| `view-review` | OK | 0 | OK | §11 항목 12 · `rv-mark rv-m-done` 배지 · 필터 5(12→1) · 「답변 수정」 클릭 시 textarea 2 + 저장 버튼 |
| `view-agents` | OK | 0 | OK | 전용 2 · 서브 3 · 이력 21행. 카드→정의 모달(`pre` 12), 이력→리포트 모달(`table` 5 · `h*` 7). `agent-modal`이 `detail-modal`과 분리 |
| `view-ml-unsup` | OK | 0 | **OK** | 아래 §2 전항목 합격 |
| `view-ml-sup` | OK | 0 | **OK** | 아래 §3 전항목 합격 |
| `view-exports` | OK | 0 | OK | 범위 31행(전체1+부서7+팀23) · 칩 3(31/8/23) · 생성 버튼 31 · 1C 토글 시 5,516→374 |
| `view-settings` | OK | 0 | OK | 사번 1 · 부서 수신인 select 7 · 팀 수신인 표 2행 · Outlook 카드 |
| `view-rules` | OK | 0 | **FAIL** | 카드 31(적용 29·제외 2) · 프로파일 select 2 · 두께 규칙 폼 5칸. **토글 무효(§B) · 고치기 무효(§C) · 정렬 사전순(§G)** |
| `view-logic` | OK | 0 | OK | Mermaid 3종 SVG · 설명 16문단 · 렌더 실패 0. 정본 문서 탭 목차 76 · 본문 282KB · `<table>` 60 · `<pre>` 37 |

미검사 항목 없음. 14개 전부 실제로 열고 조작했다.

---

### 이번에 바뀐 것 — 항목별 확인

#### 1. 식별자 문자열화 (`_ckSort` / `_ckLabel` / `_ckCategory`)

세 헬퍼 **자체는 정상**이다(실측):

```
_ckSort   ['27','3','101','TRION1','RUYA2','1','TRION10']
       -> ['1','3','27','101','RUYA2','TRION1','TRION10']
_ckLabel  '3'->'3'  '101'->'101'  'TRION1'->'TRION 1'  'RUYA12'->'RUYA 12'
_ckCategory  'TRION1'->'프로젝트'   '8'->'프로젝트'   '3'->'공통'
```

정렬이 올바른 곳: 대시보드 Check 카드(1,2,3,…,27,101~105) · 부서별 대시보드 ·
Check 목록 모달 select(3,4,6,11,12,13,14,17,19,21,23,24,26) · 상세 결과 `ck-filter`.
**틀린 곳: 프로젝트 세팅 탭(§G).** 배지가 틀린 곳: 대시보드·부서별 대시보드(§F).

#### 2. 비지도학습 1C 토글 — 전항목 합격

| 확인 | 제외(기본) | 포함 |
|---|---|---|
| `MLU.excludeTemp` / 버튼 class | `true` / `tool-btn on` | `false` / `tool-btn` |
| 버튼 색 | `rgb(0,128,127)` 청록 | 회색 |
| `#mlu-bar-sub` | `Check 13 · 1C 제외 학습 대상 374행 중 4건` | `Check 13 · 학습 대상 5,516행 중 81건` |
| KPI 학습 대상 / 이상치 | **374 / 4** | **5,516 / 81** (기대값 일치) |
| 투영 설명력 | 95% | 88% |
| 산점도 ink / 히스토그램 ink | 4,898 / 33,005 | 14,590 / 105,600 (실제로 다시 그려짐) |
| 목록 | 4행 (`MLU.rows`=4) | 50행 표시 / `MLU.rows`=81 |
| `#mlu-model` | 「1C를 학습에서 뺀 결과입니다 … Check 13 결함 건수와 다릅니다」 | 「1C를 포함해 학습한 결과입니다 — 참고용」 |
| `#badge-ml-unsup` | **81** | **81** (토글을 따라 움직이지 않음 — 요구대로 고정) |
| 행 선택 | 행 418 · 이탈도 막대 9 · 동종그룹 3행 | 행 4614(1C 행) · 이탈도 · 동종그룹 3행 |

토글 시 `#mlu-detail`이 닫히는 것도 확인(선택이 다른 모집단으로 넘어가지 않는다).

#### 3. 지도학습 1C 토글 — 전항목 합격

| | 제외(기본) | 포함 |
|---|---|---|
| 결함확정 (이번 회차 / 기록 전체) | 0 / 0 | 875 / 691 |
| 오탐 | 0 / 23 | 18 / 878 |
| 하단 문구 | 「1C를 뺀 기준에서는 대조되는 라벨이 거의 없습니다 … 본 작업(비1C) 행의 검토가 쌓이는 것이 먼저입니다」 | 「그 판정을 낳은 규칙을 이미 고쳐서 … 검증 이력 보관이 먼저입니다」 |
| 꼬리말 | `(1C 제외 기준)` | `(1C 포함 기준)` |

기준별로 **다른 이유**가 나가는 것까지 확인했다. 안내 화면 구성(① 오탐 예측 · ② 품질 예측
카드 2 + 시작 조건 3)도 그대로 있다.

#### 4. CSS `.tool-btn`

스타일시트를 훑어 실제 규칙을 확인했다 — **`.tool-btn.on`은 이제 한 번만 정의된다.**

```
.tool-btn.on           {background: var(--ck-teal-bg); border-color: var(--ck-teal); color: var(--ck-teal); …}
.tool-btn.on .temp-dot {background: var(--ck-teal);}
.tool-btn:disabled     {opacity: 0.55; cursor: not-allowed;}
```

토글이 있는 **다섯 자리 모두** 켜짐 상태가 실제로 청록으로 계산된다
(`background-color: rgba(0,128,127,0.09)` · `color: rgb(0,128,127)` · `border-color: rgb(0,128,127)`):
`#dash-temp-btn` · `#deptdash-temp-btn` · `#ex-temp-btn` · `#mlu-temp-btn` · `#mls-temp-btn`.

`:disabled`도 적용 확인(`opacity 0.55` · `cursor not-allowed`). 다만 이번 데이터에는
1C가 있어 `#mlu-temp-btn`이 실제로 비활성이 되는 경우는 재현되지 않았다 —
속성을 직접 걸어 계산값으로만 확인했다.

---

### 발견된 오류

원인이 하나다: **`/api/flags` · `/api/rules` · `recurring_patterns`의 `check_no`가 이제
문자열(`'14'` · `'101'` · `'6'`)인데, 인라인 핸들러는 숫자를 넘기고 비교는 `===`다.**
`'14' === 14`은 false이므로 조용히 «없는 것»이 된다.

#### A. Check 14 그룹 뷰가 통째로 렌더되지 않는다

- **화면**: 상세 결과 → `ck-filter`=Check 14 → 행 클릭
- **실측**: `#c14-group-slot`은 존재하나 `innerHTML.length = 0`,
  `.c14-gtbl` 0개, `.c14-gtitle` 0개. 도면번호 표시·중복 조인트 그룹핑·형제행 대조표가 전부 없다.
  모달은 「원본 데이터」 한 표(6,753자)뿐.
- **의심 코드**: `frontend/static/js/app.js:2265`
  `const f14 = (rowFlags || []).find(f => f.check_no === 14);`
  (같은 문제: `app.js:2289`, `app.js:2293` — `f.check_no === 14`)
- 서버 응답 실측: `GET /api/flags?check=14` → `"check_no": "14"` (문자열)
- 오류 없음. `_fillC14Slot`이 `if (!f14) return;`으로 조용히 빠져나간다.

#### B. 프로젝트 세팅 — 판정 항목 체크박스가 상태를 바꾸지 않는다 (가장 위험)

- **화면**: 프로젝트 세팅 → 아무 항목의 체크박스 클릭
- **실측**: 체크박스는 **시각적으로 꺼지지만**(`checked = false`)
  `RL.items[0].enabled`는 `true` 그대로, `RL.dirty`도 `false` 그대로.
  저장해도 아무것도 안 꺼진다. 화면은 꺼진 것처럼 보인다.
- **직접 증명**:
  ```
  toggleRule(1,   false) -> enabled 여전히 true
  toggleRule('1', false) -> enabled false      (문자열이면 동작)
  ```
- **의심 코드**: 생성부 `app.js:835`
  `' onchange="toggleRule(' + i.check_no + ', this.checked)"'`
  → 실제 DOM `onchange="toggleRule(1, this.checked)"`
  수신부 `app.js:866` `RL.items.find(x => x.check_no === no)` (`x.check_no`는 문자열 `'1'`)
- 오류 없음.

#### C. 프로젝트 세팅 — 「고치기」 버튼이 아무 일도 하지 않는다

- **화면**: 프로젝트 세팅 → 프로젝트 규칙(101~105)의 「고치기」
- **실측**: 실제 DOM은 `onclick="editCheckRule(101)"`.
  ```
  editCheckRule(101)   -> #ck-name 값 ''    (아무 일도 안 일어남)
  editCheckRule('101') -> #ck-name 값 '재질 KT-40/KT40 두께 허용범위'
  ```
- **의심 코드**: 생성부 `app.js:858`, 수신부 `app.js:722`
  `RL.items.find(x => x.check_no === no)`
- `deleteCheckRule`(`app.js:859`)은 `key`로 API를 부르므로 오늘은 동작한다 — 단 §E에 걸린다.

#### D. 반복 결함 패턴 모달이 열리지 않는다 (두 화면)

- **화면 1**: 부서별 결함 → 반복 결함 패턴 탭 → 행 클릭
  실제 DOM `onclick="openRecurringModal('5361', 6)"`
- **화면 2**: 용접사 관리 → 반복 패턴 표 → 행 클릭
  실제 DOM `onclick="openRecurringFromWelderTab('Q520-해양내업생산부','5361',6)"`
- **실측**: 두 경우 모두 `#detail-modal`이 `display:none` 그대로. 아무 반응 없다.
- **의심 코드**: 수신부 `app.js:2971`
  `.find(p => p.welder_no === welderNo && p.check_no === checkNo)` → `!pat`이면 `return`
  (`result.departments[*].recurring_patterns[*].check_no`는 문자열 `'6'`·`'26'`·`'14'` — API 실측)
  생성부 `app.js:3578`, `app.js:3702`, `app.js:4324`
- 오류 없음.

#### E. 식별자가 `TRION1` 꼴이 되면 인라인 핸들러가 ReferenceError로 죽는다 (잠복)

이번 샌드박스 데이터는 **옛 번호(101~105)** 라서 오늘은 터지지 않는다. 그러나
`project_checks.make_id()`가 새 규칙에 `TRIONFPU1` 같은 **비숫자** 식별자를 발급하므로,
**다음에 만드는 프로젝트 규칙부터 전부** 해당된다.

클라이언트 상태에 `no:'TRION1'` 규칙을 하나 넣고 실제로 그려 클릭해 재현했다
(서버 쓰기 없음). 생성된 HTML과 클릭 결과:

```html
onclick="goToCheckDetail(TRION1)"
onclick="event.stopPropagation(); toggleDashCheck(TRION1)"
```
```
Uncaught ReferenceError: TRION1 is not defined
    at HTMLSpanElement.onclick
Uncaught ReferenceError: TRION1 is not defined
    at HTMLDivElement.onclick
```

식별자를 따옴표 없이 인라인 핸들러에 박는 자리 **11곳**:

| 파일:행 | 생성되는 코드 |
|---|---|
| `app.js:835` | `toggleRule(` + check_no + `, this.checked)` |
| `app.js:858` | `editCheckRule(` + check_no + `)` |
| `app.js:859` | `deleteCheckRule('key',` + check_no + `)` |
| `app.js:1570` | `${onclickFn}(${c.no})` |
| `app.js:1621` | `goToCheckDetail(${c.no})` |
| `app.js:1624` | `toggleDashCheck(${c.no})` |
| `app.js:3578` | `openRecurringFromWelderTab('…','…',${p.check_no})` |
| `app.js:3702` | 동일 |
| `app.js:4237` | `goToCheckDetailScoped(${c.no})` |
| `app.js:4240` | `toggleDeptDashCheck(${c.no})` |
| `app.js:4324` | `openRecurringModal('…', ${rp.check_no})` |

`_ckSort`·`_ckLabel`·`_ckCategory`는 문자열을 제대로 다루는데 **핸들러 생성만 옛 가정에
남아 있다.** 위 §A~§D가 그 가정이 깨진 결과이고, §E는 같은 자리가 «조용한 무반응»에서
«콘솔 오류»로 바뀌는 지점이다.

#### F. 대시보드 Check 배지가 프로젝트 규칙을 「공통」으로 표시한다

- **화면**: 대시보드 · 부서별 대시보드 (Check 카드 101~105)
- **실측**: 카드 29장 중 「프로젝트」 배지는 Check 8·9 둘뿐.
  `CHECK 101` ~ `CHECK 105`는 전부 **「공통」**.
- **같은 서버의 다른 화면과 어긋난다**: `GET /api/rules`의 `items[].category`는
  101~105를 `'프로젝트'`로 주고, 프로젝트 세팅 탭도 「프로젝트」 그룹에 넣는다.
- **의심 코드**: `app.js:189-194`

```js
function _ckCategory(no) {
  if (!/^\d+$/.test(String(no))) return '프로젝트';   // 모양으로만 가른다
  return CHECK_CATEGORY[no] || '공통';                // '101' -> '공통'
}
```

  서버는 옛 번호 대역을 알고 있다 — `backend/services/project_checks.py:83` `is_common()`:
  `return not (LEGACY_ID_MIN <= int(cid) <= LEGACY_ID_MAX)` (101~199는 공통이 아니다).
- 새 식별자(`TRION1`)만 있는 서버에서는 드러나지 않지만, **옛 번호가 남아 있는
  데이터 폴더에서는 「무엇을 다시 정해야 하는지」가 화면에서 사라진다.**

#### G. 프로젝트 세팅 탭의 판정 항목 정렬이 사전순이다

- **실측 순서**(공통 그룹): `1, 10, 11, 12, 13, 14, 16, 17, 18, 19, 2, 20, 21, 22, 23, 24, 25, 26, 27, 3, 4, 5, 6, 7`
  (프로젝트 그룹): `101, 102, 103, 104, 105, 8, 9`
- 대시보드·Check 목록 모달은 `_ckSort`로 올바르게 정렬되므로 **같은 서버의 두 화면이
  다른 순서**를 보여준다.
- **의심 코드**: `app.js:809 _rlRender()` — `RL.items.filter(i => i.category === cat)`만 하고
  `_ckSort`를 부르지 않는다(`app.js:830 _rlCardHtml`). 서버 `/api/rules`의 `items`도 같은 사전순으로 온다.

---

### 재현하지 못한 것 / 관찰만

- **대시보드 1C 토글 1회 미반영**: 첫 시도(부팅 직후, 앞 화면 렌더가 끝나기 전)에서
  `toggleDashTemp()` 후 1.8초가 지나도 KPI가 5,516 그대로이고 버튼에 `on`이 붙지 않았다.
  **이후 4회 재시도 전부 정상**(374행 · 청록)이라 재현되지 않았다. `renderDashboard`의
  `_dashSeq` 가드는 코드상 올바르다. 부팅 중 겹친 렌더의 타이밍 아티팩트로 본다 —
  결함으로 올리지 않되 기록해 둔다.
- **부서별 대시보드에서 1C를 빼면 판정 대상 0**: 팀 `Q5J0-TRION공사부 › 361-(주)에스디기업`
  기준. 그 팀이 전량 1C면 정상이므로 결함으로 보지 않았다(판정 로직은 이 에이전트의 몫이 아니다).
- **0건 판정 항목은 Check 필터 select에 나오지 않는다**: `ck-filter`와 Check 목록 모달의
  select가 `stats`에서 만들어지므로 101~105(0건)는 고를 수 없다. 설계대로로 보이나,
  `openCheckListModal('101','','')`가 「전체 Check」로 조용히 떨어지는 것은 적어 둔다.

### 렌더링이 빈 채로 남은 자리

14개 뷰의 모든 `[id]` 요소를 훑어 «자식도 텍스트도 없는» 것을 뽑았다. 남은 것은 전부
**정상적으로 비어 있는** 메시지·툴팁·힌트 슬롯이다:

```
#wps-cache-status  #prog-bar                       (upload — 진행 전)
#dash-temp-btn-hint  #trend-tooltip                (dashboard — 토글 끔 / hover 전)
#deptdash-temp-btn-hint  #deptdash-trend-tooltip
#mlu-tooltip  #mlu-dev  #mlu-peer-tbody            (ml-unsup — 행 선택 전. 선택 시 채워짐 확인)
#ex-temp-btn-hint  #ex-selinfo
#settings-emp-error  #recipient-chips  #outlook-save-msg  #dr-msg  #tr-msg
#rl-msg  #rl-project-msg  #ck-msg  #rq-msg
```

내용이 있어야 하는데 비어 있는 자리는 **`#c14-group-slot` 하나**다(§A).

### 정리

- 검사용 `_test_*.html`을 **만들지 않았다** — CDP `Runtime.evaluate`로만 구동했다.
  `frontend/`에 파일 추가·수정 없음(`git status --porcelain frontend/`가 비어 있다).
- 검사 전후 `app.js` / `index.html` / `style.css` md5 동일. 서버 응답 md5도 동일.
- `/api/verify` · `POST /api/rules` **미호출**. 규칙 토글은 브라우저 메모리(`RL.items`)에서만
  건드렸고 저장하지 않았다. 사용자 실서버(8001/8002)에는 접속하지 않았다.
- 헤드리스 Edge 프로세스와 임시 프로필은 스크래치패드에만 있다.
