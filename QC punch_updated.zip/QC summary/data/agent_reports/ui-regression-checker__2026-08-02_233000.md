---
agent: ui-regression-checker
run_at: 2026-08-02 23:30:00
verdict: PASS
summary: 7개 화면 콘솔 오류 0건(2회 독립 재현). 용접사 탭 개편·Check 토글·모달 복귀·월별 추이 전부 정상.
---

## 판정: PASS

### 실행 조건
- 서버 PID 3416, 127.0.0.1:8000
- app.js / index.html md5 디스크 == 서버 응답 (새 파일 서빙 확인)
- node --check (v24.16.0) OK
- 헤드리스 Edge, 새 --user-data-dir 2개로 독립 2회 실행 — 두 번 모두 콘솔 오류 0건 재현
- 전역 함수 노출 점검: 28개 전역 누락 0개. CHECK_META.length === 14

### 화면별 결과

| 뷰 | 렌더 | 콘솔오류 | 상호작용 |
|---|---|---|---|
| view-upload | OK | 0 | OK |
| view-dashboard | OK | 0 | OK |
| view-results | OK | 0 | OK |
| view-departments | OK | 0 | OK |
| view-dept-dashboard | OK | 0 | OK |
| view-welders | OK | 0 | OK |
| view-settings | OK | 0 | OK |

### 상호작용 상세

**Check 카드 이중 동작** — 체크박스만 클릭: dashCheckSel 6 제외(13개), ck-off 부여,
KPI 결함행 3,664 → 2,181 재집계, detail-modal = none (토글이 드릴다운을 안 먹음).
카드 본문 클릭: 모달 flex, 목록 2,145건, dashCheckSel 불변 (드릴다운이 토글을 안 먹음).
부서별 대시보드: 팀 스코프 토글 → 부서 이동해도 선택 유지, 부서 KPI 3,170 → 1,761 연쇄 반영.

**모달 순서 / 목록 복귀** — raw-grid(idx 110) → fb-box(idx 5600), 원본이 위.
4페이지 + scrollTop 300에서 행 진입 후 복귀 시 페이지 4 / scrollTop 300 복원.
용접사 상세 팝업도 2페이지 / scrollTop 400 복원, 월별 차트 재페인트.

**Check 14 그룹 뷰** — 20개 그룹(58행) / 전체 383개 그룹(938행). 그룹 헤더에 도면번호 표시,
diff 배지 28개, 중복 그룹 비교표 정상.

**용접사 월별 추이** — 캔버스 1539x220 실제 픽셀 페인트. 추이 판정 배지 3개
("개선 17%p" / "악화 24%p" / "악화 12%p"), 미니 스파크 3개.

**키보드** — 방향키 행 이동, / 검색 포커스, Enter 상세, Esc 닫힘.
합성 이벤트(document.dispatchEvent)로 e.target.closest 회귀 케이스 재현 → 신규 오류 0건.

### 발견된 오류

JS 런타임 오류 0건. 2회 독립 실행 모두 window.__errs 비어 있음.

참고(오류 아님):
- 부서별 대시보드 "미작업 수량"이 모든 부서에서 0인 것은 미작업 4,475건이 전부
  (부서 미기재)에 몰려 있어서다. 데이터 특성이지 렌더 누락이 아니다.
- 메인 대시보드 토글(dashCheckSel)은 부서별 대시보드(deptDashCheckSel)로 전파되지 않는다.
  코드 주석상 의도된 분리.

### 정리
- 검사 사본 _test_probe.html 삭제 완료 (find 결과 0건)
- app.js / index.html md5 검사 전후 동일 → 코드 미수정 확인
