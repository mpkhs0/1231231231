---
agent: ui-regression-checker
run_at: 2026-08-03 14:14:00
verdict: FAIL
summary: 직전 지적 4건은 모두 실측으로 해소 확인(_jsq 10개 핸들러 전부 원문 왕복·주입 0건, Excel 401, Esc 분기, 차트 가드) — 다만 _jsq 전환에서 app.js:2666 toggleDeptSelect 한 곳이 누락돼 _esc()로 남아 있고, 부서명에 아포스트로피가 들어가면 체크박스가 죽고 주입이 실제로 실행된다.
---

## 판정: FAIL

직전 회차(`ui-regression-checker__2026-08-03_135207`) 지적 4건은 **전부 실측으로 해소를 확인**했다.
그러나 1번 수정(`_jsq()` 전환)에서 **동일 클래스의 인라인 핸들러 한 곳이 누락**되어, 새 결함 1건으로 FAIL.
8개 화면 순회·콘솔 오류·엔티티 노출·값 누락은 모두 이상 없음.

### 실행 조건

| 항목 | 값 |
|---|---|
| 서버 | `127.0.0.1:8001` LISTENING, PID **5076** |
| app.js md5 (로컬) | `eb2db78a7dfdc8bab5acc8605ae220ce` |
| app.js md5 (서버 응답) | `eb2db78a7dfdc8bab5acc8605ae220ce` → **일치** |
| index.html md5 | `4fec45fec528755b4812b55ae2a099b5` (로컬/서버 일치) |
| 백엔드 최신 여부 | `/api/result/excel` 200 응답에 `cache-control: no-store, no-cache, must-revalidate` 실제 포함 → 프로세스가 새 코드로 구동 중임을 확인 |
| `node --check` | **통과** (node v24.16.0) |
| 실행 방식 | §2에 따라 **CDP** (헤드리스 Edge 151, `--remote-debugging-port=9333`, 신규 `--user-data-dir`). `--virtual-time-budget` 미사용 |
| 로그인 | `POST /api/auth/login` 실제 통과, 사번 A551135 (`is_admin=1`), 프로필 유지로 이후 전 패스 재사용 |
| 검사 사본 | `frontend/static/_test_regress.html` (index.html + window.onerror/console.error 수집기 주입) |
| 총 11개 패스 | 부팅/로그인 → 8화면 순회 → Check카드·차트가드 → 모달·키보드 → 용접사·에이전트 → poison 값 3종 × 핸들러 11종 → Excel 캐시 → Esc 매트릭스·최종 스윕 |

### 화면별 결과

| 뷰 | 렌더 | 콘솔오류 | 상호작용 | 비고 |
|---|---|---|---|---|
| `view-upload` | OK | 0 | OK | `input[type=file]` 3개, `startVerify()` / `deleteWpsCache()` 버튼 정상 |
| `view-dashboard` | OK | 0 | OK | KPI 4, **Check 카드 14개**, 차트 3종 실제 픽셀 렌더 확인. 토글·드릴다운 둘 다 정상 |
| `view-results` | OK | 0 | OK | 50행/108페이지, `goPage()` 정상, 행 클릭 → 상세 모달 |
| `view-departments` | OK | 0 | OK | 부서 7개, 반복 결함 패턴 섹션 렌더, `openRecurringModal` → 타임라인+날짜칩 |
| `view-dept-dashboard` | OK | 0 | OK | 부서→팀 드릴다운, 독립 Check 토글이 집계에 반영·팀 전환 시 유지 |
| `view-welders` | OK | 0 | OK | KPI 4, 필터칩 5, 통합표 100행, 상세팝업 + **`wd-trend` 월별 추이 실제 렌더**(1462×220, 유효픽셀 250 샘플), 추이 배지("개선"/"악화") 표시 |
| `view-agents` | OK | 0 | OK | 카드 5(정의 수와 일치), 이력 7행, 정의 모달 `<pre>` 8개, 리포트 모달 `<table>` 4 / `<pre>` 2 / `<li>` 35 / heading 10 |
| `view-settings` | OK | 0 | OK | 사번 목록 1건, Outlook 수신인 0건(원본 상태) |

전 화면 최종 스윕: **엔티티 날것 노출 0건, `undefined`/`NaN`/`[object Object]` 0건, `window.__errs` 0건, CDP 콘솔 이벤트 0건.**
(테스트 중 관측된 401 로그는 아래 2번 항목을 일부러 재현하며 발생시킨 것으로, 의도된 거부다.)

---

## 직전 지적 4건 재검증

### 1. `_jsq()` 신설 및 인라인 onclick 전환 — **부분 해소 (1곳 누락)**

**단위 검증** — poison 값 3종을 `_jsq()`로 통과시킨 뒤 실제 DOM 속성으로 넣고 클릭:

| 입력값 | 생성된 속성 | 핸들러 컴파일 | 수신값 | 원문 왕복 |
|---|---|---|---|---|
| `O'Brien` | `f('O\'Brien')` | O | `O'Brien` | **일치** |
| `a\\b'c` | `f('a\\\\b\'c')` | O | `a\\b'c` | **일치** |
| `');window.__pwned=…;('` | `f('\');window.__pwned=…;(\'')` | O | 원문 그대로 | **일치**, 주입 실행 0건 |

**대조군(`_esc()`만 사용)**: 세 값 모두 `el.onclick === null` — 핸들러가 아예 컴파일되지 않음.
→ 직전 회차의 지적이 사실이었고, `_jsq()`가 그것을 정확히 막는다는 것을 실측으로 재확인.

**요청된 10개 핸들러 전부**를 poison 데이터로 렌더 → 클릭 → 인자 수신값 대조:

| 함수 | 속성 컴파일 | 원문 왕복 | 주입 |
|---|---|---|---|
| `deleteEmployee` | O | 3/3 일치 | 0 |
| `removeRecipient` | O | 3/3 일치 | 0 |
| `removeDeptRecipient` | O | 3/3 일치 | 0 |
| `selectDepartment` | O | 3/3 일치 | 0 |
| `selectDeptDashDept` | O | 3/3 일치 | 0 |
| `selectDeptDashTeam` | O | 3/3 일치 | 0 |
| `openWelderDetail` | O | 3/3 일치 | 0 |
| `openRecurringFromWelderTab` | O | 9/9 (부서·용접사 2인자 모두) 일치 | 0 |
| `openAgentDefinition` | O | 3/3 일치 | 0 |
| `openAgentReport` | O | 3/3 일치 | 0 |
| `setAgentFilter` | O | 3/3 일치 | 0 |

→ **요청된 항목은 전부 정상.** 검사 방식은 §4를 따라 스크린샷이 아니라 `getAttribute('onclick')` 원문 +
`el.onclick !== null`(컴파일 성공 여부) + 스텁 함수가 실제로 받은 인자값으로 판정했다.

**그러나 새 결함 발견 — 아래 "발견된 오류" 참고.**

### 2. `/api/result/excel` 캐시 우회 차단 — **해소**

브라우저에서 실제로 재현:

1. 로그인 상태에서 `downloadExcel()` → Blob 다운로드 성공(`QC_Result.xlsx`)
2. `localStorage.removeItem('qc_employee_id')` 후 동일 호출 → 다운로드 0건,
   `alert("결과 Excel을 받지 못했습니다 - 로그인이 필요합니다")` → **캐시 우회 없음**
3. 캐시 모드별 원시 fetch 매트릭스:

| 조건 | 상태 |
|---|---|
| 빈 사번 + `cache:'no-store'` | **401** |
| 빈 사번 + 기본 캐시 모드 | **401** |
| 빈 사번 + `cache:'force-cache'` | **401** |
| 헤더 자체 없음 | **401** |
| 유효 사번 | 200, `cache-control: no-store, no-cache, must-revalidate` |
| 미등록 사번 `ZZZ999` | **401** |

`force-cache`에서도 401이 나온다 = 서버 `no-store` 헤더로 캐시 엔트리 자체가 생기지 않는다.
프론트의 `cache:'no-store'`가 없더라도 막힌다는 뜻이라 이중으로 안전하다. 사번 복구 후 다운로드 재개도 확인.

### 3. `Esc`의 `agent-modal` 분기 — **해소, 간섭 없음**

| 상황 | Esc 후 `detail-modal` | Esc 후 `agent-modal` |
|---|---|---|
| detail만 열림 | none (닫힘) | none (그대로) |
| agent만 열림 | none (그대로) | none (닫힘) |
| 둘 다 열림 · Esc 1회 | **flex 유지** | none (닫힘) |
| 둘 다 열림 · Esc 2회 | none (닫힘) | none |

`app.js:3423-3427`의 "agent 먼저, 그다음 detail" 순서대로 동작하며 서로를 건드리지 않는다.
에이전트 정의 모달·리포트 모달 모두 Esc로 닫힌 뒤 상세 결과 모달이 정상 재사용된다.

### 4. 차트 3종 `if (W < 40) return;` 가드 — **해소, 영구 미렌더 없음**

- `setView('settings')`로 대시보드를 숨긴 뒤(`parentElement.clientWidth === 0`)
  `drawBarChart` / `drawDonutChart` / `drawTrendChart`를 **직접 호출** → 신규 오류 **0건**
  (이전엔 `IndexSizeError`: 음수 반경)
- 같은 상태에서 `_redrawVisibleCharts()` + `resize` 이벤트 → 신규 오류 **0건**
- `setView('dashboard')`로 복귀 → `setView()`가 `renderDashboard()`를 재호출하여 **3종 모두 실제로 그려짐**
  (canvas 픽셀 알파값 샘플링: bar 778×296/330샘플, donut 473×160/160샘플, trend 1299×200/154샘플,
  범례 텍스트도 정상). **가드 때문에 영영 안 그려지는 상황은 발생하지 않는다.**
- 부서별 대시보드 3종도 동일: 부서 미선택 시 300×150(미렌더) → 부서 클릭 후 실제 렌더,
  팀 드릴다운 후에도 재렌더 확인.

---

## 발견된 오류

### [FAIL-1] `toggleDeptSelect` 인라인 핸들러가 `_jsq()` 전환에서 누락됨

**의심 코드 위치**: `frontend/static/js/app.js:2666`

```js
onchange="toggleDeptSelect('${_esc(name)}', this.checked)">
```

바로 3줄 아래(`app.js:2669`)의 `selectDepartment('${_jsq(name)}')`는 전환되었으나,
**같은 부서명을 받는 이 `onchange`만 `_esc()`로 남아 있다.** `onclick`이 아니라 `onchange`라서
이번 전환 대상 13곳 집계에서 빠진 것으로 보인다.

**재현 조작**: 부서별 결함 화면에서 `S.result.departments`에 아포스트로피가 든 부서명을 넣고
`renderDepartments()` 실행 → 부서 칩의 체크박스 확인.

**실측 결과**:

| 부서명 | 생성된 onchange 속성 | 컴파일 | 결과 |
|---|---|---|---|
| `O'Brien` | `toggleDeptSelect('O'Brien', this.checked)` | **실패(null)** | 체크박스가 **아무 동작도 안 함** |
| `a\\b'c` | `toggleDeptSelect('a\\b'c', this.checked)` | **실패(null)** | 동일 |
| `');window.__pwned=…;('` | `toggleDeptSelect('');window.__pwned=…;('', this.checked)` | 성공 | **주입 코드가 실제로 실행됨** (`window.__pwned` 0→1) |

**오류 메시지 원문** (속성 읽기 시도 시):
```
SyntaxError: Failed to read the 'onchange' property from 'HTMLElement': missing ) after argument list
```

**영향**: 부서 선택 체크박스는 "선택 부서 발송"(Outlook 메일 발송 대상 지정)의 입력이다.
부서명은 Excel BF열에서 그대로 오므로, 스프레드시트에 아포스트로피가 든 부서명이 한 번 들어오면
(a) 그 부서를 발송 대상으로 고를 수 없고 — **콘솔에도 오류가 남지 않아 조용히 죽는다**,
(b) 스프레드시트 내용으로 임의 JS가 실행된다.
현재 실데이터 부서명 7개에는 아포스트로피가 없어 아직 발현하지 않았다.

**수정 제안**(코드 수정은 하지 않음): `_esc(name)` → `_jsq(name)`.

### [관찰-1] 이스케이프 없이 값을 넣는 인라인 핸들러 4곳 (현재는 안전)

전수 조사 결과 아래 4곳은 `_esc`/`_jsq` 없이 값을 직접 보간한다.

| 위치 | 코드 | 값의 출처 | 판단 |
|---|---|---|---|
| `app.js:924` | `chipClick(this,'${x.v}')` | `''` 또는 `String(c.no)` (상수/숫자) | 안전 |
| `app.js:1436` | `_mckChipClick(this,'${x.v}')` | 동일 | 안전 |
| `app.js:2139` | `setWelderFilter('${x.v}')` | `WELDER_FILTERS` 상수 | 안전 |
| `app.js:1781` | `_rcpSetDate('${x.v}')` | **`c.date` — Excel 유래 데이터** | 날짜 문자열이라 현재는 무해하나, 유일하게 데이터 유래 |

FAIL 사유는 아니며, `_rcpSetDate`만 방어적으로 `_jsq()`를 걸어두면 이 클래스가 완전히 닫힌다.

### [관찰-2] 대시보드 Check 토글은 부서 화면으로 연쇄되지 않는다 (설계대로)

메인 대시보드에서 Check 14를 해제하면 대시보드 KPI는 3,664 → 3,405로 바뀌지만
부서별 결함/부서별 대시보드/용접사 화면 수치는 변하지 않는다.
`app.js:2892-2901` 주석대로 부서별 대시보드는 `S.deptDashCheckSel`이라는 **독립 상태**를 쓰도록
의도된 것이며, 그쪽 자체 토글은 정상 연쇄한다:

- 부서(Q520) 결함 행 3,170 → Check 14 해제 → **2,919** (28.3% → 34.0%)
- 그 상태로 팀(5C1-해양서일) 드릴다운 → 결함 639, "13/14개 선택됨" **유지**
- 다시 켜면 팀 스코프에서 780으로 **복원**
- 카드 본문 클릭은 `goToCheckDetailScoped(5)` → 제목 "Check 5 · 특수규칙 P+G01 · Q520-해양내업생산부 › 5C1-해양서일"

즉 회귀가 아니라 명시된 설계다. 다만 §3의 "부서 → 팀까지 연쇄" 기대와 문구가 어긋나므로 기록해 둔다.

---

## 그 밖에 확인한 §3 상호작용 항목

- **Check 카드 두 동작 분리**: 체크박스만 클릭 → `aria-pressed` true→false, `ck-off` 부여, 뷰 유지, KPI 재계산.
  카드 본문 클릭 → `openCheckListModal()` 팝업(50행). 서로 잡아먹지 않음. 재클릭으로 14/14 복원.
- **상세 결과 모달 순서**: `원본 데이터 (엑셀 원문)`(인덱스 12) → `기준값 / 실측값 비교 및 검토`(512),
  `<textarea>` 코멘트 입력은 아래쪽. **원본이 위, 코멘트가 아래** 확인.
- **"‹ 목록으로 돌아가기" 상태 보존**: Check 목록 팝업에서 body를 `scrollTop=250`으로 두고 행 클릭 →
  상세 진입(`S.mck.scrollTop=250` 저장) → 돌아가기 → **page 1 유지, scrollTop 250 복원, 동일 첫 행** 확인.
- **Check 14 그룹 뷰**: 행 2142 상세에서 `중복 등록 그룹 비교 — 같은 도면·Joint No로 등록된 행들입니다`
  섹션 렌더, `도면번호 A열 1C-CD110-210-10` 표시, `Joint S03B001 2행 중복 두께 20 vs 25`로 그룹핑,
  표에 재질/두께/WPS 열 분할. 엔티티 노출 0, undefined 0.
- **용접사 월별 추이**: `wd-trend` 1462×220 실제 픽셀 렌더 + "개선"/"악화" 추이 배지 텍스트 확인.
- **에이전트 마크다운**: `_mdToHtml()` 결과가 실제 `<table>` 4개 / `<pre>` 2개 / `<li>` 35개 / heading 10개.
  (리포트 본문에서 `&amp;#39;` 패턴 11건이 검출되나, 이는 직전 리포트가 `&#39;`라는 **문자열 자체를
  본문에 인용**하고 있어서 올바르게 이중 이스케이프된 것 — 결함 아님.)
- **키보드**: `↓↓↓`/`↑` 행 이동 + `is-selected` 반영, `Enter` → 선택 행 상세 모달,
  `Esc` 닫힘, `/` → `input.f-inp#txt-filter` 포커스. `e.target.closest is not a function` 재발 없음
  (`_closest()` 헬퍼 경유 확인, `app.js:3405/3449/3472/3481`).

## 부작용 / 원복

**서버에 저장을 유발하는 조작은 하지 않았다.** 설정 화면 검증은 요청대로 DOM 레벨로만 수행했다 —
`renderEmployeeTable()` / `renderRecipientChips()` / `renderDeptRecipientChips()`를 poison 배열로
직접 호출하고, `deleteEmployee`·`removeRecipient`·`removeDeptRecipient`는 인자만 기록하는 스텁으로
교체했다. 부서/용접사/에이전트 데이터도 `S.result` 사본을 메모리에서만 바꾼 뒤 원본으로 되돌렸다.

검사 종료 후 서버 상태 재확인 — **모두 검사 전과 동일**:

```
/api/settings/employees   → {"employees":[{"id":"A551135","admin":true}]}
/api/settings/outlook     → {"enabled":false,"recipients":[]}
/api/settings/dept-recipients → {}
```

## 정리

- 생성한 `frontend/static/_test_regress.html` **삭제 완료** (`git status`에 미추적 파일로 남지 않음 확인).
- 헤드리스 Edge 프로세스 종료 완료. 임시 프로필은 스크래치패드에만 존재.
- **코드는 수정하지 않았다.** `git status`의 변경 파일(`backend/main.py`, `backend/routers/agents.py`,
  `backend/routers/auth.py`, `backend/routers/verify.py`, `frontend/static/js/app.js`,
  `tests/test_agents_router.py`)은 모두 검사 시작 시점에 이미 있던 이번 회차 수정분이다.
