---
agent: ui-regression-checker
run_at: 2026-08-12 16:20:51
verdict: PARTIAL
summary: 14개 뷰 전부 콘솔 오류 0건 · 1C 토글/드릴다운/모달 모두 정상. 단 style.css가 정의되지 않은 토큰(--line/--panel/--border-2)을 폴백 없이 써서 에이전트·현업검증 카드의 테두리와 배경이 통째로 사라졌고, 세팅에서 끈 Check 5가 대시보드 KPI에는 그대로 남아 있다.
---

## 판정: PARTIAL

렌더·상호작용·콘솔 오류 면에서는 **회귀 없음**. 다만 «존재하지 않는 CSS 토큰» 결함 3종이
실제로 화면에 영향을 주고 있어 PASS로 적지 않는다. 오류가 나지 않는 종류의 결함이라
콘솔만 봐서는 잡히지 않는다.

### 실행 조건

| 항목 | 값 |
|---|---|
| 서버 | PID 20852 · 127.0.0.1:8001 · `/api/status` = done · has_result · excel ready |
| 프로세스 신선도 | 기동 2026-08-12 15:55:50 > 최신 backend/*.py mtime 15:55:29 → **백엔드 최신** |
| app.js md5 (로컬) | `14b17636542bc7e0a4d5287e0bb74987` |
| app.js md5 (서버 응답) | `14b17636542bc7e0a4d5287e0bb74987` → **일치** |
| 캐시 헤더 | `cache-control: no-cache, must-revalidate` 확인 |
| `node --check` | v24.16.0 · `frontend/static/js/app.js` **통과** |
| 브라우저 | Edge 151.0.4129.78 headless=new · **CDP 방식**(18MB payload 때문에 virtual-time-budget 미사용) |
| 로그인 | A551135(관리자) · `/api/auth/login` 통과 · localStorage 기록 확인 |
| 데이터 | 프로파일 **TRION FPU** · 판정 5,516 · 결함 3,215 · 총 플래그 4,171 · 미작업 4,475 (지시값과 일치) |

인라인 핸들러 정적 대조: `index.html`의 `onclick/onchange/oninput/onkeydown`에서 호출되는
전역 이름 **48종 전부** app.js에 정의되어 있다. 런타임에서도 24개를 `typeof window[n]`으로
확인해 전부 `function`. 새로 추가된 `previewCheckRule` · `saveCheckRule` ·
`clearCheckRuleForm` · `editCheckRule` · `deleteCheckRule` **모두 전역에 존재**한다.

### 화면별 결과

뷰는 13개가 아니라 **14개**다(`view-rules` 신설로 사이드바·`CRUMBS` 모두 14항목).
14개 전부 순회했고, 라이트/다크 **양쪽**에서 한 바퀴씩 돌았다.

| 뷰 | 렌더 | 콘솔오류 | 상호작용 | 비고 |
|---|---|---|---|---|
| view-upload | OK | 0 | 슬롯 3개 · 「검증 실행」「캐시 삭제」 | 업로드된 두 파일명 표시 확인. 실행 안 함 |
| view-dashboard | OK | 0 | 카드 본문 · 체크박스 · 1C 토글 **전부** | 아래 상세 |
| view-results | OK | 0 | 페이지네이션 · 행→모달 · 방향키 · `/` · Esc · C14 | 아래 상세 |
| view-departments | OK | 0 | 표 3개 · tbody 134행 | 반복 결함 패턴 섹션 포함 |
| view-dept-dashboard | OK | 0 | 부서→팀 드릴다운 · Check 토글 · 1C · 범위 모달 | 아래 상세 |
| view-welders | OK | 0 | KPI 4 · 칩 5 · 표 50행 · 상세 팝업 · 월별 추이 | 아래 상세 |
| view-logic | OK | 0 | 도식 탭 ↔ 문서 탭 왕복 | 아래 상세 |
| view-rules | OK | 0 | 미리보기 디바운스 · 「고치기」 · 「새로 작성」 | **저장·삭제·프로파일 전환 안 함** |
| view-ml-unsup | OK | 0 | 행 선택 → 이탈도 막대 9개 + peer 3행 | 산점도 nz=14,934 · 히스토그램 nz=106,426 |
| view-ml-sup | OK | 0 | — (안내 화면) | 「이번 회차 / 기록 전체」 두 열 정상 |
| view-exports | OK | 0 | 1C 토글 · 범위 필터칩 · 검색 · 부서 select | 31행(전체1+부서7+팀23). 생성·발송 안 함 |
| view-review | OK | 0 | 필터칩 5 · 「현업 답변 남기기」 → textarea 2개 | §11 항목 11건. 저장 안 함 |
| view-agents | OK | 0 | 카드→정의 모달 · 이력행→리포트 모달 | 아래 상세 |
| view-settings | OK | 0 | 사번 표 · 부서/팀 수신자 select 연동 | 관리자 1건 · 팀 수신인 2건 |

**콘솔 오류 총계: 0건.** `Runtime.exceptionThrown` · `console.error` ·
`Log.entryAdded(level=error)` 세 채널을 전부 수집했고, 부팅·뷰 전환·모든 상호작용
구간에서 0건이었다. 다크 모드 순회에서도 0건.

### 상세 확인 결과

**대시보드**
- Check 카드 **17장**. 세팅에서 끈 **Check 5·7이 카드에서 사라져 있다**
  (`data/project_rules.json`의 `enabled`에서 `5`,`7`이 false인 것과 일치). 토글 박스도 17개.
- **카드 본문 클릭** → `detail-modal`이 「Check 3 · 두께 허용범위 초과 / 전체 790건」으로 열림.
- **체크박스만 클릭** → 모달이 열리지 않고 집계만 재구성. C6 제외 시 결함 3,215 → 1,629 ·
  클린 2,301 → 3,887(합 5,516 유지). 힌트 「16/17개 선택됨」. 「전체 선택으로」 버튼이
  나타나고 누르면 원복. **두 동작이 서로를 잡아먹지 않는다.**
- **1C 제외 토글**: 판정 대상 5,516 → **374**, 결함 26(7.0%), 클린 348(**93.0%**).
  CLAUDE.md의 정답값(348/374 = 93.0%)과 정확히 일치. KPI·도넛·Check 카드가 **전부**
  같은 분모를 쓴다(도넛 범례도 C12 22 · C13 26만 남는다). 다시 끄면 완전 원복.
- 도넛 범례가 걸린 Check 9종을 전부 적는다. 바/도넛/추이 캔버스 모두 실픽셀 확인.

**상세 결과**
- 모달 섹션 순서 = 「원본 데이터 (엑셀 원문)」 → 「기준값 / 실측값 비교 및 검토」. **원본이 위**.
- 2페이지에서 스크롤 600px 내린 뒤 행을 열고 닫았을 때 **page=2 · scroll=600 그대로 보존**.
- 방향키 → `TR.row-clickable.is-selected`로 포커스 이동. `/` → `#txt-filter` 포커스.
  Esc → 모달 닫힘. `e.target.closest is not a function` 계열 재발 없음(`_closest` 전역 확인).
- **Check 14 그룹 보기**: 모달에 「중복 등록 그룹 비교」 섹션이 뜨고 도면번호(`1C-CD110-210-10`)와
  NDT REPORT 번호(`SAVI04272`)까지 표시된다.
- 페이지 버튼은 `‹ 1 2 84 ›` 생략형이다. 「3」 버튼이 없는 것은 정상 동작이다.

**부서별 대시보드**
- 부서 7개 → 클릭 시 하위 팀 6개 노출 → 팀 클릭 시 `S.deptDashTeam` 갱신.
- **부서별 대시보드 안에서** 부서→팀으로 연쇄되는 것을 확인. 메인(`S.dashCheckSel`)과
  부서별(`S.deptDashCheckSel`)은 의도대로 **독립**이며, 부서별 힌트가
  「(부서/팀 전환 시에도 유지)」로 성격을 명시한다.
- Check 카드 드릴다운이 범위를 물고 간다: 「Check 3 · 두께 허용범위 초과 ·
  Q5J0-TRION공사부 › 361-(주)에스디기업 / 전체 4건」.
- 팀 범위에서 1C를 켜 **판정 대상 0행**이 되는 경계도 오류 없이 「…뺀 0행 기준입니다」로 표시.

**용접사 관리**
- KPI 4 · 필터칩 5(전체 146 / 반복 31 / 자격 미등록 43 / 표본 부족 39 / 결함 없음 51) ·
  통합 표 50행 · 반복 패턴 49행.
- 상세 팝업에 자격정보·검토현황·Check별 분포·반복 패턴·**월별 결함 건수**가 모두 있고,
  `wd-trend` 캔버스가 1462×220에 **nz=25,928 실픽셀**로 그려졌다. 추이 판정 배지도 실제로
  붙는다(`tv-good 개선 17%p`, `tv-bad 악화 18%p`). «그래프가 보이지 않던» 사고 재발 없음.

**검사 로직**
- Mermaid SVG **3장** 렌더. 간선 13 / 25 / 15 — **간선 없는 노드로 인한 레이아웃 폭주 없음**.
- `_lgFitSvg()`가 동작한다: 색 우선순위 도식의 viewBox 높이가 **102**(getBBox 78)로,
  과거 사고값 2,055에서 제대로 줄어 있다.
- `foreignObject` 129개 중 **내용이 잘린 것 0개**(scrollHeight > height 검사).
- 문서 탭: 목차 73항목 · 본문 59,410자 · `<table>` 55 · `<pre>` 35 · mermaid 3 ·
  **`<script>` 0개**(이스케이프 우선 처리 유지). 탭 왕복 후에도 도식 3장 유지.

**프로젝트 세팅(RL)**
- 프로파일 select에 `TRION FPU`(현재) / `RUYA FPU`. **전환하지 않았다.**
- 판정 항목 24개(공통/프로젝트 두 묶음) · 토글 24개 중 22개 켬 · 「판정 로직」 details 24개가
  실제 설명문을 담고 있다. 프로젝트 두께 규칙 5건(Check 101~105)에 「고치기/빼기」 버튼 10개.
- **미리보기(350ms 디바운스)가 실동작**한다. 저장 버튼은 누르지 않았다:
  - `ck-mat=SM355A` → 「지금 데이터에 2,084행 (3개 조합) — SM355A / TR-FC-F01 1,213 · …」
  - `+ ck-wps=G01` → 「799행 (1개 조합)」
  - `ck-mat=S355KL -40` → 「**0행** — 재질/WPS 표기가 실데이터와 다를 수 있습니다…」 경고 정상
- 「고치기」 클릭 → 폼에 `재질 KT-40/KT40 두께 허용범위 / 12~50 / KT-40, KT40, KL-40, KL40`,
  `ck-key=thk-mat-kt40`, 안내 「Check 101을 고치는 중입니다」. 「새로 작성」이 전부 비운다.
- `data/project_rules.json` 변경 없음(git status clean).

**에이전트**
- 전용 2 + 서브에이전트 3 = 카드 5장, 실행 이력 15행.
- 카드 클릭 → `agent-modal` 정의 원문(`<pre>` 11개). 이력 행 클릭 → 리포트 모달에
  `<table>` **8개** · 제목 14개 · `<script>` 0개. `_mdToHtml()`가 표를 실제 `<table>`로 낸다.
- 두 모달이 열려 있는 동안 `detail-modal`은 `display:none` — **간섭 없음**. Esc로 정상 종료.

**async 함수 await 누락 의심 지점 — 이번 실행에서는 재현되지 않았다**
- `_mckPopulateTeamFilter`: Check 목록 모달에서 부서를 `Q520-해양내업생산부`로 바꾸자
  팀 select가 8개 이상으로 **채워졌고** 목록도 649건으로 갱신됐다.
- `_dashAggregate`: Check 토글·1C 토글 모두 KPI/도넛/카드가 즉시 재집계됐다.
- 빈 표로 보였던 두 경우는 실제로 데이터가 0인 것이었다. 서버로 교차 확인:
  `210-판계팀`은 전체 플래그 644건이지만 `checks=3`으로는 `{"total":0}` — **화면이 맞다.**

---

## 발견된 오류

### [중] 정의되지 않은 CSS 토큰 — 카드 테두리·배경이 통째로 사라진다

`frontend/static/css/style.css`가 **어디에도 정의되지 않은** 커스텀 프로퍼티를 **폴백 없이**
쓴다. 이런 선언은 computed-value 단계에서 무효가 되어 `unset`으로 떨어지므로 `border`
단축 속성은 `border-style: none`이 되고 `background`는 투명이 된다.
**예외도 콘솔 경고도 나지 않는다.**

정의된 토큰 62개와 대조한 결과, 폴백 없이 쓰이는 미정의 토큰은 셋이다:

| 토큰 | 사용 위치 | 영향 |
|---|---|---|
| `--line` | `style.css:1331` `.ag-card` · `1373` `.ag-v-unknown` · `1384` · `1396` `.ag-md hr` · `1403` · `1440` `.rv-kpi-card` · `1453` `.rv-item` | 테두리 소실 |
| `--panel` | `style.css:1332` `.ag-card` · `1440` `.rv-kpi-card` · `1453` `.rv-item` | 배경 소실 |
| `--border-2` | `style.css:330` `.temp-dot` | 1C 토글 앞 점이 안 보임 |

런타임 computed style (라이트·다크 **양쪽 동일**):

```
.ag-card       border-top: 0px none   background: rgba(0, 0, 0, 0)   (요소 5개)
.rv-item       border-top: 0px none   background: rgba(0, 0, 0, 0)   (요소 11개)
.rv-kpi-card   border-top: 0px none   background: rgba(0, 0, 0, 0)   (요소 4개)
.temp-dot                             background: rgba(0, 0, 0, 0)   (9x9px, 3개)
```

- 재현: '에이전트' 탭 또는 '현업 검증사항' 탭을 열면 카드가 배경·테두리 없이 본문만 떠 있다.
- `--panel-2` · `--row-hover` · `--font-mono`도 미정의지만 **폴백이 있어** 무해하다.
  `--bg-1`은 이제 어디에서도 쓰이지 않는다(이미 정리된 것으로 보인다).
- 의심 원인: `.ag-*` / `.rv-*` 블록이 다른 이름 체계(`--line`/`--panel`)를 쓰는 곳에서 옮겨 온 뒤
  이 저장소 이름(`--border`/`--surface`)으로 바뀌지 않았다.

### [소] 세팅에서 끈 Check 5가 대시보드 KPI에는 그대로 남아 있다

Check 카드는 `_activeMeta()`를 거쳐 Check 5·7을 감추는데, 그 아래 「주요 KPI 지표」는
`renderKpiRec()`(`frontend/static/js/app.js:1486-1503`)가 항목을 **하드코딩**한다.

```js
{ lbl:'특수규칙 대상율 (P+G01)', val: _pct(r.stats['5']||0, total),
  sub: `Check 5 · TR-FC-G03 전환 필요`, c:'var(--ck-blue)' },
```

- 실제 화면: 「특수규칙 대상율 (P+G01) / **0.0%** / Check 5 · TR-FC-G03 전환 필요」
- 판정 자체를 하지 않는 항목이 0.0%로 표시되면 «검사했는데 0건»으로 읽힌다.
  Check 5는 rules 탭에서 「(폐지)」로 표기되므로 KPI만 옛말이 남은 상태다.
- 같은 함수가 Check 4·11·12도 하드코딩하므로, 그 항목을 끄면 같은 일이 생긴다.

### [소·잠재] `CHECK_META`에 동적 번호 101~199 자리가 없다

`app.js:64`의 `CHECK_META`는 1~20 고정 배열이고, 이를 101~199로 늘리는 코드 경로가 없다.

- **이번 회차에는 영향 없다**: 프로젝트 규칙 101~105가 정의돼 있지만 `S.result.stats`에
  101 이상 키가 **0개**라 화면에 나올 것이 없다(F03/G05 WPS와 S355KT 계열이 이번 물량에 없다).
- 배지 색은 무색이 되지 **않는다**. 결과 표는 `COLOR_TO_CLS[f.color] || 'p-blue'`로
  **서버가 준 색 이름**을 쓰고, 서버가 `_FILLS`에 있는 색만 허용하므로 색이 붙는다.
- 다만 플래그가 생기는 순간 **대시보드 Check 카드 · 도넛 범례 · `_checksParam()`의
  «전체 선택» 판정**에서 101~105가 통째로 빠진다. 예외는 나지 않고 «카드가 없는 검사»가 된다.

### [정보] index.html의 중복 문구 (실화면 영향 없음)

`frontend/index.html:259`의 정적 힌트에 `색상 = Excel 출력 색상 · 색상 = Excel 출력 색상`이
두 번 들어 있다. `renderCheckGrid()`가 `textContent`를 덮어쓰므로 결과가 있는 화면에서는
「17가지 검사 · 색상 = Excel 출력 색상 · …」로 정상 표시된다(런타임 확인).
결과가 없는 상태에서만 노출된다.

---

## 확인하지 않은 것 (정직하게)

- **파일 업로드 실행 / 검증 재실행** — 지시대로 누르지 않음.
- **범위별 Excel 생성 · 메일 발송** — 지시대로 누르지 않음(생성 1분, Outlook 초안).
- **규칙 저장(`saveCheckRule`) · 삭제(`deleteCheckRule`) · 프로파일 전환(`switchProject`) ·
  프로젝트 생성/삭제** — 판정 기준이 바뀌므로 호출하지 않음.
  `editCheckRule` · `clearCheckRuleForm` · `previewCheckRule`은 쓰기가 없어 확인함.
- **현업 답변 저장** — 폼 노출까지만 확인, 「문서에 기록」은 누르지 않음.
- 프로젝트 규칙 101~105가 **실제로 플래그를 낸 화면** — 이번 데이터에 대조 대상이 0행이라
  관측 불가. 위 [소·잠재] 항목은 코드 정적 근거로만 적었다.

## 정리

- 생성한 `_test_*.html` **없음**. 임시 사본 대신 CDP `Runtime.evaluate`로 검사했다.
- 저장소 변경 없음 — `git status` clean.
- 헤드리스 Edge 종료 완료. 스크래치패드 프로필 외 잔여물 없음.
- 판단 근거는 전부 CDP로 회수한 DOM 문자열과 런타임 상태값이다. 스크린샷은 쓰지 않았다.
