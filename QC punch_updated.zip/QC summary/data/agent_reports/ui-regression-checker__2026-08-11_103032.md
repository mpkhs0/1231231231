---
agent: ui-regression-checker
run_at: 2026-08-11 10:30:32
verdict: FAIL
summary: 13개 화면 전부 렌더 · 콘솔 오류 0건이지만, 부서별 대시보드에서 팀을 고른 뒤 Check 카드를 누르면 팀 필터가 조용히 풀려 부서 전체(166건→649건)가 나온다
---

## 판정: FAIL

콘솔 오류는 0건이고 13개 화면이 모두 렌더된다. 그러나 팝업이 «팀 범위»를 잃는
재현 가능한 결함을 실증했다. 오류가 나지 않고 제목은 팀을 그대로 적고 있어서
화면만 봐서는 알아챌 수 없다.

### 실행 조건

| 항목 | 값 |
|---|---|
| 서버 | PID 14556 · 0.0.0.0:8001 · 프로세스 시작 2026-08-11 09:46:34 |
| 백엔드 최신 파일 | backend/main.py 09:19:00 · backend/routers/diagrams.py 09:17:56 → 프로세스가 더 나중(낡은 프로세스 아님) |
| app.js md5 | 디스크 a7ad0950709ecd31d165bedefeb2c097 = 서버 응답 동일 |
| index.html md5 | 디스크 62c50bfd72bbb10f0eea787686e21fc6 = 서버 응답 동일 |
| Cache-Control | no-cache, must-revalidate (정적 파일) |
| node --check | app.js OK · vendor/mermaid.min.js OK (node v24.16.0) |
| 브라우저 | Edge 151.0.4129.72 --headless=new, 전용 --user-data-dir, 1600x1100 |
| 방식 | CDP(--remote-debugging-port) — 상주 모니터가 Runtime.exceptionThrown / consoleAPICalled / Log.entryAdded / Network 4xx를 전 구간 기록. --virtual-time-budget은 쓰지 않았다 |
| 로그인 | A551135 (관리자) · X-Employee-Id 헤더 방식 |
| 검증 결과 | 판정 5,516 · 결함 3,245 · 플래그 4,205 (요청서와 일치) |

모니터 자기검사(의도적 console.error + 404 + 미포착 예외)로 수집 경로가 살아 있음을 확인한 뒤
전 구간을 다시 훑었다. 앱이 낸 오류는 0건이다(브라우저가 낸 Canvas2D willReadFrequently
성능 경고 3건 제외 — 앱 코드와 무관).

### 화면별 결과

| 뷰 | 렌더 | 콘솔오류 | 상호작용 | 비고 |
|---|---|---|---|---|
| view-upload | OK | 0 | 파일 슬롯 3개(inp-qmg/inp-welder/inp-wps), 검증 실행 버튼 | 업로드·검증은 실행하지 않음 |
| view-dashboard | OK | 0 | KPI 4 · Check 카드 17/토글 17 · 카드 본문→팝업 · 체크박스→팝업 안 열림+재집계 · 리셋 · 1C 토글 | 캔버스 3장 실픽셀(bar 26,508 / donut 15,388 / trend 14,622) |
| view-results | OK | 0 | 표 50행 · 페이지네이션 · 행→모달 · 검색 · 부서/팀 필터 · Esc · 방향키 행이동 · / 포커스 | SAVI15003 → 36건(요구치 일치) |
| view-departments | OK | 0 | 부서 선택 · 서브탭 3개 · 반복패턴 행→팝업 | Q530-SMR/ITER생산부 122건 정상 표시(빈 표 아님) |
| view-dept-dashboard | OK | 0 | 부서→팀 드릴다운 · Check 토글(메인과 독립) · 1C 토글 · 카드→팝업 | 슬래시 부서 122건 정상 · 팝업 팀 범위 유실(아래 1번) |
| view-welders | OK | 0 | KPI 4 · 필터 칩 5 · 통합 표 146명 · 상세 팝업 · 월별 추이 캔버스 ink 21,889 + 「개선 17%p」 배지 | 반복패턴 표 49행 |
| view-logic (신규) | OK | 0 | 도식 3장 순차 렌더 · 소스 details 3 · 테마 전환 후 재렌더 · 연속 2회 전환 경합 없음 · 900px 축소 | 노드 52개 전부 잘림 0건(foreignObject vs scrollWidth/Height 대조) · 색 토큰 문제(아래 2번) |
| view-review | OK | 0 | 항목 11개 · 상태 배지 · 필터 칩 5(전체11/미결3/잠정3/완료5/반영대기0) · 답변 폼 열기→취소 | 저장은 하지 않음 |
| view-agents | OK | 0 | 정의 카드 5(전용2+벤더3) · 이력 12행 · 필터 칩 · 정의 모달 · 리포트 모달 | 마크다운 → 실제 table 9개 / pre 4개 · agent-modal과 detail-modal 간섭 없음 |
| view-ml-unsup | OK | 0 | KPI 4 · 산점도/히스토그램 실픽셀(14,463 / 101,899) · 이상치 표 50행 · 행 선택→이탈도 막대 + 비교 그룹 3행 | 행 선택 시 산점도 재렌더 확인(ink 14,463→14,502) |
| view-ml-sup | OK | 0 | 안내 카드 · 확인된 사실 표 3행 · 시작 조건 3개 | 정적 화면 |
| view-exports | OK | 0 | 범위 표 31행(전체1+부서7+팀23) · 칩 3 · 검색(SMR→2행) · 생성/내려받기 버튼 | 메일 발송 버튼은 미검증(아래 「확인 못 한 것」) |
| view-settings | OK | 0 | 사번 표 · Outlook 카드 · 부서별 수신인 · 팀별 수신인(tr-dept/tr-team/tr-new/tr-chips/tr-tbody 전부 존재) · 부서→팀 연쇄 정상 | 저장은 하지 않음 |

부가 정적 검사: index.html 인라인 핸들러 47개 + 렌더된 DOM 전체 핸들러 84개 + 모달 내부 8개의
전역 함수 이름이 전부 해결된다(미정의 0건). 페이지를 캐시 무시 재로드해도 부트 오류 0건이며
mermaid(전역)·setView·loadLogicDiagrams·_lgRender·selectRecipientTeamDept 등 신규 전역이
모두 노출된다 — 로드 순서(mermaid → app.js) 정상.

---

### 발견된 오류

#### 1. [FAIL] Check 목록 팝업이 «팀 범위»를 조용히 버린다 — app.js:1866-1867

증상 A — 부서별 대시보드에서 팀을 고른 뒤 Check 카드 클릭

```
조작: 부서별 대시보드 → Q520-해양내업생산부 → 팀 5C1-해양서일 → Check 3 카드 본문 클릭
제목: "Check 3 · 두께 허용범위 초과 · Q520-해양내업생산부 › 5C1-해양서일"
부제: "해당 팀으로 필터링된 결과입니다"
실제: 표시 중 50건 / 전체 649건        ← 부서 전체
참값: /api/flags?checks=3&dept=Q520...&team=5C1-해양서일 → total 166
      /api/flags?checks=3&dept=Q520...                  → total 649
팀 select 값: ""(전체 팀)   ·   S.mck.team: ""
```

두 번 열어도(팀 목록 캐시 후에도) 동일. 팀 select에 5C1-해양서일 옵션은 존재한다.
그 select를 사람이 직접 고르면 166건으로 바르게 좁혀진다.

증상 B — 팝업에서 팀을 직접 고른 뒤 행을 열고 「목록으로 돌아가기」

```
팀 직접 선택 → 166건  →  행 클릭(행 4544 상세)  →  '목록으로 돌아가기'
복귀 후: 팀 select ""  ·  전체 649건  ·  제목은 여전히 "... › 5C1-해양서일"
```

사용자가 스스로 건 필터가 복귀 한 번에 풀리고, 제목은 팀을 계속 주장한다. 페이지 번호는
보존되므로 같은 페이지 번호에 다른 행 집합이 놓인다.

원인

```js
// app.js:1866-1867
  _mckPopulateTeamFilter();                                   // ← async 함수, await 없음
  document.getElementById('mck-team-filter').value = team || '';
```

_mckPopulateTeamFilter()(app.js:1912)는 await _fetchTeams(deptVal)를 거쳐 마이크로태스크
이후에 teamSel.innerHTML을 채운다. 바로 다음 줄의 값 대입은 그 시점에 옵션이 하나도 없는
select에 하는 것이라 조용히 무시되고(value → ""), 이어서 동기로 호출되는
_mckFilter(false)(app.js:1880)가 team=""를 읽는다. _fetchTeams에 캐시가 있어도 await가
있는 한 순서는 같아서 항상 재현된다.

같은 파일의 상세 결과 탭 쪽(_populateTeamFilter, app.js:1256-1266)은 await 뒤에
`if (sorted.includes(cur)) teamSel.value = cur;`로 복원해 안전하다 — 팝업 쪽만 이 보호가 없다.
실제로 상세 결과 탭의 부서/팀 필터는 뷰를 나갔다 와도 1,165행으로 유지됨을 확인했다.

영향 범위: goToCheckDetailScoped()(부서별 대시보드 카드) · _mckReopen()(목록으로 돌아가기).
부서 단위 범위는 select 옵션이 동기 생성이라 정상이다(부서만 걸린 경우는 이상 없음).

#### 2. [중] 검사 로직 탭이 존재하지 않는 CSS 토큰을 참조한다 — style.css:1631·1632·1653·1657·1658, app.js:212-219

--bg-1 · --bg-2 · --line-1 · --text-1은 style.css에 정의가 0개다
(실제 토큰은 --bg / --surface / --surface-2 / --border / --border-sub / --text).

측정값(다크 테마):

```
.lg-card      background: rgba(0,0,0,0)       ← var(--bg-2) 미해결
              border-color: rgb(220,232,248)  ← currentColor로 폴백
.lg-src pre   background: rgba(0,0,0,0) · border-color: rgb(122,144,168)
_lgTheme()    getPropertyValue('--bg-1'/'--bg-2'/'--text-1'/'--line-1') → 전부 ""
              → themeVariables가 하드코딩 폴백(#ffffff/#f4f5f7/#111111/#cccccc)으로 고정
```

결과: 도식이 테마를 따라가지 않는다. 다크 모드에서도 노드는 라이트 배경(#f4f5f7)에
검은 글씨로 그려지고, 카드에는 배경이 없어 도식이 페이지 바탕 위에 떠 있으며 테두리 색이
글자색을 따라간다. 라벨 자체는 읽을 수 있어(대비 부족 노드 0건) 오류로는 드러나지 않는다.
lineColor만 --text-3가 실제로 존재해 해결되는데, 이 값은 다크에서 #4A5E72라
어두운 바탕 위 화살표 대비가 낮다.

#### 3. [중] 「임시부재(1C) 제외」 중에도 Check 카드 건수는 필터되지 않는다 — app.js:740

```
1C 제외 ON:  KPI 결함 행 26 · 클린 348   (서버 aggregate: stats={"12":22,"13":26})
             그런데 Check 카드는 C3=790 · C6=2,145 그대로
             막대그래프는 agg.stats(=필터된 값)를 쓰므로 카드와 서로 다른 값을 보여준다
```

renderDashboard()는 renderCheckGrid(r)에 원본 r.stats를 넘긴다(agg.stats가 아니라).
Check 취사선택에서 카드 건수를 유지하는 것은 주석에 적힌 의도지만, 1C 제외는 «집계 모수 자체»를
바꾸는 토글이라 같은 화면 안에서 KPI·차트와 카드가 어긋난다. 부서별 대시보드도 동일 구조다.

덧붙여 KPI 「판정 대상」과 결함률 분모는 1C 제외 중에도 judged_rows(5,516) 그대로여서
결함률이 26/5,516=0.5%로 계산된다(374 기준이면 7.0%). 버튼 옆 힌트만 «374행 기준»이라고 안내한다.

#### 4. [하] NDT REPORT 번호(BE열)가 화면에는 나오지 않는다

/api/flags 응답에는 ndt_report 필드가 실려 있고 검색도 서버 _FLAG_SEARCH_COLS 덕에
동작한다(SAVI15003 → 36건 확인). 그러나

- 상세 결과 표 헤더 17열: 행/도면번호/Joint No/블록/재질/두께/WPS No/WPS Process/용접일/NDE일자/부서/팀/Check/검토/마킹 열/기준값/실제값 — NDT REPORT 열 없음
- Check 목록 팝업 표도 동일
- 행 상세 모달 「원본 데이터(엑셀 원문)」에도 BE열 항목 없음

frontend/에서 ndt_report 문자열이 나오는 곳은 app.js:1284의 주석 한 줄뿐이다.
커밋 1a15cf1이 프론트에서 건드린 것은 팀별 수신인 UI였다. 「결과 표·상세 모달에 흐른다」는
설명과 실제 화면이 어긋난다 — 번호로 검색은 되지만 찾은 행에서 그 번호를 볼 수는 없다.

#### 5. [참고] 도식은 «넘치면 가로 스크롤»이 아니라 항상 축소된다

_lgFitSvg()는 w = Math.min(natural, Math.max(avail, 320))이라 컨테이너보다 넓어질 수 없다.
.lg-canvas의 overflow-x:auto는 실측에서 한 번도 발동하지 않았다(scrollWidth == clientWidth).

```
1600px 창: 자연폭 2146 → 1305px (61%)
 900px 창: 자연폭 2146 →  614px (29%)
```

잘림은 없지만(노드 52개 전수 확인) 좁은 창에서는 한글 라벨이 매우 작아진다.
주석/CSS가 설명하는 동작과 실제 동작이 다르다.

---

### 확인 못 한 것 (정직하게)

- 범위별 내보내기의 메일 발송 버튼: _exMailBtn()은 status==='ready'인 행에만 붙는데
  현재 31개 범위가 전부 «미생성»이라 DOM에 버튼이 없다. Excel 생성이 금지 조작이라
  순수 함수 _exMailBtn({kind:'team',...})를 직접 호출해 마크업만 확인했다 —
  팀 행에도 부서 행과 같은 버튼이 생성되며, 수신인이 없으면 disabled + 툴팁
  「설정 탭에서 이 팀의 수신인을 먼저 등록하세요」가 붙는다. data/dept_recipients.json과
  data/team_recipients.json이 둘 다 비어 있어 활성 상태(수신인 n명 표기)는 검증하지 못했다.
- 쓰기 동작 일체: 메일 발송, 검증 실행, 설정 저장(사번/수신인/Outlook), 검토 기록 저장,
  §11 답변 기록, Excel 생성 요청 — 모두 실행하지 않았다.
- 검토 기록 저장 후 사이드바 미검토 숫자 갱신(2026-08-08 리포트의 미결 지적): 저장이
  쓰기 동작이라 재확인하지 않았다.

### 정리

- _test_*.html 생성하지 않음(CDP로만 구동). frontend/ 아래 _test_* 파일 0건 확인.
- 저장소 작업 트리 변경 없음(이 리포트 파일 제외). 코드는 수정하지 않았다.
- 헤드리스 Edge 프로세스와 CDP 모니터는 종료했다. 임시 프로필은 스크래치패드에만 있다.
