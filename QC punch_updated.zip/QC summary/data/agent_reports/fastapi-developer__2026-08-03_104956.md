---
agent: fastapi-developer
run_at: 2026-08-03 10:49:56
verdict: FAIL
summary: API 계층 13건 지적. 검증 중 파일 재업로드 시 결과 Excel이 엉뚱한 원본에 마킹됨(HIGH). agents.py 경로 조작 방어는 실제 공격 페이로드 12종 모두 차단 확인.
---

# FastAPI 라우터 계층 점검 (분석 전용 · 코드 미수정)

- 범위: `backend/routers/agents.py`, `verify.py`, `main.py`, `config.py`, `auth.py`, `settings.py`, `feedback.py`
- 환경: Python 3.12.10 / FastAPI 0.115.0 / Starlette 0.38.6 / Pydantic 2.13.4
- 관찰 대상 서버: `http://127.0.0.1:8001` (GET 요청만 사용. 상태 변경 요청 없음)
- **판정 로직(`services/verifier.py`)은 열람만 하고 변경 제안하지 않았다.**
- 이 실행에서 **소스 코드는 한 줄도 수정하지 않았다.** 아래는 전부 제안이다.

---

## 요약

| # | 심각도 | 항목 | 상태 |
|---|---|---|---|
| 1 | HIGH | 검증/Excel 생성 중 파일 재업로드 무방비 → 결과 Excel 오마킹 | 코드경로 확정 |
| 2 | MEDIUM | 재시작 시 stale Excel이 `ready`로 복원됨 | 코드경로 확정 |
| 3 | MEDIUM | 21MB `app_state.json` 비원자적 쓰기 + 업로드마다 전체 재직렬화 | 실측 |
| 4 | MEDIUM | `read_only` 뱃지가 거짓으로 "읽기 전용"을 표시할 수 있음 | 재현 |
| 5 | MEDIUM | `/api/result`(19MB)·`/api/result/excel`은 무인증, `/api/feedback`은 인증 | 재현 |
| 6 | LOW | UTF-8 BOM 리포트는 frontmatter가 통째로 무시됨 | 재현(잠재) |
| 7 | LOW | `get_report`의 `_read_text`만 예외 미보호 → 500 | 격리 재현 |
| 8 | LOW | frontmatter 없는 리포트가 `---`로 시작하면 본문 앞부분 유실 | 재현 |
| 9 | LOW | `report_id`가 절대경로·대소문자 변형을 그대로 수용 | 재현(무해) |
| 10 | LOW | 시작 시 "이전 결과 복원 완료" 로그가 출력되지 않음 | 재현 |
| 11 | LOW | `delete_wps_cache` TOCTOU | 코드경로 |
| 12 | LOW | `/api/status` 폴링(600ms)마다 wps_cache.json 재파싱 | 코드경로 |
| 13 | LOW | frontmatter `name` 무검증 + `_esc`가 작은따옴표 미이스케이프 | 코드경로 |

**재현 가능** = 명령/출력을 아래에 실었다. **코드경로 확정** = 코드를 따라가 성립을 확인했으나,
상태 변경 요청이 금지되어 실제 실행은 하지 않았다.

---

## 1. [HIGH] 검증/Excel 생성 중 파일 재업로드가 무방비 → 결과 Excel이 다른 원본에 마킹된다

### (a) 무엇이 문제인가

`POST /api/verify`는 이미 이 위험을 알고 방어하고 있다 — `verify.py:216-220`:

```python
with _lock:
    if _state["status"] == "running":
        raise HTTPException(409, "검증이 이미 실행 중입니다")
    if _state["excel_status"] == "generating":
        raise HTTPException(409, "이전 검증의 Excel 결과 파일을 생성 중입니다. 잠시 후 다시 시도하세요")
```

그런데 **업로드 엔드포인트 3개(`/api/files/qmg`, `/api/files/welder`, `/api/files/wps`)에는
같은 가드가 없다.** `upload_qmg()`는 상태를 전혀 보지 않고 고정 경로를 덮어쓴다
(`verify.py:126-139`):

```python
dest = config.UPLOADS_DIR / "qmg_data.xlsx"
content = await file.read()
dest.write_bytes(content)          # ← status/excel_status 확인 없음
```

한편 백그라운드 스레드는 결과 확정 **이후에** 같은 경로를 다시 연다 (`verify.py:265` →
`verifier.py:1601-1604`):

```python
def write_result_excel(qmg_path, result, out_path) -> None:
    wb = load_workbook(str(qmg_path))          # 원본을 "다시" 읽는다
    ...
    cell = ws.cell(row=row_num, column=col)    # row_num은 "예전" 결과의 절대 행 번호
```

즉 `write_result_excel`은 결과 dict의 절대 행 번호로 워크북에 색을 칠하는데, 그 워크북이
방금 교체된 **다른 파일**일 수 있다.

### (b) 어떤 상황에서 터지나

1. 사용자가 `POST /api/verify` 실행 → 검증 완료 → `excel_status = "generating"`
2. 이 구간(`QC_Result.xlsx` 3MB 생성, 수 초~수십 초)에 사용자가 "다른 QMG 파일을 올려야겠다"며
   `POST /api/files/qmg`로 재업로드
3. `write_result_excel`이 새 파일을 열어 **예전 결과의 행 번호에 색과 코멘트를 찍는다**

결과는 예외가 아니라 **조용히 틀린 Excel**이다. 이 앱의 최종 산출물이 색상 마킹된 Excel이므로
영향이 크다. 타이밍이 어긋나면 openpyxl이 쓰기 중인 zip을 읽어 `BadZipFile` →
`excel_status = "error"`가 되는데, 이쪽은 오히려 눈에 보여서 낫다.

주: Windows CPython의 `open()`은 `FILE_SHARE_READ|WRITE`로 열리므로 `dest.write_bytes()`가
`PermissionError`로 막아주지 **않는다**. 즉 "운 좋게 실패"에 기댈 수 없다.

### (c) 제안

`POST /api/verify`가 이미 쓰는 것과 같은 판단을 업로드에도 적용한다. 헬퍼 하나로 3곳 공유:

```python
def _reject_if_busy() -> None:
    """검증 스레드가 qc_uploads/ 를 읽고 있는 동안 원본 교체를 막는다.
    write_result_excel()이 결과 확정 후 원본을 다시 열기 때문에, Excel 생성 중
    교체하면 예전 결과의 행 번호로 새 파일에 색을 칠하게 된다."""
    with _lock:
        if _state["status"] == "running":
            raise HTTPException(409, "검증이 진행 중입니다. 완료 후 파일을 교체하세요")
        if _state["excel_status"] == "generating":
            raise HTTPException(409, "결과 Excel을 생성 중입니다. 완료 후 파일을 교체하세요")

@router.post("/files/qmg")
async def upload_qmg(file: UploadFile) -> dict:
    global _qmg_path, _qmg_name
    _reject_if_busy()                      # ← 추가
    if not file.filename or not file.filename.lower().endswith('.xlsx'):
        ...
```

`/files/welder`, `/files/wps`, `DELETE /files/wps`에도 같은 줄을 넣는다
(welder/wps도 검증 스레드가 읽는 입력이다).

---

## 2. [MEDIUM] 재시작 시 결과와 짝이 맞지 않는 Excel이 `ready`로 되살아난다

### (a) 무엇이 문제인가

`_load_app_state()`는 **파일 존재만으로** `excel_status`를 정한다 (`verify.py:92-98`):

```python
excel_path = config.RESULTS_DIR / "QC_Result.xlsx"
with _lock:
    _state["result"]       = result
    _state["status"]       = "done"
    ...
    _state["excel_status"] = "ready" if excel_path.exists() else "idle"
```

그런데 `QC_Result.xlsx`가 **복원된 result와 같은 검증에서 나온 것인지는 확인하지 않는다.**

이 라우터의 작성자는 같은 종류의 위험을 이미 인지하고 있다 — `download_excel()`의 주석
(`verify.py:296-297`)이 "새 검증이 진행 중이면 디스크의 stale 파일을 내려주지 않는다"고
명시한다. 재시작 경로가 그 방어를 우회한다.

### (b) 어떤 상황에서 터지나

1. 검증 N 성공 → `_save_app_state()`로 result 저장(디스크 최신) → `excel_status="generating"`
2. Excel 생성이 실패 → `excel_status = "error"`. 디스크의 `QC_Result.xlsx`는 **검증 N-1의 것**
3. 서버 재시작 → `_load_app_state()`가 result N을 복원하고, 파일이 있으니 `excel_status="ready"`
4. 사용자가 "Excel 다운로드" → **화면(검증 N)과 내용이 다른 검증 N-1의 Excel**을 받는다

CLAUDE.md가 경고하는 "낡은 서버 프로세스" 상황과 겹치면 알아채기 어렵다.

### (c) 제안

result의 `run_at`을 함께 저장하고 복원 시 대조한다.

```python
# _save_app_state()
payload = {
    "qmg_name": _qmg_name, "welder_name": _welder_name, "wps_name": _wps_name,
    "result": _state["result"],
    # 디스크의 QC_Result.xlsx가 이 result에서 나온 것인지 재시작 후 판별하기 위한 표식
    "excel_run_at": _state["result"].get("run_at") if _state["excel_status"] == "ready"
                    and _state["result"] else None,
}

# _load_app_state()
excel_ok = (
    excel_path.exists()
    and saved.get("excel_run_at")
    and saved["excel_run_at"] == result.get("run_at")
)
_state["excel_status"] = "ready" if excel_ok else "idle"
```

`excel_status`가 `ready`가 되는 시점(`verify.py:267`)에서도 `_save_app_state()`를 한 번 더
불러야 표식이 남는다. 현재는 `generating` 시점에만 저장한다.

---

## 3. [MEDIUM] 21MB `app_state.json`을 비원자적으로 쓰고, 업로드마다 통째로 다시 쓴다

### (a) 무엇이 문제인가

실측:

```
$ ls -la data/app_state.json
-rw-r--r-- 1 김현수 197121 21093024 Aug  2 23:15 data/app_state.json

$ python -c "... json.dumps(payload) ..."
payload bytes: 21092923  dumps: 0.20s
```

두 가지 문제가 겹친다.

**(i) 비원자적 쓰기.** `config.APP_STATE_FILE.write_text(...)` (`verify.py:62-64`)는 기존 파일을
truncate한 뒤 21MB를 흘려 넣는다. 이 창(수백 ms 이상) 안에 프로세스가 죽으면 잘린 JSON이 남고,
다음 기동에서 `_load_app_state()`가 `except Exception: logger.exception(...)` 으로 삼킨다
(`verify.py:81-85`). 사용자에게는 **마지막 검증 결과가 그냥 사라진 것**으로 보인다.
`start_qc.bat` 창을 닫아 서버를 내리는 운용 방식이면 충돌 가능성이 낮지 않다.

**(ii) 업로드마다 21MB 재직렬화.** `_save_app_state()`는 파일명 하나만 바뀌는
`upload_qmg` / `upload_welder` / `upload_wps` / `delete_wps_cache`에서도 호출된다
(`verify.py:137, 152, 185, 200`). 즉 **파일 하나 올릴 때마다 result 전체를 다시 dumps하고
21MB를 디스크에 쓴다**(요청 지연 +0.2s 이상 + I/O).

같은 패턴이 `feedback_store._save_feedback`, `settings._update_dept_recipients`,
`auth.update_employees`에도 있으나 그쪽은 파일이 작아(≤4.5KB) 실질 위험이 낮다.

### (b) 제안

원자적 교체로 바꾼다. 이것만으로 (i)이 해결된다.

```python
import os, tempfile

def _atomic_write_text(path: Path, text: str) -> None:
    """같은 디렉터리에 임시 파일로 쓰고 os.replace로 교체한다.
    os.replace는 같은 볼륨 안에서 원자적이므로, 도중에 죽어도 기존 파일이 온전히 남는다."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise
```

(ii)는 선택. 파일명 3개만 담는 작은 파일(`data/upload_names.json`)로 분리하고
업로드 엔드포인트는 그쪽만 쓰게 하면 업로드 요청에서 21MB 쓰기가 사라진다. 다만
`app_state.json` 하나로 유지하는 단순함이 이 앱의 설계 의도라면, 최소한 업로드 경로에서만
result를 건드리지 않는 부분 저장 함수를 따로 두는 편이 낫다.

---

## 4. [MEDIUM] `read_only` 뱃지가 거짓으로 "읽기 전용"을 표시할 수 있다

### (a) 무엇이 문제인가

`agents.py:136, 153`:

```python
tools = [t.strip() for t in (meta.get("tools") or "").split(",") if t.strip()]
...
"read_only": not ({"Write", "Edit", "NotebookEdit"} & set(tools)),
```

이 값은 화면에서 **안전성 라벨**로 쓰인다 (`app.js:3502-3504`):

```js
const perm = a.read_only
  ? '<span ... title="Write/Edit 권한이 없어 코드를 수정할 수 없습니다">읽기 전용</span>'
  : '<span ... title="Write/Edit 권한이 있어 코드를 수정할 수 있습니다">쓰기 가능</span>';
```

`tools` 파싱이 실패하면 빈 리스트가 되고, 빈 리스트는 **"읽기 전용"으로 해석된다.**
"모르겠음"과 "권한 없음"이 같은 값으로 붕괴한다.

### (b) 어떤 상황에서 터지나

세 가지가 모두 실제 Claude Code frontmatter에서 유효한 표기다.

1. **`tools:` 키 자체가 없는 경우** — Claude Code에서 이는 "모든 도구 상속"(= Write/Edit 포함)을
   뜻한다. 그런데 `meta.get("tools")`가 None → `tools = []` → **read_only=True**.
   가장 위험한 오표시다.
2. **YAML 블록 리스트로 쓴 경우** — 재현:

```
$ python -c "from backend.routers.agents import _split_frontmatter as f; \
             print(f('---\nagent: x\ntools:\n  - Read\n  - Write\n---\nbody'))"
yaml-list  | meta= {'agent': 'x', 'tools': ''} | body= 'body'
```
   → `tools = []` → **read_only=True** (실제로는 Write 보유).
3. **`tools: "*"`** → `tools = ['*']` → 교집합 없음 → **read_only=True**.

현재 저장소의 정의 5개는 모두 인라인 쉼표 표기라 지금은 발현하지 않는다. 새 서브에이전트를
설치할 때 터진다.

### (c) 제안

"불명"을 별도 상태로 만든다.

```python
raw_tools = meta.get("tools")
tools = [t.strip() for t in (raw_tools or "").split(",") if t.strip()]

# tools 표기를 해석하지 못했으면(키 없음 / 블록 리스트 / "*") '읽기 전용'이라고
# 단정하지 않는다. Claude Code에서 tools 생략은 '전체 상속'(=Write/Edit 포함)이다.
tools_known = bool(tools) and "*" not in tools
writable    = bool({"Write", "Edit", "NotebookEdit"} & set(tools))

agents.append({
    ...
    "tools": tools,
    "read_only": (not writable) if tools_known else False,
    "tools_parsed": tools_known,      # 화면에서 '권한 불명'으로 표시할 근거
})
```

`app.js`는 `tools_parsed === false`면 "권한 불명"으로 그리게 하면 된다(프론트 수정은 별건).

---

## 5. [MEDIUM] 무거운/민감한 엔드포인트가 무인증, 가벼운 쪽만 인증

### (a) 재현

```
$ for u in /api/status /api/result/excel /docs /openapi.json /api/feedback /api/settings/employees /api/agents; do
    echo "$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8001$u)  $u"; done
200  /api/status
200  /api/result/excel
200  /docs
200  /openapi.json
401  /api/feedback
401  /api/settings/employees
200  /api/agents

$ curl -s -o /dev/null -w "%{http_code} %{size_download} bytes\n" http://127.0.0.1:8001/api/result
200 19118109 bytes
```

`/api/feedback`(4.5KB)과 `/api/settings/*`는 `X-Employee-Id`를 요구하는데,
**19MB의 전체 검증 결과(사번·도면번호·Joint No·용접사)와 색상 마킹 Excel(3MB), 그리고
`POST /api/verify` / `POST /api/files/*`는 헤더 없이 그대로 열린다.**
서버는 `0.0.0.0:8001`로 사내망에 바인딩된다.

### (b) 제안

**새 인증 방식을 도입하자는 게 아니다.** 이미 있는 한 줄짜리 사번 대조
(`feedback.py:30-36`의 `_require_login`)를 그대로 재사용하자는 것이다.
`auth.py` 또는 공용 모듈로 옮기고:

```python
from backend.routers.auth import require_login   # feedback.py의 _require_login을 이동

@router.get("/result")
def get_result(x_employee_id: str | None = Header(None)) -> JSONResponse:
    require_login(x_employee_id)
    ...
```

최소한 `/api/result`, `/api/result/excel`, `POST /api/verify`, `POST/DELETE /api/files/*`
5곳에는 붙일 값이 있다. 프론트는 이미 로그인 사번을 localStorage에 들고 있고
`apiFetch`가 헤더를 붙이는 구조이므로 클라이언트 변경 비용이 거의 없다(확인 필요).

`/docs`·`/openapi.json` 노출은 사내망 전제라 그대로 둬도 무방하다고 본다.
줄이고 싶으면 `FastAPI(..., docs_url=None, openapi_url=None)`이지만 개발 편의를 잃는다 — 판단은 사람 몫.

---

## 6. [LOW] UTF-8 BOM이 붙은 리포트는 frontmatter가 통째로 무시된다

### (a) 무엇이 문제인가

`agents.py:70`은 `encoding="utf-8"`로 읽는다. 이는 **BOM을 제거하지 않는다.**
그러면 `_split_frontmatter`의 첫 줄이 즉시 실패한다 (`agents.py:52`):

```python
if not text.startswith("---"):     # '\ufeff---' 이므로 False
    return {}, text
```

### (b) 재현

```
$ python -c "from backend.routers.agents import _split_frontmatter as f; \
             print(f('\ufeff---\nagent: x\nverdict: PASS\nsummary: hi\n---\n# body'))"
BOM  | meta= {} | body= '\ufeff---\nagent: x\nverdict: PASS\nsumm...'
```

결과: `verdict`는 `UNKNOWN`, `summary`는 빈 문자열, `agent`는 파일명 폴백,
그리고 **`---` 블록 원문이 미리보기와 본문에 그대로 노출된다.**

### (c) 어떤 상황에서 실제로 터지나

**현재 리포지토리의 9개 .md는 모두 BOM이 없다**(전수 확인). 잠재 결함이다.
다만 이 저장소는 CLAUDE.md가 PowerShell을 주 셸로 명시하고 있고,
Windows PowerShell 5.1의 `Out-File -Encoding utf8` / `Set-Content -Encoding utf8`은
**BOM을 붙인다.** 에이전트가 리포트를 PowerShell 리다이렉션으로 저장하는 순간 발현한다.

### (d) 제안

```python
def _read_text(path: Path) -> str:
    """UTF-8로 읽되, 인코딩이 어긋나도 죽지 않게 한다(리포트는 사람이 읽는 산출물).
    utf-8-sig: Windows PowerShell의 Out-File/Set-Content -Encoding utf8이 BOM을 붙이므로
    BOM이 있으면 벗겨낸다. BOM이 없으면 utf-8과 동일하게 동작한다."""
    return path.read_text(encoding="utf-8-sig", errors="replace")
```

한 글자 변경으로 끝나고 부작용이 없다.

---

## 7. [LOW] `get_report`의 파일 읽기만 예외 미보호 → 500

### (a) 무엇이 문제인가

`_scan_reports`는 읽기를 감싼다 (`agents.py:93-97`):

```python
try:
    text = _read_text(path)
except OSError as exc:
    logger.warning("리포트 읽기 실패 %s: %s", path.name, exc)
    continue
```

그런데 `get_report`는 감싸지 않는다 (`agents.py:211`):

```python
text = _read_text(path)      # ← 보호 없음
```

`resolve(strict=True)`와 `relative_to`는 **디렉터리도 통과시킨다.**

### (b) 격리 재현

임시 디렉터리에 라우터와 동일한 가드 로직을 복제하고, 리포트 이름 규칙에 맞는
**디렉터리**를 만들어 호출했다:

```
directory case: (예외)
Traceback (most recent call last):
  File "<string>", line 24, in guard
  ...
PermissionError: [Errno 13] Permission denied:
  '...\\data\\agent_reports\\dir__2026-01-01_000000.md'
```

즉 `data/agent_reports/`에 `X__YYYY-MM-DD_HHMMSS.md`라는 **디렉터리**가 생기면
목록(`/api/agents`)에는 그 항목이 뜨고(스캔은 OSError를 잡아 넘어가지만 `path.stat()`는 성공),
클릭 시 `/api/agents/reports/X__...`가 **HTTP 500**으로 떨어진다.
발생 가능성은 낮지만(우연히 그런 이름의 디렉터리가 필요) 비용이 0인 수정이다.

### (c) 제안

```python
    if not path.is_file():
        raise HTTPException(404, f"리포트를 찾을 수 없습니다: {report_id}")
    try:
        text = _read_text(path)
    except OSError as exc:
        logger.warning("리포트 읽기 실패 %s: %s", report_id, exc)
        raise HTTPException(500, f"리포트를 읽을 수 없습니다: {exc}")
```

`get_definition`은 이미 `path.is_file()`을 확인하고 있으므로(`agents.py:230`)
같은 방식으로 맞추면 된다.

---

## 8. [LOW] frontmatter 없이 `---`로 시작하는 리포트는 본문 앞부분이 조용히 사라진다

### (a) 재현

```
$ python -c "from backend.routers.agents import _split_frontmatter as f; \
             print(f('---\n# 제목\n어쩌구: 저쩌구\n---\n## 본문 시작'))"
no-frontmatter-hr-start | meta= {'어쩌구': '저쩌구'} | body= '## 본문 시작'
```

`# 제목`과 그 아래 줄이 **본문에서 없어졌고**, 대신 엉뚱한 메타 키가 생겼다.
`_split_frontmatter`가 `text.find("\n---", 3)`로 "다음에 나오는 `---`"를 무조건 종료
구분자로 보기 때문이다. 마크다운 수평선으로 시작하는 리포트가 여기에 걸린다.

### (b) 제안

frontmatter로 인정하는 조건을 좁힌다. 구분자 블록 안이 전부 `키: 값`(또는 빈 줄)일 때만
frontmatter로 본다:

```python
    head = text[3:end]
    lines = [ln for ln in head.splitlines() if ln.strip()]
    # 모든 줄이 '키: 값' 형태일 때만 frontmatter로 인정한다.
    # 그렇지 않으면 마크다운 수평선(---)으로 시작하는 본문을 frontmatter로 오인해
    # 첫 섹션을 통째로 잘라먹는다.
    if not lines or not all(re.match(r"^[A-Za-z_][\w-]*\s*:", ln) for ln in lines):
        return {}, text
```

부수 효과로 (6)의 BOM 케이스와도 잘 맞물린다.

또한 값 파싱의 `val.strip().strip('"').strip("'")`(`agents.py:64`)는 짝이 맞지 않는 따옴표도
한쪽만 벗긴다(`summary: "미완결 인용` → `미완결 인용`). 실질 피해는 없어 그대로 둬도 된다.

---

## 9. [LOW] `report_id`가 절대경로·대소문자 변형을 그대로 수용한다 (경로 조작 자체는 차단됨)

### (a) 결론 먼저: **경로 조작 방어는 충분하다.** 12종 페이로드 전수 확인

```
$ for p in ...; do curl -s -o /dev/null -w "%{http_code}" ".../api/agents/reports/$p"; done
400   ..%5C..%5Cdata%5Cemployees                       (역슬래시 traversal)
404   ..%2F..%2Fdata%2Femployees                       (슬래시 traversal)
400   %2e%2e%5C%2e%2e%5Cdata%5Capp_state               (인코딩 우회)
400   ....%5C%5C....%5C%5Cdata%5Cemployees             (dot 중첩)
400   QC-DA~1%5Cx                                      (8.3 단축명)
400   CON                                              (예약 장치명)
404   NUL__2026-08-03_090852                           (예약 장치명 + 정규식 통과)
400   ..%5C..%5C.claude%5Cagents%5Cfastapi-developer   (정의 파일 탈취 시도)
404   %5C%5C127.0.0.1%5CC%24%5C...__2026-08-03_090852  (UNC)
404   ..%5C..%5C..%5CWindows%5Csystem32%5Cx__2026-08-03_090852
400   test-automator__2026-08-03_090852%00x            (널 바이트)
400   test-automator__2026-08-03_090852.md             (이중 확장자)
```

컨테인먼트를 확실히 증명하려면 디렉터리 **바깥에** 규칙에 맞는 미끼 파일이 필요한데,
저장소를 건드릴 수 없으므로 임시 디렉터리에 동일 로직을 복제해 검증했다:

```
'good__2026-01-01_000000'                       => 200 -> ---\nverdict: PASS\n--
'..\\secret__2026-01-01_000000'                 => 404 ValueError
'..\\..\\data\\secret__2026-01-01_000000'       => 404 ValueError
'../secret__2026-01-01_000000'                  => 404 ValueError
'C:\\...\\data\\secret__2026-01-01_000000'      => 404 ValueError   (절대경로)
'..\\agent_reports\\good__2026-01-01_000000'    => 200              (되돌아옴 - 정상)
```

`resolve(strict=True)`는 Windows에서 `GetFinalPathNameByHandle` 경로를 타므로 8.3 단축명과
심볼릭 링크/정션이 정규화되고, `relative_to`가 그 결과를 막는다. **탈출 사례 0건.**
`str` 경로 파라미터가 Starlette에서 `[^/]+`로 매칭되므로 `%2F`도 라우팅 단계에서 걸러진다.

### (b) 그래도 걸리는 것

```
$ curl -o /dev/null -w "%{http_code}\n" \
  "http://127.0.0.1:8001/api/agents/reports/C%3A%5CQC%20summary%5Cdata%5Cagent_reports%5Ctest-automator__2026-08-03_090852"
200

$ curl -o /dev/null -w "%{http_code}\n" \
  "http://127.0.0.1:8001/api/agents/reports/TEST-AUTOMATOR__2026-08-03_090852"
200
```

- 절대경로가 통과하는 이유: `AGENT_REPORTS_DIR / "C:\..."`에서 pathlib은 오른쪽이 절대경로면
  **왼쪽을 버린다.** 결과가 마침 디렉터리 안이라 통과한다. 보안 문제는 아니지만
  `report_id`의 의미가 "파일명"이 아니게 되고, 응답의 `"id"` 필드는 호출자가 준 문자열을
  그대로 되돌려준다.
- 대소문자 변형이 통과하는 이유: NTFS가 대소문자를 구분하지 않기 때문. 역시 무해.

### (c) 제안 (하드닝, 선택)

정규식을 파일명만 허용하도록 좁힌다. 에이전트 이름은 이미 `[A-Za-z0-9_-]+`로 제한돼 있다
(`agents.py:226`).

```python
# 리포트 파일명 규칙: <에이전트이름>__<YYYY-MM-DD_HHMMSS>.md
# 에이전트 이름에 경로 구분자(/ \)나 드라이브 문자(:)가 끼어들지 못하게 한다.
# resolve+relative_to가 이미 탈출을 막지만, report_id를 '파일명'으로 못박아 두면
# 절대경로나 상대경로가 식별자로 통용되는 상황 자체가 사라진다.
_REPORT_RE = re.compile(r"^(?P<agent>[A-Za-z0-9_-]+?)__(?P<ts>\d{4}-\d{2}-\d{2}_\d{6})\.md$")
```

`resolve`/`relative_to`는 그대로 둔다(심볼릭 링크 방어는 정규식이 못 한다).

---

## 10. [LOW] 시작 시 "이전 검증 결과 복원 완료" 로그가 출력되지 않는다

### (a) 재현

```
$ python -c "import backend.main" 2>&1 | head -20
=== exit ===          ← 아무것도 출력되지 않음
```

핸들러를 먼저 붙이면 레코드는 분명히 생성된다:

```
$ python -c "import logging,io; buf=io.StringIO(); \
  logging.getLogger().addHandler(logging.StreamHandler(buf)); \
  logging.getLogger().setLevel(logging.INFO); import backend.main; ..."
restored status: done | has_result: True
captured log lines: '이전 검증 결과 복원 완료 (플래그 3664행)\n'
import time: 2.26s
```

### (b) 원인

`main.py`에서 라우터 import(7~11행)가 `logging.basicConfig()`(13~17행)보다 **먼저** 실행된다.
`verify.py:101`의 `_load_app_state()`는 모듈 import 시점에 돌기 때문에, 그때 root 로거에는
핸들러가 없다 → `logging.lastResort`(레벨 WARNING)로 떨어져 **INFO 레코드가 버려진다.**
uvicorn도 root 로거를 구성하지 않으므로 운영 실행에서도 동일하다.

`settings.py:27`의 `logger.warning("pywin32 미설치 — Outlook 발송 기능 비활성화")`도 같은 시점에
나가는데, WARNING이라 lastResort를 통과하긴 하지만 지정한 포맷(`%(asctime)s ...`) 없이 찍힌다.

CLAUDE.md "검증 전 반드시 확인할 것 1: 낡은 서버 프로세스"에서 필요한 게 바로 이 로그라
(복원된 플래그 수가 보이면 프로세스 세대를 구분할 수 있다) 실질 손해가 있다.

### (c) 제안

`main.py`에서 `logging.basicConfig`를 import보다 위로 올린다.

```python
import logging

# 라우터 import보다 먼저 호출해야 한다. verify.py는 import 시점에 _load_app_state()를
# 돌리며 logger.info를 남기는데, 그때 root에 핸들러가 없으면 lastResort(WARNING)로
# 떨어져 조용히 버려진다.
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%H:%M:%S",
)

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, Response

from backend import config
from backend.routers.verify import router as verify_router
...
```

---

## 11. [LOW] `delete_wps_cache`의 TOCTOU

`verify.py:196-198`:

```python
if config.WPS_CACHE.exists():
    config.WPS_CACHE.unlink()          # 그 사이에 사라지면 FileNotFoundError → 500
```

같은 파일에서 이미 `unlink(missing_ok=True)`를 쓰는 곳이 있다(`verify.py:191`).

```python
config.WPS_CACHE.unlink(missing_ok=True)
```

---

## 12. [LOW] `/api/status` 폴링마다 wps_cache.json을 다시 읽고 파싱한다

`get_status()`는 매 호출마다 `_load_wps_cache()`로 파일 전체를 읽어 `json.loads` 한다
(`verify.py:42-48, 105`). 프론트는 검증 중 **600ms 간격으로 폴링**한다(`app.js:377`).
`wps_cache_count` 하나를 얻기 위한 비용이다.

현재 `data/wps_cache.json`이 없어(`ls data/*.json` 확인) `exists()` 한 번으로 끝나므로
실제 부하는 0이다. WPS 캐시를 업로드해 쓰는 운용으로 바뀌면 발현한다.

제안: mtime 기준 메모이즈. 캐시 파일은 `/api/files/wps`로만 바뀐다.

```python
_wps_cache_memo: tuple[float, int, dict | None] | None = None   # (mtime, size, data)

def _load_wps_cache() -> dict | None:
    """mtime+size가 그대로면 재파싱하지 않는다 — /api/status가 600ms마다 호출된다."""
    global _wps_cache_memo
    try:
        st = config.WPS_CACHE.stat()
    except OSError:
        _wps_cache_memo = None
        return None
    if _wps_cache_memo and _wps_cache_memo[0] == st.st_mtime and _wps_cache_memo[1] == st.st_size:
        return _wps_cache_memo[2]
    try:
        data = json.loads(config.WPS_CACHE.read_text(encoding='utf-8'))
    except Exception:
        return None
    _wps_cache_memo = (st.st_mtime, st.st_size, data)
    return data
```

---

## 13. [LOW] frontmatter의 `name`은 무검증인데 정의 조회는 `[A-Za-z0-9_-]+`만 허용

`_scan_agents`는 `meta.get("name") or path.stem`을 그대로 내보낸다(`agents.py:148`).
반면 `get_definition`은 `re.fullmatch(r"[A-Za-z0-9_-]+", name)`을 요구한다(`agents.py:226`)
**그리고 파일 경로도 `AGENTS_DIR / f"{name}.md"`로 만든다.** 따라서

- frontmatter `name:`이 파일명과 다르면 → 카드는 뜨는데 클릭 시 **404**
- frontmatter `name:`에 허용 외 문자(한글, 점, 공백)가 있으면 → 클릭 시 **400**

부수적으로 `app.js:1916`의 `_esc`는 `& " <`만 치환하고 **작은따옴표를 이스케이프하지 않는데**,
name은 인라인 `onclick="openAgentDefinition('...')"`에 삽입된다(`app.js:3505`).
`name`에 `'`가 들어가면 핸들러가 깨진다. 원본이 로컬 파일이라 원격 XSS는 아니다.

제안(서버 쪽만): `_scan_agents`에서 `name`을 `get_definition`과 같은 규칙으로 정규화한다.

```python
        # /api/agents/definition/{name}이 파일명으로 쓰는 값이므로 같은 규칙으로 맞춘다.
        # frontmatter name이 규칙을 벗어나면 파일명(stem)을 쓴다 — 카드는 뜨는데
        # 클릭하면 400/404가 나는 상태를 만들지 않기 위해서다.
        raw_name = meta.get("name") or path.stem
        name = raw_name if re.fullmatch(r"[A-Za-z0-9_-]+", raw_name) else path.stem
```

---

## 문제 없다고 확인한 것 (억지로 지적하지 않음)

- **`agents.py` 경로 조작 방어** — 위 (9)에 전수 결과. Windows 특유 우회(대소문자, 8.3 단축명,
  예약어 CON/NUL, UNC, 심볼릭 링크, 널 바이트, `%2F`) 어느 것도 디렉터리를 벗어나지 못했다.
  `_REPORT_RE` + `resolve(strict=True)` + `relative_to` 조합은 **충분하다.**
- **`get_definition`의 입력 검증** — `[A-Za-z0-9_-]+` fullmatch는 이 용도에 적절하다.
- **`verify.py`의 `_lock` 범위** — 데드락 없음. `_save_app_state()`가 `_lock`을 잡지만
  락을 쥔 상태에서 호출되는 지점이 하나도 없다(`_run`의 260행은 `with _lock` 블록 **밖**).
  409 판정도 검사와 상태 설정이 같은 임계구역 안이라 중복 실행 창이 없다.
- **백그라운드 스레드 예외 반영** — 검증 단계(245~251행)와 Excel 단계(268~272행) 모두
  `_state`에 정확히 반영되고, `excel_status`가 `generating`에 갇히지 않는다.
  다만 `except Exception`이라 `BaseException`(예: SystemExit)에는 `status`가 `running`에
  고정되고 이를 되돌릴 API가 없다 — 재시작으로만 해소된다. 이론적 우려로만 적어둔다.
- **`_scan_reports` 예외 처리** — "조용히 삼킨다"고 보기 어렵다. 파일명 불일치는
  `logger.debug`, 읽기 실패는 `logger.warning`으로 남기고, 리포트 한 건이 목록 전체를
  막지 않는다는 문서화된 의도와 일치한다. 다만 (7)의 `get_report`만 비대칭이다.
- **리포트 누적 비용** — 우려만큼 크지 않다. 500건(각 6KB)으로 실측:

```
500 reports (6 KB each): _scan_reports = 0.164s, response items=500
json payload size: 0.5 MB
```
  게다가 프론트는 `AG.data`에 캐시하고 폴링하지 않는다(`app.js:3438`). 지금 조치할 필요는 없다.
  1,000건을 넘어가면 (i) frontmatter+미리보기용으로 앞 2KB만 읽기, (ii) 페이지네이션을 검토.
  `preview = " ".join(body.split())[:400]`은 400자를 위해 본문 전체를 split/join 하므로
  거기서부터 손대면 된다.
- **`_NoCacheStaticFiles`** — Starlette 0.38.6에서 `file_response(self, full_path, stat_result,
  scope, status_code=200)` 시그니처가 유지되고 `*args, **kwargs` 위임이 정상 동작한다.
  실측 헤더 `cache-control: no-cache, must-revalidate` + `etag` 확인. **제거 제안 없음.**
- **마운트 순서** — `/api` 라우터 5개 → `/static` 마운트 → `GET /`. 충돌 없다.
- **`config` 사용 규약** — 라우터 5개 모두 `from backend import config` + `config.XXX` 접근.
  CLAUDE.md 규칙 위반 없음.
- **`auth.update_employees` / `settings._update_dept_recipients` / `feedback_store.upsert_feedback`**
  — 읽기→수정→저장이 모두 하나의 락 안이다. 각 docstring이 밝힌 lost-update를 실제로 막고 있다.
- **`settings.py`의 Outlook 경로** — `pythoncom.CoInitialize()`/`CoUninitialize()`가
  `try/finally`로 짝이 맞고, 배치 발송은 부서 단위로 예외를 잡아 `skipped`에 모은다. 적절하다.
- **`feedback.py`** — 락은 store 계층에 있고 권한 검사가 GET/POST 모두에 걸려 있다.
  다만 `check_no`에 범위 검증이 없어(`CHECK_NAMES`는 1~14) 임의 정수가 검토키에 들어갈 수 있고,
  `remark`/`flag_snapshot`/`row_raw`에 길이 제한이 없어 로그인한 사용자가
  `flag_feedback.json`을 무한히 키울 수 있다. 사내망 단일 사용자 전제에서 방치 가능하나,
  `check_no in CHECK_NAMES` 한 줄과 `remark: str = Field("", max_length=2000)` 정도는 값이 있다.

## 제안하지 않은 것 (제약 블록 준수)

`verifier.py` 판정 로직 · ORM/Alembic/리포지토리 패턴 · OAuth2/JWT/세션 스토어 ·
Docker/Gunicorn/k8s · 검증의 `async def` 전환 · `_NoCacheStaticFiles` 제거 —
모두 검토 대상에서 제외했다. (5)의 인증 제안은 **기존 사번 대조 한 줄의 적용 범위를
넓히자는 것**이지 새 인증 방식이 아니다.

`requirements.txt`는 없는 상태다(CLAUDE.md도 인정). 신설이 유익하나 지시대로 만들지 않았다.
만든다면 실측 버전 기준: `fastapi==0.115.0`, `starlette==0.38.6`(fastapi가 끌어옴),
`pydantic==2.13.4`, `uvicorn`, `openpyxl`, 그리고 선택 의존성 `scikit-learn`, `pywin32`.

## 이번 실행에서 확인하지 못한 것

- `POST /api/verify`, `POST /api/files/*`의 **실제 실행 검증** — 상태 변경 요청이 금지되어
  (1)(2)를 코드 경로 추적으로만 확정했다. 특히 (1)은 검증 실행 중 재업로드를 실제로 시도해야
  최종 확인된다.
- Outlook 발송 경로(`_dispatch_dept_mail`)는 pywin32/Outlook 실환경이 필요해 미실행.
- `agents.py`에 대한 **테스트가 전혀 없다**(`grep -rln agents tests/` → 0건).
  어제 추가된 라우터인데 `tests/`의 63개 테스트가 하나도 덮지 않는다.
  (6)(8)의 frontmatter 파싱과 (9)의 경로 가드는 순수 함수라 테스트 비용이 매우 낮다 —
  `test-automator` 에이전트에 넘기기 좋은 항목이다.

## 권장 조치 순서

1. **(1)** 업로드 3종 + `DELETE /files/wps`에 `_reject_if_busy()` — 산출물 정합성에 직결
2. **(3)** `_atomic_write_text`로 `app_state.json` 저장 교체 — 21MB 유실 위험 제거
3. **(2)** `excel_run_at` 대조 — stale Excel 차단
4. **(5)** `/api/result`·`/api/result/excel`·`/api/verify`·`/api/files/*`에 `require_login`
5. **(6)(4)(10)** 각각 한두 줄 (`utf-8-sig` / `tools_parsed` / `basicConfig` 위치)
6. **(7)(8)(9)(11)(13)** 하드닝
7. `agents.py` 단위 테스트 추가 (`_split_frontmatter`, 경로 가드)

백엔드를 실제로 수정하면 CLAUDE.md 규정대로 `python -m pytest tests/ -v` → `qc-data-verifier`
순서로 집계 정합성을 재확인해야 한다. 이번 실행은 코드를 바꾸지 않았으므로 해당 없음.
