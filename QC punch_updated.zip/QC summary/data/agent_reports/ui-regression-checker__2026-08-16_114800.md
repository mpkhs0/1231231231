---
agent: ui-regression-checker
run_at: 2026-08-16 11:48:00
verdict: PARTIAL
summary: A~G 일곱 결함과 용접사 Check 6 혼입까지 전부 고쳐진 것을 확인했고 14개 화면 콘솔 오류 0건이다. 다만 「빼기」 버튼 한 자리가 같은 부류로 남아 있고, 비지도학습 1C 제외 기준은 결과에 데이터가 없어 확인하지 못했다.
---

## 판정: PARTIAL

직전 FAIL의 A~G는 **전부 실제 클릭으로 재현해 고쳐진 것을 확인**했다. 추가로 고쳤다는
용접사 Check 6 혼입과 `focusCheckNo` 강조도 실측으로 맞았다. `CHECK_META`를 문자열로
바꾼 것이 다른 곳을 깨뜨리지 않았다 — Check 취사선택·도넛 범례·KPI 카드·`_ruleOn`·
두 Set 연산을 전수로 확인했고 14개 화면 콘솔 오류는 0건이다.

PASS로 적지 못하는 이유는 둘이다.

1. **`deleteCheckRule`의 두 번째 인자만 따옴표가 없다.** E 목록에서 빠진 자리다.
   지금 물량은 옛 번호(101~105)뿐이라 동작하지만, 서버가 지금 발급하는 식별자
   (`TRIONFPU1` 꼴)에서는 클릭 즉시 `ReferenceError`가 난다. 실행해 증명했다.
2. **비지도학습의 「1C 제외」 기준을 확인하지 못했다.** 회귀 기준으로 받은
   「제외 374행 / 4건」을 볼 수 없었다 — 서버 응답에 그 데이터가 아예 없다.

### 실행 조건

| 항목 | 값 |
|---|---|
| 서버 | 샌드박스 `http://127.0.0.1:8013` · PID **16808** · 기동 2026-08-16 11:24:10 |
| 코드보다 새 프로세스인가 | 예 (app.js 11:22:59 · rules.py 11:22:29 < 기동 11:24:10) |
| app.js md5 (로컬 / 서버) | `771042a29e9b9d5ed34e6191745bec45` / **동일** |
| `node --check app.js` | 통과 |
| 프로파일 · 로그인 | TRION FPU · `A551135`(관리자) |
| 결과 | 판정 대상 5,516 = 결함 3,334 + 클린 2,182 · 총 플래그 4,321 |
| 방식 | 헤드리스 Edge 151 + **CDP**(`--remote-debugging-port`) 실시간 구동 |
| 쓰기 호출 | **없음.** `/api/verify` · `POST /api/rules` · 규칙 저장/삭제 · 프로파일 전환 전부 부르지 않았다 |

`--virtual-time-budget`은 쓰지 않았다(18MB 부팅 중 예산 소진으로 거짓 음성이 나는 방식).
CDP로 단계마다 상태를 회수했다. 스크린샷은 판단 근거로 쓰지 않았다 — 전부 DOM 문자열과
런타임 상태 값이다.

**검사 중 상태를 되돌렸다**: 켜고 끈 Check 취사선택은 전부 복구, `RL.dirty = false`,
1C 토글 off, 검토 답변 폼은 「취소」로 닫았다.

### 화면별 결과

| 뷰 | 렌더 | 콘솔오류 | 상호작용 | 비고 |
|---|---|---|---|---|
| `view-upload` | O | 0 | O | 슬롯 3개(`zone-qmg`·`zone-welder`·`zone-wps`) · 검증 버튼 |
| `view-dashboard` | O | 0 | O | KPI 4 · Check 카드 **29장**(체크박스 29) · 카드본문=드릴다운/체크박스=토글 **둘 다 확인** · 캔버스 3종 실픽셀 |
| `view-results` | O | 0 | O | 50행/페이지 · 87페이지 · 행클릭→모달 · 페이지·스크롤 보존 확인 |
| `view-departments` | O | 0 | O | 부서 7 · 표 3개 · 반복 결함 패턴 섹션 O |
| `view-dept-dashboard` | O | 0 | O | 부서→팀 드릴다운(4,421→902) · Check 토글이 메인과 **독립** 확인 |
| `view-welders` | O | 0 | O | KPI 4 · 필터 칩 5 · 통합 표 · 상세 팝업 · **월별 추이 캔버스 25,928픽셀** · 추이 배지 |
| `view-review` | O | 0 | O | §11 12건 · 상태 배지 · 필터 5 · 답변 폼(textarea) 열림 확인 |
| `view-agents` | O | 0 | O | 카드 5(전용2+서브3) · 이력 22건 · 정의/리포트 모달 · 마크다운 `<table>`5·`<pre>`8 |
| `view-ml-unsup` | O | 0 | △ | KPI 4 · 산점도 14,934px · 히스토그램 106,426px · 이상치 표 · 이탈도 막대 45개. **1C 제외 기준 미확인** (아래 ②) |
| `view-ml-sup` | O | 0 | O | 안내 카드 2(①오탐/②품질) · 시작조건 3 · 1C 토글 동작(0/0 ↔ 875/691) |
| `view-exports` | O | 0 | O | 범위 표 31행(전체1+부서7+팀23) · 필터 칩 3 · 생성/내려받기 버튼 |
| `view-settings` | O | 0 | O | 사번 A551135(관리자) · 부서 수신인 · 팀 수신인 |
| `view-rules` | O | 0 | O | 프로파일 select(TRION FPU*/RUYA FPU) · 카드 31 · 배지·켬끔·판정 로직 · 두께 규칙 편집 폼 |
| `view-logic` | O | 0 | O | Mermaid 3종(노드 28/66/32 · 간선 13/32/15) + 설명 · 정본 문서 탭(목차·본문 68KB·표 60) |

전 화면 순회 중 `window.__errs` = **0건**. CDP `Runtime.exceptionThrown` = 0건.

유일한 콘솔 기록은 페이지 로드 시점의 네트워크 401 하나다:

```
Failed to load resource: the server responded with a status of 401 (Unauthorized)
  @ http://127.0.0.1:8013/api/result
```

JS 예외가 아니다. `window.load` -> `pollStatus()`가 **로그인 전에** `/api/result`를
부르고 `try/catch`가 삼킨다(`app.js:1091`, `:1108`). 이번 수정과 무관한 기존 동작이라
결함으로 세지 않았다.

### A~G 재검사 — 전부 통과

| | 확인한 것 | 결과 |
|---|---|---|
| **A** Check 14 그룹 뷰 | Check 14 카드 -> 목록 모달 | 그룹 헤더 **20개** · 멤버 58행. 도면번호 표시(`1C-CD310-210-02`) · 「N행 중복」이 실제 멤버 수와 일치(2,2,5,4,3,5,5,4) · WPS 차이가 20건 중 16건에 「WPS TR-FC-G01 vs TR-FC-F01」로 표기. 행 상세에서도 「중복 등록 그룹 비교」 표 + 어긋난 칸 2개 + 「현재」 표식 렌더 |
| **B** 세팅 체크박스 | `toggleRule('101', this.checked)` 생성 확인 후 실제 클릭 | `RL.items[101].enabled` **true->false**, `RL.dirty` **false->true**, 카드 `rl-off`, 머리말 「29개 적용·2개 제외」->「28개 적용·3개 제외」, 「저장하지 않은 변경이 있습니다」. 공통 Check 3도 같이 동작(27/4). **저장하지 않고 원복** |
| **C** 「고치기」 | `editCheckRule('103')` 클릭 | 폼이 채워짐 — key=`thk-mat-kl-low` / name=`재질 KL-20/KL20 두께 허용범위` / range=`6~50` / mat=`KL-20, KL20, KL-0, KL0`, 안내 「Check 103을 고치는 중입니다」, 미리보기 「지금 데이터에 0행」 |
| **D** 반복 패턴 모달 | 두 진입점 모두 클릭 | 부서별 결함: `openRecurringModal('5361', '6')` / 용접사 탭: `openRecurringFromWelderTab('Q520-해양내업생산부','5361','6')`. 둘 다 「382건 · 5개 날짜 · 2025-02-21 ~ 2025-07-01」 모달이 뜸 |
| **E** 따옴표 없는 자리 | 생성된 DOM 속성 전수 확인 | `goToCheckDetail('14')` · `goToCheckDetailScoped('3')` · `toggleDashCheck('103')` · `toggleDeptDashCheck('1')` · `openRecurringFromWelderTab(...)` · `openRecurringModal('D304','14')` · `toggleRule('101',...)` · `editCheckRule('101')` 전부 인용됨. **`deleteCheckRule`만 예외 — 아래 결함 ①** |
| **F** 「공통」 배지 | 대시보드 카드 29장 + 세팅 카드 31장 대조 | Check 8·9·101~105 = **프로젝트**, 나머지 = 공통. 두 화면이 같은 말을 함. `_ckCategory('101')`='프로젝트', `_ckCategory('RUYA1')`='프로젝트' |
| **G** 사전순 정렬 | 세팅 카드 순서 | 공통 1,2,3,4,5,6,7,10,11,12,13,14,16~27 -> 프로젝트 8,9,101,102,103,104,105. 사전순(1,10,101,…)이 아님 |

**추가 수정 확인 — 용접사 Check 6 혼입**

용접사 `D304` 상세에서 C6가 **한 군데도 안 나온다**(`C6` 문자열 0회, pill 40개 중 0개).
숫자가 서로 맞는다:

```
CHECK별 결함 분포   C14 186 + C3 75            = 261
검토 현황           결함확정 75 + 미검토 186    = 261
결함 목록           「전체 261건」
목록 표의 결함 종류  「C3: 75, C14: 186」  (열 이름 = 「결함 종류 (C6 제외)」)
```

**`focusCheckNo` 강조**: Check 14 목록 -> 행 상세로 들어가니 `.cmp-focus` 2개,
해당 행에 「← 검토 대상」 태그가 붙었다.

### 회귀 확인

| 항목 | 결과 |
|---|---|
| `.tool-btn.on` 청록 다섯 자리 | **전부 `rgb(0,128,127)`** — `dash-temp-btn`·`deptdash-temp-btn`·`mlu-temp-btn`·`mls-temp-btn`·`ex-temp-btn`. `.temp-dot`도 같은 색 |
| 대시보드 1C 토글 | 5,516 -> **374** (안내 「임시부재 5,142행을 뺀 374행 기준」). 결함 153(40.9%) + 클린 221(59.1%) = 374. KPI·도넛·Check 카드·주요 KPI 지표가 **전부** 374 기준(C3=0·C6=0·C4=0·C12=22, 도넛의 C12도 22) |
| 지도학습 1C 토글 | 제외 「결함확정 0 / 오탐 0」 · 포함 「결함확정 875 / 오탐 18」. 기본값이 제외. 기준별로 다른 설명 문단이 나감 |
| 비지도학습 1C 토글 | **확인 못 함 — 아래 ②** |
| 사이드바 배지 81 고정 | O (토글과 무관하게 81) |
| `_ckSort` | `['RUYA10','3','101','RUYA1','14','TRION2','2']` -> `['2','3','14','101','RUYA1','RUYA10','TRION2']` |
| `_ckLabel` | `RUYA1`->`RUYA 1` · `RUYA10`->`RUYA 10` · `3`->`3` |
| `_checksParam` | 전부 선택 -> `undefined`(필터 없음) · 전부 해제 -> `'-1'` · 일부 -> `'3,14'` |
| `_ruleOn` | 문자열 식별자 전부 true (`String(no)` 경유) |
| `_dashSelectedChecks` / `_deptDashSelectedChecks` | 둘 다 29개 문자열 원소. Check 3 해제 시 3,334->3,062 / 2,182->2,454 (합 5,516 유지). 부서별에서 C6 해제 시 709->287 / 193->615 (합 902 유지). **두 Set이 서로 전파되지 않음** |
| 키보드 | `/` -> `#txt-filter` 포커스 · `ArrowDown` -> 행 선택 이동 · `Esc` -> 모달 닫힘. `closest is not a function` 없음 |
| 상세 모달 순서 | 「원본 데이터 (엑셀 원문)」 -> 「중복 등록 그룹 비교」 -> 「기준값 / 실측값 비교 및 검토」 |
| 목록 복귀 | 「‹ 목록으로 돌아가기」(`_mckReopen()`) 정상. 상세 결과 3페이지에서 열고 닫으니 **페이지 3 · 스크롤 600 그대로** |
| 모달 분리 | `agent-modal`이 뜰 때 `detail-modal`은 `display:none` 유지. 서로 간섭 없음 |

### 발견된 오류

#### 1. 「빼기」 버튼의 두 번째 인자에 따옴표가 없다 — E 목록에서 빠진 자리

```
frontend/static/js/app.js:871-872   (_rlCardHtml)

  '<button class="btn btn-sm" onclick="deleteCheckRule(\'' + _jsq(i.key || '') +
    '\',' + i.check_no + ')">빼기</button>'
                  ^^^^^^^^^^^^^^ 따옴표 없음
```

같은 카드의 다른 두 자리는 고쳐졌는데(`editCheckRule('101')` · `toggleRule('101', …)`)
여기만 남았다.

**지금 화면에서는 안 터진다.** TRION FPU의 프로젝트 규칙이 옛 번호(101~105)뿐이라
`deleteCheckRule('thk-mat-kt40',101)`이 되어 유효한 JS다. 실제 생성된 속성:

```
고치기 :: editCheckRule('101')
빼기   :: deleteCheckRule('thk-mat-kt40',101)
```

**서버가 지금 발급하는 식별자에서는 터진다.** `project_checks.make_id()`가
프로파일 이름 + 순번을 붙이므로(`backend/services/project_checks.py:116-122`),
TRION FPU에서 새 규칙을 만들면 `TRIONFPU1`이 된다. 그 값으로 같은 함수를 돌려 봤다:

```js
_rlCardHtml({check_no:'TRIONFPU1', key:'thk-test', editable:true, ...})
  -> 고치기 :: editCheckRule('TRIONFPU1')            (정상)
  -> 빼기   :: deleteCheckRule('thk-test',TRIONFPU1)

new Function("deleteCheckRule('thk-test',TRIONFPU1)")()
  -> RUNTIME_ERROR: ReferenceError: TRIONFPU1 is not defined
```

- **재현 조작**: 프로젝트 세팅 탭에서 새 두께 규칙을 저장한 뒤 그 카드의 「빼기」를 누른다.
- **증상**: 콘솔에 `ReferenceError`만 나고 확인창도 안 뜬다. 사용자에게는 「버튼이 안 눌린다」로 보인다.
- **의심 위치**: `frontend/static/js/app.js:872`
- `deleteCheckRule(key, no)`에서 `no`는 확인창 문구와 안내 메시지에만 쓰인다
  (`app.js:771-782`) — 삭제 자체는 `key`로 하므로 인용만 붙이면 된다.

#### 2. 비지도학습 탭이 「1C 도면이 없다」고 말하는데, 같은 결과가 5,142행이라고 말한다

회귀 기준으로 받은 「제외 374행 / 4건」을 확인할 수 없었다. 화면에는 이렇게 나온다:

```
임시부재(1C 도면) 제외   [버튼 disabled]
이번 물량에는 1C 도면이 없어 두 기준이 같습니다
```

그런데 **같은 서버의 같은 결과**가 다른 곳에서는 정반대로 말한다:

```
S.result.temp_judged_rows      = 5,142     (판정 대상 5,516의 93.2%)
대시보드 1C 토글 안내           「임시부재 5,142행을 뺀 374행 기준입니다」
검사 로직 도식                  「임시부재(1C) 5,142행 · 화면 토글로만 제외」
Check 14 그룹 뷰의 도면번호      1C-CD110-210-10, 1C-CD310-210-02 ...
```

원인은 화면이 아니라 **응답에 그 블록이 없는 것**이다. `/api/result`를 직접 떠서 확인했다:

```
GET /api/result  ->  200
  ml.unsupervised 의 키 = ['available', 'meta', 'detail']
  'excl_temp' in ml.unsupervised  ->  false
```

`verifier.py:2843-2848`은 `excl_temp`를 **항상** 싣는다(1C가 없으면 `available:false`로).
키 자체가 없다는 것은 이 회차가 `excl_temp` 도입 커밋(`0de68de`) **이전 코드로 판정된
회차**라는 뜻이다. 샌드박스 DB는 11:23에 복사됐고(사용자 서버의 마지막 회차), 화면이
적는 검증 시각은 「2026-08-15 11:27」이다.

- **이번 수정(`CHECK_META` 문자열화)이 만든 것이 아니다.** 프론트 변경이 서버 응답에서
  키를 지울 수 없고, 지도학습 탭의 1C 토글은 같은 데이터 위에서 정상 동작한다.
- 다만 화면 문장 자체는 **자신 있게 틀린 말**이다. `_mluSyncTempBtn()`이 `excl_temp`의
  유무만 보고 「1C 도면이 없다」로 단정한다(`app.js:6112-6113`).
  `S.result.temp_judged_rows`와 대조하면 「1C는 5,142행 있는데 이 회차에는 제외 모델이
  만들어지지 않았다」로 갈라 말할 수 있다. CLAUDE.md가 경계하는 「그럴듯한 문장이라 더
  나쁘다」에 해당한다.
  - 의심 위치: `frontend/static/js/app.js:6101-6120` (`_mluSyncTempBtn`)
- **확인하려면 재검증이 필요한데 이 에이전트는 `/api/verify`를 부르지 않는다.**
  판정을 돌려야 하는 확인이라 `qc-data-verifier` 몫이다.

#### 3. (경미) 에이전트 리포트 모달에서 인라인 코드(백틱)가 글자 그대로 나온다

리포트 모달의 표·코드블록은 실제 `<table>`(5개) · `<pre>`(8개)로 렌더된다. 다만 `<code>`는
0개이고, 본문의 인라인 코드가 백틱째 문단에 남는다. `_mdToHtml()`이 인라인 코드를 지원하지
않는 것으로 보인다. 이번 수정과 무관한 기존 동작이고 읽는 데 지장은 없어 참고로만 적는다.

### 확인하지 못한 것

- **비지도학습 「1C 제외」 기준의 수치**(374행 / 4건) — 위 2. 결과에 데이터가 없다.
- **문자열 식별자(`RUYA1` 꼴) 규칙의 화면 동작 전반** — 이 프로파일에는 옛 번호(101~105)만
  있어 실물로 못 봤다. `_ckSort`·`_ckLabel`·`_ckCategory`·`_ruleOn`·`_rlCardHtml`은
  가짜 값을 넣어 함수 단위로 확인했고, 그 과정에서 결함 1이 드러났다.
- **파일 업로드·검증 실행** — 쓰기 조작이라 하지 않았다. 업로드 화면은 렌더만 확인했다.
- **부서/팀 메일 발송, 범위별 Excel 생성** — 쓰기·외부 연동이라 버튼 존재만 확인했다.

### 정리

- `_test_*.html`을 **만들지 않았다.** 검사용 임시 사본 대신 CDP `Runtime.evaluate`로
  페이지에 직접 물었다. `frontend/`에 남은 `_test_*` 파일 없음, `git status` 깨끗함.
- 헤드리스 Edge와 임시 프로필은 스크래치패드에만 있다(저장소 밖).
- 서버 상태를 바꾸지 않았다 — 검증 미실행, 규칙 미저장, 검토 답변 미저장, 프로파일 미전환.
  검사 중 켜고 끈 Check 취사선택은 전부 원복했고, 종료 시 `RL.dirty = false`,
  `dashCheckSel`·`deptDashCheckSel` 각 29개, 1C 토글 off를 실측으로 확인했다.
