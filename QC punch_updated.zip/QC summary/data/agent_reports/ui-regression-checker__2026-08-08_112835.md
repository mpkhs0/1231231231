---
agent: ui-regression-checker
run_at: 2026-08-08 11:28:35
verdict: FAIL
summary: 12개 화면 콘솔 오류 0건 · Check 16/17 배지 4개 테마 전부 정상 · 그러나 _fillRawSlot() 경합으로 다른 행의 엑셀 원문이 표시되고 검토 기록에 잘못 저장되는 것을 실증
---

## 판정: FAIL

콘솔 오류는 12개 화면 전부 0건이다. 그러나 **B(원본 데이터 지연 로딩)에 경합 결함이 있어,
다른 행의 엑셀 원문이 화면에 표시되고 그 상태로 검토 기록에 저장되는 것을 실증했다.**
예외가 나지 않으므로 콘솔만 봐서는 발견되지 않는다.

### 실행 조건

| 항목 | 값 |
|---|---|
| 서버 PID / 포트 | 5840 / 8001 (uvicorn, host 0.0.0.0) |
| 프로세스 StartTime | 2026-08-08 10:50:40 |
| app.js mtime | 2026-08-08 10:39 -> 프로세스가 더 나중 (OK) |
| backend/routers/verify.py mtime | 2026-08-08 10:45 -> 프로세스가 더 나중 (OK) |
| app.js md5 (디스크) | dc0d20ec40874c148537cd02f1975fda |
| app.js md5 (서버 응답) | dc0d20ec40874c148537cd02f1975fda — **일치** |
| style.css md5 | a15433ff73cfff6cd2769707ec20d6ab 양쪽 일치 |
| node --check app.js | v24.16.0 / **통과** |
| /api/status | done · excel_status=ready |
| /api/result 크기 | 6,984,884 B (6.66MB) — 18MB에서 축소 확인 |
| 행 회계 | judged 5,516 / flagged 3,426 / unworked 4,475 — 지시된 값과 일치 |
| 브라우저 | Edge 151.0.4129.59 headless=new, **CDP 실시간 구동** (virtual-time-budget 미사용) |
| 프로필 | 전용 user-data-dir 신규 생성, 로그인 A551135(관리자) localStorage 주입 |

검증 방식은 CDP Runtime.evaluate 폴링이다. 판단 근거는 실제 DOM 문자열 · 런타임 상태 값 ·
getImageData() 픽셀 계수이며, 스크린샷은 보조로만 썼다.

### 화면별 결과

| 뷰 | 렌더 | 콘솔오류 | 상호작용 | 비고 |
|---|---|---|---|---|
| view-upload | OK | 0 | OK | file input 3개, 검증 실행/캐시 삭제 버튼. 업로드 슬롯 3개(QMG/용접사/WPS) 모두 파일명 표시 |
| view-dashboard | OK | 0 | OK | KPI 4, **ck-card 16개**(1~14,16,17), 캔버스 3종 실픽셀. 체크박스=토글(16->15, 모달 안 뜸) / 카드본문=드릴다운(모달 45행) 분리 확인 |
| view-results | OK | 0 | OK | 50행/페이지, pbtn 5. 행클릭 -> 모달, **페이지 3 보존 확인** |
| view-departments | OK | 0 | OK | 표 3개(용접사 50 / 반복패턴 41 / 결함목록 50). openRecurringModal 클릭 -> rcp 50행 |
| view-dept-dashboard | OK | 0 | OK | ck-card 16, 부서 -> 팀 드릴다운 시 Check 선택 15 유지. 메인(dashCheckSel=16)과 독립 확인 |
| view-welders | OK | 0 | OK | KPI 4, 칩 5개, 표 100행. 상세팝업 wd-trend 1462x220 **11.5% 실도색**, 추이 배지 tv-good 개선 55%p / tv-flat 유지 렌더 |
| view-review | OK | 0 | OK | 11장 10건(미결2/잠정3/완료5/반영대기0), rv-status 배지, 칩 필터(미결 -> 2건), 답변폼 textarea 2 + 문서에 기록 버튼 |
| view-agents | OK | 0 | OK | ag-card 5개, 이력 9행. 카드 -> 정의모달(pre 11, h2 15), 이력행 -> 리포트모달(**table 6개**). agent-modal / detail-modal 간섭 없음 |
| view-ml-unsup | OK | 0 | OK | KPI 4, mlu-scatter 7.6% / mlu-hist 55.3% 실도색. 호버 툴팁 mlu-tooltip 동작, 클릭 -> mlu-modal, 행선택 -> mlu-dev 채워짐 |
| view-ml-sup | OK | 0 | n/a | 안내 화면. mls-card 2개(확인된 사실 표 + 시작 조건), 시작조건 3항목 확인 |
| view-exports | OK | 0 | 부분 | 범위 31행(전체1+부서7+팀23), 칩 3개, 생성/선택 생성/선택 내려받기. **실제 Excel 생성/발송은 미실행**(부작용 회피) |
| view-settings | OK | 0 | 부분 | 사번 1행(A551135/관리자), 부서 수신인 7개 부서 목록. **저장 조작 미실행** |

다크 테마(data-theme=dark)로도 12개 화면 전수 재순회 — **콘솔 오류 0건**, 캔버스 전부 다크 팔레트로 재도색 확인.

---

## 발견된 오류

### [치명] 1. _fillRawSlot() 경합 — 다른 행의 엑셀 원문이 표시되고, 그대로 검토 기록에 저장된다

**의심 코드 위치**: frontend/static/js/app.js:1085-1100

    async function _fillRawSlot(rowNum) {
      let raw = _rawCache.get(rowNum);
      if (!raw) {
        try {
          const d = await apiFetch("/api/result/row/" + rowNum);   // <- 이 await 사이에 모달이 바뀔 수 있다
          raw = (d && d.raw) || [];
          _rawCache.set(rowNum, raw);
        } catch (e) { raw = []; }
      }
      S._modalRaw = raw;                                  // <- 요청 토큰 검사 없이 무조건 덮어쓴다
      const slot = document.getElementById("raw-grid-slot");
      if (slot) slot.innerHTML = _buildRawGridHtml(raw);  // <- 슬롯 존재만 볼 뿐, 그 슬롯이 rowNum의 것인지 보지 않는다
    }

(실제 소스는 템플릿 리터럴을 쓴다. 위는 인용 편의상 문자열 결합으로 바꿔 적었다.)

주석은 "그 사이에 사용자가 다른 모달을 열었으면 슬롯이 이미 없다"고 적혀 있으나 **사실이 아니다.**
openFlagDetail()은 detail-modal-body를 통째로 다시 그리면서 _rawSlotHtml()로 **같은 id
raw-grid-slot을 다시 만든다**. 따라서 늦게 도착한 응답은 없어진 슬롯이 아니라
**새 행의 슬롯**을 찾아서 채운다. rowNum을 대조하지 않으므로 조용히 덮어쓴다.

**재현 조작** (결정적 재현 — CDP로 A행 요청만 지연시켜 실행):

1. 행 A(1057)를 클릭한다 -> /api/result/row/1057 요청이 나간다 (느린 응답)
2. 응답 도착 전에 모달을 닫고 행 B(1177)를 클릭한다 -> B는 즉시 채워짐 (제목 = 행 1177 · Joint 1S01L002)
3. 뒤늦게 A의 응답이 도착한다

**실측 결과**:

    [B 열림]     제목=행 1177 · Joint 1S01L002   slot Joint=1S01L002   <- 정상
    [A 도착 후]  제목=행 1177 · Joint 1S01L002   slot Joint=1S03AT     <- 화면이 뒤바뀜
                 S._modalRaw Joint = 1S03AT  (행 1057의 원문)

제목은 여전히 **행 1177**인데, 그 아래 원본 데이터(엑셀 원문) 패널은 **행 1057의 값**을 보여준다.
콘솔 오류 0건. 사용자가 알아챌 단서가 없다.

**데이터 손상까지 확인함.** 이 상태에서 검토 의견을 저장하면
(saveFlagFeedback() -> app.js:1250 의 row_raw: S._modalRaw) 다음이 data/flag_feedback.json에
실제로 기록되었다:

    검토키    : 1C-CD000-260-05 | 1S01L002 | TR-FC-F01 | 4     <- 행 1177 (플래그 객체에서 옴, 맞음)
    row_raw   : 도면 1C-CD000-260-03 · Joint 1S03AT             <- 행 1057 (틀림)

**검토 기록의 키와 첨부된 원본 스냅샷이 서로 다른 조인트·다른 도면을 가리킨다.**
CLAUDE.md가 경계하는 "검토 기록이 무관한 조인트에 붙는" 사고와 같은 계열의 손상이,
이번에는 키가 아니라 스냅샷 쪽에서 발생한다.

**영향 범위**: openFlagDetail()(app.js:1322) · openUnworkedRawDetail()(app.js:1395) 양쪽 모두.
Check 14 그룹표의 형제행 이동처럼 **모달 안에서 연속 이동하는 경로**에서 특히 걸리기 쉽다.

**참고 — 캐시가 위험을 감춘다.** 같은 행 재방문은 캐시 히트라 즉시 채워져 경합이 나지 않는다
(캐시 동작 자체는 정상 확인: 같은 행 2회 오픈 시 /api/result/row/1543 요청 **1회**).
사내망 지연이 낮으면 평소엔 드러나지 않다가, 느린 시점에만 조용히 틀린 기록을 남긴다.

### [경미] 2. Check 카드 안내 문구가 "14가지 검사"로 남아 있다

**위치**: frontend/static/js/app.js:578, frontend/index.html:229

카드는 실제로 **16개**(1~14, 16, 17)가 렌더되는데 힌트만 14가지 검사다.
같은 계열로 app.js:67, app.js:433의 주석도 "14개 전부 선택"으로 남아 있다.
동작에는 영향 없음(선택 개수 비교는 CHECK_META.length를 쓰므로 정상).

---

## 확인된 항목 (「고쳤다」고 한 것을 실제 화면에서 대조한 결과)

**A. Check 16·17 배지 — 정상.**

- CHECK_META.length = 16, 실제 no 배열 = [1..14, 16, 17] — 15 결번 유지 확인
- **CHECK_META를 인덱스로 다루는 코드는 없다.** 대괄호 인덱스 접근 grep 결과 0건이며
  모든 접근이 find(c => c.no === n) 또는 map/filter다. 15 결번으로 인한 오프셋 붕괴 없음
- Check 17 배지 실렌더 50건, 클래스 pill p-navy:
  - 라이트(data-theme=light) -> 글자 rgb(31,56,100) / 배경 rgba(31,56,100,.09)
  - 다크(data-theme=dark) -> 글자 rgb(143,169,216) / 배경 rgba(143,169,216,.14), body는 rgb(12,17,26)
  - data-theme 미지정(미디어쿼리 기본) -> 라이트 값 정상 해석
  - **어느 테마에서도 무색이 아니다.** p-olive도 동일하게 4개 블록 전부 해석됨
  - 단, Check 16은 실데이터 0건이라 **배지 실렌더는 미확인**(CSS 계산값으로만 확인)

**B. 원본 데이터 지연 로딩 — 5개 중 4개 통과, 1개 실패.**

1. **모달 원본 패널 채워짐 — OK.** 결함 행: raw-cell 29개, 불러오는 중 문구 잔류 없음.
   미작업 행(27): raw-cell 29개 정상. 로딩 -> 실데이터 전환도 확인
   (즉시 스냅샷 loading:true -> 3초 후 loading:false, rawCells:29)
2. **S._modalRaw 채워짐 — OK.** 길이 29. 실제 저장까지 실행해 POST 본문 확인:
   본문 키에 row_raw 포함, row_raw_len=29, 서버 응답 "마지막 검토: A551135 · 2026-08-08 11:16"
3. **빠르게 여닫을 때 — FAIL.** 위 [치명] 1 참조. 예외는 안 나지만 엉뚱한 행의 원문이 채워진다
4. **캐시 — OK.** 같은 행 2회 오픈 시 네트워크 요청 1회
5. **Check 14 상세 — OK.** c14-gtbl 1개 / 그룹행 2 / c14-cell-diff 2칸 강조 /
   c14-here(현재) 표시 / 원본 패널 29셀 정상. 형제행 클릭 -> 행 2147로 이동, 원본 패널 29셀 재채움

**C. result.row_raw 잔재 — 없음.**

- app.js에서 result.row_raw 참조 0건 (S._modalRaw와 POST body 외 없음)
- /api/result 응답에 row_raw 키는 남아 있으나 **빈 dict(len 0)** — 화면이 훑는 곳 없음
- 행 회계 무손실: judged 5,516 / flagged 3,426 / unworked 4,475 / total 9,995

**그 외 확인.**

- 상세 모달 순서: 원본 데이터 innerHTML idx **71** < 기준값 idx **5087** — 원본이 위, 검토가 아래 (OK)
- 목록으로 돌아가기: _rcpReopen() 후 rcp 50행 복원, 상세결과 탭 page 3 보존 (OK)
- Check 14 그룹 뷰(mck): 그룹헤더 c14-ghead 20개 + 데이터행 58개, 헤더에 **도면번호** 열 존재,
  _c14GroupKey는 drawing_no + joint_no (도면번호 포함 — 4요소 키 원칙과 정합),
  WPS NO / WPS PROCESS는 별도 열로 분리 표시 (OK)
- 키보드: 방향키 행 선택(1행 활성), 슬래시 -> txt-filter 포커스, Enter -> 모달, Esc -> 닫힘.
  **e.target.closest is not a function 재발 없음** (OK)
- mlu-modal / agent-modal / detail-modal 상호 간섭 없음 (OK)

---

## 미확인 / 미검사

정직하게 적는다. 아래는 통과가 아니라 미확인이다.

- **Check 16 배지 실렌더** — 실데이터 0건이라 화면에 나오지 않는다. CSS 계산값만 확인했다
- **실제 파일 업로드 · 검증 재실행** — 서버 상태를 바꾸므로 실행하지 않았다
- **범위별 Excel 생성 / 부서 메일 발송** — 생성 1분 소요 + Outlook 초안이 열리므로 실행하지 않았다.
  버튼 존재와 표 렌더만 확인했다
- **설정 탭 저장 조작**(사번 추가/삭제, 수신인 저장) — 영속 데이터 변경이라 실행하지 않았다
- **11장 답변 실제 기록** — 폼이 열리고 문서에 기록 버튼이 나오는 것까지만 확인했다.
  누르면 QC_검사로직_상세분석.md가 수정되므로 중단했다
- **부서별 결함 탭 첫 두 표의 행 클릭** — onclick이 없어 클릭 대상이 아님을 확인했으나
  의도된 설계인지는 코드로만 판단했다
- **창 크기 변경 / 실제 마우스 드래그** — 합성 이벤트로만 검증했다

---

## 정리

- 생성한 _test_*.html: **없음** (CDP 실시간 구동 방식이라 임시 사본이 불필요했다).
  frontend/_test_*.html, frontend/static/_test_*.html 부재 확인 완료
- git status --porcelain -> **클린**. 프론트엔드 소스 및 저장소 파일 수정 0건
- 헤드리스 Edge 프로세스 종료 완료

### 되돌려야 할 테스트 데이터 (data/flag_feedback.json, 총 4건 중 2건이 본 검사 산물)

    1C-CD000-290-05|1S02B001|TR-FC-F01|17   remark=ui-regression-checker 자동검사 (무시해도 됩니다)
        -> row_raw 정상 (도면 1C-CD000-290-05 / Joint 1S02B001)

    1C-CD000-260-05|1S01L002|TR-FC-F01|4    remark=race-test (ui-regression-checker)
        -> row_raw 손상 (도면 1C-CD000-260-03 / Joint 1S03AT)   <- [치명] 1의 증거물

두 번째 레코드는 **경합 결함의 실물 증거**다. 결함을 고친 뒤 삭제할 것을 권한다.
