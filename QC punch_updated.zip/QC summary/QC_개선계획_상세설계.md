# QC Summary 개선 계획 — 상세 설계

> 2026-08-08 작성. 원본 `.xlsm`의 「매크로 로직」 시트, QMG 78열, WPS 목록 37열,
> 용접사 DB 80열을 전수 대조한 점검 결과를 실행 계획으로 옮긴 문서다.
> **2026-08-08: 12개 항목 전부 적용하기로 확정.** 대상 데이터는 30만 건 이상까지 상정한다.
>
> **이 문서는 계획이다.** 각 항목은 «근거 → 설계 → 위험 → 검증» 순으로 적는다.
> 근거 없이 "좋아 보여서" 넣은 항목은 없다. 실측치는 전부 2026-08 시점
> 실데이터(10,029행 / 판정대상 5,516행) 기준이다.

---

## 착수 전에 정정할 것 두 가지

설계를 시작하며 앞선 점검 보고의 두 대목을 바로잡는다.

### 정정 1 — WPS의 `Test Items`는 «생산 NDT 요구»가 아니다

점검 보고에서 *"WPS W열(Test Items)에 요구 NDT가 적혀 있는데 안 본다"*고 했는데,
실제 값을 보면 **PQR 자격시험 항목**이다:

```
- NDE : VT/MT/UT   - Trans. T.S : 2EA | - Bend : Side 4EA | - Impact Test : 3set @ -40℃
```

인장·굽힘·충격시험과 나란히 있다. 즉 «자격시험 때 수행한 NDE»이지 «이 WPS로 시공한
생산 용접에 요구되는 NDT»가 아니다. 생산 NDT 요구는 **QMG의 NDT Extent(S/T/U/V열)** 에
있고, 이건 이미 데이터에 있다.

→ **권고 5번의 근거를 `WPS Test Items`에서 `QMG NDT Extent`로 바꾼다.**

### 정정 2 — `TR-FC-G03`는 «존재하지 않는 WPS»가 아니다

WPS 목록에는 **등재되어 있다**(G03, G04, G11 등). 실데이터에서 **시공에 쓰인 적이
없을 뿐**이다. 따라서 Check 5의 지적은 "불가능한 시정 요구"가 아니라
**"이 프로젝트에서 한 번도 쓰지 않은 WPS로의 전환 요구"** 다.

전자보다 약한 표현이지만 여전히 문제다 — 전체 플래그의 26%(1,389건)가
현장에서 실행되지 않는 방향을 가리키고 있다.

---

## 실행 순서 요약

| # | 항목 | 구분 | 선행 | 규모 | 상태 |
|---|---|---|---|---|---|
| 1 | 결과 저장을 SQLite로 | 선결 | — | 대 | **완료** 2026-08-08 (1·2·3단계) |
| 2 | `/api/result` 페이지네이션 | 선결 | 1 | 중 | **부분 완료** — row_raw 분리로 −63%. flags 분할은 남음 |
| 3 | 용접사 두께·직경 자격 대조 (Check 15) | 검사(보험) | — | 중 | **보류** — 결번 처리 |
| 4 | Check 5 재정의 | 검사 | §11-2 현업 답변 | 소 | **완료** 2026-08-08 (1,389→426) |
| 5 | NDT Extent 이행 대조 (Check 16) | 검사 | — | 중 | **완료** 2026-08-08 (0건) |
| 6 | VT 미수행 검출 (Check 17) | 검사 | — | 소 | **완료** 2026-08-08 (99건) |
| 7 | 협력사 축 추가 | 확장 | — | 중 | |
| 8 | 용접봉(Consumable) 대조 (Check 18) | 확장 | — | 중 | |
| 9 | 검증 이력 비교 탭 | 확장 | 1 | 중 | |
| 10 | `requirements.txt` | 정비 | — | 소 | **완료** (`e7d63f1`) |
| 11 | §5 대응표 정정 | 정비 | — | 소 | **완료** (`e7d63f1`) |
| 12 | WPS 번호 하드코딩 제거 | 정비 | — | 소 | **완료** (`e7d63f1`) |

> **4번은 «§11-2 현업 답변»을 선행으로 잡아 두었으나, 답변 없이 착수했다.**
> 답변이 필요한 것은 «규칙의 취지»(트리거를 NDT Cat 코드로 볼지 실제 NDT 강도로 볼지)인데,
> 이번에 한 일은 그것과 무관한 «시정 불가능한 지적 제거»였기 때문이다. §11-2는 계속 미결이다.
>
> **3번은 결번으로 처리했다.** 위반 0건의 원인이 «지금 문제가 없다»가 아니라 «자격 DB에
> 유한한 두께 상한을 가진 30명이 이번 물량에 투입되지 않음»이라, 만들어도 대조할
> 조합이 0건이다. 대조할 값이
> 채워진 뒤에 다시 판단한다. Check 번호는 재사용하지 않는다(검토 기록 키 충돌).
>
> **Check 16·17의 유예 30일은 실데이터 분포에서 역산한 값이지 현장 규정이 아니다.**
> §11-10으로 추적한다.

**10·11·12는 선행 조건이 없고 위험이 낮아 언제든 먼저 처리해도 된다.**
3·5·6은 서로 독립이라 한 번에 묶어도 된다.

> **설계 중 확인된 사실**: 3·5는 실데이터에서 **검출 0건**이다(각 항목에 실측 근거
> 기재). 두 항목은 «지금 문제를 잡는 검사»가 아니라 «앞으로를 위한 감시»다.
> 즉시 효과가 있는 것은 **4(Check 5 재정의, 1,389건)** 와 **6(VT 미수행, 265건)** 뿐이다.
> 이 사실을 모르고 3·5부터 착수하면 "만들었는데 아무것도 안 잡힌다"가 된다.

---

# A. 선결 — 20만 건에서 깨지는 구조

## 1. 결과 저장을 SQLite로

### 근거 (실측)

| 항목 | 현재(1만행) | 20만행 | **30만행** |
|---|---|---|---|
| `data/app_state.json` | 20.3 MB | 406 MB | **609 MB** |
| 직렬화 시간 | 0.19초 | 3.8초 | **5.7초** |
| `/api/result` 응답 | 18 MB | 360 MB | **540 MB** |
| 검증 소요 | 6.3초 | ~2분 | **~3분** |

`_save_app_state()`는 **파일명만 바뀌는 업로드에도 전체를 재직렬화**한다.
30만 건이면 파일 하나 올릴 때마다 6초를 쓴다.

> **2026-08-08 확정**: 검토 대상이 30만 건을 넘는 경우가 있다는 것이 확인됐다.
> 609 MB JSON을 메모리에 통째로 올리고 매번 다시 쓰는 구조는 성립하지 않는다.
> SQLite 전환은 «개선»이 아니라 **동작 조건**이다.

### 설계

`data/qc.db` 하나. ORM은 쓰지 않는다(표준 `sqlite3`).

```sql
-- 검증 회차. 이력 비교(9번)의 기반이기도 하다.
CREATE TABLE run (
  id            INTEGER PRIMARY KEY,
  run_at        TEXT NOT NULL,
  qmg_filename  TEXT, welder_filename TEXT,
  total_rows    INTEGER, deleted_rows INTEGER, active_rows INTEGER,
  unworked_rows INTEGER, judged_rows  INTEGER,
  flagged_rows  INTEGER, clean_rows   INTEGER, total_flags INTEGER,
  meta_json     TEXT          -- ml.meta 등 고정크기 요약
);

CREATE TABLE flag (
  run_id INTEGER NOT NULL REFERENCES run(id) ON DELETE CASCADE,
  row_no INTEGER NOT NULL,
  check_no INTEGER NOT NULL,
  col INTEGER, col_letter TEXT, color TEXT,
  drawing_no TEXT, joint_no TEXT, block TEXT,
  department TEXT, team TEXT, subcontractor TEXT,   -- 7번에서 쓸 열 미리 확보
  welder1_no TEXT, wps_no TEXT, wps_process TEXT,
  material1 TEXT, material2 TEXT,
  thickness1 REAL, thickness2 REAL,
  weld_date TEXT, ndt_date TEXT,
  expected TEXT, actual TEXT, msg TEXT
);
CREATE INDEX ix_flag_run_check ON flag(run_id, check_no);
CREATE INDEX ix_flag_run_dept  ON flag(run_id, department, team);
CREATE INDEX ix_flag_row       ON flag(run_id, row_no);

-- 원본 스냅샷(상세 모달용). 지금 result.row_raw가 차지하던 자리.
CREATE TABLE row_raw (
  run_id INTEGER NOT NULL, row_no INTEGER NOT NULL,
  payload_json TEXT NOT NULL,
  PRIMARY KEY (run_id, row_no)
);

-- 미작업(Check 0)
CREATE TABLE unworked (
  run_id INTEGER NOT NULL, row_no INTEGER NOT NULL,
  drawing_no TEXT, joint_no TEXT, block TEXT, department TEXT, team TEXT
);

-- 집계는 저장하지 않고 쿼리로 만든다. 저장하면 flag와 어긋날 수 있다.
```

**집계를 테이블로 두지 않는 것이 핵심 결정이다.** 지금 `departments`/`welder_info`가
`flags`와 따로 계산돼 있어 «2차 패스 소급 갱신» 문제가 생겼다. SQL 집계로 바꾸면
그 종류의 불일치가 구조적으로 불가능해진다.

```sql
-- 부서별 결함 행수 (기존 dept.defect_rows)
SELECT department, COUNT(DISTINCT row_no) FROM flag WHERE run_id=? GROUP BY department;

-- 용접사 작업성 결함 (Check 6 제외, 행 단위 중복제거) — 지금 파이썬으로 하던 것
SELECT welder1_no, COUNT(DISTINCT row_no) FROM flag
 WHERE run_id=? AND check_no<>6 AND welder1_no<>'' GROUP BY welder1_no;
```

### 이행 전략 — 한 번에 갈아엎지 않는다

```
1단계  verifier는 그대로 dict를 만든다. 저장만 SQLite로 바꾼다(_save_app_state 대체).
       조회 API는 DB에서 읽어 **지금과 똑같은 dict를 조립**해 반환한다.
       -> 프론트 수정 0. 이 단계에서 pytest 157개가 그대로 통과해야 한다.
2단계  집계를 파이썬 계산에서 SQL 쿼리로 옮긴다. qc-data-verifier로 불변식 8종 대조.
3단계  2번(페이지네이션)으로 넘어간다.
```

#### 1단계 완료 (2026-08-08)

`backend/services/result_store.py` 신설. `verifier`·집계·프론트는 **한 줄도 바꾸지 않았다.**

| 확인 | 결과 |
|---|---|
| 실결과(19.9MB) 왕복 동일성 | `save_run` → `load_latest` == 원본 **True** |
| pytest | 195 → **215 passed**(신규 20), 기존 테스트 수정 0 |
| 실데이터 재검증 | Check 건수 전부 동일 |
| 회차 정리 | `KEEP_RUNS=1`, 고아 행 0 |

**계획과 다르게 간 곳 두 군데** (근거는 모듈 독스트링에 기록):

1. `thickness1/2`를 **REAL이 아니라 TEXT**로 뒀다. 실 payload 값이 `"20"` 같은
   문자열이라 REAL로 넣으면 꺼낼 때 `20.0`이 되어 왕복이 깨진다.
2. `flag`에 **`extra_json` 열**을 뒀다. 스키마에 없는 키가 생겨도 조용히 사라지지
   않게 받아 둔다(7번의 `subcontractor`가 이 경로로 먼저 들어올 수 있다).

**설계에 없었는데 필요했던 것**: `run.saved_at`. 결과 Excel과 범위별 Excel이
«지금 결과의 산출물인가»를 판단할 때 `app_state.json`의 파일 mtime을 쓰고 있었는데,
DB는 **파일명만 저장해도 mtime이 움직인다.** 그대로 뒀으면 파일 하나 올릴 때마다
멀쩡한 범위 Excel이 통째로 낡은 것으로 판정돼 1분짜리 재생성이 걸렸을 것이다.

**측정된 이득** — 1단계는 응답 크기를 줄이지 않는다(그건 3단계다). 줄어든 것은
«쓸데없이 다시 쓰는 비용»이다:

| | 옛 방식 | 새 방식 |
|---|---:|---:|
| 파일명만 저장 | 0.193s + 20MB 쓰기 | **0.004s** |
| 결과 존재 확인 | 20MB 파싱 | **0.001s** |

30만 행이면 파일 하나 올릴 때마다 약 **5.8초**를 아낀다.

> **`app_state.json`은 지우지 않았다.** 이관 뒤에도 되돌릴 자리로 남긴다.
> 다만 새 검증은 DB에만 쌓이므로 **JSON은 그 시점부터 낡는다.**
> `tests/conftest.py`의 `real_result`가 DB를 먼저 보도록 함께 고쳤다 —
> 안 그러면 불변식 검사가 조용히 옛 결과를 대상으로 돈다.

#### 2단계에서 확인된 사실 (착수 전 실측)

`departments`가 payload의 16.2%인데, 내용이 **`flags`를 부서별·팀별로 두 번 복제한
것**이다(`departments[부서]['defects']`, `departments[부서]['teams'][팀]['defects']`).
2단계에서 SQL 집계로 옮기면 이 중복이 통째로 사라진다.

| result 키 | 크기 | 비중 |
|---|---:|---:|
| `row_raw` | 11.1 MB | **64.2%** |
| `departments` | 2.8 MB | 16.2% |
| `flags` | 2.5 MB | 14.6% |
| `unworked_list` | 0.6 MB | 3.4% |
| 나머지 전부 | 0.3 MB | 1.6% |

**3단계(페이지네이션)의 목표는 `row_raw` 64%를 응답에서 빼는 것이다.** 화면은
사용자가 클릭한 한 행만 쓰는데 지금은 7,901행 전체를 실어 보낸다.

#### 2단계 완료 (2026-08-08) — 파생 집계는 저장하지 않는다

`stats`·`total_flags`·`flagged_rows`·`defect_trend_by_date`와 부서/팀의
`defect_rows`·`check_stats`·`defects`·`defect_trend_by_date`를 **저장하지 않고
꺼낼 때 flag/defect_row에서 다시 만든다.** 저장하지 않으면 어긋날 수가 없다.

| | 값 |
|---|---|
| 실결과 왕복 | 값·리스트 순서 **전부 동일** |
| DB 크기 | 21.6 MB → **18.9 MB** (중복 제거분) |
| 저장된 집계를 일부러 틀리게 넣어도 | 꺼낼 때 flag 기준으로 바로잡힌다(테스트로 고정) |

**계획을 그대로 따랐으면 틀렸을 곳 두 군데** — 실데이터를 재보고 발견했다:

1. **분모는 flag에서 만들 수 없다.** 깨끗한 판정 행은 payload 어디에도 없다.
   `total_rows`를 flag에서 세면 `defect_rows`와 같아져 **부서 결함률이 전부
   100%**가 된다. `total_rows`·`unworked_rows`·`welder_totals`는 저장한다.
2. **계획 문서의 예시 쿼리가 용접사 2~4번을 통째로 누락한다.**
   ```sql
   SELECT welder1_no, COUNT(DISTINCT row_no) FROM flag WHERE check_no<>6 ...
   ```
   `flags`에는 `welder1_no`밖에 없는데 판정 엔진은 **그 행의 용접사 4명 전원**에게
   결함을 귀속시킨다. 용접사 집계는 SQL로 옮기지 않았다.

**설계에 없었는데 필요했던 것**: `defect_row` 테이블의 `seq`.
부서 결함 목록의 순서를 row 번호로 대신할 수 없다 — 2차 패스(Check 13/14)에서
처음 결함이 된 행이 목록 **끝**에 붙기 때문이다(실데이터 7개 부서 중 5개가 row
정렬이 아니었다). 화면에 보이는 표라 저장 방식을 바꾸며 조용히 흔들면 안 된다.

**«같음»의 정의를 명시했다.** 값과 리스트 순서는 보장하고, **객체 키 순서는 보장하지
않는다**(`check_stats`의 키 순서는 «판정 중 처음 만난 Check 순서»라 flag에서 유도할
수 없다). 프론트는 `stats["13"]`처럼 키로 조회하므로 소비자가 없다. 아무도 보지 않는
것을 위해 버킷마다 순서를 저장하지는 않는다.

#### 3단계 완료 (2026-08-08) — row_raw를 응답에서 뺐다

`/api/result`가 더 이상 엑셀 원문 스냅샷을 싣지 않는다. 상세 모달을 열 때
`GET /api/result/row/{row}`로 그 행만 가져온다(캐시 있음).

| | 전 | 후 |
|---|---:|---:|
| `/api/result` 응답 | 18 MB | **6.66 MB** (−63%) |
| 행 하나 조회 | — | 1.5 KB |
| 30만 행 환산 | ~540 MB | ~200 MB |

프론트 변경은 두 곳뿐이었다(`openRowDetail`, `openUnworkedRawDetail`). 동기 렌더링
자리에 슬롯을 두고 도착하면 채운다. **검증 직후에도 메모리에서 `row_raw`를 떼어낸다** —
한쪽만 갖고 있으면 «방금 검증한 직후»와 «재시작 후 복원»이 다르게 동작한다.

#### 4단계 완료 (2026-08-08) — 부서/팀 결함 목록의 중복 제거

3단계 뒤 남은 6.03MB를 재보니 **가장 큰 덩어리가 `flags`가 아니라 그 복사본**이었다.

| 키 | 크기 | 비중 |
|---|---:|---:|
| `departments` | 2,788 KB | **45.2%** |
| ├ 부서 `defects` | 1,369 KB | |
| └ 팀 `defects` | 1,369 KB | |
| `flags` | 2,521 KB | 40.8% |
| `unworked_list` | 590 KB | 9.6% |
| 나머지 전부 | 273 KB | 4.4% |

부서·팀의 `defects`는 **같은 결함을 두 번 더 실어 보내는 것**이다(합 2,737 KB =
남은 payload의 44%). 2단계에서 이미 저장은 하지 않게 됐지만, 꺼낼 때 다시 만들어
응답에 싣고 있다.

**실데이터 전수 대조 결과 `flags`만으로 100% 재구성된다** (부서 3,426건 · 팀
3,426건, 불일치 0). 각 flag가 이미 `department`/`team`과 머리말 필드
(`joint_no`·`block`·`wps_no`·`weld_date`·`welder1_no`)를 전부 들고 있기 때문이다.

**설계**: 항목 대신 **행 번호 목록만** 보낸다.

```
departments[부서].defect_row_order  = [314, 380, 381, ...]
departments[부서].teams[팀].defect_row_order = [...]
```

화면은 이미 받은 `flags`를 행별로 묶어 그 순서대로 조립한다(부서/팀당 1회 메모이제이션).

| | 지금 | 설계 |
|---|---:|---:|
| 부서·팀 결함 목록 | 2,737 KB | **40.5 KB** (−98.5%) |
| `/api/result` 전체 | 6.03 MB | **약 3.3 MB** |

**행 번호 목록을 «순서 힌트»로 보내는 이유**: 화면에서 `flags`를 행 번호로 정렬해
만들면 순서가 바뀐다. 2차 패스(Check 13/14)에서 처음 결함이 된 행이 목록 끝에
붙기 때문이다(7개 부서 중 5개). 그 순서는 `defect_row.seq`에 이미 있고, 40KB면
그대로 보내는 편이 화면 동작을 바꾸지 않는 가장 싼 방법이다.

**소비처는 두 곳뿐이다** — `_deptDashAggregate()`(부서 대시보드 집계),
`renderDeptDefectTable()`(부서별 결함 표).

**실측 결과**

| | 전 | 후 |
|---|---:|---:|
| `/api/result` | 6.66 MB | **3.59 MB** (−46%) |
| 최초(1단계 전) 대비 | 18 MB | **−80%** |
| 30만 행 환산 | ~540 MB | ~110 MB |

프론트 파생(`_bucketDefects`)이 서버 파생(`expand_defects`)과 **바이트 단위로
동일**함을 실데이터로 대조했다(부서 7 + 팀 23, 불일치 0).

**소비처가 두 곳이 아니라 세 곳이었다** — 부서 리포트 **메일 본문**도
`dept_data['defects']`를 읽고 있었다(`settings.py`). `unworked_list`에서 겪은 것과
같은 함정이다. 그래서 파생 규칙을 `result_store.expand_defects()` 한 곳에 두고
화면·메일이 같은 것을 쓰게 했다 — 갈라지면 «메일에 적힌 건수»와 «화면에서 본
건수»가 달라진다.

**같은 종류의 어긋남을 세 번째로 만났고, 이번엔 구조로 막았다**

`row_raw`를 뺄 때(3단계) «복원 경로만 가벼워지고 신규 검증 경로는 무거운» 버그가
있었다. 4단계에서 **똑같은 일이 또 일어났다**. 원인이 같다 — 판정 엔진이 만든
dict를 화면에 그대로 내보내기 때문이다.

이제 **화면에 내보내는 것은 반드시 저장소를 한 번 거친 결과**로 통일했다:

```python
_save_result(result)
published = result_store.load_latest(include_row_raw=False) or result
_state["result"] = published
```

한쪽만 고치는 방식으로는 다음 항목에서 또 걸린다.

#### `unworked_list`(590 KB, 9.6%)는 함께 손대지 않는다

화면만 쓰는 줄 알았는데 **결과 Excel의 '미작업' 시트도 쓴다**
(`excel_report.py`가 `result["unworked_list"]`를 그대로 훑는다). 응답에서 빼려면
Excel 생성 경로가 저장소에서 직접 읽도록 바꿔야 한다 — 9.6%를 위해 결합을 늘리는
거래라 44%짜리를 먼저 하고 따로 판단한다.

> `row_raw`를 뺄 때 Excel 생성이 원본 워크북을 다시 읽어서 문제가 없었던 것과
> 대비된다. **응답에서 무언가 빼기 전에 Excel 쪽 소비처를 반드시 확인할 것.**

#### 5단계 완료 (2026-08-08) — 미작업 목록 분리

`/api/result` 3.59MB -> **2.99MB**. `GET /api/result/unworked?offset=&limit=&q=`로
한 페이지(50건 = 7.7KB)씩 가져간다.

**결과 Excel의 '미작업' 시트도 함께 옮겼다** — `excel_report`가
`result["unworked_list"]`를 그대로 훑고 있었다. 응답에서 빼기 전에 Excel·메일
소비처를 확인한다는 규칙이 두 번째로 값을 했다.

#### 6단계 — flags 서버 페이지네이션

**측정이 방향을 바꿨다.** `flags`가 남은 payload의 84%(2,521KB)인데, 필드를
줄이는 것으로는 30만 건이 풀리지 않는다:

| 절감 후보 | 크기 |
|---|---:|
| `check_name` (`check_no`로 100% 파생, 불일치 0건) | 128 KB |
| `col_letter` (`col`로 100% 파생, 불일치 0건) | 82 KB |
| `color` (`check_no`로 파생) | 77 KB |
| 행 단위 필드의 행 내 중복 | 329 KB |
| **합계** | **616 KB (−20%)** |

전부 걷어내도 30만 행에서 ~72MB다. 1~5단계는 «안 쓰는 걸 안 보낸다»여서 값이
컸지만, `flags`는 화면이 실제로 쓰는 데이터라 성격이 다르다. **한 화면이 쓰는
것은 한 페이지뿐**이므로 페이지네이션 말고는 답이 없다.

##### 서버측 완료 (2026-08-08)

| 엔드포인트 | 대체하는 화면 계산 | 검증 |
|---|---|---|
| `GET /api/flags` | 목록 필터·페이지 | 실데이터 8종 조건이 클라이언트 필터링과 **완전 일치** |
| `GET /api/flags/aggregate` | 대시보드 Check 취사선택 재집계 | 4종 조건 일치 |
| `GET /api/flags/facets` | 부서·팀 select 값 | 일치 |
| `GET /api/departments/{dept}/defects` | 부서 결함 표 | `expand_defects()`와 동일 |
| `GET /api/flags/review-counts` | 사이드바 '미검토', 용접사 상세 | 일치 |

한 페이지 26.4KB (전체 2,521KB).

##### 6단계-C·D 완료 (2026-08-08) — 프론트 14개 소비처 전환 + flags 제거

`/api/result` **2.99MB -> 0.33MB**. 최초(1단계 전) 18MB 대비 **−98%**.

| 응답에 남은 것 | 크기 |
|---|---:|
| `ml`(고정 크기 요약) | 148 KB |
| `departments`(집계 + 행 번호 목록) | 89 KB |
| `welder_info` | 83 KB |
| 나머지 | 8 KB |

`flags` · `row_raw` · `unworked_list` 셋 다 **키는 남기고 빈 값**으로 보낸다 —
화면 코드가 그대로 훑기 때문이다.

###### 옮기면서 실제로 걸린 것

**파생 집계가 `result["flags"]`를 훑고 있었다.** 플래그를 빼자마자 `stats`가 `{}`,
`total_flags`가 0이 됐다 — 예외 없이 «결함 0건»으로 조용히 틀리는 형태다.
`_rebuild_derived()`를 flag 테이블 쿼리로 바꿨고, `expand_defects()`도 flags가
비면 저장소로 폴백하게 했다(**부서 리포트 메일이 이 경로를 쓴다** — 폴백이 없으면
지적 내용이 빈 결함 목록이 메일로 나간다).

**`_patternTeams`만 서버 대응물이 없었다.** 반복 패턴 표가 표를 그리는 **도중에**
동기로 훑고 있어 패턴마다 요청할 수 없다. `/api/flags/pattern-teams`로 조합
전체(289개 / 26KB)를 한 번에 받아 두는 방식으로 풀었다.

**로더가 promise를 돌려주게 했다.** `filterResults()`가 fire-and-forget이라
테스트가 «반영될 때까지» 기다릴 수 없었다. 인라인 핸들러는 반환값을 무시하므로
화면 동작은 그대로다.

###### 검증

실서버로 화면 경로를 구동해 대조했다(Node 하니스, `app.js` 그대로 실행):

```
상세결과 1p      50건 / 전체 4,508    Check 17 필터   전체 99
검색 TR-FC-G01   전체 2,165           2페이지         51–100
대시보드 전체     flagged 3,426 / flags 4,508 / trend 117
Check 4·17만     flagged 671 / flags 735
전부 해제        flagged 0 / clean 5,516
미검토 4,507 · 팀 facets 10 · 패턴팀 289 · 부서 결함 32건
콘솔 경고/오류    없음
```

pytest 268 passed.

###### 상한 문제를 «한도 올리기»로 풀지 않았다

한 덩어리로 받아야 하는 화면 둘이 서버 상한(2,000건)에 닿을 수 있었다. 성격이
달라 처방도 달랐다.

**Check 14 그룹 — 질의를 바꿔 «자연히 묶이게» 했다.**
`q=<joint_no>` 부분일치로 후보를 받아 화면에서 그룹키로 거르고 있었다. 후보 수를
예측할 수 없어 상한에 걸릴 수 있는 구조다. `/api/flags`에 **정확일치**
(`drawing_no` + `joint_no`)를 붙이니 결과가 그룹 크기로 묶인다:

    부분일치: 후보 84건 -> 화면에서 걸러 2건
    정확일치: 2건                       (실측)

Joint No는 도면 안에서만 유일해 최대 41개 도면에 같은 번호가 있다 — 그룹은
구조적으로 그 이하다. **상한과 무관해졌다.**

**용접사 상세 — 상한을 올렸다.** 이쪽은 Check별 분포·검토 집계·월별 차트를
«그 용접사의 전 플래그»로 내므로 페이지로 자를 수 없다. 실측 최다 237건이고
30만 행이면 ~7,000건이라, 상한을 `config.MAX_FLAG_PAGE = 20000`으로 올리고
근거를 그 자리에 적었다(플래그 1건 ≈ 0.56KB → 20,000건 ≈ 11MB가 최악).

`tests/test_result_store.py::test_welder_flag_count_stays_under_the_cap`이
실데이터로 이 여유를 지킨다 — 닿으면 용접사 단위 페이지네이션이 필요하다는
신호다.

###### 전환 중 발견한 버그

**`_loadWelderFlags()`를 만들어 놓고 어디서도 부르지 않았다.** 그래서 용접사
목록의 '미검토' 열이 전부 0이었고 상세 모달은 빈 목록이었다. 앞선 검증 하니스가
용접사 탭을 안 봐서 놓쳤다.

고치면서 함께 정리한 것: 목록의 '미검토' 열은 146명분이 동시에 필요해
`/api/flags/review-counts?by=welder`로 **한 번에** 받는다(116명 / 5.5KB).
한 명씩 물으면 146번을 왕복한다. 일괄 조회와 단건 조회가 갈라지지 않는지
테스트로 묶었다 — 갈라지면 목록과 상세의 숫자가 달라진다.

##### (참고) 전환표 — 어디를 어디로 옮겼나

**부분 전환은 이득이 없다.** `flags`가 응답에 남아 있는 동안 서버 조회로 바꾸면
왕복만 늘어난다. 이득은 마지막에 `flags`를 빼는 순간 한꺼번에 온다. 그러므로
**전부 옮긴 뒤 한 번에 끊는다.**

| `app.js` | 함수 | 옮길 곳 |
|---|---|---|
| 243–244 | 사이드바 미검토 | `/api/flags/review-counts` |
| 469 | `_dashAggregate` | `/api/flags/aggregate?checks=` |
| 670 | `_patternTeams` | `/api/flags?welder=&check=&dept=` |
| 958 | `_populateTeamFilter` | `/api/flags/facets?dept=` |
| 989 · 1007 | 상세 결과 필터 | `/api/flags?check=&dept=&team=&q=&offset=&limit=` |
| 1134 | `_buildC14GroupSectionHtml` | `/api/flags?check=14` + 그룹키 대조 |
| 1291 | `openRowDetail` | `/api/flags?rows=` |
| 1527 | `_mckPopulateTeamFilter` | `/api/flags/facets?dept=` |
| 1550 | Check 목록 모달 필터 | `/api/flags?...` |
| 1750 | 용접사 반복 패턴 | `/api/flags?check=&rows=` |
| 2171 | `_welderFlags` | `/api/flags?welder=` |
| 3081 | `_flagsByRow` / `_bucketDefects` | `/api/departments/{dept}/defects` |

마지막에 `verify.py`의 `published`가 `flags`를 싣지 않게 하고
(`load_latest(..., include_flags=False)` 추가), `_setResult()`의 파생 캐시 정리를
그대로 유지한다.

###### 옮기면서 조심할 것 (이미 서버에 반영해 둔 것들)

- **검색 열을 화면과 같게** — `joint_no · wps_no · msg · block`. 다르면
  «있는데 안 나온다»가 되고, 현업은 그걸 판정이 바뀐 것으로 읽는다.
- **`checks=[]`(전부 해제)와 미지정(필터 없음)은 다르다.** 뭉개면 화면에서
  Check를 전부 해제했는데 전체가 나온다.
- **`flagged_rows`는 행 단위 중복 제거.** 한 행에 선택/제외 Check가 섞여 있어도
  선택된 것이 하나라도 있으면 그 행은 여전히 결함이다.
- **용접사별 집계는 Check 6을 뺀다.** 플래그에 `welder1_no`만 있어 C6를 포함하면
  2~4번 용접사의 자격 문제가 1번 용접사에게 잘못 붙는다.
- **팀 목록 정렬은 화면이 한다** — 한국어 정렬(`localeCompare(_, 'ko')`)은
  SQL로 재현할 수 없다.
- **지연 응답에는 «지금 화면이 무엇을 보고 있는가» 대조를 붙인다.** `row_raw`
  지연 로딩에서 이걸 빠뜨려 다른 행의 원문이 검토 기록에 섞인 사고가 있었다
  (`_fillRawSlot`의 `slot.dataset.row` 가드 참조).

#### 남은 것 — flags 분할 (개선계획 2번의 나머지)

6.66MB 중 `flags`가 2.5MB, `departments`가 2.8MB다. 30만 행이면 합쳐서 ~160MB라
아직 크다. 다만 이건 저장소 문제가 아니라 **화면 구조 문제**다 — 지금 프론트는
전체 `flags` 배열을 받아 클라이언트에서 필터·검색·정렬한다. 서버 페이지네이션으로
바꾸려면 그 로직을 서버로 옮겨야 하고, 그건 저장소 교체와 성격이 다른 작업이다.
`flag` 테이블에 인덱스(`run_id+check_no`, `run_id+department+team`, `run_id+row`)를
미리 걸어 두었으므로 착수 조건은 갖춰져 있다.

### 위험

- **가장 위험한 것은 집계값이 미묘하게 달라지는 것이다.** 1·2단계 사이에
  `qc-data-verifier`를 반드시 태운다. 불변식 8종이 이때를 위해 있다.
- `app_state.json` 복원 경로를 유지해야 한다(기존 사용자 데이터). 최초 기동 시
  JSON이 있고 DB가 없으면 1회 마이그레이션.

### 검증

- 마이그레이션 전후 `stats` / `flagged_rows` / 부서·팀 롤업 / 용접사 146명 전수 일치
- `tests/qc_invariants.py`를 DB 경로에도 파라미터화

---

## 2. `/api/result` 페이지네이션

### 근거

20만 건이면 응답 360 MB. 브라우저가 받지 못한다.

### 설계

지금 프론트는 `S.result` 하나에 전부 담고 화면마다 필터링한다. 이 구조를 유지하되
**무거운 배열만 분리**한다.

```
GET /api/result              -> 집계·메타만 (수십 KB)
                                stats, departments, welder_info, ml.meta, 행 회계
GET /api/result/flags?...    -> 플래그 페이지
                                offset, limit, check_no, dept, team, welder, q
GET /api/result/rows/{row}   -> 그 행의 원본 스냅샷 (지금 row_raw)
GET /api/result/unworked?... -> 미작업 페이지
```

프론트 변경 지점:
- `S.result.flags`를 직접 순회하는 곳 → 서버 필터·페이지로 대체
- 상세 모달의 `S.result.row_raw[row]` → 단건 조회
- **대시보드/부서 집계는 그대로 둔다** — 이미 서버가 계산해 보내므로 영향 없음

### 위험

`_dashAggregate()` 같은 «화면에서 플래그를 다시 세는» 코드가 있다.
Check 토글 기능이 그것에 의존한다. 이건 **집계 API에 `check_stats`를 부서/팀별로
이미 보내고 있으므로** 클라이언트 재계산 대신 그 값을 쓰도록 바꾼다.

### 검증

- `ui-regression-checker`로 12개 화면 전수
- 대시보드 Check 토글이 부서→팀까지 연쇄하는지(이미 회귀 이력 있음)

---

# B. 검사 로직 — 효과가 확실한 것

## 3. 용접사 두께·직경 자격 대조 → **Check 15** (신규)

### 근거

용접사 DB에 **100% 채워진** 두 열이 검사에 안 쓰인다.

| 열 | 내용 | 값 종류 |
|---|---|---|
| P(16) | Diameter | 9종 |
| Q(17) | Thickness | 10종 |

Check 6은 **프로세스와 자세만** 본다. 「12mm 자격자가 40mm를 용접했는가」를
아무도 보지 않는다. WPS 두께(Check 3)는 보면서 용접사 두께 자격은 안 보는 비대칭.

### 값 형식 — 파서가 감당해야 할 변형 (실측 전수)

```
[Thickness] 10종
  3mm TO UNLIMITED (457)   3MM TO UNL (210)      3MM TO UNLIMITED (10)
  5mm TO UNLIMITED (62)    5MM TO UNL (20)       5MM TO UNLIMITED (2)
  3MM TO MAX' 24MM (3)     3MM TO MAX' 20MM (1)  3MM TO MAX' 17.12MM (1)
  N/A (254)

[Diameter] 9종
  600mm and OVER (457)     600MM AND OVER (191)
  100mm and OVER (62)      100MM AND OVER (22)   114.3MM AND OVER (1)
  ALL (31)                 20MM<O.D<100MM (1)
  20MM<NOMINAL PIPE SIZE<100MM (1)
  N/A (254)
```

주의할 점 셋:
1. **대소문자 혼재** — `600mm and OVER` / `600MM AND OVER`. 반드시 정규화.
2. **`N/A`가 25%(254명)** — 자격 범위 미기재. **이걸 위반으로 보면 안 된다.**
   판정 불가로 두고 별도 집계한다.
3. **부등호 형식**(`20MM<O.D<100MM`)이 소수 존재. 상·하한 양쪽이 있는 유일한 형태.

### 설계

```python
def _parse_welder_range(raw: str) -> tuple[float | None, float | None] | None:
    """용접사 자격 범위 문자열 -> (하한, 상한). 판정 불가면 None.

    None을 돌려주는 경우: 빈 값, 'N/A', 어느 패턴에도 안 맞는 값.
    상한 없음(UNLIMITED/OVER)은 (하한, None)으로 돌려준다.
    """
    s = (raw or '').strip().upper().replace("'", "")
    if not s or s == 'N/A':
        return None
    if s == 'ALL':
        return (0.0, None)
    # 20MM<O.D<100MM  /  20MM<NOMINAL PIPE SIZE<100MM
    m = re.match(r'([\d.]+)\s*MM\s*<.*?<\s*([\d.]+)\s*MM', s)
    if m:
        return (float(m.group(1)), float(m.group(2)))
    # 3MM TO UNLIMITED / 3MM TO UNL
    m = re.match(r'([\d.]+)\s*MM\s+TO\s+UNL', s)
    if m:
        return (float(m.group(1)), None)
    # 3MM TO MAX 24MM
    m = re.match(r'([\d.]+)\s*MM\s+TO\s+MAX\s*([\d.]+)\s*MM', s)
    if m:
        return (float(m.group(1)), float(m.group(2)))
    # 600MM AND OVER
    m = re.match(r'([\d.]+)\s*MM\s+AND\s+OVER', s)
    if m:
        return (float(m.group(1)), None)
    return None
```

**미인식 값은 예외를 던지지 말고 `None`으로 흘린다.** 새 형식이 하나 들어왔다고
검증 전체가 멈추면 안 된다. 다만 미인식 값은 **로그와 통계에 남긴다** — 그래야
파서를 언제 늘려야 하는지 안다.

판정:

```
대상: 시공된 행 × 용접사 1~4 각각
조건: 용접사 자격범위가 판정 가능하고, 그 행의 두께(J열)가 범위 밖
색상: Purple (미사용 색)  마킹 열: 해당 용접사 열(AP/AR/AT/AV)
```

### Check 6과의 관계 — 반드시 지킬 것

**Check 15는 Check 6과 같은 성격이다** — 그 행의 작업 품질 문제가 아니라
**특정 용접사 개인의 자격 문제**다. 따라서:

- `welder_defects`(용접사 작업성 결함률)에서 **Check 6과 함께 제외**한다
- `_workmanship_rows` 방어에 Check 15도 포함시킨다

이걸 빠뜨리면 같은 행의 다른 용접사에게 오귀속된다 —
CLAUDE.md에 적힌 그 함정이 그대로 재현된다.

### 실측 검출량 — **0건**

설계한 파서를 그대로 구현해 실데이터에 돌려봤다.

```
파서 검증        Thickness 1,020건 -> 판정가능 766 / N/A 254 / 미인식 0
                 Diameter  1,020건 -> 판정가능 766 / N/A 254 / 미인식 0

대조 결과        시공 행 x 용접사 5,676건
                   대조 가능              3,567건 (62.8%)
                   DB에 없음(Check 6 영역) 2,109건 (37.2%)
                 두께 자격 위반          **0건**
```

원인은 명확하다 — 다만 **처음 적었던 «766명 중 5명»은 틀린 수치였다**(2026-08-08 정정).
실제로는 자격 DB 785명 중 594명에 두께 자격이 기재돼 있고, 그중 **564명이 UNLIMITED**다.
유한한 상한을 가진 사람은 **30명**이며, 그 30명이 **이번 물량에 한 명도 투입되지 않았다.**
즉 대조 가능한 (행 x 용접사) 조합이 **0건**이라 검사를 만들어도 아무것도 보지 못한다.

| 용접사 | 자격 두께 |
|---|---|
| 1400 | 3 ~ 17.12 mm |
| R354 | 3 ~ 20 mm |
| R524 / R526 / R535 | 3 ~ 24 mm |

나머지 761명은 `3mm TO UNLIMITED` 계열로 **상한이 없다.** 하한(3mm/5mm)은
실데이터 두께 분포(대부분 12mm)상 걸릴 일이 없다.

### 이 결과로 우선순위를 낮춘다

점검 보고에서 이 항목을 «가장 값어치 있는 것»으로 꼽았는데, **그 판단은 틀렸다.**
근거는 "100% 기재된 열을 안 본다"였지만, 실제로 그 열의 99.35%가 «무제한»이라
검사해도 걸릴 것이 없다.

여전히 넣을 이유는 Check 16과 같다 — «확인했고 문제없음»을 매 검증마다 재확인하는
값어치, 그리고 자격 체계가 바뀌거나 다른 프로젝트가 들어올 때의 대비다.
다만 **우선순위는 «효과 확실»이 아니라 «저비용 보험»으로 내린다.**

### 부수 소득 — 진짜 공백은 다른 데 있었다

대조 과정에서 나온 숫자가 더 의미 있다:

- **자격 DB에 아예 없는 용접사가 시공 행의 37.2%(2,109건)** — Check 6이 이미
  2,145건으로 잡고 있는 그 모집단이다. 두께 자격을 논하기 전에 **자격 자체가
  확인되지 않는 시공이 3분의 1**이라는 뜻이다.
- 자격범위 `N/A`가 254명(25%) — 자격 DB의 기재 미비. 결함이 아니라 **데이터 품질
  문제**이므로 검사가 아니라 §11에 기록할 사안이다.

### 검증

- 파서 단위 테스트: 실측 19종 값 전부 + 미인식 값 처리
- `qc-data-verifier`로 `welder_defects` 불변식 재대조 (Check 15 제외 확인)

---

## 4. Check 5 재정의

### 근거

- 전체 플래그의 **26%(1,389건)** 를 차지하는 최대 단일 Check
- 그중 **955건은 Groove가 FL/PP라 G03으로 이동 자체가 불가능**(§11-2 기록)
- 38mm 초과 45건은 이동 시 오히려 Check 3 위반
- **G03은 이 프로젝트에서 한 번도 시공에 쓰이지 않았다**(WPS 목록에는 등재)
- 트리거인 NDT Cat 코드가 실제 NDT 강도와 단조 관계가 아님(§11-2 실측)

### 설계 — 세 안 중 택일. **현업 답변이 선행돼야 한다.**

| 안 | 내용 | 결과 |
|---|---|---|
| **A** | 현행 유지 | 1,389건 그대로. §11-2 미해결 상태 지속 |
| **B** | **시정 가능한 것만** — Groove가 G03의 Joint Detail에 있고 두께 38mm 이하인 행만 | 약 389건으로 축소. "고칠 수 있는 지적"만 남음 |
| **C** | 폐지 후 5번(NDT Extent 이행)으로 대체 | 0건. 규칙의 원래 취지를 다른 방식으로 |

**권고: B.** 지적의 성격이 «규칙 위반»에서 «시정 요청»으로 바뀌는데, 현장에서
무시되지 않으려면 그게 맞다. 다만 **§11-2는 "표준 조사로 해결 불가"로 기록된
항목이라 현업 확인 없이 바꾸면 안 된다.**

→ **선행: '현업 검증사항' 탭에서 §11-2 현업 답변 수령.**

### 검증

- 변경 전후 `stats` diff에서 Check 5 외 다른 Check가 움직이지 않을 것
- Check 7(2+5 중복)이 함께 줄어드는지 — 현재 0건이므로 변화 없어야 정상

---

## 5. NDT Extent 이행 대조 → **Check 16** (신규)

### 근거 (정정 반영)

생산 NDT 요구는 **QMG의 NDT Extent(S/T/U/V열)** 에 있다.

| 열 | 항목 | 채움률 | 값 |
|---|---|---|---|
| S(19) | RT | 0.0% | — |
| T(20) | UT | 20.4% | 100 / 20 |
| U(21) | MT | 99.7% | 100 / 20 / 10 |
| V(22) | PT | 0.0% | — |

시공된 5,520건에 대한 실측 이행률:

```
UT  요구100 → 수행 885건 / 요구20 → 수행 200건    미수행 0건
MT  요구100 → 수행 5,146 / 요구20 → 200 / 요구10 → 174   미수행 0건
```

**현재 데이터에서는 100% 이행이다.** 즉 이 Check는 지금 0건이 나온다.

### 그래도 넣는 이유

1. **20만 건으로 늘면 반드시 미수행이 생긴다.** 지금 0%인 것이 그때도 0%라는
   보장이 없고, 그때 발견하는 것보다 지금 감시를 걸어두는 게 싸다.
2. Check 1이 0건인 것과 같은 성격 — **«확인했고 문제없음»을 매 검증마다 재확인**하는
   값어치가 있다.
3. 5번을 넣으면 4번(Check 5 폐지안 C)의 대체 경로가 생긴다.

### 설계

```
대상: 시공된 행(WPS 있음)
조건: NDT Extent 열에 값이 있는데(=요구됨) 대응하는 수행일이 비어 있음
      RT: S열 ↔ BM열(65)   UT: T열 ↔ BP열(68)
      MT: U열 ↔ BS열(71)   PT: V열 ↔ BV열(74)
색상: Teal (미사용 색)  마킹 열: 해당 NDT 수행일 열
메시지: "UT 100% 요구인데 수행 기록 없음"
```

**미작업 행은 제외한다** — 시공을 안 했으니 NDT도 없는 게 정상이다.
이 구분이 없으면 4,509건이 전부 오탐이 된다.

### 검증

- 현재 데이터로 **0건**이 나오는 것을 확인 (그게 정답)
- 합성 데이터로 «요구 있고 수행 없음»을 만들어 검출되는지

---

## 6. VT 미수행 검출 → **Check 17** (신규)

### 근거 (실측)

```
시공된 행 5,520건 중  VT 수행 5,255 / VT 미수행 265 (4.8%)
```

육안검사는 모든 용접에 필수인데 **265건에 기록이 없다.**
UT·MT가 100% 이행인 것과 대비된다.

### 설계

```
대상: 시공된 행(WPS 있음)
조건: BI열(61, VT Date)이 비어 있음
색상: Gray  마킹 열: BI(61)
메시지: "육안검사(VT) 수행 기록 없음"
```

Check 16과 분리하는 이유: **VT는 Extent 열이 없다**(모든 용접 대상).
16은 «요구된 것 대비», 17은 «무조건 필요한 것».

### 위험

265건이 정말 미수행인지, 아니면 **기록 지연**인지 구분되지 않는다.
용접일이 최근인 행은 아직 검사 전일 수 있다.

→ **완화: 용접일 기준 N일 경과한 행만 대상.** N은 실데이터의 용접→VT 리드타임
분포에서 정한다(90퍼센타일 권장). 이 값을 상수로 두고 근거를 독스트링에 남긴다.

### 검증

- 리드타임 분포를 먼저 실측하고 N을 정한 뒤 검출량 확인
- 265건 중 몇 건이 «지연»으로 걸러지는지 보고

---

# C. 확장

## 7. 협력사 축 추가

### 근거

`BH(60) Sub-contractor` **29.5% 기재**. 값 예: `C1-(주)해양서일`, `B9-선우기술`.
현재 부서/팀까지만 집계하고 협력사 축이 없다.

**부서/팀은 발주 조직이고 협력사는 시공 주체**라 결함 귀속이 다르다.

### 설계

- `Col.SUBCONTRACTOR = 60` 추가
- `flags`에 `subcontractor` 필드 (1번 SQLite 스키마에 이미 반영)
- 집계 버킷을 부서→팀 2단에서 **부서→팀→협력사 3단**으로 확장
- '부서별 대시보드'에 협력사 드릴다운 추가

### 위험

**70.5%가 미기재**다. 협력사별 결함률을 그대로 보여주면 «기재된 것만»의 통계인데
전체처럼 읽힌다. → **미기재 비율을 화면에 항상 병기**한다. 표본부족 배지와 같은 원칙.

### 검증

- 협력사 합 = 부서 합 (미기재분 포함) 불변식 추가
- `qc-data-verifier` §2에 항목 추가

---

## 8. 용접봉(Consumable) 대조 → **Check 18** (신규)

### 근거

- 매크로 순번 10 원문이 **"용접봉"** 을 언급하는데 재질로 구현돼 있다
- QMG `AL(38) Consumable Lot` **55% 기재** (예: `F902A4L4E7`)
- WPS 목록 `I(9) Filler Metal / Brand Name` (예: `Prime81K2`), `T(20) AWS Class`

### 문제 — 이 항목만 선행 조사가 필요하다

**Lot 번호(`F902A4L4E7`)와 브랜드명(`Prime81K2`)을 직접 대조할 수 없다.**
Lot → 브랜드 매핑표가 어딘가 있어야 한다.

→ **1단계는 «검사»가 아니라 «조사»다:**
```
1. Lot 번호 체계 파악 (앞자리가 브랜드 코드인가?)
2. 매핑표 존재 여부 현업 확인
3. 매핑이 불가능하면 -> Check 18 보류, 대신 '용접봉 사용 현황' 집계만 제공
```

매핑이 되면 「WPS가 지정한 용접봉과 다른 것을 썼는가」를 검사한다.
안 되면 **억지로 만들지 않는다.**

### 검증

- 1단계 조사 결과를 §11에 새 항목으로 기록 (해결 가능 여부와 무관하게)

---

## 9. 검증 이력 비교 탭

### 근거

`qc-data-verifier`가 **두 번** 보고했다: *"변경 전 `result.json`이 보존돼 있지
않아 진짜 pre-change diff는 불가"*. 판정 로직을 고칠 때마다 겪는다.

### 설계

1번(SQLite)의 `run` 테이블이 그대로 기반이 된다. 회차가 이미 쌓인다.

```
GET /api/runs                 회차 목록 (일시/파일명/행수/플래그수)
GET /api/runs/compare?a=&b=   두 회차 비교
```

화면:
```
회차 A [2026-08-03 21:45 ▾]  ↔  회차 B [2026-08-08 10:12 ▾]

행 회계     판정 5,516 → 5,516      (변화 없음)
Check 3        45 →    45
Check 5     1,389 →   389   ▼ 1,000   ← 의도한 변경
Check 6     2,145 → 2,151   ▲     6   ← 의도하지 않음. 확인 필요
```

**의도하지 않은 변화를 눈에 띄게 하는 것이 목적이다.** 정렬을 «변화량 큰 순»으로
두고, 변화 0인 Check는 접어둔다.

### 보관 정책

회차가 무한정 쌓이면 DB가 커진다. **최근 N회차만 유지**(기본 10).
`run` 삭제 시 `ON DELETE CASCADE`로 flag/row_raw가 함께 지워진다.

### 검증

- 같은 데이터로 두 번 검증 → 모든 Check 변화 0
- 의도적으로 Check 하나를 바꾼 뒤 그것만 diff에 뜨는지

---

# D. 정비 — 위험 낮음, 언제든 가능

## 10. `requirements.txt`

### 근거

없다. CLAUDE.md가 `pip install ...` 한 줄로 안내하는데 **버전이 없어 재현되지 않는다.**
scikit-learn은 선택적 의존이라 미설치 시 Check 13만 꺼지는 설계인데, 그 사실도
파일에 안 적혀 있다.

### 설계

```
# requirements.txt — 필수
fastapi>=0.110
uvicorn>=0.29
openpyxl>=3.1
pydantic>=2.6

# requirements-optional.txt — 없으면 해당 기능만 비활성
scikit-learn>=1.4    # Check 13 이상치 탐지 / 비지도학습 탭
numpy>=1.26          # 〃
pywin32>=306         # 부서별 Outlook 메일 발송 (Windows 전용)
```

**둘로 나누는 것이 핵심이다.** 하나로 합치면 리눅스에서 pywin32 때문에 설치가
통째로 실패한다. 현재 코드가 이미 `try: import` 로 선택적 처리를 하고 있으므로
파일 구성이 코드와 일치하게 된다.

설치 버전을 실측해 하한을 정한다(`pip freeze` 기준).

---

## 11. §5 대응표 정정

### 근거

`QC_검사로직_상세분석.md` §5에서 **B=9와 B=10이 뒤바뀌어** 있다.

| | 실제 「매크로 로직」 시트 | 현재 문서 |
|---|---|---|
| B=9 | 중복(2+7) → Check 7 | Check 8 |
| B=10 | RU-FC-G03 → Check 8 | Check 7 |

### 설계

표를 고치고, 아래 두 사실을 함께 기록한다:

1. **매크로 원문은 `RU-` 접두사**(`RU-FC-G03`, `RU-SMFC-G01`)이고 코드는 `TR-`.
   실데이터가 `TR-`이므로 코드가 맞다. 이 차이를 남겨야 다음 사람이 "코드가
   틀렸다"고 오해하지 않는다.
2. **매크로 순번 4(Groove)에 「(수리 WPS 제외)」 단서**가 있고 코드도 그렇게
   구현돼 있다(`_is_repair_wps`). 대응표에 이 단서가 빠져 있다.

§11은 이력 보존이 원칙이므로 **§5는 정정, §11에는 "문서 오류 발견" 항목 추가**.

---

## 12. WPS 번호 하드코딩 제거

### 근거

Check 5·8·9·11과 §11-1 override가 WPS 번호를 소스에 박아두고 있다.

```python
_SM355A_PQR_OVERRIDE_WPS = {'TR-FC-G01', 'TR-FC-G11', 'TR-FC-G03', 'TR-FC-R01'}
def _is_repair_wps(wps_no): return wps_no.upper().startswith('TR-FC-R')
# Check 5:  wps_no == 'TR-FC-G01'
# Check 8:  wps_no == 'TR-FC-G03'
# Check 9:  wps_no == 'TR-SMFC-G01'
```

**접두사가 다른 프로젝트가 들어오면 Check 5·8·9가 전부 조용히 0건이 된다.**
경고도 안 난다. 매크로 원문이 `RU-`인 것을 보면 실제로 다른 접두사가 존재한다.

### 설계

```python
# backend/config.py
WPS_RULES_FILE = BASE / "data" / "wps_rules.json"
```

```jsonc
{
  "project": "TRION FPU",
  "repair_prefix": "TR-FC-R",
  "check5":  { "target_wps": "TR-FC-G01", "recommend_wps": "TR-FC-G03" },
  "check8":  { "target_wps": "TR-FC-G03", "max_thickness": 12.0 },
  "check9":  { "target_wps": "TR-SMFC-G01", "thickness": 12.7 },
  "sm355a_pqr_override": {
    "wps": ["TR-FC-G01", "TR-FC-G11", "TR-FC-G03", "TR-FC-R01"],
    "range": [12.5, 50.0],
    "note": "§11-1 잠정결론. 현업 확인 후 확정 예정"
  }
}
```

**파일이 없으면 현재 하드코딩 값을 기본값으로 쓴다.** 동작이 바뀌지 않는다.

### 핵심 — 조용한 0건을 막는 방어

설정에 적힌 WPS가 **WPS 목록에 하나도 없으면 경고를 남긴다.**

```python
missing = [w for w in rules.referenced_wps() if w not in wps_list]
if missing:
    logger.warning("규칙이 참조하는 WPS가 WPS 목록에 없음: %s "
                   "— 해당 Check는 항상 0건이 된다", missing)
```

이 한 줄이 12번의 실제 목적이다. 설정화 자체보다 **"이 규칙은 지금 죽어 있다"를
알려주는 것**이 값어치다.

### 검증

- 설정 파일 없이 → 현재와 동일한 결과 (stats 전 Check 일치)
- 존재하지 않는 WPS를 설정에 넣고 → 경고 로그 확인

---

# 전체 검증 계획

각 항목이 끝날 때마다:

| 대상 | 도구 |
|---|---|
| 판정 로직을 고쳤으면 | `qc-data-verifier` — 불변식 8종 전수 |
| 화면을 고쳤으면 | `ui-regression-checker` — 12개 화면 |
| 언제나 | `pytest tests/ -v` (현재 157개) |

**새 Check(15·16·17·18)를 추가할 때 반드시 함께 갱신할 네 곳:**
`_FILLS` / `CHECK_COLORS` / `CHECK_NAMES` / `_PRIORITY`
— CLAUDE.md에 적힌 대로 하나라도 빠뜨리면 색상이 어긋난다.

**Check 15는 추가로** `welder_defects` 제외 목록과 `_workmanship_rows` 방어에도
넣어야 한다. Check 6과 같은 성격이기 때문이다.

---

# 미결로 남는 것

이 계획으로 해결되지 **않는** 것을 분명히 적어둔다.

| 항목 | 상태 |
|---|---|
| §11-1·11-3·11-4 | `[~] 잠정결론` — 현업 확인 대기 |
| §11-2 | `[ ] 미결` — 4번의 선행 조건 |
| 지도학습 | 라벨 부재(VT Result 전부 A-Accept, 리페어 0건). 데이터 양과 무관 |
| 용접봉 대조(8번) | Lot↔브랜드 매핑 확인 전까지 착수 불가 |
| 검사원별 분석 | 데이터는 있으나(BK/BR/BU) 이번 계획에 미포함 |
