﻿#
# data\projects.json에 정의된 포트의 QC Summary 서버를 전부 종료한다.
#
# 강제 종료(-Force) 대신 정상 종료를 먼저 시도하고, 3초 안에 꺼지지 않으면 강제 종료한다.
# 이렇게 하면 openpyxl 등이 임시 파일을 정리할 시간이 생겨 파일 손상을 막는다.
#
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding             = [System.Text.Encoding]::UTF8
Set-Location $PSScriptRoot

$listFile = Join-Path $PSScriptRoot "data\projects.json"
if (-not (Test-Path $listFile)) {
    $ports = @(8001)
} else {
    $ports = (Get-Content $listFile -Raw -Encoding UTF8 | ConvertFrom-Json).projects |
             ForEach-Object { [int]$_.port }
}

Write-Host ""
$killed = 0

foreach ($port in $ports) {
    $conn = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue |
            Select-Object -First 1
    if (-not $conn) {
        Write-Host ("  이미 꺼져 있음  :{0}" -f $port) -ForegroundColor DarkGray
        continue
    }

    $proc = Get-Process -Id $conn.OwningProcess -ErrorAction SilentlyContinue
    $name = if ($proc) { $proc.Name } else { "알 수 없음" }

    Write-Host ("  종료 중  :{0}  (PID {1} / {2})" -f $port, $conn.OwningProcess, $name) -ForegroundColor Cyan

    # 1단계: 일반 종료 시도
    if ($proc) {
        $proc.CloseMainWindow() | Out-Null
        $exited = $proc.WaitForExit(3000)
    } else {
        $exited = $false
    }

    # 2단계: 3초 안에 안 꺼지면 강제 종료
    if (-not $exited) {
        Stop-Process -Id $conn.OwningProcess -Force -ErrorAction SilentlyContinue
    }

    # 종료 확인
    Start-Sleep -Milliseconds 500
    $still = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
    if ($still) {
        Write-Host ("  ⚠ 종료 실패  :{0}" -f $port) -ForegroundColor Red
    } else {
        Write-Host ("  완료          :{0}" -f $port) -ForegroundColor Green
        $killed++
    }
}

Write-Host ""
if ($killed -eq 0) {
    Write-Host "  실행 중인 서버가 없습니다." -ForegroundColor DarkGray
} else {
    Write-Host ("  서버 {0}개 종료 완료." -f $killed) -ForegroundColor Green
}
Write-Host ""
