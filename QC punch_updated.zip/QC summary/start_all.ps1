﻿#
# data\projects.json에 적힌 프로젝트 서버를 전부 띄우고, **첫 번째 것을 연다.**
#
# 예전에는 앞에 «프로젝트를 고르는» 페이지(8000)를 따로 뒀는데, 그러면 브랜드
# 배경과 로고가 있는 로그인 화면이 뒤로 밀리고 **아무 꾸밈 없는 흰 화면이 이
# 시스템의 첫인상**이 된다. 프로젝트 선택은 이미 로그인 화면 안에 있으므로
# (사번 입력칸 바로 위 + 로그인 뒤에는 우상단 배지) 그 페이지는 할 일이 없다.
#
# **서버를 띄우는 일은 사람이 이 PC에서 한다.** 웹 페이지가 대신 띄우게 만들면
# 사내망에 열린 페이지가 이 PC에서 프로세스를 만들 수 있게 되는데, 그건
# '에이전트' 탭에서 실행 기능을 뺀 것과 같은 이유로 안 된다.
#
Set-Location $PSScriptRoot

$listFile = Join-Path $PSScriptRoot "data\projects.json"
if (-not (Test-Path $listFile)) {
    Write-Host "data\projects.json이 없습니다 — 8001 하나만 띄웁니다." -ForegroundColor Yellow
    $projects = @([pscustomobject]@{ name = "QC 자동검증"; port = 8001; data_dir = "" })
} else {
    $projects = (Get-Content $listFile -Raw -Encoding UTF8 | ConvertFrom-Json).projects
}

# 이미 떠 있는 포트는 건드리지 않는다. 다시 띄우면 uvicorn이 «주소 사용 중»으로
# 죽고, 사용자에게는 **까만 창이 하나 뜨자마자 닫히는** 것으로만 보인다.
function Test-PortUp([int]$Port) {
    $c = New-Object System.Net.Sockets.TcpClient
    try   { $c.Connect("127.0.0.1", $Port); return $true }
    catch { return $false }
    finally { $c.Close() }
}

Write-Host ""
foreach ($p in $projects) {
    $port = [int]$p.port
    $name = if ($p.name) { $p.name } else { "포트 $port" }

    if (Test-PortUp $port) {
        Write-Host ("  이미 실행 중  {0,-14} :{1}" -f $name, $port) -ForegroundColor DarkGray
        continue
    }

    # data_dir이 비어 있으면 **저장소 안의 data\를 그대로 쓴다**(폴더를 나누기
    # 전의 설치). 여기서 자동으로 새 폴더를 만들면 «그동안의 결과가 사라졌다»가
    # 되는데, 실제로는 빈 폴더를 새로 보고 있을 뿐이라 원인을 찾기 어렵다.
    $dataDir = if ($p.PSObject.Properties.Name -contains 'data_dir') { $p.data_dir } else { "" }

    Write-Host ("  띄우는 중     {0,-14} :{1}  {2}" -f $name, $port,
                $(if ($dataDir) { $dataDir } else { "(저장소 안)" })) -ForegroundColor Cyan

    if ($dataDir) {
        $cmd = "`$env:QC_DATA_DIR='$dataDir'; `$env:QC_PROJECT='$name'; " +
               "cd '$PSScriptRoot'; " +
               "py -3 -m uvicorn backend.main:app --host 0.0.0.0 --port $port"
    } else {
        $cmd = "`$env:QC_PROJECT='$name'; cd '$PSScriptRoot'; " +
               "py -3 -m uvicorn backend.main:app --host 0.0.0.0 --port $port"
    }
    Start-Process powershell -ArgumentList @("-NoExit", "-NoProfile", "-Command", $cmd)
}

$localIp = (Get-NetIPAddress -AddressFamily IPv4 |
    Where-Object { $_.IPAddress -notlike '169.254.*' -and $_.IPAddress -ne '127.0.0.1' } |
    Select-Object -First 1 -ExpandProperty IPAddress)

# 목록의 **첫 번째**를 연다. 다른 프로젝트로는 로그인 화면에서 바로 넘어갈 수
# 있으니, 여기서 다시 고르게 할 이유가 없다.
$firstPort = [int]$projects[0].port

Write-Host ""
Write-Host ("  들어가는 자리: http://localhost:{0}" -f $firstPort) -ForegroundColor Green
Write-Host ("  다른 사람    : http://{0}:{1}" -f $localIp, $firstPort)
Write-Host "  다른 프로젝트는 로그인 화면에서 고르면 됩니다." -ForegroundColor DarkGray
Write-Host ""
Write-Host "  * 새로 뜬 창을 닫으면 그 서버가 종료됩니다. 전부 끄려면 창을 모두 닫으세요." -ForegroundColor Yellow
Write-Host ""

Start-Sleep -Seconds 5
Start-Process ("http://localhost:{0}" -f $firstPort)
