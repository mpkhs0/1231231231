﻿#
# 프로젝트 서버 하나를 띄운다. 코드는 한 벌이고 **데이터 폴더와 포트만** 다르다.
#
#   .\start_project.ps1 -Project TRION -Port 8001
#   .\start_project.ps1 -Project RUYA  -Port 8002 -DataDir "D:\QC data\RUYA"
#
# -DataDir을 주지 않으면 `..\QC data\<Project>`를 쓴다. 저장소 **밖**에 두는 이유:
# 저장소 안에 두면 git이 사내 데이터를 추적할 위험이 생기고, 저장소를 통째로
# 복사·이동할 때 남의 프로젝트 데이터가 따라다닌다.
#
param(
    [Parameter(Mandatory = $true)][string]$Project,
    [Parameter(Mandatory = $true)][int]$Port,
    [string]$DataDir = ""
)

Set-Location $PSScriptRoot

if (-not $DataDir) {
    $DataDir = Join-Path (Split-Path $PSScriptRoot -Parent) "QC data\$Project"
}

# 없으면 만든다. **처음 띄우는 프로젝트는 빈 폴더가 정상이다** — 검증 결과도
# 판정 규칙도 아직 없고, 파일을 올리면서 채워진다.
if (-not (Test-Path $DataDir)) {
    New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
    Write-Host "데이터 폴더를 새로 만들었습니다: $DataDir" -ForegroundColor Yellow
}
$rawDir = Join-Path $DataDir "Raw data"
if (-not (Test-Path $rawDir)) { New-Item -ItemType Directory -Force -Path $rawDir | Out-Null }

# WPS 참조 파일이 없으면 **켜지긴 하는데 검증이 안 된다.** 그 사실을 여기서
# 말해 주지 않으면 파일을 올리고 검증을 눌러 본 뒤에야 알게 된다.
$wps = @(Get-ChildItem -Path $rawDir -Filter *.xlsm -ErrorAction SilentlyContinue)
if ($wps.Count -eq 0) {
    Write-Host ""
    Write-Host "  * WPS 참조 파일(.xlsm)이 없습니다." -ForegroundColor Yellow
    Write-Host "    이 폴더에 넣어 주세요: $rawDir" -ForegroundColor Yellow
    Write-Host "    (data\wps_cache.json이 있으면 없이도 검증됩니다)" -ForegroundColor DarkGray
}

# 예전 설치는 저장소 안(`.\data`)에 결과를 두고 돌았다. 새 폴더가 비어 있는데
# 저장소 쪽에 결과 DB가 남아 있으면 **«그동안의 검증 결과가 전부 사라졌다»로 보인다**
# — 실제로는 옮기지 않았을 뿐이다. 여기서 말해 주지 않으면 원인을 찾기 어렵다.
$oldDb = Join-Path $PSScriptRoot "data\qc.db"
$newDb = Join-Path $DataDir "data\qc.db"
if ((Test-Path $oldDb) -and -not (Test-Path $newDb)) {
    Write-Host ""
    Write-Host "  * 저장소 안에 예전 데이터가 남아 있습니다." -ForegroundColor Yellow
    Write-Host "    이 서버는 새 폴더($DataDir)를 쓰므로 빈 상태로 시작합니다." -ForegroundColor Yellow
    Write-Host "    옛 결과를 그대로 쓰려면 아래를 새 폴더로 옮기세요:" -ForegroundColor Yellow
    Write-Host "      data\  qc_uploads\  qc_results\  'Raw data'\" -ForegroundColor DarkGray
    Write-Host "      (data\employees.json 과 data\outlook_settings.json 은 공용이라 그대로 둡니다)" -ForegroundColor DarkGray
    Write-Host ""
}

$localIp = (Get-NetIPAddress -AddressFamily IPv4 |
    Where-Object { $_.IPAddress -notlike '169.254.*' -and $_.IPAddress -ne '127.0.0.1' } |
    Select-Object -First 1 -ExpandProperty IPAddress)

Write-Host ""
Write-Host "  프로젝트     : $Project" -ForegroundColor Cyan
Write-Host "  데이터 폴더  : $DataDir"
Write-Host "  내 PC        : http://localhost:$Port"
Write-Host ("  같은 네트워크: http://{0}:{1}" -f $localIp, $Port)
Write-Host ""
Write-Host "  * 새로 뜨는 'QC Server' 창을 닫으면 이 프로젝트 서버가 종료됩니다." -ForegroundColor Yellow
Write-Host "    (지금 이 창은 잠시 후 자동으로 닫히는 게 정상입니다)" -ForegroundColor Yellow
Write-Host ""

# 환경변수는 **자식 프로세스에만** 넘긴다. 이 창의 $env:를 바꾸면 같은 창에서
# 다른 프로젝트를 띄울 때 앞의 값이 남아, 두 서버가 한 폴더를 물게 된다.
$cmd = "`$env:QC_DATA_DIR='$DataDir'; `$env:QC_PROJECT='$Project'; " +
       "cd '$PSScriptRoot'; " +
       "py -3 -m uvicorn backend.main:app --host 0.0.0.0 --port $Port"
Start-Process powershell -ArgumentList @("-NoExit", "-NoProfile", "-Command", $cmd)

Start-Sleep -Seconds 3
Start-Process "http://localhost:$Port"
