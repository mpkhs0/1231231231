"""검증용 «샌드박스» 데이터 폴더를 만든다 — 에이전트가 실제 결과를 밟지 않도록.

## 무엇이 문제였나

`qc-data-verifier`는 불변식을 대조하려고 `/api/verify`를 **여러 번** 돌린다. 그런데
결과 저장소는 회차를 하나만 보관한다(`result_store.KEEP_RUNS = 1`). 즉 에이전트가
한 번 돌 때마다 **사용자가 보고 있던 결과가 사라진다.** 범위별 Excel도 함께
폐기된다(`exports.invalidate()`).

실제로 그랬다 — 어제 에이전트를 돌린 뒤 TRION 기준값을 손으로 다시 만들어야 했다.
오류가 나지 않으니 알아채는 것은 «어? 아까 그 숫자가 아닌데»뿐이다.

## 무엇을 하는가

지금 데이터 폴더를 **통째로 복사**해서 별도 포트로 띄울 수 있게 한다. 에이전트는
거기서 마음껏 재검증하고, 사용자의 8001은 건드리지 않는다. 덤으로 두 에이전트가
**동시에** 돌 수 있다 — 예전에는 서버를 공유해서 순차로만 가능했다.

    python -m tools.sandbox_server                 # 복사하고 포트를 잡아 준다
    python -m tools.sandbox_server --start         # 서버까지 띄운다
    python -m tools.sandbox_server --clean         # 샌드박스를 지운다

## 복사하지 않는 것

`qc_results/scoped/`(범위별 Excel)는 뺀다. 전부 다시 만들 수 있고, 부서 하나에
1분씩 걸리는 것들이라 복사만으로도 오래 걸린다. 검증에는 쓰이지 않는다.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
from pathlib import Path

from backend import config

# 샌드박스는 저장소 **밖**에 둔다. 안에 두면 `.gitignore`에 또 한 줄이 필요하고,
# 실수로 커밋하면 사내 데이터가 통째로 올라간다.
DEFAULT_ROOT = Path(tempfile.gettempdir()) / "qc-sandbox"

# 검증에 쓰이지 않으면서 무거운 것들
SKIP = {"scoped"}


def free_port(start: int = 8011, tries: int = 40) -> int:
    """비어 있는 포트를 찾는다. **8001~8010은 건드리지 않는다** — 사용자의
    프로젝트 서버가 그 대역을 쓴다(`data/projects.json`)."""
    for port in range(start, start + tries):
        with socket.socket() as s:
            s.settimeout(0.3)
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    raise RuntimeError(f"{start}~{start + tries}에 빈 포트가 없다")


def _copy_tree(src: Path, dst: Path) -> int:
    if not src.exists():
        return 0
    n = 0
    for p in src.rglob("*"):
        if p.is_dir() or any(part in SKIP for part in p.relative_to(src).parts):
            continue
        # 엑셀 잠금 파일은 열려 있으면 복사에 실패한다. 필요하지도 않다.
        if p.name.startswith("~$"):
            continue
        out = dst / p.relative_to(src)
        out.parent.mkdir(parents=True, exist_ok=True)
        try:
            shutil.copy2(p, out)
            n += 1
        except OSError:
            # 열려 있는 파일 하나 때문에 샌드박스 전체를 포기하지 않는다
            pass
    return n


def prepare(root: Path) -> dict:
    """지금 데이터 폴더를 샌드박스로 복사한다."""
    src = config.DATA_ROOT
    if root.exists():
        shutil.rmtree(root, ignore_errors=True)
    root.mkdir(parents=True, exist_ok=True)

    counts = {}
    for name in ("data", "qc_uploads", "qc_results", "Raw data"):
        counts[name] = _copy_tree(src / name, root / name)

    return {"source": str(src), "data_dir": str(root), "files": counts}


def start(root: Path, port: int) -> subprocess.Popen:
    """샌드박스를 물고 uvicorn을 띄운다.

    환경변수는 **자식에게만** 넘긴다. 부모 환경을 바꾸면 같은 셸에서 이어 실행하는
    다른 명령이 샌드박스를 물게 되고, 그건 «왜 결과가 안 바뀌지»로 나타난다.
    """
    env = dict(os.environ)
    env["QC_DATA_DIR"] = str(root)
    env["QC_PROJECT"] = "SANDBOX"      # 화면 배지에 뜬다 — 실서버와 헷갈리지 않게
    return subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "backend.main:app",
         "--host", "127.0.0.1", "--port", str(port)],
        cwd=str(config.BASE), env=env,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )


def main() -> int:
    ap = argparse.ArgumentParser(description="검증용 샌드박스 데이터 폴더")
    ap.add_argument("--root", default=str(DEFAULT_ROOT), help="샌드박스 위치")
    ap.add_argument("--port", type=int, default=0, help="0이면 빈 포트를 찾는다")
    ap.add_argument("--start", action="store_true", help="서버까지 띄운다")
    ap.add_argument("--clean", action="store_true", help="샌드박스를 지우고 끝낸다")
    args = ap.parse_args()

    root = Path(args.root)
    if args.clean:
        shutil.rmtree(root, ignore_errors=True)
        print(json.dumps({"cleaned": str(root)}, ensure_ascii=False))
        return 0

    info = prepare(root)
    info["port"] = args.port or free_port()
    if args.start:
        p = start(root, info["port"])
        info["pid"] = p.pid
    # 결과는 **JSON 한 줄**로만 낸다 — 에이전트가 파싱한다. 그리고 콘솔이 cp949라
    # 한글 설명을 섞으면 UnicodeEncodeError로 죽는다.
    print(json.dumps(info, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
