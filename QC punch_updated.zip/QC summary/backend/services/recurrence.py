"""
반복 결함 패턴 탐지 — verifier.py의 Check처럼 행 하나하나를 판정하는 게 아니라,
이미 만들어진 부서 결함 리스트(dept_data['defects'])를 사후 집계해 "같은 용접사가
같은 Check 항목에서 서로 다른 날짜에 반복적으로 걸리는" 패턴을 찾아내는 순수
통계 유틸리티다. 규칙 위반 여부를 새로 판정하는 게 아니라, 이미 확정된 결함들
사이의 시간적 재발 패턴을 표면화해 부서별 결함 탭/부서 리포트 메일에서
교육·재발방지 참고 자료로 쓰기 위한 것이다.

각 패턴에는 "어떤 항목이 어떻게 발생하고 있는지"를 설명하는 한 줄 요약(summary)을
붙인다. 요약은 외부 AI/API를 쓰지 않고 Check 종류별 규칙 템플릿 + 실제 값 집계만으로
결정적(deterministic)으로 만든다 - 같은 입력이면 항상 같은 문장이 나온다.
"""
import re
from collections import Counter, defaultdict
from typing import Any

MIN_DISTINCT_DATES = 2   # 서로 다른 용접일에서 2번 이상 걸려야 "반복"으로 본다
# Check 6(용접사 자격 미등록)은 용접 품질 문제가 아니라 서류/등록 문제라
# 용접사 결함률 집계에서도 제외해온 기존 관례를 여기서도 그대로 따른다.
EXCLUDE_CHECK_NOS = {6}


# ─── 한 줄 요약 생성 ──────────────────────────────────────────────────────────
def _top(values: list[str], n: int = 2) -> list[tuple[str, int]]:
    return Counter(v for v in values if v).most_common(n)


def _fmt_top(values: list[str], n: int = 2, quote: str = "") -> str:
    """가장 많이 나온 값 n개를 '값(건수)' 형태로 이어붙인다."""
    parts = [f"{quote}{v}{quote} {c}건" for v, c in _top(values, n)]
    return ", ".join(parts)


def _strip_quotes(s: str) -> str:
    return (s or "").strip().strip("'").strip('"').strip()


def _numbers(values: list[str]) -> list[float]:
    out: list[float] = []
    for v in values:
        m = re.search(r"(\d+(?:\.\d+)?)", v or "")
        if m:
            try:
                out.append(float(m.group(1)))
            except ValueError:
                pass
    return out


def _fmt_num(x: float) -> str:
    return str(int(x)) if float(x).is_integer() else f"{x:g}"


def _timing_phrase(date_counts: dict[str, int], distinct_dates: int, total: int) -> str:
    """언제/어떻게 반복되는지 (특정일 집중 vs 여러 날 분산)."""
    if not date_counts:
        return ""
    top_date, top_cnt = max(date_counts.items(), key=lambda kv: kv[1])
    if total and top_cnt / total >= 0.5 and distinct_dates > 1:
        return f"{top_date[5:]} 하루에 {top_cnt}건 집중"
    return f"{distinct_dates}개 날짜에 분산"


def _summary_c3(actuals: list[str], expected: list[str]) -> str:
    nums = _numbers(actuals)
    wps = ""
    m = re.search(r"WPS=([A-Z0-9\-]+)", expected[0] if expected else "")
    if m:
        wps = f" {m.group(1)}"
    if nums:
        lo, hi = min(nums), max(nums)
        rng = _fmt_num(lo) if lo == hi else f"{_fmt_num(lo)}~{_fmt_num(hi)}"
        return f"{wps.strip()} 허용 두께를 벗어난 {rng}mm 자재를 반복 사용".strip()
    return "허용 두께 범위를 벗어난 자재를 반복 사용"


def _summary_c4(actuals: list[str], expected: list[str]) -> str:
    vals = [_strip_quotes(a) for a in actuals]
    top = _fmt_top(vals, 2)
    return f"WPS가 허용하지 않는 Groove({top})를 반복 적용" if top else "허용되지 않는 Groove를 반복 적용"


def _summary_c5(actuals: list[str], expected: list[str]) -> str:
    cats = []
    for a in actuals:
        m = re.search(r"NDT Cat=([A-Z0-9]+)", a or "")
        if m:
            cats.append(m.group(1))
    top = _fmt_top(cats, 2)
    return (f"NDT Cat {top} 물량에 G03 대신 G01을 반복 적용" if top
            else "NDT Cat A/B 물량에 G03 대신 G01을 반복 적용")


def _summary_c11(actuals: list[str], expected: list[str]) -> str:
    vals = [_strip_quotes(a) for a in actuals]
    top = _fmt_top(vals, 2)
    return f"해당 WPS 미승인 재질({top})을 반복 사용" if top else "해당 WPS 미승인 재질을 반복 사용"


def _summary_c12(actuals: list[str], expected: list[str]) -> str:
    vals = []
    for a in actuals:
        m = re.search(r"Out Dia='([^']+)'", a or "")
        if m:
            vals.append(m.group(1))
    top = _fmt_top(vals, 2)
    return f"관재 규격({top}) 수동 확인 대상이 반복 발생" if top else "관재 규격 수동 확인 대상이 반복 발생"


def _summary_c13(actuals: list[str], expected: list[str]) -> str:
    fields = []
    for a in actuals:
        m = re.match(r"\s*([a-z_0-9]+)=", a or "")
        if m:
            fields.append(m.group(1))
    top = _fmt_top(fields, 2)
    return (f"통계적으로 드문 조합({top})이 반복 감지 (규칙 위반 아님, 확인 필요)" if top
            else "통계적으로 드문 조합이 반복 감지 (규칙 위반 아님, 확인 필요)")


def _summary_c14(actuals: list[str], expected: list[str]) -> str:
    """actual 예: "두께 ['20', '25'] / WPS ['TR-FC-F01', 'TR-FC-G01']" """
    field_cnt: Counter = Counter()
    for a in actuals:
        for name in ("재질", "두께", "WPS"):
            if f"{name} [" in (a or ""):
                field_cnt[name] += 1
    if field_cnt:
        fields = ", ".join(f"{k}" for k, _ in field_cnt.most_common(3))
        return f"동일 Joint가 서로 다른 {fields} 값으로 중복 등록되는 사례가 반복"
    return "동일 Joint가 서로 다른 값으로 중복 등록되는 사례가 반복"


_SUMMARY_BUILDERS = {
    3:  _summary_c3,
    4:  _summary_c4,
    5:  _summary_c5,
    11: _summary_c11,
    12: _summary_c12,
    13: _summary_c13,
    14: _summary_c14,
}


def build_summary(check_no: int, check_name: str, actuals: list[str],
                  expected: list[str], date_counts: dict[str, int],
                  distinct_dates: int, total: int) -> str:
    """
    Check 종류별 규칙 템플릿으로 "무엇이 어떻게 반복되는지" 한 줄 요약을 만든다.
    외부 API를 쓰지 않으며 입력이 같으면 항상 같은 문장을 돌려준다.
    """
    builder = _SUMMARY_BUILDERS.get(check_no)
    if builder is not None:
        what = builder(actuals, expected)
    else:
        top = _fmt_top([_strip_quotes(a) for a in actuals], 2)
        what = f"{check_name} 반복 발생({top})" if top else f"{check_name} 반복 발생"
    timing = _timing_phrase(date_counts, distinct_dates, total)
    return f"{what} - {timing}" if timing else what


# ─── 반복 패턴 탐지 ──────────────────────────────────────────────────────────
def detect_recurring_patterns(defects: list[dict]) -> list[dict]:
    """
    부서(또는 팀) 단위 defects 리스트를 받아 (용접사, Check) 조합별로 발생 건수와
    서로 다른 용접일 수를 집계하고, distinct 날짜가 MIN_DISTINCT_DATES 이상인
    조합만 "반복 결함 패턴"으로 추려 발생 건수 내림차순으로 반환한다.
    """
    combo: dict[tuple[str, int], dict[str, Any]] = defaultdict(lambda: {
        'count': 0, 'dates': set(), 'check_name': '', 'rows': [],
        'date_counts': defaultdict(int), 'actuals': [], 'expected': [],
    })
    for de in defects:
        wno = (de.get('welder1_no') or '').strip()
        wdate = de.get('weld_date') or ''
        if not wno:
            continue
        for c in de.get('checks', []):
            if c['check_no'] in EXCLUDE_CHECK_NOS:
                continue
            entry = combo[(wno, c['check_no'])]
            entry['count'] += 1
            if wdate:
                entry['dates'].add(wdate)
                entry['date_counts'][wdate] += 1
            entry['check_name'] = c['check_name']
            entry['rows'].append(de.get('row'))
            entry['actuals'].append(c.get('actual') or '')
            if c.get('expected'):
                entry['expected'].append(c['expected'])

    result: list[dict] = []
    for (wno, check_no), v in combo.items():
        if len(v['dates']) < MIN_DISTINCT_DATES:
            continue
        dates_sorted = sorted(v['dates'])
        result.append({
            'welder_no':      wno,
            'check_no':       check_no,
            'check_name':     v['check_name'],
            'count':          v['count'],
            'distinct_dates': len(v['dates']),
            'first_date':     dates_sorted[0],
            'last_date':      dates_sorted[-1],
            'rows':           v['rows'],
            'summary':        build_summary(
                check_no, v['check_name'], v['actuals'], v['expected'],
                dict(v['date_counts']), len(v['dates']), v['count'],
            ),
        })
    result.sort(key=lambda x: -x['count'])
    return result
