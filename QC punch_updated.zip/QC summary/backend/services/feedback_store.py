"""
Human-in-the-loop 피드백 저장소 (Check 1~13 플래그에 대한 사람의 판정 기록).

목적:
  1) QC 담당자가 각 플래그를 "결함확정/오탐/확인중"으로 분류하고 remark를 남겨
     검토 이력을 남긴다 (Action 로그의 최소 형태).
  2) 이 기록이 나중에 지도학습 라벨의 출발점이 된다 — 규칙 엔진 출력 자체를
     라벨로 쓰면 안 된다는 것이 verifier 감사에서 이미 확인됐으므로, 사람이
     확인한 결과만 신뢰 가능한 라벨이다.

식별 키: (drawing_no, joint_no, wps_no, check_no) 조합. 행 번호(row)를 쓰지 않는
이유는, 재검증(새 엑셀 업로드) 후 같은 조인트가 다른 행 번호로 나타날 수 있어 행
번호 기준으로는 이전 피드백이 이어지지 않기 때문이다.

도면번호(drawing_no)가 반드시 키에 들어가야 한다 — Joint No는 도면 안에서만
유일해서 도면이 다르면 같은 번호가 다시 등장한다(Check 14 구현 중 확인). 도면번호를
빼면 서로 무관한 조인트가 한 키를 공유해, 한 건을 검토하면 다른 도면의 조인트까지
검토 완료로 표시된다(실측: 전체 플래그의 72.6%가 영향권, 최악 사례는 키 1개가
31개 도면·43개 행에 걸침).

레코드에는 판정 당시의 원본 데이터(열 정보)를 통째로 함께 저장한다 — 나중에
이 기록만 보고도(원본 엑셀이 그때와 달라졌더라도) "무엇을 보고 이렇게 판단했는지"
이해할 수 있어야 하기 때문이다. 최신 상태만 유지하며(요청된 갱신 방식), 과거
이력을 별도로 쌓지는 않는다 — updated_at/reviewer_id는 마지막 갱신자만 남는다.
"""
import json
import logging
import threading
from datetime import datetime, timezone, timedelta
from typing import Any

from backend import config

logger = logging.getLogger(__name__)

_lock = threading.Lock()

RESULT_CHOICES = ("결함확정", "오탐", "확인중")

_KST = timezone(timedelta(hours=9))


def _make_key(drawing_no: str, joint_no: str, wps_no: str,
              check_no: int | str) -> str:
    # f-string이라 `3`과 `"3"`이 같은 키를 만든다 — 공통 항목 검토 기록
    # 1,570건이 식별자 문자열화에도 그대로 살아남는 이유다.
    return (f"{(drawing_no or '').strip()}|{(joint_no or '').strip()}"
            f"|{(wps_no or '').strip()}|{check_no}")


def _migrate_legacy_keys(data: dict[str, dict]) -> tuple[dict[str, dict], int]:
    """
    도면번호가 없던 구 키(`joint|wps|check`, 구분자 3토막)를 신 키로 옮긴다.
    저장할 때 flag_snapshot에 drawing_no를 함께 남겨왔으므로 그 값으로 복원한다.
    도면번호를 알 수 없는 기록은 손실 방지를 위해 구 키 그대로 남겨둔다.
    """
    migrated = 0
    out: dict[str, dict] = {}
    for key, rec in data.items():
        if key.count('|') == 3:          # 이미 신 키 형식
            out[key] = rec
            continue
        drawing_no = (rec.get('flag_snapshot') or {}).get('drawing_no', '')
        if not drawing_no:
            out[key] = rec               # 복원 불가 — 그대로 보존
            continue
        rec['drawing_no'] = drawing_no
        out[_make_key(drawing_no, rec.get('joint_no', ''),
                      rec.get('wps_no', ''), rec.get('check_no', 0))] = rec
        migrated += 1
    return out, migrated


def load_feedback() -> dict[str, dict]:
    """전체 피드백 레코드 로드 ({key: record} 딕셔너리). 파일 없으면 빈 딕셔너리."""
    try:
        data = json.loads(config.FEEDBACK_FILE.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except Exception as exc:
        logger.error("flag_feedback.json 읽기 오류: %s", exc)
        return {}
    data, migrated = _migrate_legacy_keys(data)
    if migrated:
        logger.info("피드백 키 마이그레이션(도면번호 추가): %d건", migrated)
        try:
            _save_feedback(data)
        except Exception as exc:
            logger.error("피드백 키 마이그레이션 저장 실패: %s", exc)
    return data


def _save_feedback(data: dict[str, dict]) -> None:
    config.FEEDBACK_FILE.parent.mkdir(parents=True, exist_ok=True)
    config.FEEDBACK_FILE.write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def upsert_many(records: list[dict], reviewer_id: str, remark: str) -> int:
    """여러 플래그에 **같은 판정**을 한 번에 기록한다. 저장한 건수를 돌려준다.

    현업 확인 한 번으로 수백~수천 건의 성격이 한꺼번에 정해지는 경우가 있다.
    예: 「TR-FC-G01이 PJP를 포함한다」는 답변 하나로 Check 4의 600건이 전부
    오탐이 된다. 한 건씩 `upsert_feedback()`을 부르면 그때마다 파일을 통째로
    읽고 쓰므로, 락을 한 번만 잡고 한 번만 저장한다.

    `records`의 각 항목은 `{drawing_no, joint_no, wps_no, check_no, result}`와
    선택적으로 `flag_snapshot`을 갖는다.

    **`remark`에 근거를 반드시 남긴다.** 이 기록은 지도학습 라벨이 되므로,
    나중에 «왜 이렇게 붙었는지»를 되짚을 수 없으면 라벨을 신뢰할 수 없다.
    """
    now = datetime.now(_KST).isoformat(timespec="seconds")
    with _lock:
        data = load_feedback()
        n = 0
        for r in records:
            result = r["result"]
            if result not in RESULT_CHOICES:
                raise ValueError(f"알 수 없는 result 값: {result!r}")
            key = _make_key(r.get("drawing_no", ""), r.get("joint_no", ""),
                            r.get("wps_no", ""), r["check_no"])
            data[key] = {
                "drawing_no":    (r.get("drawing_no") or "").strip(),
                "joint_no":      (r.get("joint_no") or "").strip(),
                "wps_no":        (r.get("wps_no") or "").strip(),
                "check_no":      r["check_no"],
                "result":        result,
                "remark":        r.get("remark") or remark,
                "reviewer_id":   reviewer_id,
                "updated_at":    now,
                "flag_snapshot": r.get("flag_snapshot") or {},
                "row_raw":       [],
            }
            n += 1
        _save_feedback(data)
    logger.info("검토 기록 일괄 저장: %d건 (%s)", n, remark[:40])
    return n


def upsert_feedback(
    drawing_no: str,
    joint_no: str,
    wps_no: str,
    check_no: int | str,
    result: str,
    remark: str,
    reviewer_id: str,
    flag_snapshot: dict[str, Any] | None = None,
    row_raw: list[dict] | None = None,
) -> dict:
    """
    읽기→수정→저장을 락 하나로 원자적으로 처리(employees.json의 update_employees와
    동일한 패턴). 같은 (drawing_no, joint_no, wps_no, check_no)에 다시 저장하면
    기존 기록을 덮어쓴다(요청된 대로 이력 누적이 아니라 최신 상태 갱신).
    """
    if result not in RESULT_CHOICES:
        raise ValueError(f"알 수 없는 result 값: {result!r} (허용: {RESULT_CHOICES})")

    key = _make_key(drawing_no, joint_no, wps_no, check_no)
    with _lock:
        data = load_feedback()
        record = {
            "drawing_no":   (drawing_no or "").strip(),
            "joint_no":     (joint_no or "").strip(),
            "wps_no":       (wps_no or "").strip(),
            "check_no":     check_no,
            "result":       result,
            "remark":       remark or "",
            "reviewer_id":  reviewer_id,
            "updated_at":   datetime.now(_KST).isoformat(timespec="seconds"),
            "flag_snapshot": flag_snapshot or {},
            "row_raw":      row_raw or [],
        }
        data[key] = record
        _save_feedback(data)
        return record
