"""
결과 Excel 생성기 — 요약/결함목록/원본마킹/미작업/검토기록 시트를 한 파일로 묶는다.

## 왜 원본 시트만으로는 부족했나

기존 산출물은 QMG 원본(10,034행 x 78열)을 복사해 결함 셀에 색을 칠하고 주석을 다는
방식이었다. 현장 양식 그대로라는 장점이 있지만:

- 주석이 **hover로만** 보여서 인쇄하거나 스캔하면 지적 내용이 사라진다
- 원본 위 색칠이라 **필터/정렬/피벗이 불가능**하다 - 받는 사람이 "우리 팀 Check 3만"을
  뽑아보려면 손으로 찾아야 한다
- 결함 46행을 받자고 10,034행짜리 파일을 뒤져야 하는 부서가 있다

그래서 원본 시트는 **그대로 두고**(현장이 익숙한 양식을 깨지 않는다) 그 앞에
집계/평면 시트를 얹는다. '결함 목록' 시트가 핵심으로, 플래그 1건이 1행이 되어
엑셀에서 자유롭게 다룰 수 있다.

## 범위(scope) 지정

부서/팀을 지정하면 그 범위의 행만 남긴다. 원본 시트는 `delete_rows`로 대상 외 행을
지우는데, 실측상 서식/주석/열너비/병합이 모두 보존된다.

**비용 주의**: 삭제 비용은 '남길 행 수'가 아니라 '흩어진 정도'에 비례한다.
실측(10,034행 기준):

    건조5부  (117행 유지, 연속구간  5개):  로드 8.6s + 삭제  1.5s + 저장 0.2s
    Q520     (4,430행 유지, 연속구간 79개): 로드 8.6s + 삭제 39.1s + 저장 4.3s

즉 큰 부서 한 곳이 1분가량 걸린다. 요청 시점에 만들면 사용자가 그만큼 기다리므로,
호출하는 쪽에서 백그라운드로 미리 만들어 두는 것을 전제로 한다.
"""

from __future__ import annotations

import logging
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from . import project_checks
from openpyxl import load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from . import wps_rules

logger = logging.getLogger(__name__)

# 원본 시트에서 부서/팀을 읽는 열 (1-based). verifier.Col과 같은 값이지만
# 이 모듈이 verifier를 임포트하지 않도록 여기 다시 둔다 - 순환 임포트를 피하고,
# 이 파일만 봐도 무엇을 읽는지 알 수 있게 한다.
COL_DRAWING_NO = 1    # A
COL_DEPARTMENT = 58   # BF
COL_TEAM = 59         # BG

# 원본 시트에서 헤더로 보존할 상단 행 수. verifier의 헤더 탐지와 무관하게,
# 실데이터에서 데이터가 6행부터 시작하므로 5행까지는 무조건 남긴다.
HEADER_ROWS = 5

_HDR_FILL = PatternFill("solid", start_color="1F3864", end_color="1F3864")
_HDR_FONT = Font(color="FFFFFF", bold=True, size=10)
_TITLE_FONT = Font(bold=True, size=14)
_SUB_FONT = Font(color="808080", size=9)
_THIN = Side(style="thin", color="BFBFBF")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

# Check 색상 -> 엑셀 채움색 (verifier._FILLS와 같은 값).
#
# 위 COL_* 와 같은 이유로 verifier를 임포트하지 않고 값을 다시 둔다. 대신 어긋나면
# `tests/test_excel_report.py::test_check_colors_match_verifier`가 잡는다 —
# Check를 추가할 때 원본 시트는 새 색으로 칠해지는데 '결함 목록' 시트만 색이
# 빠지는 일이 생기고, 예외가 나지 않아 발견이 늦기 때문이다.
_CHECK_COLOR = {
    "Red": "FF0000", "Green": "00B050", "Blue": "0070C0", "Yellow": "FFFF00",
    "Orange": "FF7F00", "Black": "000000", "Purple": "7030A0", "Teal": "008080",
    "Gray": "BFBFBF", "Cyan": "00B0C0", "Brown": "833C00",
    "Olive": "808000", "Navy": "1F3864", "Rose": "C0504D",
    "Maroon": "7B2E2E", "Indigo": "4B3F8F",
}


# ─── 범위 필터 ────────────────────────────────────────────────────────────────
class Scope:
    """내보낼 범위. dept/team이 모두 None이면 전체.

    `exclude_temp`는 임시부재(도면번호 1C*)를 파일에서 통째로 뺀다 — 대시보드
    토글과 같은 규칙이다. **범위와 함께 파일 이름·캐시 키에 들어가야 한다.**
    같은 부서인데 내용이 다른 두 파일이 생기므로, 구분되지 않으면 «1C를 뺀 줄
    알고 받았는데 들어 있는» 파일이 나간다. 그건 받은 사람이 열어 보기 전에는
    알 수 없다.
    """

    def __init__(self, dept: str | None = None, team: str | None = None,
                 exclude_temp: bool = False):
        self.dept = (dept or "").strip() or None
        self.team = (team or "").strip() or None
        self.exclude_temp = bool(exclude_temp)
        if self.team and not self.dept:
            raise ValueError("팀을 지정하려면 부서도 지정해야 합니다")

    @property
    def is_all(self) -> bool:
        """조직 범위가 «전체»인가. 임시부재 제외와는 무관하다."""
        return self.dept is None

    @property
    def keeps_every_row(self) -> bool:
        """행을 하나도 걸러내지 않는가 — 원본 시트를 줄일 필요가 있는지 판단."""
        return self.is_all and not self.exclude_temp

    @property
    def label(self) -> str:
        base = f"{self.dept} > {self.team}" if self.team else (self.dept or "전체")
        return base + (" · 임시부재 제외" if self.exclude_temp else "")

    def slug(self) -> str:
        """파일명에 쓸 수 있는 형태. 경로 구분자/공백을 없앤다."""
        raw = "전체" if self.is_all else (
            f"{self.dept}_{self.team}" if self.team else self.dept)
        out = "".join(ch for ch in raw if ch.isalnum() or ch in "-_가-힣" or ord(ch) > 127)
        return out + ("_임시부재제외" if self.exclude_temp else "")

    def matches(self, dept: Any, team: Any, drawing_no: Any = None) -> bool:
        if self.exclude_temp and wps_rules.is_temp_member(drawing_no):
            return False
        if self.is_all:
            return True
        if (dept or "").strip() != self.dept:
            return False
        if self.team and (team or "").strip() != self.team:
            return False
        return True

    def filter_flags(self, flags: list[dict]) -> list[dict]:
        if self.keeps_every_row:
            return flags
        return [f for f in flags
                if self.matches(f.get("department"), f.get("team"),
                                f.get("drawing_no"))]


# ─── 시트 공통 헬퍼 ───────────────────────────────────────────────────────────
def _write_header(ws: Worksheet, row: int, headers: list[tuple[str, int]]) -> None:
    """헤더 행 + 열 너비 + 자동필터 + 틀 고정을 한 번에."""
    for i, (name, width) in enumerate(headers, start=1):
        c = ws.cell(row=row, column=i, value=name)
        c.fill = _HDR_FILL
        c.font = _HDR_FONT
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = _BORDER
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.auto_filter.ref = f"A{row}:{get_column_letter(len(headers))}{row}"
    ws.freeze_panes = ws.cell(row=row + 1, column=1)


def _title(ws: Worksheet, text: str, sub: str) -> int:
    """시트 제목 2줄을 쓰고 다음 사용 가능 행을 돌려준다."""
    ws["A1"] = text
    ws["A1"].font = _TITLE_FONT
    ws["A2"] = sub
    ws["A2"].font = _SUB_FONT
    return 4


def _setup_print(ws: Worksheet, landscape: bool = True, repeat_row: int | None = None) -> None:
    """인쇄 설정 — 현장에서 출력해 쓰는 경우가 많다."""
    ws.page_setup.orientation = "landscape" if landscape else "portrait"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    if repeat_row:
        ws.print_title_rows = f"{repeat_row}:{repeat_row}"


# ─── ① 요약 시트 ──────────────────────────────────────────────────────────────
def _sheet_summary(wb, result: dict, scope: Scope, flags: list[dict]) -> None:
    ws = wb.create_sheet("요약", 0)
    r = _title(ws, f"QC 검증 요약 — {scope.label}",
               f"검증 실행 {result.get('run_at', '')} · 원본 {result.get('qmg_filename', '')}")

    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 14
    ws.column_dimensions["C"].width = 46

    def kv(label: str, value: Any, note: str = "") -> None:
        nonlocal r
        ws.cell(row=r, column=1, value=label).font = Font(bold=True)
        c = ws.cell(row=r, column=2, value=value)
        c.alignment = Alignment(horizontal="right")
        ws.cell(row=r, column=3, value=note).font = _SUB_FONT
        r += 1

    # 범위에 맞는 집계를 고른다. 전체면 최상위 값, 부서/팀이면 그 버킷 값.
    bucket = _scope_bucket(result, scope)
    judged = bucket.get("total_rows", 0)
    defect_rows = len({f["row"] for f in flags})
    clean = max(judged - defect_rows, 0)

    kv("판정 대상", judged, "삭제/미작업을 제외한 행 — 모든 결함률의 분모")
    kv("결함 발생", defect_rows, f"판정 대상의 {defect_rows / judged * 100:.1f}%" if judged else "")
    kv("이상 없음", clean, f"판정 대상의 {clean / judged * 100:.1f}%" if judged else "")
    kv("미작업", bucket.get("unworked_rows", 0), "Check 0 — 결함이 아니며 분모에서 제외")
    kv("총 지적 건수", len(flags), "한 행에 여러 Check가 걸릴 수 있어 결함 행수보다 많다")
    r += 1

    # Check별
    ws.cell(row=r, column=1, value="검사 항목별 지적 건수").font = Font(bold=True, size=11)
    r += 1
    _write_header(ws, r, [("Check", 10), ("건수", 10), ("검사 이름", 46)])
    hdr = r
    r += 1
    by_check = Counter(f["check_no"] for f in flags)
    names = {f["check_no"]: f["check_name"] for f in flags}
    colors = {f["check_no"]: f["color"] for f in flags}
    # 식별자가 «3»과 «RUYA1»로 섞인다 — 기본 정렬은 문자열 순이라
    # `10`이 `2`보다 앞에 온다. 공통을 숫자순으로 먼저 둔다.
    for no, cnt in sorted(by_check.items(), key=lambda kv: project_checks.sort_key(kv[0])):
        ws.cell(row=r, column=1, value=f"Check {project_checks.label(no)}").border = _BORDER
        cc = ws.cell(row=r, column=1)
        rgb = _CHECK_COLOR.get(colors.get(no, ""), None)
        if rgb:
            cc.fill = PatternFill("solid", start_color=rgb, end_color=rgb)
            if rgb in ("000000", "833C00", "7030A0", "0070C0", "FF0000"):
                cc.font = Font(color="FFFFFF", bold=True)
            else:
                cc.font = Font(bold=True)
        ws.cell(row=r, column=2, value=cnt).border = _BORDER
        ws.cell(row=r, column=3, value=names.get(no, "")).border = _BORDER
        r += 1
    ws.auto_filter.ref = None   # 요약 시트는 필터를 걸지 않는다
    ws.freeze_panes = None
    r += 1

    # 전체 범위일 때만 부서 순위를 넣는다 (부서 파일에는 자기 부서만 있으므로 무의미)
    if scope.is_all:
        ws.cell(row=r, column=1, value="부서별 현황").font = Font(bold=True, size=11)
        r += 1
        _write_header(ws, r, [("부서", 26), ("결함 행", 10), ("판정 대상", 46)])
        ws.auto_filter.ref = None
        ws.freeze_panes = None
        r += 1
        depts = result.get("departments") or {}
        for name, d in sorted(depts.items(), key=lambda x: -x[1].get("defect_rows", 0)):
            ws.cell(row=r, column=1, value=name).border = _BORDER
            ws.cell(row=r, column=2, value=d.get("defect_rows", 0)).border = _BORDER
            tot = d.get("total_rows", 0)
            rate = f"{d.get('defect_rows', 0) / tot * 100:.1f}%" if tot else "-"
            ws.cell(row=r, column=3, value=f"{tot}행 중 {rate}").border = _BORDER
            r += 1

    _setup_print(ws, landscape=False)


def _scope_bucket(result: dict, scope: Scope) -> dict:
    """범위에 해당하는 집계 버킷. 전체면 최상위 result를 그대로 쓴다."""
    if scope.is_all:
        return {
            "total_rows": result.get("judged_rows", 0),
            "unworked_rows": result.get("unworked_rows", 0),
        }
    dept = (result.get("departments") or {}).get(scope.dept) or {}
    if scope.team:
        return (dept.get("teams") or {}).get(scope.team) or {}
    return dept


# ─── ② 결함 목록 시트 ─────────────────────────────────────────────────────────
_FLAG_COLS: list[tuple[str, int, str]] = [
    ("원본 행",   9,  "row"),
    ("Check",     8,  "_check"),
    ("검사 이름", 24, "check_name"),
    # NDT REPORT 번호(BE열)를 도면번호 «앞»에 둔다 — 현업이 산출물을 되짚을 때
    # 쥐고 있는 추적 키가 도면번호가 아니라 이 번호다. 값이 없는 행이 44.8%인데,
    # 그건 NDT 계획 자체가 없는 행이라 비어 있는 것이 정상이다.
    ("NDT REPORT 번호", 18, "ndt_report"),
    ("도면번호",  26, "drawing_no"),
    ("Joint No",  14, "joint_no"),
    ("블록",      10, "block"),
    ("부서",      22, "department"),
    ("팀",        20, "team"),
    ("용접사",    10, "welder1_no"),
    ("WPS",       15, "wps_no"),
    ("Process",   9,  "wps_process"),
    ("재질",      14, "material1"),
    ("두께",      8,  "thickness1"),
    ("용접일",    12, "weld_date"),
    ("NDT일",     12, "ndt_date"),
    ("마킹 열",   9,  "col_letter"),
    ("기준값",    38, "expected"),
    ("실제값",    38, "actual"),
    ("지적 내용", 46, "msg"),
]


def _sheet_flags(wb, result: dict, scope: Scope, flags: list[dict]) -> None:
    """플래그 1건 = 1행. 이 시트가 이 파일의 핵심 작업면이다.

    원본 시트는 색칠+주석이라 필터도 정렬도 안 되지만, 여기서는 엑셀 기능을
    그대로 쓸 수 있다. 주석에만 있던 기준값/실제값도 실제 셀 값이 되어
    인쇄와 검색이 된다.
    """
    ws = wb.create_sheet("결함 목록", 1)
    r = _title(ws, f"결함 목록 — {scope.label}",
               f"총 {len(flags)}건 · 자동 필터가 걸려 있습니다 (열 머리글의 화살표)")

    _write_header(ws, r, [(n, w) for n, w, _ in _FLAG_COLS])
    hdr_row = r
    r += 1

    for f in sorted(flags, key=lambda x: (x.get("row", 0), x.get("check_no", 0))):
        for i, (_, _, key) in enumerate(_FLAG_COLS, start=1):
            if key == "_check":
                val = f.get("check_no")
            else:
                val = f.get(key, "")
            c = ws.cell(row=r, column=i, value=val)
            c.border = _BORDER
            c.alignment = Alignment(vertical="top", wrap_text=(key in ("expected", "actual", "msg")))
        # Check 번호 칸에 색을 칠해 화면과 같은 기준으로 읽히게 한다
        rgb = _CHECK_COLOR.get(f.get("color", ""), None)
        if rgb:
            cc = ws.cell(row=r, column=2)
            cc.fill = PatternFill("solid", start_color=rgb, end_color=rgb)
            cc.font = Font(color="FFFFFF" if rgb in ("000000", "833C00", "7030A0", "0070C0", "FF0000") else "000000",
                           bold=True)
            cc.alignment = Alignment(horizontal="center", vertical="center")
        r += 1

    _setup_print(ws, landscape=True, repeat_row=hdr_row)


# ─── ③ 미작업 시트 ────────────────────────────────────────────────────────────
def _sheet_unworked(wb, result: dict, scope: Scope) -> int:
    # `/api/result` 응답에서 미작업 목록을 뺐으므로(payload의 17%), 여기서는
    # 저장소에서 직접 가져온다. result에 남아 있으면 그걸 쓴다 — 판정 직후처럼
    # 아직 저장을 거치지 않은 결과도 받을 수 있어야 한다.
    src = result.get("unworked_list")
    if not src:
        from . import result_store
        src = result_store.get_unworked()["items"]
    rows = [u for u in src
            if scope.matches(u.get("department"), u.get("team"))]
    if not rows:
        return 0
    ws = wb.create_sheet("미작업")
    r = _title(ws, f"미작업 수량 (Check 0) — {scope.label}",
               f"총 {len(rows)}건 · 결함이 아닙니다. WPS No(AJ열)가 비어 있어 아직 시공되지 않은 계획 물량입니다")
    _write_header(ws, r, [("원본 행", 9), ("도면번호", 26), ("Joint No", 14),
                          ("블록", 10), ("부서", 22), ("팀", 20)])
    hdr = r
    r += 1
    for u in sorted(rows, key=lambda x: x.get("row", 0)):
        for i, key in enumerate(("row", "drawing_no", "joint_no", "block", "department", "team"), start=1):
            ws.cell(row=r, column=i, value=u.get(key, "")).border = _BORDER
        r += 1
    _setup_print(ws, repeat_row=hdr)
    return len(rows)


# ─── ④ 검토 기록 시트 ─────────────────────────────────────────────────────────
def _sheet_feedback(wb, result: dict, scope: Scope, feedback: dict) -> int:
    """현업이 앱에서 남긴 검토 결과. 검토 키는 도면|Joint|WPS|Check 4요소다."""
    rows = []
    for key, rec in (feedback or {}).items():
        snap = rec.get("flag_snapshot") or {}
        if not scope.matches(snap.get("department"), snap.get("team")):
            continue
        rows.append((key, rec, snap))
    if not rows:
        return 0

    ws = wb.create_sheet("검토 기록")
    r = _title(ws, f"현업 검토 기록 — {scope.label}",
               f"총 {len(rows)}건 · 앱에서 남긴 검토 결과입니다")
    _write_header(ws, r, [("도면번호", 26), ("Joint No", 14), ("WPS", 15), ("Check", 8),
                          ("검토 결과", 12), ("의견", 46), ("검토자", 12), ("검토 일시", 18)])
    hdr = r
    r += 1
    for key, rec, snap in sorted(rows, key=lambda x: x[1].get("updated_at", "")):
        vals = [rec.get("drawing_no", ""), rec.get("joint_no", ""), rec.get("wps_no", ""),
                rec.get("check_no", ""), rec.get("result", ""), rec.get("remark", ""),
                rec.get("reviewer_id", ""), rec.get("updated_at", "")]
        for i, v in enumerate(vals, start=1):
            c = ws.cell(row=r, column=i, value=v)
            c.border = _BORDER
            c.alignment = Alignment(vertical="top", wrap_text=(i == 6))
        r += 1
    _setup_print(ws, repeat_row=hdr)
    return len(rows)


# ─── ⑤ 원본 시트 마킹 + 범위 축소 ─────────────────────────────────────────────
def _mark_original(ws: Worksheet, flags: list[dict], priority: dict[str, int]) -> None:
    """결함 셀에 색을 칠하고 기준값/실제값을 주석으로 단다 (기존 동작 그대로)."""
    best: dict[int, dict[int, dict]] = defaultdict(dict)
    for f in flags:
        row, col = f["row"], f["col"]
        prev = best[row].get(col)
        if prev is None or priority[f["color"]] < priority[prev["color"]]:
            best[row][col] = f

    for row_num, col_map in best.items():
        for col, f in col_map.items():
            cell = ws.cell(row=row_num, column=col)
            rgb = _CHECK_COLOR.get(f["color"])
            if rgb:
                cell.fill = PatternFill("solid", start_color=rgb, end_color=rgb)
            if f["color"] == "Black":
                cell.font = Font(color="FFFFFF")
            lines = [f"[Check {f['check_no']}] {f['check_name']}"]
            if f.get("expected") or f.get("actual"):
                lines.append(f"기준값: {f.get('expected', '')}")
                lines.append(f"실제값: {f.get('actual', '')}")
            else:
                lines.append(f["msg"])
            cm = Comment("\n".join(lines), "QC Verifier")
            cm.width, cm.height = 320, 110
            cell.comment = cm


def _shrink_to_scope(ws: Worksheet, scope: Scope,
                     progress: Callable[[str], None] | None = None) -> int:
    """범위 밖 행을 지운다. 남은 데이터 행 수를 돌려준다.

    연속 구간으로 묶어 **아래에서 위로** 지운다 — 위에서 지우면 그 아래 전부가
    매번 밀려 훨씬 느리다. 실측상 서식/주석/열너비/병합은 모두 보존된다.
    """
    # 임시부재 제외만 켜도 행을 지워야 한다 — 조직 범위가 «전체»인 것과 다르다
    if scope.keeps_every_row:
        return ws.max_row

    keep: set[int] = set(range(1, HEADER_ROWS + 1))
    for row in range(HEADER_ROWS + 1, ws.max_row + 1):
        dept = ws.cell(row=row, column=COL_DEPARTMENT).value
        team = ws.cell(row=row, column=COL_TEAM).value
        drawing = ws.cell(row=row, column=COL_DRAWING_NO).value
        if scope.matches(dept, team, drawing):
            keep.add(row)

    drop = [r for r in range(1, ws.max_row + 1) if r not in keep]
    blocks: list[list[int]] = []
    for r in drop:
        if blocks and blocks[-1][0] + blocks[-1][1] == r:
            blocks[-1][1] += 1
        else:
            blocks.append([r, 1])

    if progress:
        progress(f"원본 시트 축소 중 ({len(drop)}행 제거, {len(blocks)}구간)")
    for start, cnt in reversed(blocks):
        ws.delete_rows(start, cnt)
    return ws.max_row


# ─── 진입점 ───────────────────────────────────────────────────────────────────
def _flags_for(result: dict, scope: Scope) -> list[dict]:
    """이 범위의 플래그. `result`에 없으면 **저장소에서 직접 가져온다.**

    호출부가 두 종류다:

    - `verify.py` — 판정 직후, 플래그가 실린 원본 dict를 넘긴다
    - `exports.py` — 화면에 공개된 결과(`get_last_result()`)를 넘기는데, 이건
      **플래그를 싣지 않는다**(응답의 84%라 뺐다)

    후자를 그냥 훑으면 '결함 목록' 시트가 헤더만 남고 원본 시트에 색도 안 칠해진다.
    **예외가 아니라 «0건짜리 정상 파일»이 나가므로** 받는 사람이 «우리 부서는
    결함이 없구나»로 읽는다. 그래서 호출부가 아니라 여기서 막는다.
    """
    flags = result.get("flags") or []
    if flags:
        return scope.filter_flags(flags)
    from . import result_store
    return result_store.query_flags(dept=scope.dept, team=scope.team,
                                    exclude_temp=scope.exclude_temp)["items"]


def build_report(
    qmg_path: str | Path,
    result: dict,
    out_path: str | Path,
    *,
    dept: str | None = None,
    team: str | None = None,
    exclude_temp: bool = False,
    feedback: dict | None = None,
    priority: dict[str, int] | None = None,
    progress: Callable[[str], None] | None = None,
) -> dict[str, Any]:
    """범위별 결과 Excel을 만든다. 반환값은 무엇이 담겼는지에 대한 요약."""
    scope = Scope(dept, team, exclude_temp)
    flags = _flags_for(result, scope)
    priority = priority or {}

    def note(msg: str) -> None:
        if progress:
            progress(msg)

    note("원본 파일 여는 중")
    wb = load_workbook(str(qmg_path))
    ws = wb.active

    note(f"결함 마킹 중 ({len(flags)}건)")
    _mark_original(ws, flags, priority)

    kept_rows = _shrink_to_scope(ws, scope, progress)

    note("요약/목록 시트 만드는 중")
    _sheet_summary(wb, result, scope, flags)
    _sheet_flags(wb, result, scope, flags)
    n_unworked = _sheet_unworked(wb, result, scope)
    n_feedback = _sheet_feedback(wb, result, scope, feedback or {})

    # 열었을 때 요약부터 보이게
    wb.active = 0

    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    note("저장 중")
    wb.save(str(out))

    info = {
        "scope": scope.label,
        "path": str(out),
        "size": out.stat().st_size,
        "flags": len(flags),
        "defect_rows": len({f["row"] for f in flags}),
        "original_rows": kept_rows,
        "unworked": n_unworked,
        "feedback": n_feedback,
        "built_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    logger.info("Excel 생성: %s (%s, %.0f KB, 플래그 %d건)",
                out.name, scope.label, info["size"] / 1024, len(flags))
    return info
