"""이 PC에서 도는 프로젝트 서버들의 목록과 생사.

## 고르는 자리는 로그인 화면 «안»이다

예전에는 앞에 별도 선택 페이지(포트 8000)를 뒀는데, 그러면 배경 영상과 로고가
있는 로그인 화면이 뒤로 밀리고 **아무 꾸밈 없는 흰 화면이 이 시스템의 첫인상**이
된다. 그래서 선택을 로그인 화면 안으로 들여왔다. 자리는 둘이다 —
**로그인 화면의 목록**(처음 들어오는 사람)과 **상단 배지 드롭다운**(이미
로그인해 둔 사람은 로그인 화면을 아예 지나가지 않는다). 둘이 같은 답을 내야
해서 여기 한 곳에 둔다.

## 확인은 서버 사이드다

브라우저에서 8001/8002를 직접 부르면 CORS에 걸린다(다른 포트 = 다른 origin).
`fetch` 실패로는 «서버가 꺼졌다»와 «CORS로 막혔다»를 구분할 수 없어서, 멀쩡히
도는 서버가 «중지됨»으로 보인다.

## 목록 파일은 공용이다

`data/projects.json`(저장소 쪽). 프로젝트별 폴더에 두면 **서버마다 다른 목록**을
보게 되어, 어느 창에서 보느냐에 따라 있는 프로젝트가 없어 보인다.
"""
from __future__ import annotations

import json
import logging
import urllib.error
import urllib.request
from pathlib import Path

logger = logging.getLogger(__name__)

# `config.EMPLOYEES_FILE`과 같은 자리(공용 data/). config를 거치지 않고 직접 잡는
# 이유는 이 목록이 **프로젝트 데이터 폴더와 무관**하기 때문이다 — 프로젝트별로
# 두면 서버마다 다른 목록을 보게 되어, 어느 창에서 보느냐에 따라 있는 프로젝트가
# 없어 보인다.
PROJECTS_FILE = Path(__file__).resolve().parent.parent.parent / "data" / "projects.json"

# 목록 파일이 없을 때. 폴더를 나누지 않은 설치가 이 모습이다 — 8001 하나.
FALLBACK = [{"name": "QC 자동검증", "port": 8001, "note": "기본 서버"}]


def load_projects() -> list[dict]:
    """매 요청 다시 읽는다 — 프로젝트를 추가하고 서버를 재시작하게 만들면,
    그 재시작을 잊는 쪽이 훨씬 흔하다."""
    try:
        raw = json.loads(PROJECTS_FILE.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return list(FALLBACK)
    except (OSError, json.JSONDecodeError) as e:
        logger.warning("projects.json을 읽지 못했다: %s", e)
        return list(FALLBACK)

    items = raw.get("projects") if isinstance(raw, dict) else raw
    out: list[dict] = []
    for it in items or []:
        try:
            port = int(it["port"])
        except (KeyError, TypeError, ValueError):
            continue
        out.append({"name": str(it.get("name") or f"포트 {port}"),
                    "port": port,
                    "note": str(it.get("note") or "")})
    return out or list(FALLBACK)


def probe(port: int, timeout: float = 1.5) -> dict:
    """그 포트의 서버가 살아 있는가.

    **여기서 예외가 새면 목록 전체가 죽는다** — 한 프로젝트 서버가 꺼져 있다는
    이유로 다른 프로젝트로도 못 들어가게 된다.
    """
    try:
        with urllib.request.urlopen(
                f"http://127.0.0.1:{port}/api/server-info", timeout=timeout) as r:
            info = json.loads(r.read() or b"{}")
        return {"up": True,
                "project": info.get("project") or "",
                "data_root": info.get("data_root") or "",
                "wps_ref_found": bool(info.get("wps_ref_found"))}
    except urllib.error.HTTPError as e:
        # 응답은 했으니 서버는 살아 있다. 옛 버전이라 이 엔드포인트가 없을 뿐이다.
        return {"up": True, "project": "", "data_root": "",
                "wps_ref_found": True, "note": f"HTTP {e.code}"}
    except Exception:
        return {"up": False, "project": "", "data_root": "", "wps_ref_found": False}


def listing() -> list[dict]:
    """목록 + 생사. 순서는 파일 그대로다 — 생사로 정렬하면 서버 하나를 껐다 켤
    때마다 카드 자리가 바뀌어, 늘 같은 자리를 누르던 사람이 다른 데로 들어간다."""
    return [dict(p, **probe(p["port"])) for p in load_projects()]
