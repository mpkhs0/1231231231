"""
Check 13 — 통계적 이상치(특이 조인트) 탐지.

규칙 기반 Check(1~12)는 "정해진 기준 위반"을 찾지만, 이 Check는 명시적 규칙이
없어도 전체 데이터 분포에서 크게 벗어난 조합(흔치 않은 재질·두께·WPS·부서 조합
등)을 찾아 사람이 검토하도록 표시한다. 규칙 위반이 아니므로 "결함 확정"이 아니라
"확인 필요" 성격이며, 반드시 Human-in-the-loop 피드백(확정/오탐/확인중)으로
사람이 최종 판단해야 한다.

Isolation Forest(scikit-learn) 사용 — 의사결정나무 기반이라 GPU가 필요 없고,
5천~30만 행 규모에서 일반 사무용 PC CPU로 수 초~수십 초 내에 처리된다. 회사
서버 PC에 GPU가 없어도 문제되지 않는다(딥러닝이 아니라 고전적 트리 앙상블).

## 인코딩을 빈도(희소도) 기준으로 바꾼 이유

예전에는 범주형을 정수로 인코딩했다(WPS를 0,1,2,...). Isolation Forest 자체는
분할 기반이라 그래도 동작하지만, **그 좌표로 그림을 그릴 수 없었다** — 'WPS 3번과
4번의 거리'에 아무 의미가 없기 때문이다.

지금은 각 범주값을 **전체에서 차지하는 비율**로 바꾼다:

    WPS 'TR-FC-G01'   (62.0%) -> 0.620
    WPS 'TR-SMFC-G01' ( 0.7%) -> 0.007

그러면 축을 읽을 수 있게 된다 — **원점 쪽 = 흔한 값들의 조합, 바깥 = 드문 값들의
조합**. 화면의 '피처별 이탈도' 막대가 숫자로 보여주는 것과 산점도가 같은 것을
그림으로 보여주게 되어 서로를 설명한다.

수치형은 z-score로 표준화한다(빈도와 눈금을 맞추기 위함).

## 이 모듈이 학습을 누적하지 않는다는 점

`detect_anomalies()`는 호출될 때마다 새로 `fit`한다. 모델 파일을 저장하지 않으므로
"작년 데이터로 배운 모델"이 아니라 **"이번 데이터 안에서 상대적으로 튀는 것"** 을
찾는다. 이상 탐지에서 흔한 설계이고, 프로젝트마다 정상 분포가 달라지는 이 업무에는
오히려 맞다. 다만 누적 학습이 아니라는 점은 분명히 해둔다.
"""
import logging
import math
from bisect import bisect_left, bisect_right
from collections import Counter

logger = logging.getLogger(__name__)

try:
    import numpy as np
    from sklearn.decomposition import PCA
    from sklearn.ensemble import IsolationForest
    _AVAILABLE = True
except ImportError:
    _AVAILABLE = False
    logger.warning("scikit-learn/numpy 미설치 - Check 13(이상치 탐지) 비활성화됨")

# 이보다 판정대상 행수가 적으면 통계적으로 의미 있는 이상치 탐지가 어려워 건너뛴다.
MIN_ROWS_REQUIRED = 30

_CATEGORICAL_FIELDS = ('material_key', 'wps_no', 'groove', 'ndt_cat', 'department', 'team')
_NUMERIC_FIELDS = ('thickness1', 'thickness2', 'weld_to_ndt_days')

# 화면 표시용 한국어 이름
FIELD_LABELS = {
    'material_key': '재질', 'wps_no': 'WPS', 'groove': 'Groove',
    'ndt_cat': 'NDT Cat', 'department': '부서', 'team': '팀',
    'thickness1': '두께1', 'thickness2': '두께2', 'weld_to_ndt_days': '용접~NDT(일)',
}

# 산점도 배경(정상 영역)을 그릴 격자 크기. 20만 행이어도 격자는 이 크기로 고정되므로
# 화면에 보내는 데이터 양이 행수와 무관하게 일정하다.
_GRID = 48


def is_available() -> bool:
    return _AVAILABLE


def _freq_tables(feats: list[dict]) -> dict[str, dict[str, float]]:
    """범주형 각 값이 전체에서 차지하는 비율."""
    n = len(feats) or 1
    out: dict[str, dict[str, float]] = {}
    for field in _CATEGORICAL_FIELDS:
        c = Counter(f.get(field) or '(미기재)' for f in feats)
        out[field] = {k: v / n for k, v in c.items()}
    return out


def _numeric_stats(feats: list[dict]) -> tuple[dict, dict]:
    mean: dict[str, float] = {}
    std: dict[str, float] = {}
    for field in _NUMERIC_FIELDS:
        vals = np.array([f.get(field) for f in feats if f.get(field) is not None], dtype=float)
        if len(vals):
            mean[field] = float(np.mean(vals))
            std[field] = float(np.std(vals)) or 1.0
    return mean, std


def _encode(feats: list[dict], freq: dict, mean: dict, std: dict):
    """범주형 -> 빈도, 수치형 -> z-score. 결측 수치형은 평균(=z 0)으로 채운다."""
    cols = []
    for field in _CATEGORICAL_FIELDS:
        table = freq[field]
        cols.append(np.array(
            [table.get(f.get(field) or '(미기재)', 0.0) for f in feats], dtype=float))
    for field in _NUMERIC_FIELDS:
        m = mean.get(field)
        s = std.get(field)
        if m is None:
            cols.append(np.zeros(len(feats)))
            continue
        cols.append(np.array(
            [((f.get(field) - m) / s) if f.get(field) is not None else 0.0 for f in feats],
            dtype=float))
    return np.column_stack(cols)


def _deviations(feat: dict, freq: dict, mean: dict, std: dict) -> list[dict]:
    """
    피처별 이탈도 — 화면의 막대 그래프 재료.

    Isolation Forest는 '왜 이상한지'를 알려주지 않는다. 그래서 각 피처가 따로
    얼마나 드문지/멀리 있는지를 계산해 사람이 읽을 수 있게 만든다.
    이건 모델의 판단 근거가 아니라 **같은 데이터를 사람 눈으로 본 것**이다.
    """
    out: list[dict] = []
    for field in _CATEGORICAL_FIELDS:
        val = feat.get(field) or '(미기재)'
        share = freq[field].get(val, 0.0)
        out.append({
            'field': field, 'label': FIELD_LABELS.get(field, field),
            'kind': 'cat', 'value': val,
            'share': round(share, 5),          # 전체 중 비율
            'deviation': round(1 - share, 4),  # 0=흔함, 1에 가까울수록 드묾
            'text': f"전체의 {share * 100:.1f}%",
        })
    for field in _NUMERIC_FIELDS:
        val = feat.get(field)
        m, s = mean.get(field), std.get(field)
        if val is None or m is None:
            out.append({
                'field': field, 'label': FIELD_LABELS.get(field, field),
                'kind': 'num', 'value': None, 'z': None,
                'deviation': 0.0, 'text': '값 없음',
            })
            continue
        z = (val - m) / s if s else 0.0
        out.append({
            'field': field, 'label': FIELD_LABELS.get(field, field),
            'kind': 'num', 'value': val, 'z': round(z, 2),
            # z=3 이상이면 최대치로 본다 (막대가 무한정 길어지지 않게)
            'deviation': round(min(abs(z) / 3.0, 1.0), 4),
            'text': f"평균 {m:.1f} 대비 {z:+.1f}σ",
        })
    out.sort(key=lambda d: -d['deviation'])
    return out


def _build_peer_index(feats: list[dict]) -> dict:
    """feats 전체를 한 번 순회해 O(1)/O(log n) 조회용 인덱스를 빌드한다."""
    mat_cnt      = Counter(f.get('material_key') for f in feats if f.get('material_key'))
    mat_wps_cnt  = Counter((f.get('material_key'), f.get('wps_no'))
                           for f in feats if f.get('material_key'))
    dept_cnt     = Counter(f.get('department') for f in feats if f.get('department'))
    dept_mat_wps = Counter((f.get('department'), f.get('material_key'), f.get('wps_no'))
                           for f in feats if f.get('department'))
    th_sorted    = sorted(f['thickness1'] for f in feats if f.get('thickness1') is not None)
    # (thickness1, material_key) 투플 정렬 → bisect로 두께 범위 내 mat 조합 카운트
    th_mat_sorted = sorted(
        (f['thickness1'], f.get('material_key'))
        for f in feats if f.get('thickness1') is not None
    )
    return dict(mat=mat_cnt, mat_wps=mat_wps_cnt,
                dept=dept_cnt, dept_mat_wps=dept_mat_wps,
                th=th_sorted, th_mat=th_mat_sorted)


def _peer_groups(feat: dict, peer_index: dict) -> list[dict]:
    """
    '동종 그룹 대비' — 같은 조건의 행 중 이 행 같은 경우가 몇 건인지.

    이탈도 막대가 '전체 대비'라면 이건 '비슷한 것들 대비'다. 현장에서
    "이게 진짜 이상한가"를 판단할 때 실제로 필요한 정보다.
    peer_index는 _build_peer_index()로 루프 전에 한 번만 빌드한다.
    """
    out = []
    mat  = feat.get('material_key')
    wps  = feat.get('wps_no')
    dept = feat.get('department')
    th   = feat.get('thickness1')

    if mat:
        base = peer_index['mat'][mat]
        same = peer_index['mat_wps'][(mat, wps)]
        out.append({'group': f"같은 재질({mat})", 'base': base, 'match': same,
                    'what': f"이 WPS({wps or '미기재'}) 사용"})
    if th is not None:
        lo, hi = th - 2, th + 2
        th_list = peer_index['th']
        base = bisect_right(th_list, hi) - bisect_left(th_list, lo)
        th_mat = peer_index['th_mat']
        # (lo, mat) ~ (hi, mat) 범위: 투플 정렬 특성으로 두께 ∈ [lo,hi] AND mat 일치 행 수
        same = bisect_right(th_mat, (hi, mat)) - bisect_left(th_mat, (lo, mat))
        out.append({'group': f"비슷한 두께({lo:g}~{hi:g}mm)", 'base': base, 'match': same,
                    'what': f"이 재질({mat or '미기재'}) 사용"})
    if dept:
        base = peer_index['dept'][dept]
        same = peer_index['dept_mat_wps'][(dept, mat, wps)]
        out.append({'group': f"같은 부서({dept})", 'base': base, 'match': same,
                    'what': "이 재질+WPS 조합"})
    for o in out:
        o['pct'] = round(o['match'] / o['base'] * 100, 2) if o['base'] else 0.0
    return out


def _score_histogram(scores, threshold: float, bins: int = 40) -> dict:
    """
    점수 분포 + 임계선.

    contamination(1.5%)은 **사람이 넣은 가정**이다. 데이터가 "83개가 이상하다"고
    말한 게 아니라 상위 1.5%를 자른 것이다. 그 사실이 화면에 보여야 오해가 없다.
    """
    lo, hi = float(np.min(scores)), float(np.max(scores))
    if hi <= lo:
        hi = lo + 1e-6
    counts, edges = np.histogram(scores, bins=bins, range=(lo, hi))
    return {
        'bins': [round(float(e), 5) for e in edges],
        'counts': [int(c) for c in counts],
        'threshold': round(float(threshold), 5),
    }


def _projection(X, preds):
    """
    2D 투영 — 정상은 '영역'으로, 이상치는 '점'으로.

    전체를 점으로 뿌리면 20만 건에서 렌더가 불가능하고, 회색 점 더미에 이상치가
    묻힌다. 그래서 정상 분포는 밀도 격자(고정 크기)로 요약해 배경에 깔고,
    이상치만 개별 점으로 그린다. 화면에 보내는 데이터 양이 행수와 무관해진다.

    축에 물리적 단위는 없다(주성분). 다만 빈도 인코딩을 쓰므로 **원점 쪽이 흔한
    조합, 바깥이 드문 조합**이라는 읽는 법은 성립한다. 화면에도 그렇게 표시한다.
    """
    pca = PCA(n_components=2, random_state=42)
    P = pca.fit_transform(X)

    normal = P[preds == 1]
    outlier = P[preds == -1]
    if len(normal) == 0:
        normal = P

    x0, x1 = float(np.min(P[:, 0])), float(np.max(P[:, 0]))
    y0, y1 = float(np.min(P[:, 1])), float(np.max(P[:, 1]))
    if x1 <= x0:
        x1 = x0 + 1e-6
    if y1 <= y0:
        y1 = y0 + 1e-6

    H, _, _ = np.histogram2d(normal[:, 0], normal[:, 1], bins=_GRID,
                             range=[[x0, x1], [y0, y1]])
    hmax = float(H.max()) or 1.0
    # 밀도 편차가 커서 선형으로는 중심만 보인다 - log로 눌러 외곽 윤곽이 살게 한다
    dens = (np.log1p(H) / math.log1p(hmax)).round(3)

    centroid = normal.mean(axis=0)
    meta = {
        'x_range': [round(x0, 4), round(x1, 4)],
        'y_range': [round(y0, 4), round(y1, 4)],
        'grid': _GRID,
        'density': [[float(v) for v in row] for row in dens.T.tolist()],
        'centroid': [round(float(centroid[0]), 4), round(float(centroid[1]), 4)],
        'explained': [round(float(v), 3) for v in pca.explained_variance_ratio_],
        'normal_count': int(len(normal)),
    }
    return meta, P


def detect_anomalies(rows: list[tuple[int, dict]], contamination: float = 0.015) -> dict:
    """
    rows: (row_num, feature_dict) 리스트.
    feature_dict 키: material_key/wps_no/groove/ndt_cat/department/team(문자열,
    없으면 None 가능) + thickness1/thickness2/weld_to_ndt_days(숫자 또는 None).

    반환:
      {
        'anomalies': {row_num: {'score','reason','deviations','peers','xy'}},
        'meta': {...}   # 화면(머신러닝 분석 탭)에서 쓰는 분포/투영 정보
      }
    이상치가 없거나 비활성화면 anomalies는 빈 dict.
    """
    empty = {'anomalies': {}, 'meta': None}
    if not _AVAILABLE:
        return empty
    if len(rows) < MIN_ROWS_REQUIRED:
        logger.info("Check13: 판정대상 %d행 < 최소 %d행, 이상치 탐지 건너뜀",
                    len(rows), MIN_ROWS_REQUIRED)
        return empty

    row_nums = [r for r, _ in rows]
    feats = [f for _, f in rows]

    freq = _freq_tables(feats)
    mean, std = _numeric_stats(feats)
    X = _encode(feats, freq, mean, std)

    model = IsolationForest(
        n_estimators=200,
        contamination=contamination,
        random_state=42,
        n_jobs=-1,
    )
    model.fit(X)
    scores = model.decision_function(X)
    preds = model.predict(X)

    proj, P = _projection(X, preds)

    out_scores = scores[preds == -1]
    threshold = float(np.max(out_scores)) if len(out_scores) else float(np.min(scores))

    peer_index = _build_peer_index(feats)
    anomalies: dict[int, dict] = {}
    for i, (row_num, feat) in enumerate(zip(row_nums, feats)):
        if preds[i] != -1:
            continue
        devs = _deviations(feat, freq, mean, std)
        top = devs[0]
        anomalies[row_num] = {
            'score': round(float(scores[i]), 4),
            'reason': (f"{top['label']}='{top['value']}' ({top['text']})"
                       if top['kind'] == 'cat'
                       else f"{top['label']}={top['value']} ({top['text']})"),
            'deviations': devs,
            'peers': _peer_groups(feat, peer_index),
            'xy': [round(float(P[i, 0]), 4), round(float(P[i, 1]), 4)],
        }

    meta = {
        'total_rows': len(rows),
        'anomaly_count': len(anomalies),
        'contamination': contamination,
        'histogram': _score_histogram(scores, threshold),
        'projection': proj,
        'fields': [{'key': k, 'label': FIELD_LABELS.get(k, k),
                    'kind': 'cat' if k in _CATEGORICAL_FIELDS else 'num'}
                   for k in _CATEGORICAL_FIELDS + _NUMERIC_FIELDS],
        'model': {
            'algorithm': 'IsolationForest',
            'n_estimators': 200,
            'encoding': '범주형=전체 빈도, 수치형=z-score',
            'note': '매 검증마다 새로 학습한다(모델을 저장하지 않음) — '
                    '이번 데이터 안에서 상대적으로 드문 조합을 찾는다',
        },
    }
    logger.info("Check13: %d행 중 이상치 %d건 (임계 %.4f)",
                len(rows), len(anomalies), threshold)
    return {'anomalies': anomalies, 'meta': meta}
