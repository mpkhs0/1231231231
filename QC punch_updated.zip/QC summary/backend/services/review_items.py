"""
`QC_검사로직_상세분석.md` §11(확인 필요 사항)을 읽고, 현업 답변을 그 파일에 되쓴다.

**왜 DB가 아니라 마크다운 파일인가**
§11은 이 프로젝트의 판정 근거 이력이고, git으로 추적되며 사람이 직접 손으로도 고친다.
문서를 정본으로 두고 서버는 그 위에 얹히는 입력 창구 역할만 한다. 그래서:

- 읽기는 **매 요청마다 파일을 다시 판다.** 캐시하지 않는다 — 손으로 고친 내용이
  화면에 곧바로 보여야 양방향이 성립한다.
- 쓰기는 **해당 항목의 답변 블록 한 덩어리만** 갈아끼운다. 파일 전체를 다시 쓰지
  않으므로, 사람이 같은 파일의 다른 곳을 고쳐두었어도 그 편집이 날아가지 않는다.

**서버가 하지 않는 것**
헤딩의 상태 표기(`[ ]`/`[~]`/`[x]`)를 자동으로 바꾸지 않는다. 문서에 적힌 인계 규칙상
헤딩 동기화와 판정 코드 반영은 답변을 읽은 작업자가 함께 판단해야 하는 일이라,
서버가 먼저 `[x] 완료`로 바꿔버리면 "답변은 왔지만 코드는 그대로"인 상태가
완료로 보이게 된다. 답변이 달린 항목은 화면에서 '반영 대기'로 구분해 보여준다.
"""

from __future__ import annotations

import contextlib
import logging
import os
import re
import threading
import time
from datetime import date
from typing import Any

from .. import config

logger = logging.getLogger(__name__)

# 파일을 읽고-고쳐-쓰는 사이에 다른 요청이 끼어들지 않게 한다.
_lock = threading.Lock()

# "## 11. ..." 부터 다음 "## " 직전까지가 대상 구간
_SEC11_RE = re.compile(r"^## 11\.", re.M)
_NEXT_H2_RE = re.compile(r"^## ", re.M)

# "### 11-3. [~] 잠정결론(2026-08-02, 표준 조사 기반 — 현업 확인 대기) — 제목"
#
# 상태 표기의 괄호 안에도 em-dash가 들어간다("표준 조사 기반 — 현업 확인 대기").
# 그래서 제목 구분자로 쓰는 em-dash를 찾기 전에 **괄호를 통째로 먼저 삼켜야** 한다.
# 그러지 않으면 괄호 안의 첫 em-dash에서 잘려 제목이 "현업 확인 대기) — ..."가 된다.
#
# 괄호 «한 겹 중첩»까지 견딘다. 결론을 적다 보면 자연스럽게 중첩된다:
#     완료(2026-08-10, 결론: 기준일(데이터 내 최종 용접일) 유지)
# `[^)]*`로는 안쪽 `)`에서 먼저 닫혀 **줄 전체가 안 맞고 항목이 통째로 사라진다.**
# 예외도 경고도 없이 화면에서 한 줄이 없어질 뿐이라 알아채기 어렵다 —
# 실제로 11-10이 그렇게 사라졌다.
_ITEM_RE = re.compile(
    r"^### (?P<num>11-\d+)\.\s*"
    r"\[(?P<mark> |~|x)\]\s*"
    r"(?P<status>[^\s(—]+(?:\((?:[^()]|\([^()]*\))*\))?)\s*"
    r"(?:—\s*(?P<title>[^\n]*))?$",
    re.M,
)

# "#### [x] 현업 답변(2026-08-03, 답변자: 홍길동)"
# "#### [x] 현업 답변(2026-08-10) — 두께범위는 `3~24`가 맞다"   ← 뒤에 요약을 붙이기도 한다
#
# 예전에는 `\)\s*$`로 끝나서 **요약이 붙은 답변을 통째로 못 봤다.** 문서에는 답변이
# 다섯 건이나 있는데 화면에는 「답변 없음」으로 떴고, 그래서 «반영 대기» 표시도
# 뜨지 않았다 — 답변을 남긴 현업 입장에서는 «내가 쓴 게 어디 갔나»가 된다.
# 항목 헤딩(`_ITEM_RE`)이 이미 `— 제목`을 허용하므로 형식을 맞춘다.
_ANSWER_RE = re.compile(
    r"^#### \[x\] 현업 답변\((?P<meta>[^)]*)\)\s*(?:—\s*(?P<summary>[^\n]*))?$",
    re.M,
)

_MARK_LABEL = {
    " ": "미결",
    "~": "잠정결론",
    "x": "완료",
}


def _read() -> str:
    return config.ANALYSIS_DOC.read_text(encoding="utf-8")


# 잠금이 남아 있어도 이 시간이 지나면 버린다. 프로세스가 죽으면 파일이 남는데,
# 그대로 두면 **아무도 답변을 못 남기는 상태**가 되어 잠금보다 나쁘다.
_LOCK_STALE_SEC = 30.0

# 잠금을 기다리는 시간. 테스트가 줄여 쓴다.
_LOCK_TIMEOUT = 5.0


@contextlib.contextmanager
def _file_lock(timeout: float | None = None):
    """정본 문서에 대한 **프로세스 사이** 잠금.

    `threading.Lock`은 한 프로세스 안에서만 유효하다. 프로젝트별 서버를 둘 이상
    띄우면(8001·8002) 둘 다 **같은** `QC_검사로직_상세분석.md`에 읽고-고쳐-쓴다.
    그 사이가 겹치면 답변 한 건이 조용히 사라진다:

        8001 읽음 -> 8002 읽음 -> 8001 씀 -> 8002 씀   (8001의 답변이 없어짐)

    파일이 깨지지는 않는다(`os.replace`가 원자적). **덮어써질 뿐이라 아무 데서도
    오류가 나지 않는다** — 답변한 사람이 다시 열어 보기 전에는 모른다.
    """
    lock = config.ANALYSIS_DOC.with_suffix(config.ANALYSIS_DOC.suffix + ".lock")
    deadline = time.monotonic() + (_LOCK_TIMEOUT if timeout is None else timeout)
    while True:
        try:
            fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(os.getpid()).encode())
            os.close(fd)
            break
        except FileExistsError:
            try:
                age = time.time() - lock.stat().st_mtime
            except OSError:
                continue                     # 방금 풀렸다 — 다시 시도
            if age > _LOCK_STALE_SEC:
                logger.warning("오래된 잠금을 버린다(%.0f초): %s", age, lock)
                lock.unlink(missing_ok=True)
                continue
            if time.monotonic() > deadline:
                raise ValueError(
                    "다른 서버가 문서를 쓰는 중입니다. 잠시 후 다시 시도하세요.")
            time.sleep(0.05)
    try:
        yield
    finally:
        lock.unlink(missing_ok=True)


def _unchanged_since(text: str) -> bool:
    """읽어 둔 내용이 **지금도 그대로인가.** 잠금이 못 막는 것을 잡는다 —
    사람이 편집기로 직접 고치는 경우가 그렇다.

    `stat()` 지문을 쓰지 않는 이유: «언제 찍었는가»에 의존해서, 읽기와 찍기
    사이에 들어온 변경을 놓친다. 내용을 그대로 비교하면 순서와 무관하다.
    문서가 2,300여 줄이라 한 번 더 읽는 비용은 무시할 만하다.
    """
    try:
        return _read() == text
    except OSError:
        return False


def _write_atomic(text: str) -> None:
    """임시 파일에 쓴 뒤 갈아끼운다 — 쓰는 도중 죽어도 원본이 잘리지 않게."""
    tmp = config.ANALYSIS_DOC.with_suffix(".md.tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, config.ANALYSIS_DOC)


def _section_bounds(text: str) -> tuple[int, int]:
    """§11 구간의 [시작, 끝) 오프셋. 없으면 (-1, -1)."""
    m = _SEC11_RE.search(text)
    if not m:
        return -1, -1
    nxt = _NEXT_H2_RE.search(text, m.end())
    return m.start(), (nxt.start() if nxt else len(text))


def _parse_answer(body: str) -> dict[str, Any] | None:
    """항목 본문에서 현업 답변 블록을 찾아 돌려준다(없으면 None)."""
    m = _ANSWER_RE.search(body)
    if not m:
        return None
    raw_meta = m.group("meta").strip()
    answered_on, author = "", ""
    for part in raw_meta.split(","):
        part = part.strip()
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", part):
            answered_on = part
        elif part.startswith("답변자:"):
            author = part.split(":", 1)[1].strip()
    return {
        "answered_on": answered_on,
        "author": author,
        "text": body[m.end():].strip(),
        "raw_meta": raw_meta,
    }


def load_items() -> list[dict[str, Any]]:
    """§11 항목 목록. 파일이 없거나 §11이 없으면 빈 목록."""
    if not config.ANALYSIS_DOC.is_file():
        logger.warning("분석 문서를 찾을 수 없음: %s", config.ANALYSIS_DOC)
        return []

    text = _read()
    start, end = _section_bounds(text)
    if start < 0:
        logger.warning("문서에서 '## 11.' 섹션을 찾지 못했다")
        return []

    section = text[start:end]
    matches = list(_ITEM_RE.finditer(section))
    items: list[dict[str, Any]] = []

    for i, m in enumerate(matches):
        body_start = m.end()
        body_end = matches[i + 1].start() if i + 1 < len(matches) else len(section)
        body = section[body_start:body_end].strip()

        answer = _parse_answer(body)
        # 답변 블록은 별도로 보여주므로 본문에서는 덜어낸다
        body_wo_answer = body
        if answer:
            am = _ANSWER_RE.search(body)
            body_wo_answer = body[: am.start()].strip()

        mark = m.group("mark")
        items.append(
            {
                "id": m.group("num"),
                "mark": mark,                                   # " " | "~" | "x"
                "status_label": _MARK_LABEL.get(mark, mark),
                "status_text": (m.group("status") or "").strip(),
                "title": (m.group("title") or "").strip(),
                "body": body_wo_answer,
                "answer": answer,
                # 답변은 왔는데 헤딩이 아직 완료가 아니면 '반영 대기'다.
                # 이 상태를 화면에서 구분해줘야 인계가 누락되지 않는다.
                "needs_followup": bool(answer) and mark != "x",
            }
        )
    return items


def save_answer(item_id: str, conclusion: str, remark: str, author: str) -> dict[str, Any]:
    """항목에 현업 답변 블록을 기록한다(이미 있으면 갈아끼운다).

    반환값은 갱신된 그 항목. 예외 대신 ValueError를 던지고 라우터가 HTTP로 옮긴다.
    """
    conclusion = (conclusion or "").strip()
    author = (author or "").strip()
    remark = (remark or "").strip()
    if not conclusion:
        raise ValueError("결론 내용을 입력하세요")
    if not author:
        raise ValueError("답변자를 입력하세요")

    block_lines = [
        f"#### [x] 현업 답변({date.today().isoformat()}, 답변자: {author})",
        "",
        f"결론: {conclusion}",
    ]
    if remark:
        block_lines.append(f"비고: {remark}")
    block = "\n".join(block_lines) + "\n"

    with _lock, _file_lock():
        if not config.ANALYSIS_DOC.is_file():
            raise ValueError(f"분석 문서를 찾을 수 없습니다: {config.ANALYSIS_DOC}")

        # 손으로 고쳤을 수 있으니 쓰기 직전에 다시 읽는다
        text = _read()
        start, end = _section_bounds(text)
        if start < 0:
            raise ValueError("문서에서 '## 11.' 섹션을 찾지 못했습니다")

        section = text[start:end]
        matches = list(_ITEM_RE.finditer(section))
        target = next((m for m in matches if m.group("num") == item_id), None)
        if target is None:
            raise ValueError(f"항목을 찾을 수 없습니다: {item_id}")

        idx = matches.index(target)
        body_start = target.end()
        body_end = matches[idx + 1].start() if idx + 1 < len(matches) else len(section)
        body = section[body_start:body_end]

        # 기존 답변 블록이 있으면 그 자리를 대체, 없으면 본문 끝에 붙인다.
        # 파일은 git으로 추적되므로 이전 답변은 커밋 이력에 남는다.
        am = _ANSWER_RE.search(body)
        if am:
            new_body = body[: am.start()].rstrip() + "\n\n" + block
        else:
            new_body = body.rstrip() + "\n\n" + block

        # 항목 사이 간격을 원래대로 유지한다(다음 헤딩 앞 빈 줄)
        if idx + 1 < len(matches):
            new_body = new_body.rstrip() + "\n\n"

        new_section = section[:body_start] + new_body + section[body_end:]
        # **읽은 뒤에 파일이 바뀌었으면 쓰지 않는다.** 잠금은 이 서버들 사이만
        # 막는다 — 사람이 편집기로 직접 고치고 있으면 그대로 덮어써서, 그 편집이
        # 조용히 사라진다. 오류를 내는 편이 낫다: 다시 누르면 새 내용 위에 얹힌다.
        if not _unchanged_since(text):
            raise ValueError(
                "문서가 방금 다른 곳에서 바뀌었습니다. 새로고침한 뒤 다시 저장하세요.")
        _write_atomic(text[:start] + new_section + text[end:])
        logger.info("§11 %s 현업 답변 기록 (답변자: %s)", item_id, author)

    return next((it for it in load_items() if it["id"] == item_id), {})


def doc_info() -> dict[str, Any]:
    """문서 자체의 상태 — 화면에서 '무엇을 보고 있는지' 알 수 있게."""
    p = config.ANALYSIS_DOC
    if not p.is_file():
        return {"exists": False, "path": str(p), "mtime": "", "size": 0}
    st = p.stat()
    from datetime import datetime

    return {
        "exists": True,
        "path": str(p),
        "mtime": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
        "size": st.st_size,
    }
