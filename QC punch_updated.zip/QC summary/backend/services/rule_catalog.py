"""
판정 항목 카탈로그 — 각 Check가 «무엇을 보는가 / 어느 구분인가 / 켜져 있는가».

## 왜 별도 모듈인가

Check 번호와 이름은 `verifier`에 있지만, 그것만으로는 화면에서 **무슨 검사인지
알 수 없다.** 「특수규칙 P+G01」이라는 카드를 보고 무엇을 판정하는지 아는 사람은
그 코드를 쓴 사람뿐이다. 그래서 항목마다 **설명과 판정 로직**을 함께 둔다.

## 공통 · 프로젝트

| 구분 | 뜻 | 바뀌는가 |
|---|---|---|
| **공통** | 어느 프로젝트에서나 성립하는 규칙(표준·자격·기록 품질) | 거의 안 바뀐다 |
| **프로젝트** | 이 프로젝트에서만 합의된 값(특정 WPS의 허용 두께 등) | 프로젝트마다 다르다 |

이 구분이 화면에 보여야 하는 이유: 프로젝트가 바뀌면 **무엇을 다시 정해야 하는지**
가 한눈에 보여야 한다. 구분이 없으면 다음 프로젝트에서 남의 프로젝트 값으로
판정하고도 아무도 눈치채지 못한다.

## 켜고 끄기는 «판정»을 정한다 — 보기 필터가 아니다

'프로젝트 세팅'에서 끈 항목은 **판정 자체를 하지 않는다.** 그래서 바꾸면
**재검증이 필요하다.** 대시보드의 Check 취사선택과 혼동하면 안 된다 — 그쪽은
이미 판정된 결과를 «보는» 필터라 즉시 반영된다.

    프로젝트 세팅   무엇을 판정할 것인가   -> 재검증 필요
    대시보드 토글   판정된 것 중 무엇을 볼 것인가 -> 즉시

끈 항목의 플래그는 애초에 생기지 않으므로, 결함 행수·클린 행수·부서 실적이
전부 그 기준으로 다시 계산된다. 켜고 끄기를 화면 필터로 처리하면 이 재계산이
일어나지 않아 «분모는 그대로인데 분자만 줄어드는» 상태가 된다.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

from .. import config
from . import project_checks

logger = logging.getLogger(__name__)

COMMON = "공통"
PROJECT = "프로젝트"

# 각 항목: 구분 · 한 줄 요약 · 판정 로직(사람이 읽는 문장) · 관련 열
#
# `logic`은 «코드를 읽지 않고도 무엇을 하는지 알 수 있는» 수준으로 적는다.
# 화면의 카드만 보고는 알 수 없다는 지적에서 나온 자리다.
CATALOG: dict[int, dict[str, Any]] = {
    1: {"category": COMMON, "cols": "AM · AO",
        "summary": "용접일과 NDT 계획일의 앞뒤가 맞는가",
        "logic": "NDT 계획일(AO)이 용접일(AM)보다 앞서면 결함. 날짜가 하나만 있는 "
                 "경우는 판정하지 않는다."},
    2: {"category": COMMON, "cols": "AJ · AK",
        "summary": "입력한 WPS가 WPS List에 있고, Process가 등록값과 같은가",
        "logic": "AJ열 WPS No가 WPS List에 없으면 결함. 있으면 AK열 Process를 "
                 "등록 Process와 대조한다. SMFC/GTFC/FCSA는 표기 흔들림을 허용한다."},
    3: {"category": COMMON, "cols": "J · K",
        "summary": "모재 두께가 그 WPS·재질의 허용 범위 안인가",
        "logic": "WPS List G열에서 «이 재질에 해당하는» 두께 범위를 골라 대조한다. "
                 "**M·N 재질이 같으면 J열과 K열을 각각** 본다 — 이음을 구성하는 각 "
                 "부재에 대해 자격 범위가 성립해야 하기 때문이다(ASME IX QW-451). "
                 "**재질이 서로 다르면 낮은 두께만** 본다 — 이종재 이음은 상위 "
                 "그레이드 재질과 낮은 두께 기준으로 WPS를 고르기 때문이다"
                 "(현업 확인 2026-08-13). "
                 "관재(파이프·형강)는 두께가 아니라 외경이 기준이라 건너뛴다."},
    4: {"category": COMMON, "cols": "R",
        "summary": "Groove 형상이 그 WPS의 Joint Detail에 있는가",
        "logic": "R열 Groove 코드(SB·DB·FL·PP 등)가 WPS List L열의 Joint Detail에 "
                 "포함되는지 본다. 수리(Repair) WPS는 제외한다."},
    5: {"category": COMMON, "cols": "—",
        "summary": "(폐지) NDT Cat A/B면 TR-FC-G03을 쓰라는 규칙",
        "logic": "현업 확인(2026-08-10, §11-2)으로 **규칙 자체를 폐지**했다. "
                 "번호와 이름만 남겨 둔다 — 검토 기록 키가 이 번호를 쓰고 있어서, "
                 "지우거나 재사용하면 과거 의견이 무관한 항목에 붙는다."},
    6: {"category": COMMON, "cols": "AP · AR · AT · AV",
        "summary": "투입된 용접사가 그 프로세스 자격을 가졌는가",
        "logic": "용접사 1~4번 각각에 대해, 자격 DB에 있는지와 시공 프로세스"
                 "(AQ/AS/AU/AW) 자격을 가졌는지 본다. **SMFC 자격 보유자의 FCAW "
                 "시공은 허용**한다(현업 확인 2026-08-11). **혼합 프로세스"
                 "(GTFC·SMFC·FCSA) 이음은 4명 중 한 명만 그 자격이 있으면 나머지는 "
                 "FCAW 자격으로 충분하다**(현업 확인 2026-08-13) — 자격자가 아무도 "
                 "없으면 완화하지 않는다. 이 검사는 그 행의 작업 "
                 "품질이 아니라 개인의 서류 문제라 용접사별 결함률에서 제외한다."},
    7: {"category": COMMON, "cols": "—",
        "summary": "(폐지) Check 2와 5가 동시에 걸린 행",
        "logic": "Check 5(NDT Cat A/B → TR-FC-G03)가 폐지되면서 «Check 2와 5가 "
                 "동시에 걸린 행»이라는 조건 자체가 성립하지 않게 됐다. 번호와 "
                 "이름만 남겨 둔다 — 검토 기록 키가 이 번호를 쓰고 있어서다."},
    8: {"category": PROJECT, "cols": "J",
        "summary": "TR-FC-G03에 -40 재질을 쓸 때의 두께 상한",
        "logic": "대상 WPS(기본 TR-FC-G03)에 충격시험 -40 재질을 쓰면 두께 상한을 "
                 "12mm로 본다. 대상 WPS 번호와 상한값이 프로젝트 설정이다."},
    9: {"category": PROJECT, "cols": "J · K · M · N",
        "summary": "대상 WPS는 API 재질에 특정 두께를 쓸 수 없다",
        "logic": "대상 WPS(프로젝트 설정, 예: TR-SMFC-G01)에 **M열 또는 N열 재질이 "
                 "API로 시작**하면서 J열 또는 K열 두께가 금지 목록(기본 12.7·8.2·"
                 "6mm)에 해당하면 결함이다(현업 확인 2026-08-13). 예전에는 «두께 "
                 "12.7을 확인 대상으로 표시»였고 재질 조건이 없었다 — 성격이 "
                 "«확인»에서 «금지»로 바뀌었지만 검토 기록 키가 `…|Check No`라 "
                 "번호는 그대로 쓴다. 대상 WPS와 금지 두께 목록이 프로젝트 설정이다."},
    10: {"category": COMMON, "cols": "J",
         "summary": "두께 초과와 특수 규칙이 동시에 걸린 행",
         "logic": "Check 3과 Check 8이 같은 행에 걸리면 복합 오류로 따로 표시한다. "
                  "겹친 것을 눈에 먼저 띄게 하려는 것이라 색 우선순위가 가장 높다."},
    11: {"category": COMMON, "cols": "M · N",
         "summary": "모재가 그 WPS의 허용 재질인가",
         "logic": "WPS List F열(허용 모재)과 G열의 재질 라벨을 함께 본다. F열 기재가 "
                  "빠진 WPS가 실제로 있어서, 두 곳 모두에 없을 때만 결함으로 본다."},
    12: {"category": COMMON, "cols": "I",
         "summary": "관재는 두께가 아니라 외경 규격으로 봐야 한다",
         "logic": "재질이 관재(파이프·중공형강)면 J열 두께로 판정할 수 없으므로 "
                  "«수동 확인 필요»로 표시한다. 결함 확정이 아니라 사람이 볼 대상이다."},
    13: {"category": COMMON, "cols": "A",
         "summary": "전체 분포에서 드문 조합 (통계·비지도학습)",
         "logic": "IsolationForest로 재질·WPS·Groove·NDT Cat·부서·두께 조합의 "
                  "이례성을 점수화하고 상위 1.5%를 표시한다. **규칙 위반이 아니라** "
                  "«드물다»는 뜻이며, 사람이 확인해 판단을 남기는 것이 전제다. "
                  "매 검증마다 새로 학습한다."},
    14: {"category": COMMON, "cols": "D",
         "summary": "같은 도면·Joint가 값이 다르게 여러 번 등록됨",
         "logic": "(도면번호, Joint No)로 묶어 두께·WPS·재질이 서로 다른 그룹을 "
                  "찾는다. Joint No는 도면 안에서만 유일하므로 도면번호를 반드시 "
                  "함께 묶는다. 값이 전부 같은 단순 중복은 제외한다."},
    16: {"category": COMMON, "cols": "S~V · BM~BV",
         "summary": "요구된 NDT를 실제로 수행했는가",
         "logic": "S~V열의 NDT Extent(RT/UT/MT/PT 요구 비율)에 값이 있으면 그 "
                  "검사의 수행일 열이 채워져 있어야 한다. 기준일은 «오늘»이 아니라 "
                  "**데이터 내 최종 용접일**이고 유예는 30일이다."},
    17: {"category": COMMON, "cols": "BI",
         "summary": "육안검사(VT)를 수행했는가",
         "logic": "용접 후 유예 30일이 지났는데 VT 수행일(BI)이 공란이면 결함. "
                  "기준일은 데이터 내 최종 용접일이다 — «오늘»로 하면 같은 파일을 "
                  "내일 다시 돌릴 때 건수가 늘어 «코드가 바뀐 것»과 구분되지 않는다."},
    18: {"category": COMMON, "cols": "AL",
         "summary": "용접봉 Lot 번호가 기재되어 있는가",
         "logic": "AL열(용접봉 Lot)이 공란이면 결함. 원래는 «WPS가 지정한 용접봉과 "
                  "다른 것을 썼는가»를 보려 했으나, Lot 번호와 WPS의 브랜드명을 "
                  "대조할 매핑표가 없어 «누락만 본다»로 범위를 줄였다(§11-12). "
                  "실데이터는 전량 기재돼 있어 0건이다 — 기재율이 떨어지면 그때 잡는다."},
    19: {"category": COMMON, "cols": "AK · AP~AW",
         "summary": "WPS Process 자격자가 최소 한 명은 투입되었는가",
         "logic": "AK열 WPS Process(SMFC·GTFC 등)에 대해, 그 행의 용접사 1~4명 중 "
                  "**최소 한 명**은 같은 프로세스 자격을 보유해야 한다. 아무도 없으면 "
                  "결함이다. Check 6이 «각 용접사가 자기 시공 프로세스 자격을 "
                  "가졌는가»를 보는 것과 축이 다르다 — 이쪽은 «WPS가 요구하는 "
                  "프로세스를 아는 사람이 그 이음에 있었는가»를 본다."},
    20: {"category": COMMON, "cols": "M · N · R · AK",
         "summary": "API 재질은 Groove에 따라 허용 프로세스가 다르다",
         "logic": "M열 또는 N열 재질이 API로 시작하면, R열 Groove가 FL 또는 FW이면 "
                  "FCAW를 적용하고 그 외 Groove(SB 등)에는 SMFC 또는 GTFC를 적용해야 "
                  "한다. 예를 들어 SB에 FCAW를 쓰면 결함이다."},
    21: {"category": COMMON, "cols": "AK · AL",
         "summary": "혼합 프로세스 이음은 용접재료를 둘 적어야 한다",
         "logic": "AK열 Process가 GTFC·SMFC·FCSA처럼 두 프로세스를 함께 쓰는 경우, "
                  "AL열에 용접재료를 쉼표로 구분해 2종 적어야 한다. AL이 아예 비어 "
                  "있으면 Check 18이 지적하므로 여기서는 값이 있을 때만 개수를 센다."},
    22: {"category": COMMON, "cols": "S~V · BD · BN·BQ·BT·BW",
         "summary": "NDT 100% 구간인데 리포트 번호가 확정되지 않았다",
         "logic": "요구 요율(S~V열)이 100인 구간은 전수 검사다. NDT 계획/신청일(BD)이 "
                  "잡혀 있는데 그 검사의 리포트 번호가 공란이거나 «*»로 끝나면(촬영하지 "
                  "않은 수량 표기) 결함이다. 100%가 아닌 구간의 «*»는 정상이며, 그쪽 "
                  "실제 촬영율은 Check 26이 묶음 단위로 본다."},
    23: {"category": COMMON, "cols": "E · AJ",
         "summary": "수리 시공인데 수리용 WPS를 쓰지 않았다",
         "logic": "E열(헤더 RE)에 값이 있으면 수리 시공이다(RE·R1·U1·M1 등 표기는 "
                  "다양하고 비어 있지 않기만 하면 해당). 그때 AJ열 WPS No는 끝에서 "
                  "세 번째 문자가 R이어야 한다(예: TR-FC-R01)."},
    24: {"category": COMMON, "cols": "Q · AJ",
         "summary": "TKY 이음(Q열 TT)은 전용 WPS를 써야 한다",
         "logic": "Q열 Type이 TT면 TKY 이음(관재 교차부)이다. AJ열 WPS의 마지막 "
                  "구분(하이픈 뒤 마지막 토큰)이 GK로 시작해야 한다 — TR-SMFC-GK01 "
                  "형태다. 앞의 프로세스 표기는 프로젝트마다 달라 보지 않는다."},
    25: {"category": COMMON, "cols": "Q · AJ",
         "summary": "Q01 WPS는 이음 Type이 B인 곳에만 쓴다",
         "logic": "AJ열 WPS의 마지막 구분이 Q01이면 Q열 Type이 B여야 한다. "
                  "Q열이 비어 있으면 판정하지 않는다."},
    26: {"category": COMMON, "cols": "S~V · BN·BQ·BT·BW",
         "summary": "리포트 묶음의 실제 촬영율이 요구 요율에 못 미친다",
         "logic": "리포트 번호 끝의 «*»는 촬영하지 않은 수량이다. «*»를 뗀 번호가 "
                  "같은 행들이 한 묶음이고, 촬영율 = («*» 없는 건수) / (묶음 전체). "
                  "한 묶음에 요구 요율이 섞여 있으면 **가장 높은 것**을 기준으로 한다 "
                  "— 낮은 요율 조인트를 끼워 넣는 것만으로 요구가 내려가면 안 된다. "
                  "묶음 단위라 2차 패스에서 판정한다."},
    27: {"category": COMMON, "cols": "M · N · AJ",
         "summary": "[보류] 이종재 이음은 상위 그레이드 기준으로 WPS를 골라야 한다",
         "logic": "**[보류] — 전체 등급표가 아직 없다.** 지금은 재질명 끝의 시험온도"
                  "(낮을수록 상위, -40 > -20)와 S355 < S420 두 가지만 비교할 수 있고, "
                  "그 외 조합은 판정하지 않는다. 근거 없이 찍으면 오탐이 되기 때문이다. "
                  "현업이 등급표를 주면 verifier의 _GRADE_ORDER를 채워 완성한다. "
                  "이종재 이음의 **두께**는 Check 3이 낮은 쪽 기준으로 이미 본다."},
}

# 결번. 번호를 재사용하면 검토 기록 키(`…|Check No`)가 과거 의견을 무관한
# 항목에 붙인다.
RETIRED = {15}

# 저장 형식 — **프로젝트별 프로파일**.
#
#     {"active": "TRION FPU",
#      "profiles": {"TRION FPU": {"enabled": {"18": false}}, ...},
#      "requests": [...]}
#
# 이 시스템은 한 프로젝트 전용이 아니다. 프로젝트마다 적용할 판정 항목이 다르고,
# 이름으로 불러와 바꾼 뒤 파일을 올려 돌리는 방식으로 쓴다. 그래서 설정을
# «하나»가 아니라 «이름이 붙은 여러 벌»로 둔다.
#
# `requests`(신규 규칙 요청)는 프로파일 **밖**이다. 규칙 요청은 «이 프로젝트에서
# 무엇을 켤까»가 아니라 «시스템에 무엇을 추가할까»라, 프로젝트를 바꿨다고
# 사라지면 안 된다.
DEFAULT_PROFILE = "기본"

_SETTINGS_DEFAULT: dict[str, Any] = {
    "active": DEFAULT_PROFILE,
    "profiles": {},
    "check_ids": {},
    "requests": [],
}


def _blank() -> dict[str, Any]:
    return {"active": DEFAULT_PROFILE, "profiles": {}, "check_ids": {}, "requests": []}


def _load() -> dict[str, Any]:
    path = config.PROJECT_RULES_FILE
    if not path.exists():
        return _blank()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("최상위가 객체가 아니다")
    except Exception:
        logger.exception("프로젝트 규칙 설정을 읽지 못했다 — 기본값(전부 켬)으로 진행한다")
        return _blank()

    # 프로파일이 없던 옛 형식({"project": ..., "enabled": {...}})을 옮겨 담는다.
    # 그냥 무시하면 꺼 둔 항목이 조용히 다시 켜진다.
    if "profiles" not in data and "enabled" in data:
        name = (data.get("project") or "").strip() or DEFAULT_PROFILE
        data = {"active": name,
                "profiles": {name: {"enabled": data.get("enabled") or {}}},
                "requests": data.get("requests") or []}
        logger.info("판정 항목 설정을 프로파일 형식으로 옮겼다: '%s'", name)

    out = {**_SETTINGS_DEFAULT, **data}
    out["profiles"] = out.get("profiles") or {}
    out["requests"] = out.get("requests") or []
    out["check_ids"] = out.get("check_ids") or {}
    if not out.get("active"):
        out["active"] = DEFAULT_PROFILE
    return out


def active_profile_name() -> str:
    return _load()["active"]


def profile_names() -> list[str]:
    d = _load()
    names = set(d["profiles"]) | {d["active"]}
    return sorted(names, key=lambda x: (x != d["active"], x))


def has_profile(name: str) -> bool:
    """이미 있는 프로젝트인가.

    검증 실행이 «없는 이름»을 받았을 때 새로 만들면 안 되기 때문에 필요하다.
    `switch_profile()`은 일부러 만들어 주지만(세팅 탭에서 새 프로젝트를 만드는
    길이다), 검증 쪽에서 그러면 **오타 한 글자가 «전 항목 켬»이 되어** 엉뚱한
    기준으로 돌아간다. 결과에는 그 오타 이름이 박히므로 나중에도 알기 어렵다.
    """
    d = _load()
    name = (name or "").strip()
    return bool(name) and (name in d["profiles"] or name == d["active"])


def _active(data: dict[str, Any]) -> dict[str, Any]:
    return data["profiles"].get(data["active"]) or {}


def is_enabled(check_no: int | str) -> bool:
    """그 Check를 판정할 것인가. **설정에 없으면 켬**이다.

    새 Check를 추가했을 때 설정 파일에 없다고 꺼지면, 검사를 만들어 놓고도
    아무 일이 일어나지 않는다. 예외도 경고도 없어서 발견이 아주 늦다.
    """
    return bool((_active(_load()).get("enabled") or {}).get(str(check_no), True))


def enabled_map() -> dict[str, bool]:
    """켜져 있는 항목 — **공통 + 활성 프로파일의 프로젝트 규칙.**

    **키는 문자열이다** — 공통 `"3"`, 프로젝트 `"RUYA1"`.
    프로젝트 규칙을 빼면 세 곳이 조용히 틀린다:
      - `verifier._rule_on()`이 항상 True를 줘서 «껐는데 판정된다»
      - 회차 스냅샷(`result.rules`)에 프로젝트 규칙이 없어 화면이 카드를 못 그린다
      - `routers/rules.py`의 «알려진 번호»에 빠져 UI에서 토글하면 400
    """
    on = _active(_load()).get("enabled") or {}
    nos = {str(n) for n in CATALOG} | {
        str(c.get("no") or "").strip() for c in active_checks()}
    nos.discard("")
    return {no: bool(on.get(no, True))
            for no in sorted(nos, key=project_checks.sort_key)}


def catalog() -> dict[str, dict[str, Any]]:
    """공통 카탈로그 + 활성 프로파일의 프로젝트 규칙. 화면·라우터가 쓴다.

    **키는 문자열이다.** 공통은 `"3"`, 프로젝트는 `"RUYA1"`. `CATALOG` 자체는
    정수 키를 그대로 둔다 — 전부 바꾸면 정본 문서·테스트·에이전트 정의의
    「Check 14」 표기가 함께 낡는다.
    """
    out: dict[str, dict[str, Any]] = {str(no): dict(spec) for no, spec in CATALOG.items()}
    for c in active_checks():
        no = str(c.get("no") or "").strip()
        if not no:
            continue
        out[no] = {"category": PROJECT,
                   "cols": c.get("cols", ""),
                   "summary": c.get("summary", ""),
                   "logic": c.get("logic", ""),
                   "key": c.get("key", ""),
                   "color": c.get("color", "Gray"),
                   "name": c.get("name", ""),
                   "kind": c.get("kind", ""),
                   "param": c.get("param") or {},
                   "when": c.get("when") or {},
                   "overrides": c.get("overrides") or []}
    return out


def settings() -> dict[str, Any]:
    return _load()


def active_params() -> dict[str, Any]:
    """활성 프로파일의 `params` — 공통 Check에 «먹이는» 프로젝트 값.

    `checks`(별도 검증항목)와 나누는 기준:

        params  공통 Check가 그대로 쓰는 값     repair_prefix · wps_corrections · temp_member
        checks  자기 번호를 갖는 별도 판정항목   재질별·WPS별 두께 허용범위

    `wps_rules.load()`가 이걸 마지막에 겹쳐 쓴다. 프로파일에 두는 이유는
    **전환할 때 «켬/끔»과 «값»이 한 번에 바뀌어야** 하기 때문이다 — 파일 하나에
    두면 프로젝트를 바꿔도 앞 프로젝트의 값이 그대로 남는다.
    """
    return dict(_active(_load()).get("params") or {})


def active_checks() -> list[dict[str, Any]]:
    """활성 프로파일의 프로젝트 판정규칙 정의(원문). 검증은 `project_checks.parse()`."""
    return list(_active(_load()).get("checks") or [])


def check_ledger() -> dict[str, Any]:
    """번호 할당대장. **프로파일 밖**이다 — 한 서버에 프로파일이 둘 이상 있어도
    검토 기록과 결과 DB는 공유되므로, 번호는 서버 단위로 유일해야 한다."""
    return dict(_load().get("check_ids") or {})


def save_ledger(ledger: dict[str, Any]) -> None:
    data = _load()
    data["check_ids"] = ledger
    _write(data)


def save_enabled(enabled: dict[int, bool], project: str | None = None) -> dict[str, Any]:
    """켜고 끔을 **활성 프로파일**에 저장한다.

    `project`를 주면 그 이름의 프로파일에 저장하고 활성으로 바꾼다 — 새 이름이면
    새로 만든다. 파일 전체를 다시 쓰지 않고 필요한 키만 갈아끼운다: 신규 규칙
    요청과 다른 프로젝트의 설정이 같은 파일에 있어서, 통째로 덮으면 날아간다.
    """
    data = _load()
    name = (project or "").strip() or data["active"]
    data["active"] = name
    prof = data["profiles"].setdefault(name, {})
    prof["enabled"] = {str(k): bool(v) for k, v in enabled.items()}
    _write(data)
    return data


def switch_profile(name: str) -> dict[str, Any]:
    """활성 프로파일을 바꾼다. 없는 이름이면 «전부 켬»으로 새로 만든다.

    **바꾸면 판정 기준이 달라지므로 재검증이 필요하다.** 호출부가 그걸 알린다.
    """
    data = _load()
    name = (name or "").strip()
    if not name:
        raise ValueError("프로젝트 이름이 비어 있다")
    data["active"] = name
    data["profiles"].setdefault(name, {"enabled": {}})
    _write(data)
    return data


def delete_profile(name: str) -> bool:
    """프로파일을 지운다. 활성 프로파일은 지울 수 없다 — 지우면 «무엇을 기준으로
    판정 중인지»가 사라진다."""
    data = _load()
    name = (name or "").strip()
    if name == data["active"] or name not in data["profiles"]:
        return False
    data["profiles"].pop(name, None)
    _write(data)
    return True


def add_request(req: dict[str, Any]) -> dict[str, Any]:
    """현업이 낸 «신규 판정로직» 요청을 쌓아 둔다.

    **서버는 이 요청을 코드로 바꾸지 않는다.** 자연어를 판정 코드로 옮기는 일을
    서버가 하려면 이 PC의 Claude Code 자격증명이 사내망에 열려야 하는데,
    '에이전트' 탭에서 이미 같은 이유로 실행 기능을 뺐다. 여기서는 받아 적기만
    하고, 관리자가 Claude Code로 반영한 뒤 상태를 바꾼다.

    프로파일 밖에 쌓는다 — 프로젝트를 바꿨다고 요청이 사라지면 안 된다.
    """
    data = _load()
    reqs = list(data.get("requests") or [])
    req = dict(req)
    req.setdefault("status", "접수")
    req.setdefault("project", data["active"])
    req["id"] = max([r.get("id", 0) for r in reqs], default=0) + 1
    reqs.append(req)
    data["requests"] = reqs
    _write(data)
    return req


def set_request_status(req_id: int, status: str) -> bool:
    data = _load()
    hit = False
    for r in data.get("requests") or []:
        if r.get("id") == req_id:
            r["status"] = status
            hit = True
    if hit:
        _write(data)
    return hit


def _write(data: dict[str, Any]) -> None:
    """임시 파일 + `os.replace`로 원자적으로 바꾼다 — 쓰다 끊겨도 반쪽 파일이
    남지 않는다. 반쪽이 남으면 다음 기동에서 «설정 없음 = 전부 켬»이 되어,
    꺼 둔 항목이 조용히 다시 켜진다."""
    path = config.PROJECT_RULES_FILE
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)

    # 프로파일 `params`가 `wps_rules.load()`의 마지막 층이다. 캐시를 안 버리면
    # 프로젝트를 바꿔도 옛 값이 계속 쓰인다 — 화면과 판정이 갈라진다.
    try:
        from . import wps_rules
        wps_rules.invalidate()
    except Exception:
        logger.exception("WPS 규칙 캐시를 비우지 못했다")


def describe(check_no: int | str) -> dict[str, Any]:
    spec = CATALOG.get(check_no, {})
    return {"check_no": check_no,
            "category": spec.get("category", COMMON),
            "cols": spec.get("cols", ""),
            "summary": spec.get("summary", ""),
            "logic": spec.get("logic", "")}


def category_of(check_no: int | str) -> str:
    """공통인가 프로젝트인가. **번호가 아니라 모양으로** 가른다 —
    표에 적어 두면 규칙을 추가할 때마다 여기도 고쳐야 하고, 빠뜨리면
    프로젝트 규칙이 «공통» 배지를 단다."""
    cid = str(check_no).strip()
    if not project_checks.is_common(cid):
        return PROJECT
    return CATALOG.get(int(cid), {}).get("category", COMMON) if cid.isdigit() else COMMON
