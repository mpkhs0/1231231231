"""
`QC_검사로직_상세분석.md`를 화면에서 읽을 수 있게 HTML로 바꾼다.

## 왜 필요한가

이 문서가 검사 로직의 **정본**인데, 지금은 저장소에 접근할 수 있는 서버 관리자만
볼 수 있다. 정작 판정 결과를 받아 검토하는 현업이 «이 검사가 무엇을 보는가»를
확인할 방법이 없다. 그래서 '검사 로직' 탭에서 문서를 그대로 읽게 한다.

## 왜 라이브러리를 쓰지 않는가

두 가지 이유다.

1. **사내망이라 CDN을 못 쓴다.** 파일로 들여오면 되지만(mermaid가 그렇다),
   범용 마크다운 라이브러리는 기본값이 **HTML을 그대로 통과시킨다.**
2. 이 문서에는 **현업이 화면에서 입력한 글이 들어온다.** `review_items.py`가
   §11에 「현업 답변」 블록을 되쓰기 때문이다. 즉 신뢰할 수 없는 문자열이
   섞이는 문서다.

그래서 **이스케이프를 먼저 하고 그 위에 태그를 얹는다.** 순서가 반대면 본문에
들어온 `<script>`가 살아난다. 지원 범위를 우리가 실제로 쓰는 문법으로 좁히는
대신, 통과하는 HTML이 하나도 없게 만드는 쪽을 택했다.

## 다루는 문법

제목 · 표 · 코드펜스 · 인용 · 목록 · 수평선 · 문단, 인라인은 **굵게** ·
`코드` · [링크](url). 그 외는 글자 그대로 나온다 — 문서가 깨져 보이는 것이
없는 태그가 실행되는 것보다 낫다.
"""

from __future__ import annotations

import html
import logging
import re
from typing import Any

from .. import config

logger = logging.getLogger(__name__)

_INLINE_CODE = re.compile(r"`([^`]+)`")
_BOLD = re.compile(r"\*\*([^*]+)\*\*")
_LINK = re.compile(r"\[([^\]]+)\]\(([^)\s]+)\)")
_HEADING = re.compile(r"^(#{1,6})\s+(.*)$")
_TABLE_SEP = re.compile(r"^\s*\|?[\s:\-|]+\|[\s:\-|]*$")


def _inline(text: str) -> str:
    """인라인 서식. **이스케이프가 먼저다** — 순서가 바뀌면 태그가 살아난다."""
    out = html.escape(text, quote=False)
    out = _INLINE_CODE.sub(lambda m: f"<code>{m.group(1)}</code>", out)
    out = _BOLD.sub(lambda m: f"<b>{m.group(1)}</b>", out)

    def _link(m: re.Match) -> str:
        url = m.group(2)
        # 사내망 문서라 링크는 http(s)만 연다. `javascript:` 같은 스킴을 막는다.
        if not url.startswith(("http://", "https://", "#")):
            return m.group(0)
        return (f'<a href="{html.escape(url, quote=True)}" '
                f'target="_blank" rel="noopener">{m.group(1)}</a>')

    return _LINK.sub(_link, out)


def _slug(text: str, used: set[str]) -> str:
    """목차에서 쓸 앵커. 한글을 그대로 두면 URL 인코딩이 지저분해 번호를 붙인다."""
    base = re.sub(r"[^0-9A-Za-z가-힣]+", "-", text).strip("-").lower() or "sec"
    slug = base
    n = 2
    while slug in used:
        slug = f"{base}-{n}"
        n += 1
    used.add(slug)
    return slug


def render(md: str) -> dict[str, Any]:
    """마크다운 -> {html, outline}. outline은 목차용 (level·text·id)."""
    lines = md.replace("\r\n", "\n").split("\n")
    out: list[str] = []
    outline: list[dict[str, Any]] = []
    used: set[str] = set()

    i = 0
    para: list[str] = []

    def flush_para() -> None:
        if para:
            out.append("<p>" + "<br>".join(_inline(x) for x in para) + "</p>")
            para.clear()

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # ── 코드펜스 ────────────────────────────────────────────────────────
        if stripped.startswith("```"):
            flush_para()
            lang = stripped[3:].strip()
            body: list[str] = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                body.append(lines[i])
                i += 1
            i += 1
            text = "\n".join(body)
            if lang == "mermaid":
                # 도식은 화면에서 그린다. 소스는 그대로 두고 프론트가 렌더한다 —
                # 서버가 SVG를 구우면 '판정 규칙 도식' 부탭과 만드는 경로가 갈린다.
                out.append('<div class="doc-mermaid">'
                           + html.escape(text, quote=False) + "</div>")
            else:
                out.append("<pre><code>" + html.escape(text, quote=False)
                           + "</code></pre>")
            continue

        # ── 제목 ────────────────────────────────────────────────────────────
        m = _HEADING.match(line)
        if m:
            flush_para()
            level = len(m.group(1))
            text = m.group(2).strip()
            sid = _slug(text, used)
            # 목차는 2·3단계만 담는다 — 전부 담으면 훑어보는 값이 사라진다
            if 2 <= level <= 3:
                outline.append({"level": level, "text": text, "id": sid})
            out.append(f'<h{level} id="{sid}">{_inline(text)}</h{level}>')
            i += 1
            continue

        # ── 수평선 ──────────────────────────────────────────────────────────
        if re.fullmatch(r"-{3,}|\*{3,}|_{3,}", stripped):
            flush_para()
            out.append("<hr>")
            i += 1
            continue

        # ── 표 ──────────────────────────────────────────────────────────────
        if stripped.startswith("|") and i + 1 < len(lines) \
                and _TABLE_SEP.match(lines[i + 1]):
            flush_para()
            head = _row_cells(stripped)
            i += 2
            rows: list[list[str]] = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append(_row_cells(lines[i].strip()))
                i += 1
            out.append(_table_html(head, rows))
            continue

        # ── 인용 ────────────────────────────────────────────────────────────
        if stripped.startswith(">"):
            flush_para()
            quote: list[str] = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                quote.append(lines[i].strip().lstrip(">").strip())
                i += 1
            out.append("<blockquote>"
                       + "<br>".join(_inline(x) for x in quote if x)
                       + "</blockquote>")
            continue

        # ── 목록 ────────────────────────────────────────────────────────────
        if re.match(r"^\s*([-*+]|\d+\.)\s+", line):
            flush_para()
            ordered = bool(re.match(r"^\s*\d+\.\s+", line))
            items: list[str] = []
            while i < len(lines) and re.match(r"^\s*([-*+]|\d+\.)\s+", lines[i]):
                items.append(re.sub(r"^\s*([-*+]|\d+\.)\s+", "", lines[i]))
                i += 1
                # 다음 줄이 들여쓴 이어짐이면 같은 항목에 붙인다
                while i < len(lines) and lines[i].startswith("  ") \
                        and lines[i].strip() \
                        and not re.match(r"^\s*([-*+]|\d+\.)\s+", lines[i]):
                    items[-1] += " " + lines[i].strip()
                    i += 1
            tag = "ol" if ordered else "ul"
            out.append(f"<{tag}>"
                       + "".join(f"<li>{_inline(x)}</li>" for x in items)
                       + f"</{tag}>")
            continue

        # ── 빈 줄 / 문단 ────────────────────────────────────────────────────
        if not stripped:
            flush_para()
        else:
            para.append(stripped)
        i += 1

    flush_para()
    return {"html": "\n".join(out), "outline": outline}


def _row_cells(line: str) -> list[str]:
    cells = line.strip().strip("|").split("|")
    return [c.strip() for c in cells]


def _table_html(head: list[str], rows: list[list[str]]) -> str:
    ths = "".join(f"<th>{_inline(c)}</th>" for c in head)
    trs = []
    for r in rows:
        # 열 수가 머리글과 다른 행이 실제로 있다. 잘라내지 말고 채운다 —
        # 잘라내면 내용이 조용히 사라진다.
        cells = r + [""] * (len(head) - len(r))
        trs.append("<tr>" + "".join(f"<td>{_inline(c)}</td>" for c in cells) + "</tr>")
    return ('<div class="doc-tbl-wrap"><table class="doc-tbl"><thead><tr>'
            + ths + "</tr></thead><tbody>" + "".join(trs) + "</tbody></table></div>")


def load_doc() -> dict[str, Any]:
    """정본 문서를 읽어 화면용으로 바꾼다. **매 요청 다시 읽는다** —
    문서를 손으로 고쳐도 새로고침이면 반영된다(§11 조회와 같은 방침)."""
    path = config.ANALYSIS_DOC
    if not path.exists():
        return {"ok": False, "html": "", "outline": [],
                "error": f"문서를 찾을 수 없습니다: {path.name}"}
    text = path.read_text(encoding="utf-8")
    data = render(text)
    stat = path.stat()
    return {"ok": True, "title": path.stem, "filename": path.name,
            "bytes": stat.st_size, "mtime": stat.st_mtime,
            "lines": text.count("\n") + 1, **data}
