"""
HHI DRM(현대중공업 보안등급) 암호화 xlsx 파일을 일반 xlsx로 변환.

핵심 제약:
  - openpyxl.load_workbook(drm_file) → "File is not a zip file"
  - Excel COM SaveAs(xlsx) → 출력도 DRM 재암호화
  - Excel COM 을 사용한 프로세스에서 openpyxl 쓰기도 DRM 재암호화

해결책 — 3단계 격리:
  1. 격리된 subprocess 에서 Excel COM 으로 DRM 파일의 각 시트를
     CSV 형식으로 임시 파일에 저장 (CSV 는 DRM 미적용)
     → Excel 완전 종료 후 CSV 를 읽어 JSON 으로 stdout 출력
     (Excel COM 오염이 해당 subprocess 에만 국한됨)
  2. 메인 프로세스(오염 없음)에서 JSON 을 파싱
  3. openpyxl 로 새 xlsx 를 생성·저장 → 출력 파일은 DRM 없음

한계:
  - CSV 경유이므로 셀 서식(색상·병합·수식)은 손실된다.
  - 검증 로직은 셀 값만 읽으므로 실용상 문제 없음.
  - 날짜는 Excel 의 CSV 직렬화 형식(문자열)으로 보존된다.
"""
import csv
import io
import json
import logging
import subprocess
import sys
import tempfile
import os
from pathlib import Path

from openpyxl import Workbook

logger = logging.getLogger(__name__)

_DRM_SIG = b"HHIDRMC"

# 격리 subprocess: Excel COM 으로 각 시트를 CSV 로 뽑아 JSON 으로 stdout 출력.
# SaveAs(FileFormat=6 = CSV) 는 DRM 재암호화가 없다.
# 시트명은 SaveAs 호출 전에 캡처해야 한다 — SaveAs 가 시트명을 파일명으로 바꾼다.
_READ_SCRIPT = r"""
import sys, json, csv, os, tempfile, pythoncom, win32com.client
sys.stdout.reconfigure(encoding='utf-8')

src = sys.argv[1]
pythoncom.CoInitialize()
xl = win32com.client.Dispatch("Excel.Application")
xl.Visible = False
xl.DisplayAlerts = False

tmp_files   = []
sheet_names = []
try:
    wb = xl.Workbooks.Open(src)
    for i in range(1, wb.Sheets.Count + 1):
        sh   = wb.Sheets(i)
        name = sh.Name                           # SaveAs 전에 캡처
        tmp  = tempfile.mktemp(suffix=".csv")
        sh.SaveAs(tmp, FileFormat=6)             # CSV — DRM 없음
        tmp_files.append(tmp)
        sheet_names.append(name)
    wb.Close(False)
finally:
    xl.Quit()
    pythoncom.CoUninitialize()

# Excel 완전 종료 후 CSV 읽기 → JSON 출력
result = {}
for name, path in zip(sheet_names, tmp_files):
    try:
        # Excel 이 시스템 기본 인코딩(cp949)으로 저장하므로 utf-8-sig 와 cp949 를 모두 시도
        for enc in ('utf-8-sig', 'cp949', 'utf-8'):
            try:
                with open(path, encoding=enc, errors='strict') as f:
                    result[name] = list(csv.reader(f))
                break
            except (UnicodeDecodeError, LookupError):
                continue
        else:
            with open(path, encoding='utf-8', errors='replace') as f:
                result[name] = list(csv.reader(f))
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
sys.stdout.write(json.dumps(result, ensure_ascii=False))
"""


def is_drm(path: Path) -> bool:
    """파일이 HHI DRM 암호화 형식인지 확인한다."""
    try:
        with open(path, "rb") as f:
            return f.read(7) == _DRM_SIG
    except OSError:
        return False


def convert(src: Path, dest: Path) -> None:
    """DRM xlsx 를 일반 xlsx 로 변환해 dest 에 저장한다.

    - 격리 subprocess: Excel COM → CSV → JSON (stdout)
    - 메인 프로세스: openpyxl 로 새 xlsx 생성
    """
    result = subprocess.run(
        [sys.executable, "-c", _READ_SCRIPT, str(src.resolve())],
        capture_output=True,
        timeout=120,
    )
    if result.returncode != 0:
        err = result.stderr.decode("utf-8", "replace").strip() or "알 수 없는 오류"
        raise RuntimeError(f"Excel COM CSV 추출 실패: {err}")

    try:
        sheets_data: dict = json.loads(result.stdout.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise RuntimeError(f"Excel COM 출력 파싱 실패: {exc}") from exc

    wb = Workbook()
    wb.remove(wb.active)
    for sheet_name, rows in sheets_data.items():
        ws = wb.create_sheet(title=sheet_name)
        for row in rows:
            ws.append(row)
    wb.save(str(dest))
    logger.info("DRM 변환 완료: %s → %s (%d 시트)", src.name, dest.name, len(sheets_data))


def convert_to_bytes(src: Path) -> bytes:
    """DRM xlsx를 변환하여 메모리(bytes)로 반환한다. 디스크 쓰기 없으므로 DRM 재암호화 불가."""
    result = subprocess.run(
        [sys.executable, "-c", _READ_SCRIPT, str(src.resolve())],
        capture_output=True,
        timeout=120,
    )
    if result.returncode != 0:
        err = result.stderr.decode("utf-8", "replace").strip() or "알 수 없는 오류"
        raise RuntimeError(f"Excel COM CSV 추출 실패: {err}")

    try:
        sheets_data: dict = json.loads(result.stdout.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise RuntimeError(f"Excel COM 출력 파싱 실패: {exc}") from exc

    bio = io.BytesIO()
    wb = Workbook()
    wb.remove(wb.active)
    for sheet_name, rows in sheets_data.items():
        ws = wb.create_sheet(title=sheet_name)
        for row in rows:
            ws.append(row)
    wb.save(bio)
    bio.seek(0)
    data = bio.read()
    logger.info("DRM 메모리 변환 완료: %s (%d 시트, %d bytes)", src.name, len(sheets_data), len(data))
    return data
