"""
프로젝트 판정규칙 — 공통 Check를 **덮어쓰지 않고** 자기 번호로 판정한다.

## 왜 필요한가

프로젝트마다 WPS가 새로 만들어지고, 선급 룰에 따라 재질별 두께가 조금씩 다르다.
예전에는 그 값이 `wps_rules.DEFAULTS`에 하드코딩되어 있었고, `_c3_thickness_side()`
첫머리에서 맞으면 `return None`으로 **WPS List G열 판정을 통째로 대체**했다.
게다가 위반해도 `Flag(3)`, 즉 «공통» Check 3 건수로 집계됐다.

그래서 두 가지가 동시에 틀렸다:

1. 다른 프로젝트를 올리면 앞 프로젝트의 두께 규칙을 그대로 물려받는다
2. 화면 배지는 «공통»이라고 말하는데 근거는 프로젝트 합의값이다

이 모듈은 프로젝트 규칙을 **자기 번호(101~199)를 가진 별도 검증항목**으로 만든다.

## 번호는 «뜻»에 붙는다

안정 식별자는 `key`(사람이 정하는 slug)이고, 번호는 거기 붙는 부산물이다.

    같은 key   -> 어느 프로파일에서든 같은 번호 (검토 기록이 이어져야 하니까)
    다른 key   -> 새 번호
    지운 규칙  -> retired 로 남기고 **재발급하지 않는다**

할당대장을 **프로파일 밖**(`project_rules.json` 최상위)에 두는 이유: 한 서버에
프로파일이 둘 이상 있어도 검토 기록(`flag_feedback.json`)과 결과 DB는 공유된다.
프로파일마다 101을 자유롭게 쓰면 «101»이 두 뜻을 갖고, 그건 번호 재사용 사고와
정확히 같다 — 검토 기록 키가 `도면번호|Joint No|WPS No|Check No`이기 때문이다.

## 선점은 «위반»이 아니라 «일치»에서 일어난다

    when이 이 side에 맞는가?
     ├─ 예   -> 그 side는 이 규칙이 판정한다 (통과=무플래그 / 위반=Flag(101))
     │           공통 Check 3은 이 side에서만 침묵
     └─ 아니오 -> 공통 Check 3이 지금 그대로 판정

위반일 때만 선점하면, 프로젝트 범위 «안»인 행이 G열 판정으로 흘러가 **없던
Check 3이 새로 생긴다.** 그래서 통과도 이 규칙의 판정이다.

## kind는 화이트리스트다

데이터는 «어느 판정기를, 어떤 값으로, 어디에 걸 것인가»만 정한다. 새로운 판정
논리는 여전히 코드 + 테스트 + 새 `kind`가 필요하다 — `routers/rules.py`가 이미
세운 «서버가 자연어를 판정 코드로 바꾸지 않는다» 선과 같다.

## 색은 기존 16색 중에서만

`_FILLS` · `_PRIORITY` · `excel_report._CHECK_COLOR` · `style.css` · `COLOR_TO_CLS`가
전부 **색 이름으로** 키가 잡혀 있다. 기존 색으로 강제하면 이 다섯 곳을 손대지
않아도 된다. 없는 색을 회색으로 떨어뜨리지 않고 **거부**하는 이유: 조용히
무색으로 나가면 Excel을 받는 사람이 그 항목만 못 본다.
"""

from __future__ import annotations

import logging
import re
from datetime import date
from typing import Any

logger = logging.getLogger(__name__)

# ── 판정 항목 식별자 ────────────────────────────────────────────────────────
#
#     공통      "1" · "3" · "27"        지금 그대로. 검토 기록 키가 안 바뀐다
#     프로젝트  "RUYA1" · "TRION1"      프로젝트 이름 + 순번
#
# 예전에는 프로젝트도 번호(101~199)였는데 **어느 프로젝트 것인지 화면에서 알 수
# 없었다.** 게다가 번호가 «데이터 폴더별»로 매겨져 TRION의 101과 RUYA의 101이
# 서로 다른 뜻이었다 — 두 리포트를 나란히 놓으면 같은 번호가 다른 것을 가리켰다.
#
# 공통을 건드리지 않은 이유: 검토 기록 키가 `도면번호|Joint No|WPS No|Check No`라
# 공통 번호를 바꾸면 **1,570건이 전부 고아가 된다.** 정본 문서·에이전트 정의·과거
# 리포트의 「Check 14」 표기도 모두 낡는다.
ID_MAX_SEQ = 99          # 한 프로젝트가 가질 수 있는 규칙 수

# 옛 번호 대역. 이미 발급된 101~199를 «프로젝트 항목»으로 알아보는 데만 쓴다.
LEGACY_ID_MIN, LEGACY_ID_MAX = 101, 199


def is_common(check_id: str) -> bool:
    """공통 항목인가. 숫자면 공통이다."""
    cid = str(check_id).strip()
    if not cid.isdigit():
        return False
    # 옛 프로젝트 번호(101~199)는 숫자지만 공통이 아니다
    return not (LEGACY_ID_MIN <= int(cid) <= LEGACY_ID_MAX)


def sort_key(check_id: str) -> tuple[int, str, int]:
    """공통을 숫자순으로 먼저, 그다음 프로젝트를 **이름으로 묶어** 순번순.

    `sorted(..., key=int)`로 정렬하던 자리가 여럿이었다 — 프로젝트 식별자가
    문자열이 되면 **거기서 ValueError로 죽는다.** 전부 이걸로 바꾼다.
    """
    cid = str(check_id).strip()
    if is_common(cid):
        return (0, "", int(cid))
    m = re.match(r"^(.*?)(\d+)$", cid)
    # 이름이 먼저다 — 순번을 앞에 두면 `TRION1`이 `RUYA2` 앞으로 와서
    # 프로젝트별로 묶이지 않는다.
    return (1, (m.group(1) if m else cid).upper(), int(m.group(2)) if m else 0)


def label(check_id: str) -> str:
    """화면·리포트에 쓰는 표기. `RUYA1` -> `RUYA 1`, `3` -> `3`."""
    cid = str(check_id).strip()
    if cid.isdigit():
        return cid
    m = re.match(r"^(.*?)(\d+)$", cid)
    return f"{m.group(1)} {m.group(2)}" if m else cid


def make_id(profile: str, seq: int) -> str:
    """프로젝트 식별자. 공백·특수문자를 지운 프로파일 이름 + 순번."""
    stem = re.sub(r"[^0-9A-Za-z가-힣]+", "", profile or "").upper()
    if not stem:
        stem = "PROJ"
    if stem[0].isdigit():
        stem = "P" + stem        # 숫자로 시작하면 공통과 구분되지 않는다
    return f"{stem}{seq}"

# 코드가 아는 판정기. 여기 없는 kind는 로드에서 거부한다.
#
#   thickness_range  대상 side의 두께가 범위 안인가        (side 단위 · 공통 3 선점)
#   forbid           대상이면 그 자체로 위반                (행 단위)
#   require_wps      대상이면 WPS에 이 조각이 있어야 한다   (행 단위)
#
# **side 단위와 행 단위는 평가 지점이 다르다.** `thickness_range`는 `_c3_side()`가
# 공통 Check 3을 선점하며 부르고, 나머지 둘은 `_check_row()`가 따로 부른다.
# 행 단위 규칙은 공통 Check를 선점하지 않는다 — 대체할 상대가 없기 때문이다.
KINDS = ("thickness_range", "forbid", "require_wps")

# 행 단위로 평가하는 kind. `thickness_range`만 side 단위다.
ROW_KINDS = ("forbid", "require_wps")

_KEY_RE = re.compile(r"^[a-z0-9][a-z0-9\-]{0,48}$")


class RuleError(ValueError):
    """규칙 정의가 성립하지 않는다. 거부하고 경고를 남긴다."""


# ─── 규칙 하나 ───────────────────────────────────────────────────────────────
class Rule:
    __slots__ = ("key", "no", "name", "color", "kind", "when", "param",
                 "overrides", "scope", "cols", "summary", "logic")

    def __init__(self, d: dict[str, Any]) -> None:
        self.key = str(d.get("key", "")).strip()
        # 식별자는 **문자열**이다. 옛 정수 번호(101~199)도 그대로 받아 문자열로 둔다.
        self.no = str(d.get("no") or "").strip()
        self.name = str(d.get("name", "")).strip()
        self.color = str(d.get("color", "")).strip()
        self.kind = str(d.get("kind", "")).strip()
        self.when = dict(d.get("when") or {})
        self.param = dict(d.get("param") or {})
        # 식별자는 전부 문자열이다. 여기만 int로 두면 억제 카운터의 키가
        # `("RUYA1", 3)`이 되어 `_rule_on("3")`·`stats["3"]`과 짝이 안 맞는다.
        self.overrides = [str(x).strip() for x in (d.get("overrides") or [])]
        self.scope = str(d.get("scope") or "side")
        self.cols = str(d.get("cols") or "")
        self.summary = str(d.get("summary") or "")
        self.logic = str(d.get("logic") or "")

    def as_dict(self) -> dict[str, Any]:
        return {k: getattr(self, k) for k in self.__slots__}

    # ── 대상 판별 ────────────────────────────────────────────────────────────
    def matches(self, material: str, wps_no: str) -> bool:
        """이 side가 이 규칙의 대상인가.

        `material`은 **원문 표기**(M/N열 그대로)를 받는다. 표준 재질 키가 아니다 —
        `S355KT-40`처럼 등급이 재질명 안에 붙어 오기 때문이다. 대문자화하고 공백만
        지운 뒤 부분일치로 본다.
        """
        mats = [t for t in self.when.get("material_contains", []) if t]
        wpss = [t for t in self.when.get("wps_contains", []) if t]
        if not mats and not wpss:
            return False        # 조건이 없으면 «전부»가 아니라 «아무것도»다
        if mats and not _contains_any(material, mats):
            return False
        if wpss and not _contains_any(wps_no, wpss):
            return False
        return True

    def matches_row(self, materials: list[str], wps_no: str, ndt_cat: str) -> bool:
        """이 **행**이 대상인가. `forbid` · `require_wps`가 쓴다.

        `matches()`와 셋이 다르다:
          · 재질을 M·N **둘 다** 본다(한쪽만 맞아도 대상)
          · P열 NDT Category 접두사 조건(`ndt_cat_startswith`)을 함께 본다
          · side가 아니라 행 하나에 대해 답한다

        조건은 전부 **AND**다. 하나도 없으면 «전부»가 아니라 «아무것도»다 —
        빈 조건이 전체를 잡으면 규칙 하나가 물량 전체를 결함으로 만든다.
        """
        mats = [t for t in self.when.get("material_contains", []) if t]
        wpss = [t for t in self.when.get("wps_contains", []) if t]
        cats = [t for t in self.when.get("ndt_cat_startswith", []) if t]
        if not mats and not wpss and not cats:
            return False
        if mats and not any(_contains_any(m, mats) for m in materials):
            return False
        if wpss and not _contains_any(wps_no, wpss):
            return False
        if cats and not _starts_with_any(ndt_cat, cats):
            return False
        return True

    # ── 판정 ────────────────────────────────────────────────────────────────
    def judge_thickness(self, thk: float) -> bool:
        """범위 안이면 True. `thickness_range` 전용."""
        from .verifier import _thickness_in_range
        return _thickness_in_range(thk, str(self.param.get("range", "")))

    def judge_row(self, wps_no: str) -> bool:
        """행 단위 판정 — 통과면 True.

        `forbid`      대상이 된 순간 위반이므로 항상 False
        `require_wps` WPS에 `param.wps_must_contain` 중 하나가 있어야 True
        """
        if self.kind == "forbid":
            return False
        if self.kind == "require_wps":
            need = [t for t in (self.param.get("wps_must_contain") or []) if t]
            return _contains_any(wps_no, need) if need else True
        return True

    @property
    def required_wps_text(self) -> str:
        return ", ".join(str(t) for t in (self.param.get("wps_must_contain") or []))

    @property
    def range_text(self) -> str:
        return str(self.param.get("range", ""))


def _contains_any(value: str, tokens: list[str]) -> bool:
    up = (value or "").upper().replace(" ", "")
    if not up:
        return False
    return any(t.upper().replace(" ", "") in up for t in tokens)


def _starts_with_any(value: str, tokens: list[str]) -> bool:
    """P열 NDT Category처럼 «A로 시작하는 것 전부»를 잡는 조건.

    실데이터의 P열은 `A6`·`A5`·`A1`·`C5`·`S4`처럼 문자+숫자다. 정확일치로 받으면
    `A`가 아무것도 못 잡는다 — 현업이 «A와 B로 시작하는 것 모두»라고 확인해 줬다.
    """
    up = (value or "").upper().replace(" ", "")
    if not up:
        return False
    return any(up.startswith(t.upper().replace(" ", "")) for t in tokens)


# ─── 로드 · 검증 ─────────────────────────────────────────────────────────────
def parse(raw: list[dict[str, Any]] | None,
          strict: bool = False) -> tuple[list[Rule], list[str]]:
    """규칙 목록을 읽고 (성립하는 것, 거부 사유)를 돌려준다.

    **깨진 규칙 하나가 검증 전체를 멈추게 하지 않는다** — 그 규칙만 빼고 경고를
    남긴다(`wps_rules.load()`와 같은 방침). 다만 조용히 넘어가지는 않는다:
    거부 사유가 `rule_health`를 거쳐 화면까지 올라간다.

    순서를 그대로 지킨다. 지금의 `material_thickness`가 «위에서부터 먼저 맞는 것,
    좁은 것을 앞에»로 동작하는데, 그 성질을 승계해야 `S355KT-40`이 'KT'보다
    'KT-40'에 먼저 걸린다.
    """
    from .verifier import _FILLS

    out: list[Rule] = []
    problems: list[str] = []
    seen_keys: set[str] = set()
    seen_nos: set[int] = set()

    for i, d in enumerate(raw or []):
        try:
            r = Rule(d)
            if not _KEY_RE.match(r.key):
                raise RuleError(f"key가 규칙에 맞지 않는다(소문자·숫자·하이픈): {r.key!r}")
            if r.key in seen_keys:
                raise RuleError(f"key가 중복된다: {r.key}")
            if not r.no:
                raise RuleError("식별자가 없다")
            if is_common(r.no):
                raise RuleError(
                    f"'{r.no}'는 공통 번호다 — 프로젝트 규칙은 이름+순번이어야 한다"
                    f"(예: {make_id('RUYA', 1)})")
            if r.no in seen_nos:
                raise RuleError(f"식별자가 중복된다: {r.no}")
            if r.kind not in KINDS:
                raise RuleError(f"모르는 kind: {r.kind!r} (있는 것: {', '.join(KINDS)})")
            if r.color not in _FILLS:
                raise RuleError(f"색 '{r.color}'은 쓸 수 없다 "
                                f"(있는 것: {', '.join(sorted(_FILLS))})")
            if not r.name:
                raise RuleError("이름이 비어 있다")
            if r.kind == "thickness_range" and not r.range_text:
                raise RuleError("thickness_range인데 param.range가 없다")
            if not r.when.get("material_contains") and not r.when.get("wps_contains"):
                raise RuleError("when에 대상 조건이 없다 — 이 규칙은 아무 행에도 걸리지 않는다")
            seen_keys.add(r.key)
            seen_nos.add(r.no)
            out.append(r)
        except (RuleError, ValueError, TypeError) as exc:
            msg = f"프로젝트 규칙 #{i + 1}({d.get('key') or d.get('name') or '이름 없음'}) 거부: {exc}"
            problems.append(msg)
            logger.warning("%s", msg)
            if strict:
                raise

    return out, problems


# ─── 번호 할당대장 ───────────────────────────────────────────────────────────
def assign_id(ledger: dict[str, Any], key: str, name: str,
              profile: str) -> tuple[str, bool]:
    """`key`에 붙은 식별자를 돌려준다. 없으면 새로 발급.

    돌려주는 두 번째 값은 «새로 발급했는가». 호출부가 대장을 저장해야 한다.

    **반납이 없다.** 규칙을 지워도 식별자는 `retired`로 남고 재발급되지 않는다 —
    검토 기록이 그 식별자로 남아 있기 때문이다(`…|Check No`).

    순번은 **그 프로파일 안에서** 센다. 프로젝트 이름이 앞에 붙으므로 서버가
    달라도 겹치지 않는다 — 예전 번호(101~199)는 데이터 폴더별로 매겨져
    TRION의 101과 RUYA의 101이 서로 다른 뜻이었다.
    """
    for cid, meta in ledger.items():
        if meta.get("key") == key:
            return str(cid), False

    stem = make_id(profile, 0)[:-1]          # 순번을 뗀 앞부분
    used = set()
    for cid in ledger:
        c = str(cid)
        if c.upper().startswith(stem) and c[len(stem):].isdigit():
            used.add(int(c[len(stem):]))
    for seq in range(1, ID_MAX_SEQ + 1):
        if seq in used:
            continue
        cid = f"{stem}{seq}"
        ledger[cid] = {
            "key": key, "name": name,
            "first_seen": date.today().isoformat(),
            "born_in": profile, "retired": False,
        }
        return cid, True
    raise RuleError(f"'{profile}' 규칙 식별자가 바닥났다 (1~{ID_MAX_SEQ})")


def retire_missing(ledger: dict[str, Any], live_keys: set[str]) -> list[str]:
    """대장에는 있는데 지금 프로파일에 없는 규칙을 `retired`로 표시한다.

    지우지 않는다. 번호가 사라지면 다음 발급이 그 번호를 재사용하고, 그러면
    과거 검토 의견이 무관한 항목에 붙는다.
    """
    changed: list[str] = []
    for no, meta in ledger.items():
        want = meta.get("key") not in live_keys
        if bool(meta.get("retired")) != want:
            meta["retired"] = want
            # `int(no)`였다. 식별자가 `RUYA1`이 되면 여기서 ValueError로 죽는데,
            # 규칙을 지우는 순간에만 터져서 «삭제가 안 된다»로만 보인다.
            changed.append(str(no))
    return changed


# ─── 판정 표면 — verifier가 쓰는 것은 이 둘뿐 ────────────────────────────────
def claim_thickness(rules: list[Rule], material: str,
                    wps_no: str) -> Rule | None:
    """이 side를 선점하는 두께 규칙. 없으면 None(= 공통 Check 3이 판정한다).

    목록 **위에서부터 먼저 맞는 것**을 쓴다. 좁은 조건을 앞에 두어야
    `S355KT-40`이 'KT'가 아니라 'KT-40'에 걸린다.
    """
    for r in rules:
        if r.kind == "thickness_range" and r.matches(material, wps_no):
            return r
    return None


def row_rules(rules: list[Rule], materials: list[str], wps_no: str,
              ndt_cat: str) -> list[Rule]:
    """이 **행**에 걸리는 행 단위 규칙 전부.

    두께 규칙과 달리 «먼저 맞는 하나»가 아니라 **전부**를 돌려준다. 서로 다른
    금지 조건이 한 행에 겹칠 수 있고(예: G05 + NDT Cat A + S420 자재), 하나만
    보고하면 나머지를 고쳐도 계속 걸리는 것처럼 보인다.
    """
    return [r for r in rules
            if r.kind in ROW_KINDS and r.matches_row(materials, wps_no, ndt_cat)]


def health(rules: list[Rule], matched: dict[int, int],
           problems: list[str]) -> list[dict[str, Any]]:
    """규칙이 살아 있는지. **0행에 걸리는 것은 «문제 없음»이 아니라 경고다.**

    실제로 F03·G05·S355KT 계열이 지금 물량에서 정확히 0행인데, 그게 «규칙이
    맞다»인지 «표기가 안 맞아 죽어 있다»인지 구분할 방법이 없었다.
    `wps_rules.check_rules_alive()`가 WPS에 대해 하는 일을 규칙에 대해 한다.
    """
    out: list[dict[str, Any]] = []
    for p in problems:
        out.append({"level": "rejected", "msg": p})
    for r in rules:
        n = matched.get(r.no, 0)
        if n == 0:
            out.append({
                "level": "unmatched", "check_no": r.no, "key": r.key,
                "msg": f"프로젝트 규칙 {label(r.no)}({r.name})이 0행에 걸렸다 "
                       f"— 재질/WPS 표기가 실데이터와 다를 수 있다",
            })
    for h in out:
        logger.warning("프로젝트 규칙 점검: %s", h["msg"])
    return out
