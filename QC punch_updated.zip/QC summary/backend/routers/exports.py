"""
범위별 결과 Excel 내보내기 — 생성 요청 / 상태 조회 / 내려받기.

## 왜 백그라운드인가

원본 시트를 범위에 맞게 줄이는 비용이 범위마다 크게 다르다. 실측(10,034행 기준):

    건조5부 (117행 유지, 연속구간  5개):  약  7초
    Q520    (4,430행 유지, 연속구간 79개): 약 61초

큰 부서를 요청 시점에 만들면 사용자가 1분을 기다린다. 그래서 생성은 스레드로 돌리고
화면은 상태를 폴링한다 — 검증 실행과 같은 패턴이다.

## 재검증하면 기존 산출물은 버린다

검증 결과가 바뀌면 이전에 만든 범위 파일은 전부 낡은 것이 된다. 파일이 남아 있다는
이유로 옛 결과를 내려주면 '조용히 틀린 산출물'이 되므로, 새 검증이 끝나면
`invalidate()`로 통째로 버린다.
"""

from __future__ import annotations

import logging
import shutil
import threading
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Header, HTTPException, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel

from backend import config
from backend.routers.auth import require_login
from backend.routers.verify import get_last_result, get_qmg_path
from backend.services import excel_report, result_store
from backend.services import feedback_store
from backend.services.verifier import _PRIORITY

logger = logging.getLogger(__name__)
router = APIRouter()

_lock = threading.Lock()

# key -> {"status": idle|building|ready|error, "info": {...}, "error": str, "run_at": str}
_exports: dict[str, dict[str, Any]] = {}


def _key(dept: str | None, team: str | None, exclude_temp: bool = False) -> str:
    """캐시 키. **임시부재 제외 여부가 반드시 들어간다.**

    같은 부서인데 내용이 다른 두 파일이 존재하므로, 키가 같으면 «1C를 뺀 줄 알고
    받았는데 들어 있는» 파일이 나간다. 받은 사람이 열어 보기 전에는 알 수 없다.
    """
    return (f"{(dept or '').strip()}||{(team or '').strip()}"
            f"||{'notemp' if exclude_temp else 'all'}")


def _path_for(scope: excel_report.Scope) -> Path:
    return config.EXPORTS_DIR / f"QC_Result_{scope.slug()}.xlsx"


def _adopt_from_disk(scope: excel_report.Scope, key: str, run_at: str) -> dict | None:
    """서버를 재시작하면 메모리 상태가 비지만 파일은 디스크에 남아 있다.

    그 파일이 현재 검증 결과의 산출물이면 다시 만들 이유가 없다(큰 부서는 1분씩 걸린다).
    판단 기준은 검증 결과가 저장된 시각보다 새것인지다 - 결과 Excel 복원에 쓰는 것과
    같은 기준이라, 낡은 파일을 ready로 착각하지 않는다.

    예전에는 `app_state.json`의 파일 mtime을 그 시각으로 썼다. 저장소가 SQLite가 된
    뒤로는 그 대용이 성립하지 않는다 - **업로드 파일명만 바뀌어도 DB 파일의 mtime이
    움직여서**, 검증은 그대로인데 멀쩡한 파일이 통째로 낡은 것으로 판정된다.
    그래서 회차에 기록된 저장 시각(`run.saved_at`)을 직접 쓴다.
    """
    path = _path_for(scope)
    if not path.exists():
        return None
    saved_at = result_store.latest_saved_at()
    if saved_at is None:
        return None
    try:
        if path.stat().st_mtime < saved_at:
            return None
    except OSError:
        return None
    st = {
        "status": "ready",
        "info": {"scope": scope.label, "path": str(path), "size": path.stat().st_size},
        "error": None,
        "run_at": run_at,
        "message": "이전에 생성된 파일",
    }
    _exports[key] = st
    return st


def invalidate() -> None:
    """검증 결과가 바뀌었을 때 호출 — 만들어둔 범위 파일을 전부 버린다."""
    with _lock:
        _exports.clear()
    try:
        if config.EXPORTS_DIR.is_dir():
            shutil.rmtree(config.EXPORTS_DIR)
        config.EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
        logger.info("범위별 내보내기 캐시 비움")
    except OSError:
        logger.exception("내보내기 캐시 삭제 실패")


def _build(scope: excel_report.Scope, key: str, run_at: str) -> None:
    """스레드에서 도는 실제 생성 작업."""
    def progress(msg: str) -> None:
        with _lock:
            st = _exports.get(key)
            if st:
                st["message"] = msg

    try:
        result = get_last_result()
        qmg = get_qmg_path()
        if result is None or qmg is None or not qmg.exists():
            raise RuntimeError("검증 결과 또는 원본 파일이 없습니다")

        info = excel_report.build_report(
            qmg, result, _path_for(scope),
            dept=scope.dept, team=scope.team, exclude_temp=scope.exclude_temp,
            feedback=feedback_store.load_feedback(),
            priority=_PRIORITY,
            progress=progress,
        )
        with _lock:
            _exports[key] = {"status": "ready", "info": info, "error": None,
                             "run_at": run_at, "message": "완료"}
    except Exception as exc:
        logger.exception("범위 Excel 생성 실패: %s", scope.label)
        with _lock:
            _exports[key] = {"status": "error", "info": None, "error": str(exc),
                             "run_at": run_at, "message": f"오류: {exc}"}


def ensure_built(dept: str | None, team: str | None, wait: bool = False,
                 exclude_temp: bool = False) -> dict:
    """생성돼 있지 않으면 시작한다. wait=True면 끝날 때까지 기다린다(메일 첨부용)."""
    result = get_last_result()
    if result is None:
        raise HTTPException(404, "검증 결과가 없습니다. 먼저 검증을 실행하세요")

    scope = excel_report.Scope(dept, team, exclude_temp)
    key = _key(dept, team, exclude_temp)
    run_at = result.get("run_at", "")

    with _lock:
        st = _exports.get(key)
        # 다른 검증 결과로 만든 것은 낡은 것이다
        if st and st.get("run_at") != run_at:
            st = None
            _exports.pop(key, None)
        if st is None:
            st = _adopt_from_disk(scope, key, run_at)
        if st and st["status"] in ("ready", "building"):
            if st["status"] == "ready" and not _path_for(scope).exists():
                _exports.pop(key, None)   # 파일이 사라졌으면 다시 만든다
            else:
                return dict(st, key=key, scope=scope.label)
        _exports[key] = {"status": "building", "info": None, "error": None,
                         "run_at": run_at, "message": "대기 중"}

    t = threading.Thread(target=_build, args=(scope, key, run_at), daemon=True)
    t.start()
    if wait:
        t.join()
    with _lock:
        return dict(_exports[key], key=key, scope=scope.label)


# ─── 엔드포인트 ───────────────────────────────────────────────────────────────
class BuildIn(BaseModel):
    dept: str | None = None
    team: str | None = None
    exclude_temp: bool = False


@router.get("/exports")
def list_exports(exclude_temp: bool = Query(False),
                 x_employee_id: str | None = Header(None)) -> dict:
    """선택 가능한 범위 목록 + 각각의 생성 상태.

    `exclude_temp`가 켜지면 **표에 적히는 건수도 그 기준으로 바뀐다.** 안 바꾸면
    「1C 제외로 받겠다」고 해놓고 표에는 전체 건수가 적혀 있어, 받은 파일과
    화면이 어긋난다. 31개 범위를 한 번의 질의로 센다.
    """
    require_login(x_employee_id)
    result = get_last_result()
    if result is None:
        return {"has_result": False, "scopes": []}

    # 임시부재를 뺀 건수는 flag에서 세지만, **분모(판정 대상)는 flag에서 셀 수 없다**
    # — 깨끗한 행은 flag에 없기 때문이다. 판정 때 세어 둔 `temp_rows`를 뺀다.
    defect_by_scope = (result_store.scope_defect_rows(exclude_temp=True)
                       if exclude_temp else None)
    scopes: list[dict[str, Any]] = []

    def add(dept: str | None, team: str | None, label: str,
            judged: int, defects: int, temp: int, kind: str) -> None:
        if exclude_temp:
            judged = max(judged - temp, 0)
            defects = defect_by_scope.get((dept or "", team or ""), 0)
        key = _key(dept, team, exclude_temp)
        st = _exports.get(key) or {}
        if st.get("run_at") and st["run_at"] != result.get("run_at"):
            st = {}
        if not st:
            st = _adopt_from_disk(excel_report.Scope(dept, team, exclude_temp), key,
                                  result.get("run_at", "")) or {}
        scopes.append({
            "kind": kind, "dept": dept, "team": team, "label": label,
            "judged_rows": judged, "defect_rows": defects,
            "status": st.get("status", "idle"),
            "message": st.get("message", ""),
            "info": st.get("info"),
            "error": st.get("error"),
        })

    add(None, None, "전체", result.get("judged_rows", 0),
        result.get("flagged_rows", 0), result.get("temp_judged_rows", 0), "all")
    for name, d in sorted((result.get("departments") or {}).items(),
                          key=lambda x: -x[1].get("defect_rows", 0)):
        add(name, None, name, d.get("total_rows", 0), d.get("defect_rows", 0),
            d.get("temp_rows", 0), "dept")
        for tname, t in sorted((d.get("teams") or {}).items(),
                               key=lambda x: -x[1].get("defect_rows", 0)):
            add(name, tname, f"{name} > {tname}",
                t.get("total_rows", 0), t.get("defect_rows", 0),
                t.get("temp_rows", 0), "team")

    return {"has_result": True, "run_at": result.get("run_at", ""),
            "exclude_temp": exclude_temp, "scopes": scopes}


@router.post("/exports/build")
def build_export(body: BuildIn, x_employee_id: str | None = Header(None)) -> dict:
    require_login(x_employee_id)
    return ensure_built(body.dept, body.team, exclude_temp=body.exclude_temp)


@router.get("/exports/download")
def download_export(
    dept: str | None = Query(None),
    team: str | None = Query(None),
    exclude_temp: bool = Query(False),
    x_employee_id: str | None = Header(None),
) -> FileResponse:
    require_login(x_employee_id)
    scope = excel_report.Scope(dept, team, exclude_temp)
    key = _key(dept, team, exclude_temp)

    with _lock:
        st = _exports.get(key) or {}
    if st.get("status") == "building":
        raise HTTPException(409, "파일을 생성 중입니다. 잠시 후 다시 시도하세요")
    if st.get("status") == "error":
        raise HTTPException(500, f"생성 실패: {st.get('error')}")

    path = _path_for(scope)
    if not path.exists():
        raise HTTPException(404, "아직 생성되지 않았습니다. 먼저 생성을 요청하세요")

    return FileResponse(
        str(path),
        filename=path.name,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        # 인증이 브라우저 캐시로 우회되지 않게 한다 (/api/result/excel과 같은 이유)
        headers={"Cache-Control": "no-store, no-cache, must-revalidate"},
    )
