"""
플래그 검토 피드백(Human-in-the-loop) 라우터.
로그인한 사번이면 누구나 남길 수 있다(관리자 전용 아님 — 로그인 자체가 이미
employees.json으로 관리자가 통제하는 대상이므로 여기서 별도 권한 제한을 두지 않는다).
"""
import logging
from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel
from typing import Any

from backend.routers.auth import load_employees
from backend.services import feedback_store

logger = logging.getLogger(__name__)
router = APIRouter()


class FeedbackRequest(BaseModel):
    # 도면번호가 있어야 조인트가 유일하게 식별된다 (Joint No는 도면 내에서만 유일).
    drawing_no: str = ""
    joint_no: str
    wps_no: str = ""
    check_no: int | str
    result: str
    remark: str = ""
    flag_snapshot: dict[str, Any] | None = None
    row_raw: list[dict] | None = None


def _require_login(x_employee_id: str | None) -> str:
    emp_id = (x_employee_id or "").strip().upper()
    if not emp_id:
        raise HTTPException(401, "로그인이 필요합니다")
    if not any(e["id"] == emp_id for e in load_employees()):
        raise HTTPException(401, "등록되지 않은 사번입니다")
    return emp_id


@router.get("/feedback")
def get_feedback(x_employee_id: str | None = Header(None)) -> dict:
    _require_login(x_employee_id)
    return {"feedback": feedback_store.load_feedback()}


@router.post("/feedback")
def submit_feedback(req: FeedbackRequest, x_employee_id: str | None = Header(None)) -> dict:
    emp_id = _require_login(x_employee_id)
    if not req.joint_no:
        raise HTTPException(400, "joint_no가 필요합니다")
    if req.result not in feedback_store.RESULT_CHOICES:
        raise HTTPException(
            400, f"result는 {feedback_store.RESULT_CHOICES} 중 하나여야 합니다"
        )
    record = feedback_store.upsert_feedback(
        drawing_no=req.drawing_no,
        joint_no=req.joint_no,
        wps_no=req.wps_no,
        check_no=req.check_no,
        result=req.result,
        remark=req.remark,
        reviewer_id=emp_id,
        flag_snapshot=req.flag_snapshot,
        row_raw=req.row_raw,
    )
    logger.info("피드백 저장: %s / %s Check%d = %s (by %s)",
               req.drawing_no, req.joint_no, req.check_no, req.result, emp_id)
    return {"ok": True, "record": record}
