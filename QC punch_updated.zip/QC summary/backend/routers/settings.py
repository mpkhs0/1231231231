"""
관리자 설정 라우터 — 사번(관리자) 관리 + Outlook 자동 발송 설정 + 부서별 결함 리포트 발송
모든 엔드포인트는 요청자가 관리자(admin=true)인 사번이어야 접근 가능.
요청자 사번은 X-Employee-Id 헤더로 전달받는다 (localStorage에 저장된 로그인 사번).
"""
import json
import logging
import threading
from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

from backend import config
from backend.services import result_store
from backend.routers.auth import load_employees, is_admin, update_employees
from backend.routers.verify import get_last_result
from backend.services import project_checks
from backend.services.verifier import check_name as verifier_check_name

logger = logging.getLogger(__name__)
router = APIRouter()
_lock = threading.Lock()

try:
    import win32com.client
    import pythoncom
    _OUTLOOK_AVAILABLE = True
except ImportError:
    _OUTLOOK_AVAILABLE = False
    logger.warning("pywin32 미설치 — Outlook 발송 기능 비활성화")


def _require_admin(x_employee_id: str | None) -> str:
    emp_id = (x_employee_id or "").strip().upper()
    if not emp_id:
        raise HTTPException(401, "로그인이 필요합니다")
    if not is_admin(emp_id):
        raise HTTPException(403, "관리자 권한이 필요합니다")
    return emp_id


# ─── 사번(관리자) 관리 ────────────────────────────────────────────────────────
@router.get("/settings/employees")
def list_employees(x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    return {"employees": load_employees()}


class EmployeeIn(BaseModel):
    id: str
    admin: bool = False


@router.post("/settings/employees")
def add_employee(body: EmployeeIn, x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    new_id = body.id.strip().upper()
    if not new_id:
        raise HTTPException(400, "사번을 입력하세요")

    error: dict | None = None
    def _mutate(employees: list[dict]) -> list[dict]:
        nonlocal error
        if any(e["id"] == new_id for e in employees):
            error = {"status": 409, "detail": f"사번 '{new_id}'는 이미 등록되어 있습니다"}
            return employees
        employees.append({"id": new_id, "admin": body.admin})
        return employees

    # 읽기→수정→저장을 하나의 락으로 묶어 두 관리자의 동시 요청이 서로
    # 덮어쓰지 않도록 한다(update_employees, backend/routers/auth.py).
    employees = update_employees(_mutate)
    if error:
        raise HTTPException(error["status"], error["detail"])
    logger.info("사번 등록: %s (admin=%s)", new_id, body.admin)
    return {"ok": True, "employees": employees}


@router.delete("/settings/employees/{emp_id}")
def delete_employee(emp_id: str, x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    target = emp_id.strip().upper()

    error: dict | None = None
    def _mutate(employees: list[dict]) -> list[dict]:
        nonlocal error
        match = next((e for e in employees if e["id"] == target), None)
        if match is None:
            error = {"status": 404, "detail": f"사번 '{target}'를 찾을 수 없습니다"}
            return employees
        remaining_admins = [e for e in employees if e["admin"] and e["id"] != target]
        if match["admin"] and not remaining_admins:
            error = {"status": 400, "detail": "마지막 관리자는 삭제할 수 없습니다"}
            return employees
        return [e for e in employees if e["id"] != target]

    employees = update_employees(_mutate)
    if error:
        raise HTTPException(error["status"], error["detail"])
    logger.info("사번 삭제: %s", target)
    return {"ok": True, "employees": employees}


# ─── Outlook 자동 발송 설정 (설정값 저장만 — 실제 발송 로직은 추후 별도 구현) ──────
class OutlookSettingsIn(BaseModel):
    enabled: bool = False
    recipients: list[str] = []


def _load_outlook_settings() -> dict:
    if config.OUTLOOK_SETTINGS.exists():
        try:
            return json.loads(config.OUTLOOK_SETTINGS.read_text(encoding="utf-8"))
        except Exception:
            return {"enabled": False, "recipients": []}
    return {"enabled": False, "recipients": []}


@router.get("/settings/outlook")
def get_outlook_settings(x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    return _load_outlook_settings()


@router.post("/settings/outlook")
def save_outlook_settings(body: OutlookSettingsIn,
                          x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    recipients = [r.strip() for r in body.recipients if r.strip()]
    data = {"enabled": body.enabled, "recipients": recipients}
    with _lock:
        config.OUTLOOK_SETTINGS.parent.mkdir(parents=True, exist_ok=True)
        config.OUTLOOK_SETTINGS.write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    logger.info("Outlook 설정 저장: enabled=%s, 수신인 %d명", body.enabled, len(recipients))
    return {"ok": True, **data}


# ─── 부서별 결함 리포트 — 수신인 관리 + Outlook 발송 ────────────────────────────
def _load_dept_recipients() -> dict[str, list[str]]:
    if config.DEPT_RECIPIENTS_FILE.exists():
        try:
            return json.loads(config.DEPT_RECIPIENTS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _update_dept_recipients(dept: str, recipients: list[str]) -> None:
    """읽기→수정→저장을 락 하나로 묶어 두 관리자의 동시 저장이 서로
    덮어쓰지 않도록 한다(기존에는 _load_dept_recipients()/_save_dept_recipients()를
    따로 호출해서 lost-update가 가능했다)."""
    with _lock:
        data: dict[str, list[str]] = {}
        if config.DEPT_RECIPIENTS_FILE.exists():
            try:
                data = json.loads(config.DEPT_RECIPIENTS_FILE.read_text(encoding="utf-8"))
            except Exception:
                data = {}
        data[dept] = recipients
        config.DEPT_RECIPIENTS_FILE.parent.mkdir(parents=True, exist_ok=True)
        config.DEPT_RECIPIENTS_FILE.write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )


@router.get("/settings/dept-recipients")
def get_dept_recipients(x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    return _load_dept_recipients()


class DeptRecipientsIn(BaseModel):
    department: str
    recipients: list[str] = []


@router.post("/settings/dept-recipients")
def save_dept_recipients_endpoint(body: DeptRecipientsIn,
                                  x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    dept = body.department.strip()
    if not dept:
        raise HTTPException(400, "부서명이 필요합니다")
    recipients = [r.strip() for r in body.recipients if r.strip()]
    _update_dept_recipients(dept, recipients)
    logger.info("부서 수신인 저장: %s (%d명)", dept, len(recipients))
    return {"ok": True, "department": dept, "recipients": recipients}


# ─── 팀별 수신인 ──────────────────────────────────────────────────────────────
#
# 부서 아래에 중첩해 둔다: `{부서: {팀: [메일주소]}}`.
# 팀 이름만으로 키를 잡지 않는 이유는 `config.TEAM_RECIPIENTS_FILE` 주석에 있다.
def _load_team_recipients() -> dict[str, dict[str, list[str]]]:
    if config.TEAM_RECIPIENTS_FILE.exists():
        try:
            data = json.loads(config.TEAM_RECIPIENTS_FILE.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception:
            logger.exception("팀 수신인 파일을 읽지 못했다")
            return {}
    return {}


def _update_team_recipients(dept: str, team: str, recipients: list[str]) -> None:
    """읽기→수정→저장을 락 하나로 묶는다 (부서 쪽과 같은 이유 — lost update 방지)."""
    with _lock:
        data: dict[str, dict[str, list[str]]] = {}
        if config.TEAM_RECIPIENTS_FILE.exists():
            try:
                loaded = json.loads(config.TEAM_RECIPIENTS_FILE.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    data = loaded
            except Exception:
                data = {}
        bucket = data.setdefault(dept, {})
        if recipients:
            bucket[team] = recipients
        else:
            # 빈 목록은 «삭제»로 본다. 남겨 두면 화면이 «설정됨»으로 읽는다.
            bucket.pop(team, None)
            if not bucket:
                data.pop(dept, None)
        config.TEAM_RECIPIENTS_FILE.parent.mkdir(parents=True, exist_ok=True)
        config.TEAM_RECIPIENTS_FILE.write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )


def _team_recipients_of(dept: str, team: str) -> list[str]:
    return (_load_team_recipients().get(dept) or {}).get(team) or []


@router.get("/settings/team-recipients")
def get_team_recipients(x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    return _load_team_recipients()


class TeamRecipientsIn(BaseModel):
    department: str
    team: str
    recipients: list[str] = []


@router.post("/settings/team-recipients")
def save_team_recipients_endpoint(body: TeamRecipientsIn,
                                  x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    dept = body.department.strip()
    team = body.team.strip()
    if not dept or not team:
        raise HTTPException(400, "부서명과 팀명이 모두 필요합니다")
    recipients = [r.strip() for r in body.recipients if r.strip()]
    _update_team_recipients(dept, team, recipients)
    logger.info("팀 수신인 저장: %s > %s (%d명)", dept, team, len(recipients))
    return {"ok": True, "department": dept, "team": team, "recipients": recipients}


def _td(v) -> str:
    style = "border:1px solid #ccc;padding:4px 8px;text-align:left;font-size:12px"
    return f'<td style="{style}">{v}</td>'


def _build_dept_report_html(department: str, dept_data: dict,
                            defects: list[dict], run_at: str,
                            team: str | None = None,
                            exclude_temp: bool = False,
                            totals: dict | None = None) -> str:
    """부서(또는 팀) 리포트 메일 본문.

    팀 범위도 **같은 함수**로 만든다. 팀 버킷은 부서 버킷과 키 모양이 같고,
    본문이 갈라지면 «부서 메일에 적힌 합»과 «팀 메일들의 합»이 어긋났을 때
    어느 쪽이 틀렸는지 알 수 없게 된다.

    `defects`를 **인자로 받는다** — 예전에는 `dept_data['defects']`를 읽었는데,
    응답 크기 때문에 부서 버킷에서 항목을 빼고 행 번호 목록만 남겼기 때문이다
    (payload의 44%였다). 목록은 `result_store.expand_defects()`가 `flags`에서
    되살린다 — 화면과 **같은 규칙**을 써야 «메일에 적힌 건수»와 «화면에서 본
    건수»가 갈라지지 않는다.
    """
    scope    = f"{department} > {team}" if team else department
    kind     = "팀 실적" if team else "부서 실적"
    if exclude_temp:
        kind += " · 임시부재(1C) 제외"
    # 임시부재를 뺐으면 **분모도 함께 줄여야 한다.** 안 그러면 결함률이 실제보다
    # 낮게 나오고, 받은 사람은 그 숫자를 그대로 믿는다.
    total    = (totals or {}).get('judged', dept_data.get('total_rows', 0))
    unworked = dept_data.get('unworked_rows', 0)   # 미작업 (결함률 분모 아님)
    defect   = (totals or {}).get('defect', dept_data.get('defect_rows', 0))
    rate     = round(defect / total * 100, 1) if total else 0.0
    th_style = "border:1px solid #ccc;padding:4px 8px;text-align:left;font-size:12px;background:#f2f2f2"

    check_rows = "".join(
        "<tr>" + _td(f"Check {project_checks.label(no)}") + _td(verifier_check_name(no)) + _td(cnt) + "</tr>"
        for no, cnt in sorted(dept_data.get('check_stats', {}).items(), key=lambda x: -x[1])
    ) or f'<tr><td colspan="3" style="{th_style}">해당 없음</td></tr>'

    welder_rows = "".join(
        "<tr>" + _td(w['welder_no']) + _td(w['total']) + _td(w['defect']) + _td(f"{w['rate']}%") + "</tr>"
        for w in dept_data.get('welder_defect_rate', [])
    ) or f'<tr><td colspan="4" style="{th_style}">해당 없음</td></tr>'

    defect_rows = "".join(
        "<tr>" + _td(d['row']) + _td(d.get('ndt_report') or '-')
        + _td(d['joint_no']) + _td(d['block']) + _td(d['wps_no'])
        + _td(d['weld_date']) + _td(d['welder1_no'])
        + _td('; '.join(c['check_name'] for c in d['checks']))
        + _td('; '.join(c.get('expected') or c['msg'] for c in d['checks']))
        + _td('; '.join(c.get('actual') or '' for c in d['checks']))
        + "</tr>"
        for d in defects
    ) or f'<tr><td colspan="10" style="{th_style}">해당 없음</td></tr>'

    # 반복 결함 패턴(6번 서브에이전트, recurrence.py) — 해당 부서에 실제로 반복
    # 패턴이 있을 때만 섹션을 추가한다. 없으면 메일에서 아예 빠진다.
    recurring = dept_data.get('recurring_patterns') or []
    recurring_section = ""
    if recurring:
        recurring_rows = "".join(
            "<tr>" + _td(rp['welder_no']) + _td(f"Check {rp['check_no']}")
            + _td(f"{rp['check_name']}<br><span style='color:#666;font-size:11px'>{rp.get('summary', '')}</span>")
            + _td(rp['count']) + _td(rp['distinct_dates']) + _td(f"{rp['first_date']} ~ {rp['last_date']}")
            + "</tr>"
            for rp in recurring
        )
        recurring_section = f"""
      <h4 style="margin-top:16px">반복 결함 패턴 (동일 용접사·Check가 서로 다른 날짜에 반복 발생 — 교육/재발방지 참고용)</h4>
      <table style="border-collapse:collapse;width:100%">
        <tr><th style="{th_style}">용접사</th><th style="{th_style}">Check</th><th style="{th_style}">항목 / 발생 양상</th>
            <th style="{th_style}">발생 건수</th><th style="{th_style}">발생 일수</th><th style="{th_style}">기간</th></tr>
        {recurring_rows}
      </table>
        """

    return f"""
    <div style="font-family:'Malgun Gothic',sans-serif">
      <h3>{scope} 결함 리포트 ({kind})</h3>
      <p>검증 실행: {run_at}</p>
      {'<p style="color:#7030A0">도면번호가 <b>1C</b>로 시작하는 임시부재는 이 리포트에서 제외했습니다.</p>' if exclude_temp else ''}
      <p>판정 대상: {total:,}건 · 결함 발생: {defect:,}건 ({rate}%)
         {f' · 미작업(판정 제외): {unworked:,}건' if unworked else ''}</p>
      <h4>검사 항목별 건수</h4>
      <table style="border-collapse:collapse;width:100%">
        <tr><th style="{th_style}">Check</th><th style="{th_style}">항목</th><th style="{th_style}">건수</th></tr>
        {check_rows}
      </table>
      <h4 style="margin-top:16px">용접사별 결함 발생률 (실제 작업성 결함 기준 · 교육 참고용 — 순위 아님)</h4>
      <table style="border-collapse:collapse;width:100%">
        <tr><th style="{th_style}">용접사</th><th style="{th_style}">검증건수</th>
            <th style="{th_style}">결함건수</th><th style="{th_style}">발생률</th></tr>
        {welder_rows}
      </table>
      <h4 style="margin-top:16px">결함 리스트</h4>
      <table style="border-collapse:collapse;width:100%">
        <tr><th style="{th_style}">행</th>
            <th style="{th_style}">NDT REPORT 번호</th>
            <th style="{th_style}">Joint No</th>
            <th style="{th_style}">블록</th><th style="{th_style}">WPS No</th>
            <th style="{th_style}">용접일</th><th style="{th_style}">용접사</th>
            <th style="{th_style}">Check</th>
            <th style="{th_style}">기준값</th><th style="{th_style}">실제값</th></tr>
        {defect_rows}
      </table>
      {recurring_section}
    </div>
    """


def _dept_excel_path(department: str, team: str | None = None,
                     exclude_temp: bool = False) -> str | None:
    """그 부서(또는 팀) 범위의 결과 Excel을 만들어 경로를 돌려준다. 실패하면 None.

    본문 HTML만 보내면 수신자가 원본 대조를 할 수 없어서 첨부한다.
    생성이 오래 걸릴 수 있으므로(큰 부서 약 1분) 완료까지 기다린다 - 메일 초안이
    첨부 없이 먼저 열리면 사용자가 그대로 보내버리기 때문이다.
    첨부에 실패해도 메일 자체는 보낼 수 있어야 하므로 예외를 밖으로 던지지 않는다.
    """
    try:
        from backend.routers import exports
        st = exports.ensure_built(department, team, wait=True,
                                  exclude_temp=exclude_temp)
        if st.get("status") == "ready" and st.get("info"):
            return st["info"]["path"]
        logger.warning("범위 Excel 생성 실패로 첨부 없이 발송: %s (%s)",
                       st.get("scope") or department, st.get("error"))
    except Exception:
        logger.exception("범위 Excel 첨부 준비 실패: %s / %s", department, team)
    return None


def _dispatch_dept_mail(department: str, dept_data: dict, defects: list[dict],
                        recipients: list[str], run_at: str,
                        team: str | None = None,
                        exclude_temp: bool = False) -> None:
    """부서(또는 팀) 1곳에 대한 Outlook 초안 1통을 연다. 실패 시 예외 발생.

    본문과 첨부는 **같은 기준**이어야 한다. 한쪽만 임시부재를 빼면 「본문 26건,
    첨부 3,245건」처럼 어긋나고, 받은 사람은 어느 쪽이 맞는지 알 수 없다.
    """
    scope     = f"{department} > {team}" if team else department
    totals = None
    if exclude_temp:
        agg = result_store.aggregate_flags(dept=department, team=team,
                                           exclude_temp=True)
        totals = {"judged": agg["flagged_rows"] + agg["clean_rows"],
                  "defect": agg["flagged_rows"]}
    html_body = _build_dept_report_html(department, dept_data, defects, run_at,
                                        team, exclude_temp, totals)
    subject   = (f"[QC Summary] {scope} 결함 리포트"
                 + (" (임시부재 제외)" if exclude_temp else "")
                 + f" - {run_at}")
    attach    = _dept_excel_path(department, team, exclude_temp)

    pythoncom.CoInitialize()
    try:
        outlook = win32com.client.Dispatch("Outlook.Application")
        mail = outlook.CreateItem(0)  # olMailItem
        mail.To = "; ".join(recipients)
        mail.Subject = subject
        mail.HTMLBody = html_body
        if attach:
            mail.Attachments.Add(attach)
        mail.Display()
    finally:
        pythoncom.CoUninitialize()


@router.post("/departments/send")
def send_department_report(department: str, exclude_temp: bool = False,
                           x_employee_id: str | None = Header(None)) -> dict:
    """
    부서별 결함 리포트를 Outlook 초안으로 연다 (mail.Display()).
    사용자가 Outlook에서 직접 확인 후 '보내기'를 눌러야 실제 발송된다.
    (추후 검증 완료 시 mail.Send()로 자동 발송하도록 전환 예정)

    부서명은 **질의 파라미터로 받는다.** 경로에 두면 `Q530-SMR/ITER생산부`처럼
    이름에 `/`가 든 부서가 404가 된다 — `encodeURIComponent`로 `%2F`를 보내도
    ASGI 서버가 라우팅 전에 경로를 풀어 버려서 세그먼트가 갈라진다.
    결함 목록 쪽에서 같은 이유로 표가 통째로 비었던 적이 있다.
    """
    _require_admin(x_employee_id)
    if not _OUTLOOK_AVAILABLE:
        raise HTTPException(501, "Outlook 연동을 사용할 수 없습니다 (pywin32 미설치)")

    result = get_last_result()
    if result is None:
        raise HTTPException(404, "검증 결과가 없습니다. 먼저 검증을 실행하세요")
    dept_data = (result.get('departments') or {}).get(department)
    if dept_data is None:
        raise HTTPException(404, f"'{department}' 부서 데이터를 찾을 수 없습니다")

    recipients = _load_dept_recipients().get(department, [])
    if not recipients:
        raise HTTPException(400, f"'{department}'의 수신인이 설정되지 않았습니다. 먼저 수신인을 추가하세요")

    try:
        _dispatch_dept_mail(department, dept_data,
                            result_store.expand_defects(result, department,
                                                        exclude_temp=exclude_temp),
                            recipients, result.get('run_at', ''),
                            exclude_temp=exclude_temp)
    except Exception as exc:
        logger.exception("Outlook 초안 생성 실패")
        raise HTTPException(500, f"Outlook 초안 생성 실패: {exc}")

    logger.info("부서 리포트 초안 생성: %s%s → %s", department,
                " (임시부재 제외)" if exclude_temp else "", recipients)
    return {"ok": True, "department": department, "recipients": recipients,
            "exclude_temp": exclude_temp, "mode": "draft"}


@router.post("/teams/send")
def send_team_report(department: str, team: str, exclude_temp: bool = False,
                     x_employee_id: str | None = Header(None)) -> dict:
    """팀별 결함 리포트를 Outlook 초안으로 연다.

    부서 발송과 **같은 본문·같은 첨부 구조**를 쓴다. 다른 것은 범위뿐이다:
    수신인은 그 팀에 설정된 주소이고, 첨부는 그 팀 범위의 결과 Excel이다.

    부서명·팀명 모두 질의 파라미터로 받는다 — 이름에 `/`가 들어간 부서가
    실제로 있어서(`Q530-SMR/ITER생산부`) 경로에 두면 그 부서만 404가 된다.
    """
    _require_admin(x_employee_id)
    if not _OUTLOOK_AVAILABLE:
        raise HTTPException(501, "Outlook 연동을 사용할 수 없습니다 (pywin32 미설치)")

    result = get_last_result()
    if result is None:
        raise HTTPException(404, "검증 결과가 없습니다. 먼저 검증을 실행하세요")
    dept_data = (result.get('departments') or {}).get(department)
    if dept_data is None:
        raise HTTPException(404, f"'{department}' 부서 데이터를 찾을 수 없습니다")
    team_data = (dept_data.get('teams') or {}).get(team)
    if team_data is None:
        raise HTTPException(404, f"'{department} > {team}' 팀 데이터를 찾을 수 없습니다")

    recipients = _team_recipients_of(department, team)
    if not recipients:
        raise HTTPException(400, f"'{team}'의 수신인이 설정되지 않았습니다. 먼저 수신인을 추가하세요")

    try:
        _dispatch_dept_mail(department, team_data,
                            result_store.expand_defects(result, department, team,
                                                        exclude_temp=exclude_temp),
                            recipients, result.get('run_at', ''), team=team,
                            exclude_temp=exclude_temp)
    except Exception as exc:
        logger.exception("Outlook 초안 생성 실패")
        raise HTTPException(500, f"Outlook 초안 생성 실패: {exc}")

    logger.info("팀 리포트 초안 생성: %s > %s%s → %s", department, team,
                " (임시부재 제외)" if exclude_temp else "", recipients)
    return {"ok": True, "department": department, "team": team,
            "recipients": recipients, "exclude_temp": exclude_temp, "mode": "draft"}


class SendBatchIn(BaseModel):
    departments: list[str]


@router.post("/departments/send-batch")
def send_department_reports_batch(body: SendBatchIn,
                                  x_employee_id: str | None = Header(None)) -> dict:
    """
    선택된 여러 부서 각각에 대해 개별 Outlook 초안을 연다.
    부서마다 별도 메일로, 그 부서의 개별 수신인에게만 발송(초안)된다 — 하나로 합쳐 보내지 않음.
    """
    _require_admin(x_employee_id)
    if not _OUTLOOK_AVAILABLE:
        raise HTTPException(501, "Outlook 연동을 사용할 수 없습니다 (pywin32 미설치)")
    if not body.departments:
        raise HTTPException(400, "발송할 부서를 선택하세요")

    result = get_last_result()
    if result is None:
        raise HTTPException(404, "검증 결과가 없습니다. 먼저 검증을 실행하세요")
    departments_data = result.get('departments') or {}
    recipients_map    = _load_dept_recipients()
    run_at            = result.get('run_at', '')

    sent:    list[dict] = []
    skipped: list[dict] = []
    for dept in body.departments:
        dept_data = departments_data.get(dept)
        if dept_data is None:
            skipped.append({"department": dept, "reason": "부서 데이터를 찾을 수 없음"})
            continue
        recipients = recipients_map.get(dept, [])
        if not recipients:
            skipped.append({"department": dept, "reason": "수신인이 설정되지 않음"})
            continue
        try:
            _dispatch_dept_mail(dept, dept_data,
                                result_store.expand_defects(result, dept),
                                recipients, run_at)
            sent.append({"department": dept, "recipients": recipients})
        except Exception as exc:
            logger.exception("Outlook 초안 생성 실패: %s", dept)
            skipped.append({"department": dept, "reason": str(exc)})

    logger.info("부서 일괄 발송: 성공 %d건, 건너뜀 %d건", len(sent), len(skipped))
    return {"ok": True, "sent": sent, "skipped": skipped}
