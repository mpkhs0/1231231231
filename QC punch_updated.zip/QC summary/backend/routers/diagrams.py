"""
판정 로직 도식 조회 — Mermaid 소스를 그대로 내준다.

렌더는 브라우저가 한다(`frontend/static/js/vendor/mermaid.min.js`). 서버가 SVG를
만들지 않는 이유는 두 가지다:

1. 같은 소스를 `QC_검사로직_상세분석.md`에도 넣는데, 문서 쪽은 Obsidian·GitHub가
   렌더한다. 서버가 SVG를 굽기 시작하면 «화면의 그림»과 «문서의 그림»이 서로 다른
   경로로 만들어져 갈라질 수 있다.
2. 도식은 **매 요청 새로 만든다**(비용이 밀리초 단위다). 캐시하면 판정 코드를
   고쳤는데 옛 그림이 남는 상황이 생기고, 그건 이 도식이 막으려던 바로 그 문제다.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Header, HTTPException

from backend.routers.auth import require_login
from backend.routers.verify import get_last_result
from backend.services import diagrams, doc_view

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/diagrams")
def list_diagrams(x_employee_id: str | None = Header(None)) -> dict:
    """도식 전부. 검증 결과가 있으면 행 회계 숫자가 함께 실린다."""
    require_login(x_employee_id)
    result = get_last_result()
    return {"has_result": result is not None,
            "run_at": (result or {}).get("run_at", ""),
            "items": diagrams.build_all(result)}


@router.get("/diagrams/{name}")
def get_diagram(name: str, x_employee_id: str | None = Header(None)) -> dict:
    require_login(x_employee_id)
    if name not in diagrams.DIAGRAMS:
        raise HTTPException(
            404, f"'{name}' 도식이 없습니다 (있는 것: {', '.join(diagrams.DIAGRAMS)})")
    return diagrams.build(name, get_last_result())


@router.get("/logic-doc")
def get_logic_doc(x_employee_id: str | None = Header(None)) -> dict:
    """검사 로직 정본 문서(`QC_검사로직_상세분석.md`)를 화면용 HTML로.

    지금까지 이 문서는 저장소에 접근할 수 있는 **서버 관리자만** 볼 수 있었다.
    정작 판정 결과를 받아 검토하는 현업이 «이 검사가 무엇을 보는가»를 확인할
    방법이 없었다. 그래서 '검사 로직' 탭에서 그대로 읽게 한다.

    매 요청 다시 읽는다 — 문서를 손으로 고쳐도 새로고침이면 반영된다
    (§11 조회와 같은 방침).
    """
    require_login(x_employee_id)
    return doc_view.load_doc()
