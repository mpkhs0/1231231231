"""
서브에이전트 정의 목록과 실행 리포트를 읽어 '에이전트' 탭에 제공한다.

이 라우터는 **읽기 전용**이다. 서버가 에이전트를 실행하지는 않는다.
에이전트는 Claude Code에서 실행되고, 각 에이전트가 작업 마지막에 리포트를
`data/agent_reports/<이름>__<YYYY-MM-DD_HHMMSS>.md`로 남긴다
(각 에이전트 정의 .md의 "리포트 저장" 절 참고). 서버는 그 디렉터리를 훑을 뿐이다.

이렇게 나눈 이유: 서버가 에이전트를 실행하려면 이 PC의 Claude Code 자격증명으로
외부에서 코드를 돌릴 수 있게 되는데, 이 앱은 0.0.0.0으로 사내망에 열려 있고
로그인이 사번 하나뿐이라 그 위험을 지지 않기로 했다.
"""

import logging
import re
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Header, HTTPException

from .. import config
from .auth import require_login

logger = logging.getLogger(__name__)
router = APIRouter()

# 리포트 파일명 규칙: <에이전트이름>__<YYYY-MM-DD_HHMMSS>.md
_REPORT_RE = re.compile(r"^(?P<agent>.+?)__(?P<ts>\d{4}-\d{2}-\d{2}_\d{6})\.md$")

# 에이전트 출처 표시. frontmatter가 아니라 본문 주석에 두는 이유:
# frontmatter는 Claude Code가 파싱하는 영역이라 임의 키를 넣지 않는다.
# HTML 주석은 마크다운 렌더 시 보이지도 않고 파서에 영향도 없다.
_ORIGIN_RE = re.compile(r"<!--\s*origin:\s*(\w+)\s*-->")

# 카드에 보여줄 한국어 기능 요약. frontmatter의 description은 외부에서 가져온 정의의 경우
# 영문 원본이라 화면에서 무슨 일을 하는 에이전트인지 읽히지 않는다. origin과 같은 방식으로
# 본문 주석에 두어 frontmatter 파싱과 마크다운 렌더 어디에도 영향을 주지 않게 한다.
_SUMMARY_RE = re.compile(r"<!--\s*summary:\s*(.+?)\s*-->", re.S)

_ORIGIN_LABEL = {
    "project": "전용 에이전트",
    "vendor": "서브에이전트",
}

_VALID_VERDICTS = {"PASS", "FAIL", "PARTIAL"}

# 목록 응답에 실어 보내는 본문 미리보기 길이 (첫 화면이 무거워지지 않게)
_PREVIEW_CHARS = 400


def _split_frontmatter(text: str) -> tuple[dict[str, str], str]:
    """맨 앞 YAML frontmatter를 얕게 파싱한다.

    PyYAML 의존을 새로 들이지 않으려고 `키: 값` 한 줄짜리만 처리한다. 에이전트 정의와
    리포트 frontmatter는 모두 이 형태라 충분하다. 형식이 어긋나도 예외를 던지지 않고
    빈 dict를 돌려준다 — 파일 한 건이 깨졌다고 목록 전체가 안 뜨면 안 된다.
    """
    if not text.startswith("---"):
        return {}, text
    end = text.find("\n---", 3)
    if end == -1:
        return {}, text
    head = text[3:end]
    body = text[end + 4 :].lstrip("\n")
    meta: dict[str, str] = {}
    for line in head.splitlines():
        key, sep, val = line.partition(":")
        if not sep:
            continue
        meta[key.strip()] = val.strip().strip('"').strip("'")
    return meta, body


_WRITE_TOOLS = {"Write", "Edit", "NotebookEdit", "MultiEdit"}


def _is_read_only(tools_raw: str | None) -> bool:
    """정의가 코드를 수정할 수 없음이 **확실할 때만** True.

    화면에서 "읽기 전용"이라는 초록 배지로 쓰이는 값이라, 애매하면 안전한 쪽(False)으로
    기운다. 빈 목록을 곧바로 read_only=True로 보면 안 되는 경우가 셋 있다:

    - `tools:` 키 자체가 없음  -> Claude Code에서는 **전체 도구 상속**(Write/Edit 포함)
    - `tools: "*"`             -> 전체 허용
    - YAML 블록 리스트로 적음  -> 한 줄 파서가 못 읽어 빈 목록이 된다

    셋 다 예전 구현에서는 `[]`가 되어 "읽기 전용"으로 잘못 표시됐다.
    """
    if tools_raw is None:
        return False                      # 키 없음 = 전체 상속
    raw = tools_raw.strip()
    if not raw or raw in {"*", "[]", '"*"', "'*'"}:
        return False                      # 빈 값/와일드카드 = 판단 불가 -> 안전한 쪽
    names = {t.strip().strip("\"'-[] ") for t in raw.replace("\n", ",").split(",")}
    names.discard("")
    if not names:
        return False                      # 파싱 실패 -> 안전한 쪽
    return not (_WRITE_TOOLS & names)


def _read_text(path: Path) -> str:
    """UTF-8로 읽되, 인코딩이 어긋나도 죽지 않게 한다(리포트는 사람이 읽는 산출물)."""
    return path.read_text(encoding="utf-8", errors="replace")


def _display_ts(raw: str) -> str:
    """파일명 타임스탬프(YYYY-MM-DD_HHMMSS)를 화면용 문자열로 바꾼다."""
    if len(raw) != 17:
        return raw
    return f"{raw[:10]} {raw[11:13]}:{raw[13:15]}:{raw[15:17]}"


def _scan_reports() -> list[dict[str, Any]]:
    """리포트 디렉터리를 훑어 최신순 목록을 만든다. 디렉터리가 없으면 빈 목록."""
    base = config.AGENT_REPORTS_DIR
    if not base.is_dir():
        return []

    items: list[dict[str, Any]] = []
    for path in base.glob("*.md"):
        m = _REPORT_RE.match(path.name)
        if not m:
            # 규칙에 안 맞는 파일은 조용히 건너뛴다 (사람이 메모를 남겨둘 수도 있다)
            logger.debug("리포트 파일명 규칙 불일치, 건너뜀: %s", path.name)
            continue
        try:
            text = _read_text(path)
        except OSError as exc:
            logger.warning("리포트 읽기 실패 %s: %s", path.name, exc)
            continue

        meta, body = _split_frontmatter(text)
        verdict = (meta.get("verdict") or "").upper()
        if verdict not in _VALID_VERDICTS:
            verdict = "UNKNOWN"

        preview = " ".join(body.split())[:_PREVIEW_CHARS]
        items.append(
            {
                "id": path.stem,                       # 파일명(확장자 제외)이 그대로 식별자
                "agent": meta.get("agent") or m.group("agent"),
                "ts": m.group("ts"),                   # 정렬 키 (문자열 정렬 = 시간순)
                "run_at": meta.get("run_at") or _display_ts(m.group("ts")),
                "verdict": verdict,
                "summary": meta.get("summary", ""),
                "preview": preview,
                "size": path.stat().st_size,
            }
        )

    items.sort(key=lambda x: x["ts"], reverse=True)
    return items


def _scan_agents() -> list[dict[str, Any]]:
    """.claude/agents/*.md 정의를 읽어 목록을 만든다."""
    base = config.AGENTS_DIR
    if not base.is_dir():
        return []

    agents: list[dict[str, Any]] = []
    for path in sorted(base.glob("*.md")):
        try:
            text = _read_text(path)
        except OSError as exc:
            logger.warning("에이전트 정의 읽기 실패 %s: %s", path.name, exc)
            continue
        meta, body = _split_frontmatter(text)
        tools = [t.strip() for t in (meta.get("tools") or "").split(",") if t.strip()]

        # 표식이 없으면 "외부에서 가져와 제약을 덧댄 것"인지로 추정하고, 그것도 아니면
        # 이 저장소에서 쓴 것으로 본다 (새로 추가하는 에이전트는 대개 직접 작성이다).
        m_origin = _ORIGIN_RE.search(body)
        if m_origin:
            origin = m_origin.group(1)
        else:
            origin = "vendor" if "원본 정의에 추가됨" in body else "project"

        m_sum = _SUMMARY_RE.search(body)
        # 줄바꿈으로 나뉘어 적혀 있어도 한 줄로 합쳐 보낸다
        summary = " ".join(m_sum.group(1).split()) if m_sum else ""

        agents.append(
            {
                "name": meta.get("name") or path.stem,
                "summary": summary,
                "description": meta.get("description", ""),
                "model": meta.get("model", ""),
                "tools": tools,
                "read_only": _is_read_only(meta.get("tools")),
                "origin": origin,
                "origin_label": _ORIGIN_LABEL.get(origin, origin),
                "lines": body.count("\n") + 1,
            }
        )
    return agents


@router.get("/agents")
def list_agents(x_employee_id: str | None = Header(None)) -> dict:
    """에이전트 정의 + 리포트 목록 + 에이전트별 요약 통계."""
    require_login(x_employee_id)
    agents = _scan_agents()
    reports = _scan_reports()

    by_agent: dict[str, dict[str, Any]] = {}
    for r in reports:
        st = by_agent.setdefault(
            r["agent"], {"runs": 0, "last_run": "", "last_verdict": "", "verdicts": {}}
        )
        st["runs"] += 1
        st["verdicts"][r["verdict"]] = st["verdicts"].get(r["verdict"], 0) + 1
        if not st["last_run"]:  # reports가 최신순이므로 처음 만난 것이 최신
            st["last_run"] = r["run_at"]
            st["last_verdict"] = r["verdict"]

    for a in agents:
        a["stats"] = by_agent.get(
            a["name"], {"runs": 0, "last_run": "", "last_verdict": "", "verdicts": {}}
        )

    # 정의가 사라진 에이전트의 리포트도 목록에는 남는다(이력 보존). 그 사실을 표시해준다.
    known = {a["name"] for a in agents}
    orphans = sorted({r["agent"] for r in reports if r["agent"] not in known})

    return {
        "agents": agents,
        "reports": reports,
        "orphan_agents": orphans,
        "reports_dir": str(config.AGENT_REPORTS_DIR),
        "total_runs": len(reports),
    }


@router.get("/agents/reports/{report_id}")
def get_report(report_id: str, x_employee_id: str | None = Header(None)) -> dict:
    """리포트 본문(마크다운 원문)을 돌려준다."""
    require_login(x_employee_id)
    # 경로 조작 방지 — 파일명 규칙에 맞는 것만 허용한다
    if not _REPORT_RE.match(f"{report_id}.md"):
        raise HTTPException(400, f"리포트 식별자 형식이 올바르지 않습니다: {report_id}")

    path = config.AGENT_REPORTS_DIR / f"{report_id}.md"
    try:
        path = path.resolve(strict=True)
        path.relative_to(config.AGENT_REPORTS_DIR.resolve())
    except (OSError, ValueError):
        raise HTTPException(404, f"리포트를 찾을 수 없습니다: {report_id}")

    text = _read_text(path)
    meta, body = _split_frontmatter(text)
    return {
        "id": report_id,
        "agent": meta.get("agent", ""),
        "run_at": meta.get("run_at", ""),
        "verdict": (meta.get("verdict") or "UNKNOWN").upper(),
        "summary": meta.get("summary", ""),
        "markdown": body,
    }


@router.get("/agents/definition/{name}")
def get_definition(name: str, x_employee_id: str | None = Header(None)) -> dict:
    """에이전트 정의(.md) 본문을 돌려준다 — 무엇을 검사하는 에이전트인지 화면에서 확인용."""
    require_login(x_employee_id)
    if not re.fullmatch(r"[A-Za-z0-9_-]+", name):
        raise HTTPException(400, f"에이전트 이름 형식이 올바르지 않습니다: {name}")

    path = config.AGENTS_DIR / f"{name}.md"
    if not path.is_file():
        raise HTTPException(404, f"에이전트 정의를 찾을 수 없습니다: {name}")

    meta, body = _split_frontmatter(_read_text(path))
    return {
        "name": meta.get("name") or name,
        "description": meta.get("description", ""),
        "model": meta.get("model", ""),
        "tools": [t.strip() for t in (meta.get("tools") or "").split(",") if t.strip()],
        "markdown": body,
    }
