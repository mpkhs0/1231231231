"""
사번 기반 로그인 인증 라우터
허용 사번 목록: data/employees.json ({"employees": [{"id": ..., "admin": bool}, ...]})
"""
import json
import logging
import threading
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from backend import config

logger = logging.getLogger(__name__)
router = APIRouter()

_lock = threading.Lock()


class LoginRequest(BaseModel):
    employee_id: str


def load_employees() -> list[dict]:
    """등록된 사번 목록 읽기 ({"id": str, "admin": bool} 리스트). 파일 없으면 빈 목록."""
    try:
        data = json.loads(config.EMPLOYEES_FILE.read_text(encoding="utf-8"))
        result = []
        for e in data.get("employees", []):
            result.append({"id": str(e.get("id", "")).strip().upper(),
                          "admin": bool(e.get("admin", False))})
        return [e for e in result if e["id"]]
    except FileNotFoundError:
        logger.warning("employees.json 파일을 찾을 수 없음: %s", config.EMPLOYEES_FILE)
        return []
    except Exception as exc:
        logger.error("employees.json 읽기 오류: %s", exc)
        return []


def save_employees(employees: list[dict]) -> None:
    with _lock:
        config.EMPLOYEES_FILE.parent.mkdir(parents=True, exist_ok=True)
        config.EMPLOYEES_FILE.write_text(
            json.dumps({"employees": employees}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )


def update_employees(mutator) -> list[dict]:
    """
    employees.json을 읽기→수정→저장까지 락 하나로 원자적으로 처리한다.
    (기존에는 호출부에서 load_employees()/save_employees()를 따로 호출했는데,
    두 관리자가 거의 동시에 사번을 추가/삭제하면 나중에 저장한 쪽이 먼저 쪽의
    변경을 그대로 덮어쓰는 lost-update가 가능했다.)
    mutator: employees 리스트를 받아 수정된 리스트를 반환하는 함수.
    """
    with _lock:
        data: dict = {"employees": []}
        try:
            data = json.loads(config.EMPLOYEES_FILE.read_text(encoding="utf-8"))
        except FileNotFoundError:
            pass
        raw = data.get("employees", [])
        employees = [
            {"id": str(e.get("id", "")).strip().upper(), "admin": bool(e.get("admin", False))}
            for e in raw
        ]
        employees = [e for e in employees if e["id"]]
        employees = mutator(employees)
        config.EMPLOYEES_FILE.parent.mkdir(parents=True, exist_ok=True)
        config.EMPLOYEES_FILE.write_text(
            json.dumps({"employees": employees}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return employees


def require_login(x_employee_id: str | None) -> str:
    """X-Employee-Id 헤더의 사번이 등록된 것인지 확인하고 정규화해 돌려준다.

    이 앱은 0.0.0.0으로 사내망 전체에 열려 있다. 사번 확인은 강한 인증이 아니지만,
    최소한 employees.json에 등록되지 않은 사람이 검증 결과(사번/도면번호/용접사 이름이
    들어 있는 19MB JSON)를 그대로 받아가거나 검증을 걸어버리는 것은 막는다.
    """
    emp_id = (x_employee_id or "").strip().upper()
    if not emp_id:
        raise HTTPException(401, "로그인이 필요합니다")
    if not any(e["id"] == emp_id for e in load_employees()):
        raise HTTPException(401, "등록되지 않은 사번입니다")
    return emp_id


def is_admin(employee_id: str) -> bool:
    emp_id = (employee_id or "").strip().upper()
    for e in load_employees():
        if e["id"] == emp_id:
            return e["admin"]
    return False


@router.post("/auth/login")
def login(req: LoginRequest) -> dict:
    """사번 검증 후 허용 여부 + 관리자 여부 반환."""
    emp_id = req.employee_id.strip().upper()
    if not emp_id:
        raise HTTPException(status_code=400, detail="사번을 입력하세요")

    # **«목록이 없다»와 «그 사번이 없다»는 다르다.**
    #
    # 새 PC에 복사하면 `data/`가 `.gitignore` 대상이라 `employees.json`이 없다.
    # 그때 «등록되지 않은 사번»이라고 하면 관리자는 사번을 등록하려 하는데,
    # 등록하려면 관리자 로그인이 필요하다 — **교착이다.** 실제로 이 경로가
    # 배포 때 아무도 못 들어가게 만든다.
    if not config.EMPLOYEES_FILE.exists():
        logger.error("사번 목록이 없다: %s — employees.example.json을 복사하라",
                     config.EMPLOYEES_FILE)
        raise HTTPException(
            status_code=503,
            detail=(f"사번 목록 파일이 없습니다: {config.EMPLOYEES_FILE.name}. "
                    f"같은 폴더의 employees.example.json을 복사해 "
                    f"실제 사번으로 고친 뒤 서버를 다시 띄우세요."))

    employees = load_employees()
    if not employees:
        logger.error("사번 목록이 비어 있다: %s", config.EMPLOYEES_FILE)
        raise HTTPException(
            status_code=503,
            detail=(f"사번 목록이 비어 있습니다: {config.EMPLOYEES_FILE.name}. "
                    f"관리자 사번을 최소 한 명 등록해야 합니다."))

    match = next((e for e in employees if e["id"] == emp_id), None)
    if match is None:
        logger.info("로그인 거부: %s", emp_id)
        raise HTTPException(status_code=401, detail="등록되지 않은 사번입니다")

    logger.info("로그인 성공: %s (admin=%s)", emp_id, match["admin"])
    return {"ok": True, "employee_id": emp_id, "is_admin": match["admin"]}
