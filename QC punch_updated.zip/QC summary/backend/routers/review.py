"""
'현업 검증사항' 탭 API — `QC_검사로직_상세분석.md` §11의 조회/답변 등록.

문서가 정본이고 서버는 입력 창구다. 조회는 매 요청 파일을 다시 파므로,
문서를 손으로 고쳐도 새로고침만 하면 화면에 반영된다(양방향).

권한: 관리자 전용이 아니다. 이 기능의 목적 자체가 **문서 파일에 접근할 수 없는
현업 담당자가 답변을 남기게 하는 것**이라, 등록된 사번이면 누구나 쓸 수 있다.
(사번 등록은 관리자가 통제하므로 아무나 쓸 수 있는 것은 아니다.)
"""

import logging

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

from backend.routers.auth import require_login
from backend.services import review_items

logger = logging.getLogger(__name__)
router = APIRouter()


class AnswerRequest(BaseModel):
    conclusion: str
    remark: str = ""
    author: str = ""


@router.get("/review-items")
def list_review_items(x_employee_id: str | None = Header(None)) -> dict:
    require_login(x_employee_id)
    items = review_items.load_items()
    return {
        "items": items,
        "doc": review_items.doc_info(),
        "counts": {
            "total": len(items),
            "open": sum(1 for i in items if i["mark"] == " "),
            "provisional": sum(1 for i in items if i["mark"] == "~"),
            "done": sum(1 for i in items if i["mark"] == "x"),
            # 답변은 왔지만 헤딩/코드 반영이 남은 것 — 인계 누락을 잡기 위한 수치
            "needs_followup": sum(1 for i in items if i["needs_followup"]),
        },
    }


@router.post("/review-items/{item_id}/answer")
def save_review_answer(
    item_id: str,
    req: AnswerRequest,
    x_employee_id: str | None = Header(None),
) -> dict:
    emp_id = require_login(x_employee_id)
    # 답변자를 안 적으면 로그인 사번으로 기록한다 — 누가 남겼는지는 반드시 남아야 한다
    author = (req.author or "").strip() or emp_id
    try:
        item = review_items.save_answer(item_id, req.conclusion, req.remark, author)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    except OSError as exc:
        logger.exception("§11 답변 기록 실패")
        raise HTTPException(500, f"문서에 기록하지 못했습니다: {exc}")
    return {"ok": True, "item": item}
