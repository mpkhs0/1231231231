#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
QMG4520 QC Summary List Verifier
용접 품질관리 데이터 자동 검증 시스템 v1.0

입력:
  1) QMG4520 데이터 파일  (xlsx)  ← QMG4520 Report QC Summary List For Structure
  2) Qualified Welder List (xlsx) ← Qualified weler list (C=번호, F=프로세스, K=자세)
  3) WPS 참조 파일        (xlsm)  ← 매크로 파일의 'Hull & Topside WPS List' 시트

출력:
  - 색상 코딩된 검증 결과 Excel
  - 콘솔 요약 리포트

검사 목록 (10가지):
  1  일정 오류          AM(용접일) > AO(NDT계획일)          → AO열 Red
  2  WPS/Process 불일치  AJ+AK 조합이 WPS List에 없음        → AJ열 Green
  3  두께 허용범위 초과   WPS 두께 범위 밖                   → J열 Blue
  4  Groove 불일치       R열이 WPS Joint Detail에 없음        → R열 Yellow
  5  특수규칙 P+WPS      P열 A/B + WPS=TR-FC-G01            → AJ열 Blue
  6  용접사 자격 미등록   AP~AW 용접사 프로세스 자격 없음     → AP/AR/AT/AV열 Orange
  7  중복 오류 (2+5)     Check2와 Check5 동시 발생           → AJ열 Yellow
  8  TR-FC-G03 특수      -40 재질 + 두께≤12T               → J열 Blue
  9  TR-SMFC-G01 특수    두께 12.7T                         → J열 Green
  10 복합 오류 (3+8)     두께 범위 + TR-FC-G03 특수 동시     → J열 Black
"""

import sys
import re
import logging
import argparse
from datetime import datetime, date
from pathlib import Path
from collections import defaultdict
from typing import Optional, Tuple, Dict, List, Set, Any

logging.basicConfig(
    level=logging.INFO,
    format='%(levelname)s  %(message)s',
)
logger = logging.getLogger(__name__)

try:
    import openpyxl
    from openpyxl import load_workbook
    from openpyxl.styles import PatternFill, Font
    from openpyxl.utils import get_column_letter
except ImportError:
    logger.error("openpyxl 패키지가 필요합니다: pip install openpyxl")
    sys.exit(1)

# ─────────────────────────────────────────────────────────────────────────────
# 컬럼 인덱스 상수 (1-based)
# ─────────────────────────────────────────────────────────────────────────────
class Col:
    """QMG4520 시트 컬럼"""
    DRAWING_NO    = 1   # A  도면번호
    BLOCK         = 2   # B  블록
    LOT           = 3   # C  Lot
    JOINT_NO      = 4   # D  Weld No (Joint No)
    RE            = 5   # E  RE
    THICKNESS1    = 10  # J  두께1
    THICKNESS2    = 11  # K  두께2
    MATERIAL1     = 13  # M  재질1
    MATERIAL2     = 14  # N  재질2
    NDT_CAT       = 16  # P  NDT Category
    NDT_TYPE      = 17  # Q  Type
    GROOVE        = 18  # R  Groove
    DELETE_STATUS = 24  # X  Delete Status
    AI_HULL       = 35  # AI Hull/Topside
    WPS_NO        = 36  # AJ WPS No
    WPS_PROCESS   = 37  # AK WPS Process
    CONSUMABLE    = 38  # AL Consumable Lot
    WELD_DATE     = 39  # AM Welding Date
    WELD_TIME     = 40  # AN Welding Time
    NDT_DATE      = 41  # AO NDT Plan Date
    WELDER1_NO    = 42  # AP Welder#1 No
    WELDER1_PROC  = 43  # AQ Welder#1 Process
    WELDER2_NO    = 44  # AR Welder#2 No
    WELDER2_PROC  = 45  # AS Welder#2 Process
    WELDER3_NO    = 46  # AT Welder#3 No
    WELDER3_PROC  = 47  # AU Welder#3 Process
    WELDER4_NO    = 48  # AV Welder#4 No
    WELDER4_PROC  = 49  # AW Welder#4 Process

class WPSCol:
    """Hull & Topside WPS List 시트 컬럼"""
    SER_NO        = 2   # B  순번
    WPS_NO        = 3   # C  WPS No
    DOC_NO        = 4   # D  Doc No
    PROCESS       = 5   # E  Welding Process
    BASE_METAL    = 6   # F  Base Metal
    THICKNESS     = 7   # G  Thickness Range
    DIAMETER      = 8   # H  Diameter
    FILLER_BRAND  = 9   # I  Filler Brand
    FILLER_DIA    = 10  # J  Filler Dia
    POSITION      = 11  # K  Position
    JOINT_DETAIL  = 12  # L  Joint Detail (Groove)

class WelderCol:
    """Qualified Welder List 컬럼"""
    NO            = 3   # C  용접사 번호
    PROCESS       = 6   # F  용접 프로세스
    POSITION      = 11  # K  자세
    STATUS        = 80  # CB Update Status (퇴사 = 제외)

# ─────────────────────────────────────────────────────────────────────────────
# 색상 정의
# ─────────────────────────────────────────────────────────────────────────────
def _fill(hex_color: str) -> PatternFill:
    return PatternFill(start_color=hex_color, end_color=hex_color, fill_type="solid")

COLOR_RED    = _fill("FF0000")   # Check 1: 일정 오류
COLOR_GREEN  = _fill("00B050")   # Check 2: WPS 불일치 / Check 9: SMFC 특수
COLOR_BLUE   = _fill("0070C0")   # Check 3/5/8: 두께·특수규칙
COLOR_YELLOW = _fill("FFFF00")   # Check 4/7: Groove·중복
COLOR_ORANGE = _fill("FF7F00")   # Check 6: 용접사 미등록
COLOR_BLACK  = _fill("000000")   # Check 10: 복합 오류

COLOR_PRIORITY = {  # 낮을수록 높은 우선순위
    COLOR_BLACK: 0, COLOR_RED: 1, COLOR_ORANGE: 2,
    COLOR_YELLOW: 3, COLOR_BLUE: 4, COLOR_GREEN: 5,
}

# ─────────────────────────────────────────────────────────────────────────────
# 유틸리티 함수
# ─────────────────────────────────────────────────────────────────────────────
def _clean(v: Any) -> str:
    """셀 값을 정제된 문자열로 변환"""
    if v is None:
        return ""
    return str(v).strip()

def _normalize_process(v: Any) -> str:
    """
    용접 프로세스 정규화
    예: 'FCAW\n(Non-CTOD)' → 'FCAW'
        'FCAW-Carriage\n(Non-CTOD)' → 'FCAW'  (캐리지도 FCAW로 통합)
        'FCSA' → 'FCSA'
    """
    s = _clean(v).upper()
    s = re.sub(r'\(.*?\)', '', s)       # 괄호 내용 제거
    s = re.sub(r'[\n\r\s]+', '', s)     # 공백/줄바꿈 제거
    s = re.sub(r'-CARRIAGE$', '', s)    # -CARRIAGE 접미사 제거
    return s

def _parse_date(v: Any) -> Optional[date]:
    """다양한 형식의 날짜 파싱"""
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    s = _clean(v)
    if not s or s in (' ', 'None'):
        return None
    for fmt in ('%Y-%m-%d', '%Y/%m/%d', '%d/%m/%Y', '%m/%d/%Y', '%Y.%m.%d'):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None

def _to_float(v: Any) -> Optional[float]:
    """숫자 변환 (실패 시 None)"""
    if v is None:
        return None
    try:
        return float(str(v).strip())
    except (ValueError, TypeError):
        return None

def _is_deleted(row: tuple) -> bool:
    """X열(Delete Status) 값이 있으면 삭제된 행"""
    v = _clean(row[Col.DELETE_STATUS - 1] if len(row) >= Col.DELETE_STATUS else None)
    return bool(v)

def _is_repair_wps(wps_no: str) -> bool:
    """수리 WPS 여부 (TR-FC-R 접두어)"""
    return bool(wps_no) and wps_no.upper().startswith('TR-FC-R')

def _row_val(row: tuple, col: int) -> Any:
    """1-based 컬럼으로 tuple 접근"""
    idx = col - 1
    return row[idx] if idx < len(row) else None

# ─────────────────────────────────────────────────────────────────────────────
# 두께 범위 파싱
# ─────────────────────────────────────────────────────────────────────────────
def _parse_thickness_ranges(text: str) -> List[Tuple[float, float]]:
    """
    WPS G열 두께 범위 텍스트에서 (min, max) 튜플 리스트 추출.

    지원 형식:
      "3~50"  "3 ~ 50"   → [(3, 50)]
      "3-50"  "10-40"    → [(3, 50)]   (대시 구분자)
      "500~"             → [(500, 9999)]
      "~E36\n: 3~50\nEO420\n:25~38" → [(3,50),(25,38)]
    """
    ranges: List[Tuple[float, float]] = []
    matched: set[int] = set()

    # 1) "숫자 [~|-] 숫자" (양쪽 경계 모두 있는 경우)
    for m in re.finditer(r'(\d+(?:\.\d+)?)\s*[~\-]\s*(\d+(?:\.\d+)?)', text):
        lo, hi = float(m.group(1)), float(m.group(2))
        if lo <= hi:
            ranges.append((lo, hi))
            matched.update(range(m.start(), m.end()))

    # 2) "숫자~" (상한 없음) — Pattern 1이 차지한 위치와 겹치면 건너뜀
    for m in re.finditer(r'(\d+(?:\.\d+)?)\s*~', text):
        if m.start() in matched:
            continue
        ranges.append((float(m.group(1)), 9999.0))

    # 3) "~숫자" (하한 없음) — Pattern 1이 차지한 위치와 겹치면 건너뜀
    for m in re.finditer(r'~\s*(\d+(?:\.\d+)?)', text):
        if m.start() in matched:
            continue
        ranges.append((0.0, float(m.group(1))))

    return ranges

def _thickness_in_range(thickness: float, range_text: str) -> bool:
    """두께가 WPS 허용 범위 내에 있는지 확인"""
    if not range_text:
        return True
    ranges = _parse_thickness_ranges(range_text)
    if not ranges:
        return True  # 파싱 불가 시 통과
    return any(lo <= thickness <= hi for lo, hi in ranges)

# ─────────────────────────────────────────────────────────────────────────────
# 재질 분류 매핑
# ─────────────────────────────────────────────────────────────────────────────
# QMG4520 M열 재질명 → WPS Base Metal 카테고리 키
MATERIAL_MAP: Dict[str, List[str]] = {
    'EO420':  ['EO420', 'NV-EO420', 'NV EO420'],
    'EW420':  ['EW420', 'NV-EW420', 'NV EW420', 'NV-EW420Z'],
    'API2H':  ['API 2H', 'API2H', 'API-2H'],
    'API5L':  ['API 5L', 'API5L', 'API-5L'],
    'A36_AR': ['ASTM A36', 'ASTM-A36', 'A36 (AS', 'A36(AS', 'AH36 (AS', 'AB AH36', 'A500'],
    'S355NH': ['S355NH', 'EN S355NH', 'KS SS275', 'JIS SS400'],
    'EH36':   ['NV-EH36', 'EH36', 'NV EH36'],
    'DH36':   ['NV-DH36', 'DH36', 'NV DH36'],
    'AH36':   ['NV-AH36', 'AH36', 'NV AH36'],
    'E36':    ['NV-A36', 'NV A36', 'A36', 'AW36', 'DW36', 'EW36'],  # fallback
}

def _get_material_key(material: str) -> str:
    """재질명을 카테고리 키로 변환"""
    m_up = material.upper().replace('-', ' ')
    for key, patterns in MATERIAL_MAP.items():
        for pat in patterns:
            if pat.upper().replace('-', ' ') in m_up:
                return key
    return 'E36'  # 기본 (NV A~E36 계열)

def _material_covered_by_wps(material_key: str, wps_base_metal: str) -> bool:
    """재질 키가 WPS Base Metal 범위에 포함되는지 확인"""
    bm = wps_base_metal.upper()
    checks = {
        'EO420':  ['EO420'],
        'EW420':  ['EW420'],
        'API2H':  ['API 2H', 'API2H', '2H GR'],
        'API5L':  ['API 5L', 'API5L'],
        'A36_AR': ['A36', 'AS ROLL', 'ASTM A36', 'S355NH'],
        'S355NH': ['S355NH', 'SS275', 'SS400'],
        'EH36':   ['E(EW)36', 'EH36', 'EW36', 'A(AW)~E(EW)36'],
        'DH36':   ['D(DW)36', 'DH36', 'A(AW)~E(EW)36'],
        'AH36':   ['A(AW)36', 'AH36', 'AW36', 'A(AW)~E(EW)36'],
        'E36':    ['A(AW)~E(EW)36', 'A36', 'NV A', 'NV E', 'KS SS', 'JIS SS'],
    }
    for pat in checks.get(material_key, ['A(AW)~E(EW)36']):
        if pat.upper() in bm:
            return True
    return False

# ─────────────────────────────────────────────────────────────────────────────
# 데이터 로더
# ─────────────────────────────────────────────────────────────────────────────
class QCDataLoader:

    def __init__(self):
        # WPS No → {process, base_metal, thickness_range, position, joint_detail}
        self.wps_table: Dict[str, dict] = {}
        # welder_no → {process: set(), position: set()}
        self.welder_qual: Dict[str, Dict[str, Set[str]]] = defaultdict(
            lambda: {'process': set(), 'position': set()}
        )
        # QMG 행 데이터 [(row_num, values_tuple), ...]
        self.qmg_rows: List[Tuple[int, tuple]] = []

    # ── WPS 참조 로드 ──────────────────────────────────────────────────────
    def load_wps(self, xlsm_path: str) -> None:
        wb = load_workbook(xlsm_path, data_only=True, keep_vba=True)
        if 'Hull & Topside WPS List' not in wb.sheetnames:
            logger.warning("'Hull & Topside WPS List' 시트를 찾을 수 없음")
            wb.close()
            return
        ws = wb['Hull & Topside WPS List']

        current = None
        for row in ws.iter_rows(min_row=6, values_only=True):
            wps_no = _clean(_row_val(row, WPSCol.WPS_NO))
            if wps_no:
                current = wps_no
                self.wps_table[current] = {
                    'process':      _normalize_process(_row_val(row, WPSCol.PROCESS)),
                    'base_metal':   _clean(_row_val(row, WPSCol.BASE_METAL)),
                    'thk_range':    _clean(_row_val(row, WPSCol.THICKNESS)),
                    'position':     _clean(_row_val(row, WPSCol.POSITION)),
                    'joint_detail': _clean(_row_val(row, WPSCol.JOINT_DETAIL)),
                }
        wb.close()
        logger.info("WPS  %d개 로드 완료", len(self.wps_table))

    # ── Qualified Welder List 로드 ─────────────────────────────────────────
    def load_welders(self, welder_path: str) -> None:
        wb = load_workbook(welder_path, data_only=True, read_only=True)
        ws = wb.active

        loaded = 0
        skipped_retired = 0
        for row in ws.iter_rows(min_row=4, values_only=True):
            if not row:
                continue
            welder_no = _clean(_row_val(row, WelderCol.NO))
            process   = _normalize_process(_row_val(row, WelderCol.PROCESS))
            position  = _clean(_row_val(row, WelderCol.POSITION))
            status    = _clean(_row_val(row, WelderCol.STATUS)) if len(row) >= WelderCol.STATUS else ''

            if not welder_no or not process:
                continue
            if '퇴사' in status:
                skipped_retired += 1
                continue

            self.welder_qual[welder_no]['process'].add(process)
            if position:
                self.welder_qual[welder_no]['position'].add(position)
            loaded += 1

        wb.close()
        logger.info("Welder  %d명 / %d건 자격 로드 완료 (퇴사자 %d건 제외)",
                    len(self.welder_qual), loaded, skipped_retired)

    # ── QMG4520 데이터 로드 ───────────────────────────────────────────────
    def load_qmg(self, qmg_path: str) -> None:
        wb = load_workbook(qmg_path, data_only=True, read_only=True)
        ws = wb.active

        self.qmg_rows = []
        for excel_row, row in enumerate(ws.iter_rows(min_row=6, values_only=True), start=6):
            # 완전히 빈 행 스킵
            if not any(v for v in row if v not in (None, '', ' ')):
                continue
            self.qmg_rows.append((excel_row, row))

        wb.close()
        logger.info("QMG  %d행 로드 완료", len(self.qmg_rows))


# ─────────────────────────────────────────────────────────────────────────────
# 검사 결과 데이터 클래스
# ─────────────────────────────────────────────────────────────────────────────
class Flag:
    """단일 셀 플래그"""
    __slots__ = ('check_no', 'col', 'color', 'msg')

    def __init__(self, check_no: int, col: int, color: PatternFill, msg: str):
        self.check_no = check_no
        self.col      = col
        self.color    = color
        self.msg      = msg

    def __repr__(self):
        return f"Flag(C{self.check_no}, col={self.col}, {self.msg[:40]})"


# ─────────────────────────────────────────────────────────────────────────────
# 검사 엔진
# ─────────────────────────────────────────────────────────────────────────────
class QCChecker:

    def __init__(self, loader: QCDataLoader):
        self.loader = loader
        # row_num → [Flag, ...]
        self.row_flags: Dict[int, List[Flag]] = {}
        # check_no → count
        self.stats: Dict[int, int] = defaultdict(int)

    def run(self) -> None:
        """전체 행 검사 실행"""
        self.row_flags = {}
        self.stats     = defaultdict(int)

        for row_num, row in self.loader.qmg_rows:
            if _is_deleted(row):
                continue
            flags = self._check_row(row)
            if flags:
                self.row_flags[row_num] = flags
                # check_no별 카운트 (Check 6은 행당 여러 플래그 가능)
                counted = defaultdict(int)
                for f in flags:
                    counted[f.check_no] += 1
                for check_no, cnt in counted.items():
                    self.stats[check_no] += cnt

    # ── 행 단위 검사 ──────────────────────────────────────────────────────
    def _check_row(self, row: tuple) -> List[Flag]:
        flags: List[Flag] = []

        wps_no  = _clean(_row_val(row, Col.WPS_NO))
        wps_prc = _normalize_process(_row_val(row, Col.WPS_PROCESS))
        repair  = _is_repair_wps(wps_no)

        # Check 1 ─ 일정 오류
        f1 = self._c1_schedule(row)
        if f1:
            flags.append(f1)

        # Check 2 ─ WPS/Process 불일치
        f2 = self._c2_wps_process(row, wps_no, wps_prc, repair)
        if f2:
            flags.append(f2)

        # Check 3 ─ 두께 허용범위
        f3 = self._c3_thickness(row, wps_no)
        if f3:
            flags.append(f3)

        # Check 4 ─ Groove 불일치
        f4 = self._c4_groove(row, wps_no, repair)
        if f4:
            flags.append(f4)

        # Check 5 ─ 특수규칙 (P열 A/B + TR-FC-G01)
        f5 = self._c5_special_p_g01(row, wps_no)
        if f5:
            flags.append(f5)

        # Check 6 ─ 용접사 자격 (#1~#4)
        f6_list = self._c6_welders(row)
        flags.extend(f6_list)

        # Check 7 ─ 중복 오류 (Check2 + Check5)
        if f2 and f5:
            flags.append(Flag(7, Col.WPS_NO, COLOR_YELLOW,
                              "중복 오류: WPS 불일치 + 특수규칙 동시 발생"))

        # Check 8 ─ TR-FC-G03 특수 (-40 재질 + ≤12T)
        f8 = self._c8_tr_fc_g03(row, wps_no)
        if f8:
            flags.append(f8)

        # Check 9 ─ TR-SMFC-G01 특수 (12.7T)
        f9 = self._c9_tr_smfc_g01(row, wps_no)
        if f9:
            flags.append(f9)

        # Check 10 ─ 복합 오류 (Check3 + Check8)
        if f3 and f8:
            flags.append(Flag(10, Col.THICKNESS1, COLOR_BLACK,
                              "복합 오류: 두께 범위 초과 + TR-FC-G03 특수 동시 발생"))

        return flags

    # ── Check 1: 일정 오류 ────────────────────────────────────────────────
    def _c1_schedule(self, row: tuple) -> Optional[Flag]:
        weld_dt = _parse_date(_row_val(row, Col.WELD_DATE))
        ndt_dt  = _parse_date(_row_val(row, Col.NDT_DATE))
        if weld_dt and ndt_dt and ndt_dt < weld_dt:
            return Flag(1, Col.NDT_DATE, COLOR_RED,
                        f"일정오류: 용접일({weld_dt}) > NDT계획일({ndt_dt})")
        return None

    # ── Check 2: WPS/Process 불일치 ──────────────────────────────────────
    def _c2_wps_process(self, row: tuple, wps_no: str, wps_prc: str, repair: bool) -> Optional[Flag]:
        if not wps_no or repair:
            return None
        wps = self.loader.wps_table.get(wps_no)
        if wps is None:
            return Flag(2, Col.WPS_NO, COLOR_GREEN,
                        f"WPS '{wps_no}' WPS List에 없음")
        reg_prc = wps['process']
        # 프로세스 불일치 (SMFC/GTFC 계열 복합 공정 고려)
        if wps_prc and reg_prc and wps_prc != reg_prc:
            if not (('SMFC' in wps_prc and 'SMFC' in reg_prc) or
                    ('GTFC' in wps_prc and 'GTFC' in reg_prc) or
                    ('FCSA' in wps_prc and 'FCSA' in reg_prc)):
                return Flag(2, Col.WPS_NO, COLOR_GREEN,
                            f"Process 불일치: 입력={wps_prc}, 등록={reg_prc} (WPS={wps_no})")
        return None

    # ── Check 3: 두께 허용범위 ───────────────────────────────────────────
    def _c3_thickness(self, row: tuple, wps_no: str) -> Optional[Flag]:
        if not wps_no:
            return None
        wps = self.loader.wps_table.get(wps_no)
        if not wps or not wps['thk_range']:
            return None

        thk = _to_float(_row_val(row, Col.THICKNESS1))
        if thk is None:
            return None

        mat1 = _clean(_row_val(row, Col.MATERIAL1))
        mat_key = _get_material_key(mat1)

        # WPS Base Metal 범위에 재질이 포함되는지 확인
        if not _material_covered_by_wps(mat_key, wps['base_metal']):
            return None  # 재질 자체가 WPS 범위 밖이면 Check 2에서 처리

        # 두께 범위 확인
        if not _thickness_in_range(thk, wps['thk_range']):
            return Flag(3, Col.THICKNESS1, COLOR_BLUE,
                        f"두께범위 초과: {thk}mm, WPS={wps_no}, 허용범위={wps['thk_range'][:60]}")
        return None

    # ── Check 4: Groove 불일치 ───────────────────────────────────────────
    def _c4_groove(self, row: tuple, wps_no: str, repair: bool) -> Optional[Flag]:
        if not wps_no or repair:
            return None
        groove = _clean(_row_val(row, Col.GROOVE))
        if not groove:
            return None
        wps = self.loader.wps_table.get(wps_no)
        if not wps or not wps['joint_detail']:
            return None

        jd_raw = wps['joint_detail']
        gr_upper = groove.upper().strip()

        # Joint Detail에서 유효 코드 토큰 추출
        # 예: "SB, DB, SV, DV,FL"   → {SB, DB, SV, DV, FL}
        # 예: "SQ\n(both side 1run)" → {SQ}  ← 괄호 내용 무시
        # 예: "PJP. Repair"          → {PJP}
        jd_clean = re.sub(r'\(.*?\)', '', jd_raw, flags=re.DOTALL)  # 괄호 제거
        jd_clean = re.sub(r'\.?\s*(repair|multi|pass|side|run|both)[^,\n]*', '',
                          jd_clean, flags=re.IGNORECASE)            # 설명어 제거
        jd_tokens = {t.strip().upper() for t in re.split(r'[,\n\r\s]+', jd_clean)
                     if t.strip()}

        # PP = Partial Penetration → PJP 와도 매칭
        gr_aliases = {gr_upper}
        if gr_upper == 'PP':
            gr_aliases.add('PJP')

        if not gr_aliases.intersection(jd_tokens):
            return Flag(4, Col.GROOVE, COLOR_YELLOW,
                        f"Groove 불일치: '{groove}' not in [{', '.join(sorted(jd_tokens))}]")
        return None

    # ── Check 5: 특수규칙 P + TR-FC-G01 ─────────────────────────────────
    def _c5_special_p_g01(self, row: tuple, wps_no: str) -> Optional[Flag]:
        ndt_cat = _clean(_row_val(row, Col.NDT_CAT))
        if not ndt_cat:
            return None
        first = ndt_cat[0].upper()
        if first in ('A', 'B') and wps_no.upper() == 'TR-FC-G01':
            return Flag(5, Col.WPS_NO, COLOR_BLUE,
                        f"특수규칙: NDT Cat='{ndt_cat}'(A/B) + WPS=TR-FC-G01 → G03 사용 필요")
        return None

    # ── Check 6: 용접사 자격 (#1~#4) ─────────────────────────────────────
    def _c6_welders(self, row: tuple) -> List[Flag]:
        pairs = [
            (Col.WELDER1_NO, Col.WELDER1_PROC, 'AP'),
            (Col.WELDER2_NO, Col.WELDER2_PROC, 'AR'),
            (Col.WELDER3_NO, Col.WELDER3_PROC, 'AT'),
            (Col.WELDER4_NO, Col.WELDER4_PROC, 'AV'),
        ]
        flags = []
        for no_col, pr_col, col_name in pairs:
            no  = _clean(_row_val(row, no_col))
            prc = _normalize_process(_row_val(row, pr_col))
            if not no or not prc:
                continue
            qual = self.loader.welder_qual.get(no)
            if qual is None:
                flags.append(Flag(6, no_col, COLOR_ORANGE,
                                  f"용접사 '{no}' 자격 DB 미등록"))
            elif prc not in qual['process']:
                flags.append(Flag(6, no_col, COLOR_ORANGE,
                                  f"용접사 '{no}' 프로세스 '{prc}' 자격 없음 "
                                  f"(보유: {','.join(sorted(qual['process']))})"))
        return flags

    # ── Check 8: TR-FC-G03 특수 ──────────────────────────────────────────
    def _c8_tr_fc_g03(self, row: tuple, wps_no: str) -> Optional[Flag]:
        if wps_no.upper() != 'TR-FC-G03':
            return None
        mat1 = _clean(_row_val(row, Col.MATERIAL1)).upper()
        mat2 = _clean(_row_val(row, Col.MATERIAL2)).upper()

        # -40°C 충격시험 요구 재질 판정
        # EO420, EH36, DH36 계열은 -40°C 기준 재질
        minus40_keywords = ['EO420', 'EH36', 'EH', 'EO', '-40', 'DH36', 'FH36']
        has_minus40 = any(kw in mat1 or kw in mat2 for kw in minus40_keywords)

        thk1 = _to_float(_row_val(row, Col.THICKNESS1)) or 0
        thk2 = _to_float(_row_val(row, Col.THICKNESS2)) or 0
        thk  = min(thk1, thk2) if thk2 else thk1  # 얇은 쪽 기준

        if has_minus40 and 0 < thk <= 12:
            return Flag(8, Col.THICKNESS1, COLOR_BLUE,
                        f"TR-FC-G03 특수: -40재질({mat1}) + 두께({thk}mm)≤12mm")
        return None

    # ── Check 9: TR-SMFC-G01 특수 ────────────────────────────────────────
    def _c9_tr_smfc_g01(self, row: tuple, wps_no: str) -> Optional[Flag]:
        if wps_no.upper() != 'TR-SMFC-G01':
            return None
        thk1 = _to_float(_row_val(row, Col.THICKNESS1)) or 0
        thk2 = _to_float(_row_val(row, Col.THICKNESS2)) or 0
        if abs(thk1 - 12.7) < 0.05 or abs(thk2 - 12.7) < 0.05:
            return Flag(9, Col.THICKNESS1, COLOR_GREEN,
                        f"SMFC-G01 특수: 두께 12.7mm (WPS={wps_no})")
        return None


# ─────────────────────────────────────────────────────────────────────────────
# 출력 생성기
# ─────────────────────────────────────────────────────────────────────────────
class ReportGenerator:

    CHECK_NAMES = {
        1:  "일정 오류          (Red   )",
        2:  "WPS/Process 불일치  (Green )",
        3:  "두께 허용범위 초과  (Blue  )",
        4:  "Groove 불일치       (Yellow)",
        5:  "특수규칙 P+G01      (Blue  )",
        6:  "용접사 자격 미등록  (Orange)",
        7:  "중복 오류 (2+5)     (Yellow)",
        8:  "TR-FC-G03 특수      (Blue  )",
        9:  "TR-SMFC-G01 특수    (Green )",
        10: "복합 오류 (3+8)     (Black )",
    }

    def __init__(self, checker: QCChecker, qmg_path: str):
        self.checker  = checker
        self.qmg_path = qmg_path

    def write_excel(self, out_path: str) -> None:
        """QMG 원본을 복사하여 색상 마킹 후 저장"""
        wb = load_workbook(self.qmg_path)
        ws = wb.active

        for row_num, flags in self.checker.row_flags.items():
            # 컬럼별 최우선 색상 결정
            best: Dict[int, Flag] = {}
            for f in flags:
                prev = best.get(f.col)
                if prev is None or COLOR_PRIORITY[f.color] < COLOR_PRIORITY[prev.color]:
                    best[f.col] = f

            for col, f in best.items():
                cell = ws.cell(row=row_num, column=col)
                cell.fill = f.color
                if f.color == COLOR_BLACK:
                    cell.font = Font(color="FFFFFF")  # 검정 배경엔 흰 글씨

        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        wb.save(out_path)
        logger.info("결과 저장 완료: %s", out_path)

    def print_summary(self) -> None:
        stats = self.checker.stats
        total = sum(stats.values())
        total_rows = len(self.checker.row_flags)

        print()
        print("=" * 65)
        print("   QMG4520 QC 검증 결과 요약")
        print("=" * 65)
        for no, name in self.CHECK_NAMES.items():
            cnt = stats.get(no, 0)
            bar = "▌" * min(cnt // max(total // 40, 1), 30) if cnt else ""
            print(f"  Check {no:2d}: {name}  {cnt:5,}건  {bar}")
        print("-" * 65)
        print(f"  총 플래그: {total:,}건  (플래그 있는 행: {total_rows:,}행)")
        print("=" * 65)

    def write_flag_report(self, out_path: str) -> None:
        """플래그 상세 리포트 (텍스트)"""
        lines = [
            "QMG4520 QC 검증 상세 리포트",
            "=" * 80,
            "",
        ]
        for row_num in sorted(self.checker.row_flags):
            flags = self.checker.row_flags[row_num]
            lines.append(f"  [행 {row_num:5d}]")
            for f in flags:
                lines.append(f"    Check {f.check_no}: col={get_column_letter(f.col)}"
                             f"({f.col})  {f.msg}")
            lines.append("")

        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        Path(out_path).write_text("\n".join(lines), encoding='utf-8-sig')
        logger.info("상세 리포트 저장: %s", out_path)


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description='QMG4520 QC Summary List 자동 검증 시스템',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
예시:
  python qc_verifier.py \\
    --qmg  "Raw data/QMG4520 Report QC Summary List For Structure(0729)_10000EA.xlsx" \\
    --welder "Raw data/Qualified weler list(structure_0729).xlsx" \\
    --wps-ref "Raw data/QMG4520 Report QC Summary List For Structure(테스트R5).xlsm" \\
    --output output/QC_Result.xlsx
        """
    )
    p.add_argument('--qmg',      required=True, metavar='FILE', help='QMG4520 데이터 xlsx')
    p.add_argument('--welder',   required=True, metavar='FILE', help='Qualified Welder List xlsx')
    p.add_argument('--wps-ref',  required=True, metavar='FILE', help='WPS 참조 xlsm')
    p.add_argument('--output',   default='output/QC_Result.xlsx', metavar='FILE', help='결과 xlsx (기본: output/QC_Result.xlsx)')
    p.add_argument('--report',   default='output/QC_Report.txt',  metavar='FILE', help='상세 리포트 txt (기본: output/QC_Report.txt)')
    p.add_argument('--no-report', action='store_true', help='상세 리포트 생략')
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)

    for path, label in [(args.qmg, 'QMG'), (args.welder, 'Welder'), (args.wps_ref, 'WPS Ref')]:
        if not Path(path).exists():
            logger.error("파일 없음: %s  (%s)", path, label)
            return 1

    print()
    print("=" * 65)
    print("   QMG4520 QC 자동 검증 시스템  v1.0")
    print("=" * 65)

    loader = QCDataLoader()
    loader.load_wps(args.wps_ref)
    loader.load_welders(args.welder)
    loader.load_qmg(args.qmg)

    checker = QCChecker(loader)
    logger.info("검사 실행 중...")
    checker.run()

    reporter = ReportGenerator(checker, args.qmg)
    reporter.print_summary()
    reporter.write_excel(args.output)
    if not args.no_report:
        reporter.write_flag_report(args.report)

    return 0


if __name__ == '__main__':
    sys.exit(main())
