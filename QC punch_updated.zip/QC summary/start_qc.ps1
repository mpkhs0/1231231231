﻿Set-Location $PSScriptRoot

Write-Host "QMG4520 QC 검증 서버 시작 중..." -ForegroundColor Cyan
Write-Host ""

$localIp = (Get-NetIPAddress -AddressFamily IPv4 |
    Where-Object { $_.IPAddress -notlike '169.254.*' -and $_.IPAddress -ne '127.0.0.1' } |
    Select-Object -First 1 -ExpandProperty IPAddress)

Write-Host "  내 PC에서 접속:               http://localhost:8001"
Write-Host ("  다른 사람 접속 (같은 네트워크): http://{0}:8001" -f $localIp)
Write-Host ""
Write-Host "  * 아래에 새로 뜨는 'QC Server' 창을 닫으면 서버가 종료되어" -ForegroundColor Yellow
Write-Host "    다른 사람도 더 이상 접속할 수 없게 됩니다." -ForegroundColor Yellow
Write-Host "    (지금 이 창은 잠시 후 자동으로 닫히는 게 정상입니다)" -ForegroundColor Yellow
Write-Host ""

Start-Process powershell -ArgumentList @(
    "-NoExit", "-NoProfile", "-Command",
    "cd '$PSScriptRoot'; py -3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8001"
)

Start-Sleep -Seconds 3
Start-Process "http://localhost:8001"
