"""임시부재(1C)를 **학습에서 빼는** 두 번째 모델 — 비지도/지도학습 탭.

현업 확인(2026-08-15): 1C는 임시 용접이라 작업도 결과 처리도 불완전하다.
그래서 **학습 항목이 되어서는 안 된다** — 1C 포함은 참고용이고, 미포함이 진짜
검토용·학습용이다.

여기서 지키는 것은 셋이고, 셋 다 **아무 데서도 오류가 나지 않는** 종류다:

1. 「제외」가 **거르기가 아니라 다시 학습하기**여야 한다.
   판정 대상의 93%가 1C이므로 지금의 «흔한 조합»은 임시 용접의 모양이다.
   결과만 걸러 내면 남은 행의 점수가 여전히 1C가 만든 분포로 매긴 값이라,
   그건 «뺐다»가 아니라 «감췄다»다. 화면은 똑같아 보인다.

2. **Check 13 판정은 안 바뀐다.** §11-11에서 현업이 「1C 도면도 다른 행과
   똑같이 판정한다」로 정했다. 두 번째 모델이 플래그를 만들면 결함 목록·부서
   실적·Excel·메일이 전부 따라 움직이는데, 그 결정과 정면으로 부딪힌다.

3. 지도학습의 두 열(`by_result` / `by_result_all`)이 **같은 기준**이어야 한다.
   한쪽만 거르면 차이가 «규칙 변경 때문»인지 «1C 때문»인지 구분할 수 없어,
   두 열을 나란히 두는 이유 자체가 무너진다.
"""
from __future__ import annotations

import pytest

from backend.services import anomaly, result_store, verifier as V
from backend.services import wps_rules
from backend.services.verifier import Col
from tests.test_checks_16_17 import FakeLoader, make_row


# ── 판정 엔진: 두 번째 학습 ─────────────────────────────────────────────────
def _feat_row(i: int, temp: bool, odd: bool = False) -> tuple[int, tuple]:
    """1C / 비1C 행을 만든다. `odd`면 나머지와 다른 조합이라 이상치 후보가 된다."""
    return (i, make_row(
        DRAWING_NO=("1C-%04d" % i) if temp else ("2A-%04d" % i),
        JOINT_NO=str(i),
        WPS_NO="TR-FC-G01",
        MATERIAL1="API5L" if odd else "ASTM A36",
        GROOVE="FL" if odd else "DB",
        NDT_CAT="A1" if odd else "C5",
        DEPARTMENT="D9" if odd else "D1",
        TEAM="T9" if odd else "T1",
        THICKNESS1="90" if odd else "12",
        WELD_DATE="2026-01-05",
        NDT_DATE="2026-01-10",
    ))


def _checker(rows: list[tuple[int, tuple]]) -> V.QCChecker:
    c = V.QCChecker(FakeLoader({}))
    c._enabled = {}
    c._rules, c._rule_problems = [], []
    c._judged_rows_cache = rows
    return c


@pytest.fixture
def temp_1c(monkeypatch):
    """`1C`를 임시부재 접두사로 고정한다 — 프로파일에 의존하지 않게."""
    monkeypatch.setattr(wps_rules, "temp_member_prefixes", lambda: ("1C",))
    return "1C"


@pytest.mark.synthetic
@pytest.mark.skipif(not anomaly.is_available(), reason="scikit-learn 미설치 환경")
def test_the_second_model_learns_from_a_different_population(temp_1c):
    """**거르기가 아니라 다시 학습하기**여야 한다.

    1C 200행 + 비1C 60행을 준다. 두 번째 모델의 `total_rows`가 60이면 다시
    학습한 것이고, 260이면 «전부로 학습한 뒤 결과만 거른» 것이다 — 후자는
    화면에서 구분이 안 되고, 남은 행의 점수가 1C가 만든 분포에서 나온다.
    """
    rows = [_feat_row(i, temp=True) for i in range(1, 201)]
    rows += [_feat_row(i, temp=False) for i in range(201, 261)]
    c = _checker(rows)
    c._detect_check13_anomalies()

    assert c.ml_meta["total_rows"] == 260, "1차(참고용)는 전량으로 학습한다"
    assert c.ml_excl_temp_rows == 60
    assert c.ml_excl_temp_meta is not None, "1C가 있는데 두 번째 학습이 없다"
    assert c.ml_excl_temp_meta["total_rows"] == 60, \
        "결과만 거르고 학습은 전량으로 했다 — «뺐다»가 아니라 «감췄다»가 된다"


@pytest.mark.synthetic
@pytest.mark.skipif(not anomaly.is_available(), reason="scikit-learn 미설치 환경")
def test_the_second_model_never_creates_a_flag(temp_1c):
    """§11-11: 1C도 다른 행과 똑같이 판정한다. 두 번째 학습은 **보기**일 뿐이다.

    플래그를 만들면 결함 목록·부서 실적·Excel·메일이 전부 따라 움직인다.
    """
    rows = [_feat_row(i, temp=True) for i in range(1, 201)]
    rows += [_feat_row(i, temp=False) for i in range(201, 261)]
    rows.append(_feat_row(999, temp=False, odd=True))
    c = _checker(rows)
    c._detect_check13_anomalies()

    flagged = {r for r, fl in c.row_flags.items()
               if any(f.check_no == "13" for f in fl)}
    assert flagged, "1차 학습이 이상치를 하나도 못 찾았다 — 시험 데이터가 약하다"
    assert c.ml_excl_temp_detail, "두 번째 학습이 아무것도 못 찾았다 — 시험이 헛돈다"

    # **플래그 수는 1차 학습이 찾은 수와 정확히 같아야 한다.** 두 번째가 하나라도
    # 보태면 여기가 커진다 — 두 모델의 이상치가 겹치지 않는 행이 있기 때문이다.
    assert len(flagged) == c.ml_meta["anomaly_count"], \
        "Check 13 플래그가 1차 학습이 찾은 수와 다르다 — 두 번째가 새어 나왔다"
    assert c.stats["13"] == c.ml_meta["anomaly_count"]
    assert c._scope["13"] == len(rows), "관문 계측이 두 번 세어졌다"


@pytest.mark.synthetic
@pytest.mark.skipif(not anomaly.is_available(), reason="scikit-learn 미설치 환경")
def test_no_temp_member_means_no_second_model(temp_1c):
    """1C가 한 행도 없으면 두 번째를 만들지 않는다.

    같은 결과를 두 벌 담으면 payload만 커지고, 화면이 «두 기준이 있다»고 잘못
    읽어 있지도 않은 선택지를 내민다.
    """
    c = _checker([_feat_row(i, temp=False) for i in range(1, 121)])
    c._detect_check13_anomalies()
    assert c.ml_excl_temp_meta is None
    assert c.ml_excl_temp_detail == {}


# ── 지도학습: 라벨 집계 ─────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_both_label_columns_use_the_same_basis(temp_1c):
    """`by_result`(이번 회차)와 `by_result_all`(기록 전체)이 같은 기준이어야 한다.

    한쪽만 거르면 두 열의 차이가 «규칙이 바뀌어 대조할 행이 사라졌다»인지
    «1C를 뺐다»인지 구분할 수 없다. 두 열을 나란히 두는 이유 자체가 무너진다.
    """
    fb = {
        "1C-0001|J1|W1|3": {"result": "오탐"},
        "1C-0002|J2|W1|3": {"result": "오탐"},
        "2A-0001|J3|W1|3": {"result": "결함확정"},
    }
    # DB 없이도 `by_result_all`은 계산된다(기록 파일만 보므로).
    got = result_store.review_counts(fb, exclude_temp=True,
                                     path=_empty_db())
    assert got["by_result_all"] == {"결함확정": 1}, \
        "기록 전체 쪽이 1C를 그대로 세고 있다"

    got_all = result_store.review_counts(fb, exclude_temp=False,
                                         path=_empty_db())
    assert got_all["by_result_all"] == {"결함확정": 1, "오탐": 2}


def _empty_db():
    """flag가 하나도 없는 임시 DB. `by_result_all`만 보는 시험용이다."""
    import tempfile
    from pathlib import Path
    p = Path(tempfile.mkdtemp()) / "qc.db"
    result_store.connect(p).close()
    return p


# ── 화면이 두 기준을 갈라 보여주는가 ────────────────────────────────────────
@pytest.mark.synthetic
def test_the_screen_switches_the_model_instead_of_filtering():
    """화면이 `excl_temp` 블록으로 **갈아타는지** 정적으로 본다.

    목록만 거르도록 되돌아가면 아무 오류도 나지 않고 숫자만 조용히 틀린다.
    정규식을 쓰지 않는다 — `\\b`가 리터럴 백스페이스가 되어 영원히 매칭되지
    않는 테스트가 두 번 통과한 적이 있다.
    """
    from pathlib import Path
    js = (Path(__file__).resolve().parents[1]
          / "frontend" / "static" / "js" / "app.js").read_text(encoding="utf-8")
    assert "ml.excl_temp" in js, "화면이 두 번째 학습 블록을 아예 안 본다"
    assert "excludeTemp: true" in js, "비지도학습 탭의 기본이 «제외»가 아니다"
    assert "MLS_EXCLUDE_TEMP = true" in js, "지도학습 탭의 기본이 «제외»가 아니다"
    # 사이드바 배지는 Check 13 결함 건수라 **포함 기준으로 고정**이다.
    # 보고 있는 쪽을 따라 움직이면 사이드바와 결함 목록이 갈라진다.
    assert "badge && ml.meta" in js, "배지가 보고 있는 쪽을 따라 움직인다"


@pytest.mark.synthetic
def test_a_missing_second_model_is_not_called_an_empty_dataset():
    """`excl_temp`가 없는 데는 **두 이유**가 있다.

        1C가 정말 한 행도 없다        -> 「두 기준이 같습니다」가 맞다
        이 회차가 기능 도입 «전»이다   -> 「1C가 없다」는 **틀린 단정**이다

    화면에서는 둘 다 그냥 키가 없는 것으로 보인다. 실제로 판정 대상의 93%가
    1C인 회차에서 「이번 물량에는 1C 도면이 없어 두 기준이 같습니다」가 나갔고,
    **같은 화면의 대시보드 토글은 5,142행이라고 말하고 있었다.** 오류는 나지
    않는다 — 문장이 그럴듯해서 그대로 믿는다.

    이 저장소가 「0건은 두 가지 뜻이다」로 이미 한 번 겪은 것과 같은 종류다.
    """
    from pathlib import Path
    js = (Path(__file__).resolve().parents[1]
          / "frontend" / "static" / "js" / "app.js").read_text(encoding="utf-8")
    body = js[js.index("function _mluSyncTempBtn("):]
    body = body[:body.index("\n}")]
    assert "temp_judged_rows" in body, \
        "«1C가 없다»와 «옛 회차다»를 구분하지 않는다 — 틀린 사실을 단정한다"


@pytest.mark.synthetic
def test_the_screen_says_which_basis_it_is_showing():
    """건수가 Check 13과 다른 이유를 **화면이 말해야** 한다.

    말하지 않으면 「탭에는 6건인데 결함은 81건」이 되어 어느 쪽이 맞는지
    보는 사람이 알 방법이 없다.
    """
    from pathlib import Path
    js = (Path(__file__).resolve().parents[1]
          / "frontend" / "static" / "js" / "app.js").read_text(encoding="utf-8")
    body = js[js.index("function _mluModelHtml("):]
    body = body[:body.index("\n}")]
    assert "Check 13" in body and "다릅니다" in body, \
        "1C 제외 화면이 «Check 13 건수와 다르다»를 말하지 않는다"
    assert "참고용" in body, "1C 포함 화면이 «참고용»이라고 말하지 않는다"


@pytest.mark.synthetic
def test_the_supervised_tab_does_not_blame_the_wrong_cause():
    """1C를 뺀 상태의 «라벨 0건»은 원인이 다르다.

    실측(TRION): 1C 포함이면 결함확정 875 · 오탐 18인데, 빼면 **둘 다 0**이다.
    지금까지의 검토가 대부분 1C 행에 대해 이뤄졌다는 뜻이다.

    그런데 화면의 기존 설명은 「그 판정을 낳은 규칙을 이미 고쳐서 대조할 행이
    없다 -> 검증 이력 보관이 먼저다」였다. 1C를 뺀 상태에서는 **틀린 이유를
    자신 있게 말하는** 셈이고, 그걸 본 사람은 엉뚱한 일을 하러 간다.
    오류는 나지 않는다 — 문장이 그럴듯하기 때문에 더 나쁘다.
    """
    from pathlib import Path
    js = (Path(__file__).resolve().parents[1]
          / "frontend" / "static" / "js" / "app.js").read_text(encoding="utf-8")
    body = js[js.index("async function loadMlSupLabels("):]
    body = body[:body.index("\n}\n")]
    assert "MLS_EXCLUDE_TEMP && pos + neg" in body, \
        "1C 제외 기준의 «라벨 없음»을 따로 설명하지 않는다"
    assert "임시 용접의 기록이라 학습에 쓸 수 없습니다" in body, \
        "1C를 포함하면 건수가 느는 이유를 말하지 않는다"
