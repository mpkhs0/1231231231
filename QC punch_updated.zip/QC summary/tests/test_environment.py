"""
테스트 환경 자체에 대한 계약.

이 저장소에는 requirements.txt 도 CI 도 없다. 다른 PC(사내 오프라인 단말)에서
`python -m pytest tests/ -v` 를 돌렸을 때 **선택적 의존성이 없다는 이유로 수집
단계에서 깨지는 일**이 없어야 한다. 여기서 그 계약을 못 박는다.

- scikit-learn / numpy 없음 -> Check 13(이상치) 비활성화, 임포트는 성공해야 한다
- pywin32(win32com) 없음 -> Outlook 연동 비활성화, 테스트에는 영향 없어야 한다
- openpyxl 은 verifier 의 필수 의존이지만, 테스트는 verifier 를 임포트하지 않고
  결과 페이로드만 보므로 없어도 대부분 돈다
"""
from __future__ import annotations

import importlib.util

import pytest

pytestmark = pytest.mark.synthetic

OPTIONAL_MODULES = ("sklearn", "numpy", "win32com", "openpyxl", "fastapi")


HEAVY_MODULES = ("sklearn", "numpy", "openpyxl", "win32com", "fastapi")


def test_test_helpers_import_without_optional_deps() -> None:
    """
    검사기/합성데이터 모듈은 표준 라이브러리만으로 임포트돼야 한다.
    (backend.services.verifier 를 끌어오면 openpyxl 이 필수가 되어 버린다.)

    별도 프로세스에서 임포트해 sys.modules 를 직접 확인한다. 같은 프로세스에서는
    다른 테스트가 이미 무거운 모듈을 올려놨을 수 있어 판별이 안 된다.
    """
    import subprocess
    import sys as _sys
    from pathlib import Path

    tests_dir = Path(__file__).resolve().parent
    code = (
        "import sys; sys.path.insert(0, r'%s');"
        "import qc_invariants, synthetic;"
        "loaded=[m for m in %r if m in sys.modules];"
        "print('LOADED:' + ','.join(loaded))" % (tests_dir, HEAVY_MODULES)
    )
    proc = subprocess.run([_sys.executable, "-c", code], capture_output=True, text=True)
    assert proc.returncode == 0, f"helper import failed: {proc.stderr[-500:]}"
    loaded = proc.stdout.strip().split("LOADED:")[-1].strip()
    assert not loaded, (
        f"test helpers pulled in optional/heavy modules: {loaded}. "
        "They must stay importable on a PC without scikit-learn or pywin32."
    )


def test_anomaly_module_degrades_without_sklearn() -> None:
    """
    Check 13 은 scikit-learn 이 없으면 조용히 비활성화돼야 한다 (예외로 죽으면 안 된다).
    sklearn 이 설치돼 있든 없든 `_AVAILABLE` 플래그가 존재하고 bool 이어야 한다.
    """
    try:
        from backend.services import anomaly
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"backend.services.anomaly must import without sklearn: {exc!r}")
    assert isinstance(anomaly._AVAILABLE, bool)
    if not anomaly._AVAILABLE:
        assert anomaly.MIN_ROWS_REQUIRED > 0


def test_optional_dependency_report() -> None:
    """
    어떤 선택적 의존이 이 PC 에 있는지 기록만 남긴다 (실패 조건 아님).
    -v 로 돌릴 때 skip 사유를 이해하는 데 쓴다.
    """
    present = [m for m in OPTIONAL_MODULES if importlib.util.find_spec(m) is not None]
    missing = [m for m in OPTIONAL_MODULES if m not in present]
    # 하나도 없어도 테스트 수집/실행은 성공해야 한다.
    assert isinstance(present, list) and isinstance(missing, list)


@pytest.mark.parametrize("module_name", OPTIONAL_MODULES)
def test_missing_optional_module_does_not_break_collection(module_name: str) -> None:
    """선택적 모듈이 없으면 그 사실만 확인하고 skip - 실패로 만들지 않는다."""
    if importlib.util.find_spec(module_name) is None:
        pytest.skip(f"{module_name} not installed (optional)")
    assert importlib.util.find_spec(module_name) is not None


def test_config_paths_are_importable() -> None:
    """backend.config 는 표준 라이브러리만 쓰므로 항상 임포트돼야 한다."""
    from backend import config

    for attr in ("APP_STATE_FILE", "FEEDBACK_FILE", "UPLOADS_DIR", "RESULTS_DIR"):
        assert hasattr(config, attr), f"backend.config is missing {attr}"
