"""
경로 파라미터에 «값에 `/`가 들어갈 수 있는 것»을 두지 않았는지 정적으로 본다.

실제로 두 번 당했다. 부서명 `Q530-SMR/ITER생산부`(실데이터에 있다)를
경로 세그먼트로 받으면:

    /api/departments/Q530-SMR%2FITER생산부/defects
        -> ASGI 서버가 라우팅 «전»에 경로를 풀어 세그먼트가 갈라진다
        -> 어느 라우트에도 안 맞아 404

`encodeURIComponent`로 감싸도 막히지 않는다. 그리고 404가 화면에서
«결함 0건»이 아니라 **빈 표**로 보이기 때문에, 그 부서만 조용히 사라진다
(실제 122건이 있었고 아무도 모르고 있었다).

부서 결함 목록은 질의 파라미터로 옮겼고, 부서 메일 발송도 같은 이유로 옮겼다.
사번·행번호·항목 ID처럼 형식이 고정된 것은 경로에 두어도 된다.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

ROUTERS = Path(__file__).resolve().parent.parent / "backend" / "routers"

_ROUTE_RE = re.compile(r"@router\.(get|post|put|delete)\(\s*[\"']([^\"']+)[\"']")

# 값에 `/`가 들어올 수 있는 이름들. 전부 엑셀에서 그대로 들어온 문자열이다.
_FREEFORM = ("dept", "department", "team", "welder", "drawing", "joint",
             "wps", "block", "material")


def _routes() -> list[tuple[str, str, str]]:
    out: list[tuple[str, str, str]] = []
    for py in ROUTERS.glob("*.py"):
        for m in _ROUTE_RE.finditer(py.read_text(encoding="utf-8")):
            out.append((py.name, m.group(1), m.group(2)))
    return out


@pytest.mark.synthetic
def test_routes_are_found():
    assert len(_routes()) > 20, "라우트를 못 읽었다 - 정규식이 형식과 어긋났다"


@pytest.mark.synthetic
def test_no_freeform_name_sits_in_a_path_segment():
    bad: list[str] = []
    for fname, verb, path in _routes():
        for param in re.findall(r"\{([^}:]+)", path):
            low = param.lower()
            if any(k in low for k in _FREEFORM):
                bad.append(f"{fname}  {verb.upper()} {path}  (파라미터 {param})")
    assert not bad, (
        "이름에 `/`가 들어갈 수 있는 값이 경로에 있다 - 그 부서/팀만 404가 된다:\n  "
        + "\n  ".join(bad)
    )


@pytest.mark.synthetic
def test_the_two_endpoints_that_were_fixed_stay_query_based():
    """되돌리기 쉬운 형태라 이름으로 못 박아 둔다."""
    paths = {p for _, _, p in _routes()}
    assert "/departments/defects" in paths
    assert "/departments/send" in paths
    for gone in ("/departments/{dept}/defects", "/departments/{department}/send"):
        assert gone not in paths, f"경로 파라미터 방식으로 되돌아갔다: {gone}"


@pytest.mark.synthetic
def test_frontend_calls_them_as_query_parameters():
    """서버만 고치고 화면을 두면 그대로 404다."""
    app_js = (Path(__file__).resolve().parent.parent / "frontend" / "static"
              / "js" / "app.js").read_text(encoding="utf-8")
    assert "/api/departments/defects?" in app_js
    assert "/api/departments/send?department=" in app_js
    assert "'/api/departments/' + encodeURIComponent" not in app_js, \
        "부서명을 경로에 붙이는 호출이 남아 있다"
    assert "/api/teams/send?department=" in app_js


@pytest.mark.synthetic
def test_exports_tab_knows_team_recipients():
    """팀 행에 발송 버튼을 띄우려면 팀 수신인 설정을 받아와야 한다.

    부서 수신인만 받아오면 팀 버튼이 **영구히 비활성**이고, 등록은 됐는데
    버튼이 안 켜지는 모습이라 «설정이 저장되지 않았다»로 오해하게 된다.
    """
    app_js = (Path(__file__).resolve().parent.parent / "frontend" / "static"
              / "js" / "app.js").read_text(encoding="utf-8")
    assert "/api/settings/team-recipients" in app_js
    assert "EX.teamRecipients" in app_js
    assert "s.kind !== 'dept' && s.kind !== 'team'" in app_js, \
        "발송 버튼이 부서 범위에만 붙어 있다"


# ---- 임시부재 제외는 «파일이 달라지는» 조건이다 ---------------------------
#
# 범위별 내보내기의 1C 토글은 대시보드 토글과 성격이 다르다. 대시보드는 보는
# 방식만 바꾸지만 여기서는 **만들어지는 파일이 바뀐다.** 그래서 캐시 키와 파일
# 이름에 반드시 들어가야 하고, 화면이 생성·내려받기·발송 요청에 이 값을 함께
# 보내야 한다. 하나라도 빠지면 «뺀 줄 알고 받았는데 들어 있는» 파일이 나가고,
# 그건 받은 사람이 열어 보기 전에는 알 수 없다.
@pytest.mark.synthetic
def test_export_cache_key_separates_the_temp_filter():
    from backend.routers import exports

    assert exports._key("A", None, False) != exports._key("A", None, True),         "캐시 키가 같으면 두 파일이 서로를 덮어쓴다"


@pytest.mark.synthetic
def test_frontend_sends_the_temp_filter_everywhere():
    app_js = (Path(__file__).resolve().parent.parent / "frontend" / "static"
              / "js" / "app.js").read_text(encoding="utf-8")
    assert "'/api/exports' +" in app_js and "exclude_temp=1" in app_js, "목록 조회"
    assert "exclude_temp: !!EX.excludeTemp" in app_js, "생성 요청"
    assert "qs.set('exclude_temp', '1')" in app_js, "내려받기"
    assert "EX.excludeTemp ? '&exclude_temp=1' : ''" in app_js, "메일 발송"


@pytest.mark.synthetic
def test_export_endpoints_accept_the_temp_filter():
    """서버 쪽 네 군데가 모두 이 값을 받아야 한다."""
    import inspect

    from backend.routers import exports, settings

    for fn in (exports.list_exports, exports.download_export,
               settings.send_department_report, settings.send_team_report):
        assert "exclude_temp" in inspect.signature(fn).parameters,             f"{fn.__name__}가 임시부재 제외를 받지 않는다"
    assert "exclude_temp" in exports.BuildIn.model_fields
