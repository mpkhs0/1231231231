"""
검사 이행 축 — Check 16(NDT 요구 대비 미수행) · Check 17(VT 미수행)과
Check 5 재정의(B안)를 고정한다.

## 이 세 가지를 한 파일에 묶은 이유

Check 1~12는 **«기재된 값이 규칙에 맞는가»**를 본다. 16·17은 **«해야 할 검사를
했는가»**를 본다 — 원본 매크로에 없던 축이고, 실제로 선급 검사에서 걸리는 쪽이다.

Check 5 재정의도 같은 뿌리다. 예전 Check 5는 "NDT Cat A/B면 G03을 쓰라"고 무조건
지적했는데, 실데이터 1,389건 중 955건은 **G03으로 옮기는 것이 물리적으로 불가능**했다
(G03의 Joint Detail에 FL·PP가 없고 두께 상한이 38mm). 시정 방법이 없는 지적은
현장에서 통째로 무시되므로, 옮길 수 있는 것만 남기도록 바꿨다.

## 실데이터를 쓰지 않는 이유

여기 있는 테스트는 전부 **손으로 만든 행 튜플**로 돈다. 판정 조건이 정확히
무엇인지(유예 며칠, 어느 열이 짝인지)를 코드 없이 읽을 수 있어야 하기 때문이다.
실데이터 대조는 `qc-data-verifier` 에이전트와 `test_invariants.py`의 몫이다.
"""
from __future__ import annotations

import inspect
from datetime import date

import pytest

from backend.services import verifier as V
from backend.services.verifier import Col


# ── 행 만들기 ────────────────────────────────────────────────────────────────
_WIDTH = 80          # BV열(74)까지 넉넉히


def make_row(**cells: object) -> tuple:
    """`Col` 상수 이름을 키로 받아 엑셀 행 튜플을 만든다.

    `make_row(WPS_NO='TR-FC-G01', VT_DATE='')` 처럼 쓴다. 열 번호를 테스트마다
    손으로 세면 «AJ가 36이었나 37이었나»로 조용히 틀린다.
    """
    row: list[object] = [None] * _WIDTH
    for name, val in cells.items():
        row[getattr(Col, name) - 1] = val
    return tuple(row)


class FakeLoader:
    """`wps_table`만 있으면 되는 최소 로더."""

    def __init__(self, wps_table: dict | None = None) -> None:
        self.wps_table = wps_table or {}
        self.welder_qual = {}
        self.retired_welders = set()
        self.welder_names = {}
        self.welder_certs = {}
        self.qmg_rows = []


def make_checker(ref: date | None = date(2026, 7, 6),
                 grace: int = 30,
                 wps_table: dict | None = None) -> V.QCChecker:
    c = V.QCChecker(FakeLoader(wps_table))
    c._ref_date = ref
    c._grace_days = grace
    return c


# ── Check 17 — VT 미수행 ─────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_c17_flags_vt_blank_past_grace():
    c = make_checker()
    row = make_row(WELD_DATE=date(2026, 5, 1), VT_DATE=None)   # 66일 경과
    f = c._c17_vt_missing(row)
    assert f is not None
    assert f.check_no == "17"
    assert f.col == Col.VT_DATE, "마킹은 VT 날짜 열(BI)에 해야 한다"
    assert f.color == "Navy"


@pytest.mark.synthetic
def test_c17_silent_inside_grace():
    """용접 직후에는 VT가 아직 안 끝난 것이 정상이다.

    유예가 없으면 최근 용접분이 통째로 결함이 되어 지표가 못 쓰게 된다.
    """
    c = make_checker()
    row = make_row(WELD_DATE=date(2026, 6, 20), VT_DATE=None)  # 16일 경과 < 30
    assert c._c17_vt_missing(row) is None


@pytest.mark.synthetic
def test_c17_boundary_is_inclusive():
    """정확히 유예일수만큼 지난 날은 «지적»이다 — 경계가 흔들리면 건수가 변한다."""
    c = make_checker(grace=30)
    assert c._c17_vt_missing(make_row(WELD_DATE=date(2026, 6, 6))) is not None   # 30일
    assert c._c17_vt_missing(make_row(WELD_DATE=date(2026, 6, 7))) is None       # 29일


@pytest.mark.synthetic
def test_c17_silent_when_vt_done():
    c = make_checker()
    row = make_row(WELD_DATE=date(2026, 1, 1), VT_DATE=date(2026, 1, 5))
    assert c._c17_vt_missing(row) is None


@pytest.mark.synthetic
def test_c17_silent_without_weld_date():
    """용접일이 없으면 «며칠 지났는지»를 알 수 없다 — 그건 Check 1의 영역이다."""
    c = make_checker()
    assert c._c17_vt_missing(make_row(WELD_DATE=None, VT_DATE=None)) is None


@pytest.mark.synthetic
def test_c17_silent_without_reference_date():
    """기준일을 못 정했으면(용접일이 한 건도 없는 데이터) 아무것도 지적하지 않는다."""
    c = make_checker(ref=None)
    assert c._c17_vt_missing(make_row(WELD_DATE=date(2020, 1, 1))) is None


# ── 기준일은 «오늘»이 아니다 ─────────────────────────────────────────────────
@pytest.mark.synthetic
def test_reference_date_is_data_not_today():
    """같은 파일을 언제 돌려도 같은 결과가 나와야 한다.

    `date.today()`를 쓰면 내일 다시 돌릴 때 Check 17 건수가 늘어난다. 그러면
    검증 이력 비교(개선계획 9번)에서 «코드가 바뀐 것»과 «날짜가 흐른 것»을
    구분할 수 없다. 그래서 기준일은 데이터 안의 최종 용접일이다.
    """
    loader = FakeLoader()
    loader.qmg_rows = [
        (6, make_row(WPS_NO="TR-A", WELD_DATE=date(2026, 3, 1))),
        (7, make_row(WPS_NO="TR-A", WELD_DATE=date(2026, 7, 6))),   # 최종
        (8, make_row(WPS_NO="TR-A", WELD_DATE=date(2026, 5, 9))),
    ]
    c = V.QCChecker(loader)
    c.run()
    assert c._ref_date == date(2026, 7, 6)
    assert c._ref_date != date.today(), "«오늘»을 기준일로 쓰면 결과가 매일 달라진다"


# ── Check 16 — NDT Extent 대비 미수행 ───────────────────────────────────────
@pytest.mark.synthetic
def test_c16_flags_required_but_not_done():
    c = make_checker()
    row = make_row(WELD_DATE=date(2026, 5, 1), NDT_EXT_UT=100, UT_DATE=None)
    flags = c._c16_ndt_extent(row)
    assert len(flags) == 1
    assert flags[0].check_no == "16"
    assert flags[0].col == Col.UT_DATE
    assert flags[0].color == "Olive"


@pytest.mark.synthetic
def test_c16_silent_when_done():
    c = make_checker()
    row = make_row(WELD_DATE=date(2026, 5, 1), NDT_EXT_UT=100,
                   UT_DATE=date(2026, 5, 3))
    assert c._c16_ndt_extent(row) == []


@pytest.mark.synthetic
def test_c16_ignores_non_numeric_extent():
    """실데이터의 RT Extent 열에는 담당자가 적어 넣은 메모가 섞여 있다.

    실제 값: '리페어WPS구분?' 1건. «공란이 아니다»를 «요구된다»로 읽으면 오탐이다.
    """
    c = make_checker()
    row = make_row(WELD_DATE=date(2026, 5, 1), NDT_EXT_RT="리페어WPS구분?", RT_DATE=None)
    assert c._c16_ndt_extent(row) == []


@pytest.mark.synthetic
def test_c16_ignores_zero_extent():
    c = make_checker()
    row = make_row(WELD_DATE=date(2026, 5, 1), NDT_EXT_MT=0, MT_DATE=None)
    assert c._c16_ndt_extent(row) == []


@pytest.mark.synthetic
def test_c16_each_ndt_type_flags_its_own_date_column():
    """Extent 열(S~V)과 수행일 열(BM/BP/BS/BV)이 엑셀에서 멀리 떨어져 있어
    짝을 바꿔 넣기 쉽다. 네 쌍 전부를 고정한다."""
    c = make_checker()
    row = make_row(WELD_DATE=date(2026, 5, 1),
                   NDT_EXT_RT=100, NDT_EXT_UT=20, NDT_EXT_MT=10, NDT_EXT_PT=100)
    got = {f.col for f in c._c16_ndt_extent(row)}
    assert got == {Col.RT_DATE, Col.UT_DATE, Col.MT_DATE, Col.PT_DATE}


@pytest.mark.synthetic
def test_c16_respects_grace_period():
    c = make_checker()
    row = make_row(WELD_DATE=date(2026, 6, 25), NDT_EXT_UT=100, UT_DATE=None)
    assert c._c16_ndt_extent(row) == [], "유예 안이면 아직 진행 중이다"


# ── Check 5는 제거됐다 (현업 확인 2026-08-10) ───────────────────────────────
@pytest.mark.synthetic
def test_check5_is_no_longer_generated():
    """현업 확인 결과 «NDT Cat A/B -> TR-FC-G03» 규칙 자체가 불필요했다(§11-2).

    번호 5와 7은 **재사용하지 않는다** — 검토 기록 키가 `…|Check No`라서
    재사용하면 이미 붙은 라벨 426건이 무관한 항목에 붙는다.
    """
    src = inspect.getsource(V)
    assert "def _c5_special_p_g01" not in src, "판정 함수가 남아 있다"
    assert "Flag(7," not in src, "Check 7(중복 2+5)은 Check 5에 딸린 것이라 함께 빠져야 한다"
    # 색/이름 정의는 남아야 한다 — 이미 붙은 라벨이 화면에서 읽혀야 한다
    assert V.CHECK_NAMES.get(5) and V.CHECK_NAMES.get(7)
    assert V.CHECK_COLORS.get(5) and V.CHECK_COLORS.get(7)


@pytest.mark.synthetic
def test_wps_corrections_are_applied_to_the_table():
    """WPS 문서의 «기재 누락»은 표를 읽은 직후 한 곳에서 보정한다.

    현업 확인 결과 Check 4·11의 622건이 «적히지 않았을 뿐 자격은 있는» 것이었다.
    판정 코드 여기저기서 보정을 따지면 어느 Check가 무엇을 보정했는지 추적할 수 없다.
    """
    from backend.services import wps_rules

    table = {"TR-FC-G01": {"joint_detail": "SB, DB, SV, DV, FL",
                           "materials": [{"base_metal": "NV E36", "thk_range": "3~50"}]},
             "TR-SMFC-G01": {"joint_detail": "SB",
                             "materials": [{"base_metal": "ASTM A36", "thk_range": "3~24"}]}}
    wps_rules.apply_corrections(table)

    assert V._groove_in_joint_detail("PP", table["TR-FC-G01"]["joint_detail"])
    blob = " ".join(m["base_metal"] for m in table["TR-SMFC-G01"]["materials"])
    assert "A500" in blob

    # 기존 항목의 두께 범위를 물려받으면 안 된다 — 새 항목으로 붙어야 한다
    added = [m for m in table["TR-SMFC-G01"]["materials"] if "A500" in m["base_metal"]]
    assert added and added[0]["thk_range"] == "", "추가 재질이 남의 두께 범위를 물려받았다"


@pytest.mark.synthetic
def test_corrections_are_idempotent():
    """두 번 적용해도 같은 값이어야 한다 — 재검증 때마다 문자열이 늘어나면 안 된다."""
    from backend.services import wps_rules

    table = {"TR-FC-G01": {"joint_detail": "SB", "materials": []}}
    wps_rules.apply_corrections(table)
    once = (table["TR-FC-G01"]["joint_detail"], len(table["TR-FC-G01"]["materials"]))
    wps_rules.apply_corrections(table)
    assert (table["TR-FC-G01"]["joint_detail"],
            len(table["TR-FC-G01"]["materials"])) == once


# ── Check 18: 용접봉 Lot 미기재 ─────────────────────────────────────────────
@pytest.mark.synthetic
def test_c18_flags_missing_lot():
    """Lot 번호와 WPS 브랜드명을 대조할 방법이 없어 «누락만» 본다(§11-12)."""
    c = make_checker()
    assert c._c18_consumable_lot(make_row(CONSUMABLE_LOT=None)) is not None
    assert c._c18_consumable_lot(make_row(CONSUMABLE_LOT="")) is not None
    f = c._c18_consumable_lot(make_row(CONSUMABLE_LOT=None))
    assert f.check_no == "18" and f.col == Col.CONSUMABLE_LOT and f.color == "Rose"


@pytest.mark.synthetic
def test_c18_silent_when_lot_present():
    c = make_checker()
    assert c._c18_consumable_lot(make_row(CONSUMABLE_LOT="F902A5C5A7")) is None


# ── 헬퍼 ─────────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_thickness_helper_is_gone_with_check5():
    """`_max_thickness_of()`는 Check 5의 «G03으로 옮길 수 있는가» 판단 전용이었다.

    Check 5가 사라졌으므로 함께 뺐다. 남겨 두면 아무도 부르지 않는 코드가
    «쓰이고 있다»는 인상을 준다.
    """
    assert not hasattr(V, "_max_thickness_of")


@pytest.mark.synthetic
def test_groove_matching_preserves_check4_behavior():
    """Check 4에서 모듈 헬퍼로 올릴 때 동작이 바뀌지 않았음을 고정한다."""
    jd = "SB, DB, SV, DV"
    assert V._groove_in_joint_detail("SB", jd)
    assert V._groove_in_joint_detail("sb", jd), "대소문자를 가리면 안 된다"
    assert not V._groove_in_joint_detail("FL", jd)
    # 괄호 주석과 repair/multi 같은 수식어는 걷어낸다
    assert V._groove_in_joint_detail("SB", "SB (repair only), DB")
    # PP는 WPS 표기가 PJP인 경우가 있다
    assert V._groove_in_joint_detail("PP", "CJP, PJP")
    # 판단 근거가 없으면 «아니다»라고 단정하지 않는다
    assert V._groove_in_joint_detail("SB", "")
    assert V._groove_in_joint_detail("", jd)


@pytest.mark.synthetic
def test_joint_detail_tokens_feed_the_check4_message():
    """Check 4의 오류 메시지가 보여주는 «허용 목록»은 판정에 쓴 것과 같아야 한다."""
    assert V._joint_detail_tokens("SB, DB (both sides), SV") == {"SB", "DB", "SV"}


# ── 색상 정의 4곳이 함께 갱신됐는지 ─────────────────────────────────────────
@pytest.mark.synthetic
def test_every_check_has_all_four_color_definitions():
    """`_FILLS` / `CHECK_COLORS` / `CHECK_NAMES` / `_PRIORITY` 네 곳은 항상 함께
    갱신해야 한다. Check를 추가할 때 가장 자주 빠뜨리는 곳이다.

    빠뜨려도 예외가 나지 않는다 — 색이 안 칠해지거나 이름이 빈 채로 리포트가
    나갈 뿐이라, 이렇게 강제하지 않으면 발견이 늦는다.
    """
    for check_no, color in V.CHECK_COLORS.items():
        assert color in V._FILLS, f"Check {check_no}: 색 '{color}'이 _FILLS에 없다"
        assert color in V._PRIORITY, f"Check {check_no}: 색 '{color}'이 _PRIORITY에 없다"
        assert check_no in V.CHECK_NAMES, f"Check {check_no}: CHECK_NAMES에 이름이 없다"
    assert set(V.CHECK_NAMES) == set(V.CHECK_COLORS), \
        "이름만 있고 색이 없거나, 그 반대인 Check가 있다"


@pytest.mark.synthetic
def test_priority_has_no_ties():
    """한 셀에 여러 Check가 걸리면 `_PRIORITY`로 **하나만** 칠한다.

    같은 순위가 둘이면 어느 쪽이 칠해질지 dict 순서에 달리게 되어, 색이
    조용히 바뀌는 재현 안 되는 버그가 된다.
    """
    vals = list(V._PRIORITY.values())
    assert len(vals) == len(set(vals)), f"_PRIORITY에 같은 순위가 있다: {V._PRIORITY}"


@pytest.mark.synthetic
def test_new_checks_are_registered():
    assert V.CHECK_COLORS[16] == "Olive"
    assert V.CHECK_COLORS[17] == "Navy"
    assert "NDT" in V.CHECK_NAMES[16]
    assert "VT" in V.CHECK_NAMES[17]


# ── 결과가 프로세스마다 같아야 한다 ─────────────────────────────────────────
@pytest.mark.synthetic
def test_welder_rate_ordering_is_deterministic():
    """동점 용접사의 순서가 파이썬 프로세스마다 달라지면 안 된다.

    `verifier.run()`이 그 행의 용접사를 **set**으로 순회하므로 `welder_totals`의
    삽입 순서가 문자열 해시 무작위화(PYTHONHASHSEED)에 좌우된다. 정렬이 안정
    정렬이라 그 순서가 동점 구간에 그대로 남는다 — 실데이터에서 117명 중 2자리가
    프로세스마다 뒤바뀌었다.

    수치는 같으니 «틀린» 것은 아니지만, 같은 파일을 두 번 돌렸을 때 결과가 다르면
    검증 이력 비교(개선계획 9번)에서 «바뀐 것»으로 보인다. 정렬 키에 용접사 번호를
    넣어 동점을 끊는다.
    """
    import random

    base = [
        {"welder_no": f"W{i:02d}", "total": 100, "defect": 10, "rate": 10.0}
        for i in range(20)
    ]
    key = lambda w: (-w["rate"], -w["defect"], w["welder_no"])   # noqa: E731

    expected = sorted(base, key=key)
    for seed in range(5):
        shuffled = base[:]
        random.Random(seed).shuffle(shuffled)
        assert sorted(shuffled, key=key) == expected, \
            "삽입 순서가 다르면 동점 구간의 순서가 달라진다"


@pytest.mark.synthetic
def test_sort_key_includes_welder_no():
    """정렬 키에서 용접사 번호를 빼면 위 성질이 조용히 사라진다."""
    import inspect

    src = inspect.getsource(V)
    assert '(-w["rate"], -w["defect"])' not in src, \
        "동점을 끊지 않는 정렬 키가 남아 있다 - 결과가 프로세스마다 달라진다"
    assert src.count('(-w["rate"], -w["defect"], w["welder_no"])') == 2, \
        "전체/부서 두 곳 모두 같은 키를 써야 한다"
