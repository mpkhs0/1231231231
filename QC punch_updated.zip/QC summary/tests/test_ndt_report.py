"""
NDT REPORT 번호(BE열)가 판정 → 저장 → 산출물까지 끊기지 않는지 본다.

## 왜 이 열인가

현업이 결함 리포트를 받고 원본을 되짚을 때 쥐고 있는 키는 **도면번호가 아니라
NDT 리포트 번호**다(`SAVI14996` 형태). 리포트 하나가 여러 조인트를 덮으므로
행마다 유일하지 않고, NDT 계획이 없는 행에는 아예 값이 없다 — 실데이터 9,997행
중 5,520행(55.2%)에만 값이 있고 서로 다른 번호가 166개다.

## 왜 «흐르는지»를 보는가

이 값은 **어디서 끊겨도 예외가 나지 않는다.** 판정 엔진이 안 담으면 빈 열이 되고,
저장소 열이 없으면 왕복에서 사라지고, Excel 열 정의에서 빠지면 표만 좁아진다.
셋 다 «표는 나오는데 추적이 안 되는» 모습이라, 받은 사람이 말해 주기 전에는
알 수 없다. 그래서 구간마다 못을 박는다.
"""
from __future__ import annotations

import re

import pytest

from backend.services import excel_report as er
from backend.services import result_store as rs
from backend.services import verifier as V


@pytest.mark.synthetic
def test_column_index_is_be():
    """BE = 57. 엑셀 양식이 바뀐 게 아니면 이 값은 움직이면 안 된다."""
    from openpyxl.utils import get_column_letter
    assert get_column_letter(V.Col.NDT_REPORT) == "BE"
    # 부서(BF)·팀(BG)과 이웃이다. 하나 밀리면 부서명이 리포트 번호로 실린다.
    assert V.Col.NDT_REPORT == V.Col.DEPARTMENT - 1


@pytest.mark.synthetic
def test_the_value_flows_through_every_stage():
    """판정 payload · 저장소 열 · 결함 목록 시트 — 세 곳 모두에 있어야 한다."""
    assert "ndt_report" in rs._FLAG_COLS, "저장소 flag 열에 없다 - 왕복에서 사라진다"
    assert "ndt_report" in rs._DEFECT_ROW_COLS, \
        "결함 행 머리말에 없다 - 부서/팀 리포트에서만 조용히 빠진다"
    assert "ndt_report" in [k for _, _, k in er._FLAG_COLS], \
        "결함 목록 시트 열 정의에 없다"


@pytest.mark.synthetic
def test_it_is_searchable():
    """리포트 번호로 검색하면 그 리포트에 걸린 결함이 한 번에 나와야 한다."""
    assert "ndt_report" in rs._FLAG_SEARCH_COLS


@pytest.mark.synthetic
def test_round_trips_through_the_store(tmp_path):
    from tests.test_result_store import make_result

    db = tmp_path / "qc.db"
    r = make_result(2)
    rs.save_run(r, path=db)

    got = rs.load_latest(path=db)
    assert [f["ndt_report"] for f in got["flags"]] == ["SAVI14996"] * 2

    hit = rs.query_flags(q="savi1499", path=db)          # 대소문자 무시
    assert hit["total"] == 2, "리포트 번호로 검색이 안 된다"

    items = rs.dept_defects("건조5부", path=db)["items"]
    assert items and all(e["ndt_report"] == "SAVI14996" for e in items), \
        "부서 결함 목록에서 빠졌다 - 메일 본문이 이걸 쓴다"


@pytest.mark.synthetic
def test_blank_is_preserved_not_invented(tmp_path):
    """값이 없는 행은 «없음»으로 남아야 한다.

    44.8%가 공란이고 그건 NDT 계획 자체가 없는 행이다. 빈 문자열을 다른 값으로
    채우거나 앞 행의 값을 물려받으면 «없는 검사기록을 가리키는» 표가 된다.
    """
    from tests.test_result_store import make_result

    db = tmp_path / "qc.db"
    r = make_result(2)
    r["flags"][1]["ndt_report"] = ""
    rs.save_run(r, path=db)

    got = rs.load_latest(path=db)
    assert [f["ndt_report"] for f in got["flags"]] == ["SAVI14996", ""]


@pytest.mark.synthetic
def test_the_number_is_visible_on_screen_too():
    """검색만 되고 «찾은 행에서 그 번호를 볼 수 없는» 상태가 되면 안 된다.

    상세 모달의 원본 데이터는 `_RAW_SNAPSHOT_COLS`가 정한다. 여기에 없으면
    번호로 찾아 놓고도 그 행이 어느 리포트의 건인지 화면에서 확인할 수 없다.
    """
    labels = [lbl for lbl, _ in V._RAW_SNAPSHOT_COLS]
    cols = [col for _, col in V._RAW_SNAPSHOT_COLS]
    assert V.Col.NDT_REPORT in cols, "원본 데이터 스냅샷에 BE열이 없다"
    assert "NDT REPORT 번호" in labels


# ---- 1차 패스와 2차 패스가 «같은 것»을 담는가 ------------------------------
#
# `row_data`와 결함 항목 머리말을 **두 곳에서 따로 만든다**:
#
#   1차 패스  `run()` 안 - Check 1~12가 걸린 행
#   2차 패스  `_register_flag()` - Check 13/14로만 걸린 행
#
# 한쪽에만 필드를 추가하면 **그 검사로만 걸린 행에서만** 값이 빈다. 실제로
# `ndt_report`를 1차에만 넣어서, Check 14만 걸린 행 4건이 부서 Excel에 번호
# 없이 나갔다(원본에는 SAVI11048이 있었다). 예외도 경고도 없이 빈 칸이다.
#
# CLAUDE.md가 «2단계 패스가 가장 자주 깨지는 곳»이라고 적어 둔 자리이고,
# 과거에도 용접사 집계에서 257행이 같은 이유로 빠진 적이 있다.
def _dict_keys_after(src: str, marker: str) -> list[str]:
    """소스에서 `marker` 뒤 첫 dict 리터럴의 키 목록."""
    body = src[src.index(marker):]
    body = body[body.index("{"):]
    depth = 0
    end = 0
    for i, ch in enumerate(body):
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                end = i
                break
    return re.findall(r"'([a-z0-9_]+)':", body[:end])


def _verifier_source() -> str:
    return open(V.__file__, encoding="utf-8").read()


@pytest.mark.synthetic
def test_both_passes_build_the_same_row_data():
    src = _verifier_source()
    first = set(_dict_keys_after(src, "self.row_data[row_num] = {"))
    second = set(_dict_keys_after(src, "if row_num not in self.row_data:"))
    assert first and second
    diff = sorted(first ^ second)
    assert not diff, f"1차/2차 패스의 row_data 필드가 다르다 (한쪽에만: {diff})"
    assert "ndt_report" in first


@pytest.mark.synthetic
def test_both_passes_build_the_same_defect_entry():
    src = _verifier_source()
    first = set(_dict_keys_after(src, "defect_entry = {"))
    second = set(_dict_keys_after(src, "            defect_entry = {"))
    assert first and second
    diff = sorted(first ^ second)
    assert not diff, f"1차/2차 패스의 결함 항목 머리말이 다르다 (한쪽에만: {diff})"
    assert "ndt_report" in first


@pytest.mark.realdata
def test_second_pass_only_rows_still_carry_the_number(real_result):
    """Check 13/14로만 걸린 행에도 번호가 실려야 한다 - 실데이터로 본다."""
    checks_by_row: dict[int, set[int]] = {}
    for f in rs.query_flags(limit=20000)["items"]:
        checks_by_row.setdefault(f["row"], set()).add(f["check_no"])
    rows = [r for r, cks in checks_by_row.items() if cks <= {13, 14}][:200]
    if not rows:
        pytest.skip("2차 패스로만 걸린 행이 없다")

    got = rs.query_flags(rows=rows, limit=20000)["items"]
    filled = sum(1 for f in got if (f.get("ndt_report") or "").strip())
    assert filled > 0, f"2차 패스로만 걸린 행 {len(rows)}건 전부 번호가 비었다"
