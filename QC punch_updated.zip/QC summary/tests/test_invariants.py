"""
qc-data-verifier 문서 §2 불변식 8종 - 합성 데이터와 실데이터 양쪽에 동일하게 적용.

에이전트를 5분 돌려서 하던 교차검증을 여기로 옮긴 것이다. 각 테스트는
`tests/qc_invariants.py` 의 순수 함수를 호출하고, 위반 목록이 비어 있는지만 본다.

**테스트가 실패하면 그것이 발견이다.** 통과시키려고 backend/ 의 판정 로직을
고치지 마라 - 그 순간 이 테스트는 아무것도 지켜주지 못하게 된다.
"""
from __future__ import annotations

import pytest

import qc_invariants as inv


def _assert_clean(violations: list[str], label: str) -> None:
    assert not violations, f"{label}: {len(violations)} violation(s)\n" + "\n".join(
        f"  - {v}" for v in violations[:20]
    )


# ---------------------------------------------------------------------------
# 2-1 행 수 회계
# ---------------------------------------------------------------------------
def test_row_accounting(result: dict) -> None:
    _assert_clean(inv.check_row_accounting(result), "2-1 row accounting")


def test_judged_rows_is_the_only_denominator(result: dict) -> None:
    """judged_rows(삭제도 미작업도 아닌 행)가 모든 결함률의 유일한 분모다."""
    assert result["judged_rows"] == result["active_rows"] - result["unworked_rows"]
    assert result["judged_rows"] <= result["active_rows"] <= result["total_rows"]


# ---------------------------------------------------------------------------
# 2-2 플래그 회계
# ---------------------------------------------------------------------------
def test_flag_accounting(result: dict) -> None:
    _assert_clean(inv.check_flag_accounting(result), "2-2 flag accounting")


def test_flags_are_at_least_as_many_as_flagged_rows(result: dict) -> None:
    """플래그는 행보다 많거나 같다 (한 행에 여러 Check 가 걸린다)."""
    assert result["total_flags"] >= result["flagged_rows"]


# ---------------------------------------------------------------------------
# 2-3 부서 -> 전사 롤업
# ---------------------------------------------------------------------------
def test_department_rollup(result: dict) -> None:
    _assert_clean(inv.check_department_rollup(result), "2-3 department rollup")


# ---------------------------------------------------------------------------
# 2-4 팀 -> 부서 롤업 (부서 전수)
# ---------------------------------------------------------------------------
def test_team_rollup(result: dict) -> None:
    _assert_clean(inv.check_team_rollup(result), "2-4 team rollup")


# ---------------------------------------------------------------------------
# 2-5 용접사 집계
# ---------------------------------------------------------------------------
def test_welder_defects_recomputed_from_flags(result: dict) -> None:
    """welder_info[*].defect 를 flags + row_raw 로 독립 재계산해 대조한다."""
    _assert_clean(inv.check_welder_defects(result), "2-5 welder defects")


def test_welder_date_stats(result: dict) -> None:
    _assert_clean(inv.check_welder_date_stats(result), "2-5 welder date_stats")


def test_welder_rates(result: dict) -> None:
    _assert_clean(inv.check_welder_rates(result), "2-5 welder rate")


def test_welder_defect_rate_list(result: dict) -> None:
    _assert_clean(inv.check_welder_defect_rate_list(result), "2-5 welder_defect_rate list")


def test_check6_is_excluded_from_welder_defects(result: dict) -> None:
    """
    C6(자격 미등록)만 걸린 행은 그 행의 어떤 용접사에게도 결함 행으로 잡히면 안 된다.
    C6 는 개인 서류 문제라 같은 행의 다른 용접사에게 오귀속되기 때문이다.
    """
    from collections import defaultdict

    by_row: dict[int, set[int]] = defaultdict(set)
    for f in result["flags"]:
        by_row[f["row"]].add(f["check_no"])
    c6_only_rows = [row for row, checks in by_row.items() if checks == {6}]
    if not c6_only_rows:
        pytest.skip("no C6-only rows in this dataset")

    recalc = inv.recompute_welder_defects(result)
    for row in c6_only_rows:
        for wno in inv.welders_of_row(result, row):
            # 그 용접사의 결함 행 수는 C6-only 행을 포함하지 않는 재계산값과 같아야 한다.
            reported = result["welder_info"].get(wno, {}).get("defect", 0)
            assert reported == recalc.get(wno, 0), (
                f"welder[{inv._a(wno)}] defect={reported} but C6-excluded "
                f"recomputation gives {recalc.get(wno, 0)}"
            )


# ---------------------------------------------------------------------------
# 2-6 2차 패스(Check 13/14) 소급 반영
# ---------------------------------------------------------------------------
def test_second_pass_backfill(result: dict) -> None:
    _assert_clean(inv.check_second_pass_backfill(result), "2-6 second pass backfill")


# ---------------------------------------------------------------------------
# 2-7 검토 기록 키 무결성
# ---------------------------------------------------------------------------
def test_feedback_key_scope(result: dict) -> None:
    """검토 키 하나가 2개 이상 도면에 걸치면 무관한 조인트가 기록을 공유하게 된다."""
    _assert_clean(inv.check_feedback_key_scope(result), "2-7 feedback key scope")


# ---------------------------------------------------------------------------
# 2-8 Check 0 (미작업)
# ---------------------------------------------------------------------------
def test_unworked_is_not_a_defect(result: dict) -> None:
    _assert_clean(inv.check_unworked(result), "2-8 unworked")


# ---------------------------------------------------------------------------
# 전체 요약 - 어느 항목이 깨졌는지 한눈에 보기 위한 통합 테스트
# ---------------------------------------------------------------------------
def test_all_invariants(result: dict) -> None:
    report = inv.run_all(result)
    broken = {k: v for k, v in report.items() if v}
    assert not broken, "broken invariants: " + ", ".join(
        f"{k} ({len(v)})" for k, v in sorted(broken.items())
    )
