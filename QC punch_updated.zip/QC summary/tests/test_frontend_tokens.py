"""프론트엔드에서 **오류를 내지 않고 조용히 틀리는** 세 가지를 정적으로 본다.

셋 다 콘솔이 조용하다. CSS는 미정의 토큰에 아무 말도 하지 않고, 하드코딩된 KPI
항목은 멀쩡히 렌더되며, 목록에 없는 Check 번호는 그냥 빠질 뿐이다.
`ui-regression-checker`가 헤드리스 브라우저로 잡아냈지만, 브라우저를 띄우지 않고도
회귀를 막으려고 여기에 못을 박는다.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
CSS = ROOT / "frontend" / "static" / "css" / "style.css"
JS = ROOT / "frontend" / "static" / "js" / "app.js"
HTML = ROOT / "frontend" / "index.html"


def _css() -> str:
    return CSS.read_text(encoding="utf-8")


# ── ① 미정의 CSS 토큰 ───────────────────────────────────────────────────────
#
# `var(--line)`처럼 **폴백 없이** 쓰는데 어디서도 정의되지 않으면 그 선언이 통째로
# 무효가 된다. 실측: `.ag-card` · `.rv-item` · `.rv-kpi-card`가 computed로
# `border: 0px none` · `background: rgba(0,0,0,0)` — 테두리와 배경이 사라졌는데
# 콘솔은 조용했다. «원래 밋밋한 디자인»으로 보여서 아무도 신고하지 않는다.
@pytest.mark.synthetic
def test_every_css_token_used_without_a_fallback_is_defined():
    css = _css()
    # 정의 = `var(` 안이 아닌 자리의 `--x:` (선언). 한 줄에 여러 선언이 올 수 있어
    # 줄 앞에 앵커를 걸지 않는다 — 걸었다가 `--ck-*-bg`를 전부 미정의로 오판했다.
    defined = set(re.findall(r"(?<!\()(--[a-z0-9-]+)\s*:", css))
    # 인라인 style로 요소마다 넣어 주는 것들(폴백이 있어 무해하다)
    inline = set(re.findall(r"--[a-z0-9-]+(?=:\$\{|:var\()", JS.read_text(encoding="utf-8")))

    missing = sorted(
        t for t in set(re.findall(r"var\(\s*(--[a-z0-9-]+)\s*\)", css))
        if t not in defined and t not in inline
    )
    assert not missing, (
        f"폴백 없이 쓰는데 정의되지 않은 토큰: {missing} — "
        "그 선언이 통째로 무효가 되어 테두리·배경이 조용히 사라진다"
    )


@pytest.mark.synthetic
def test_the_aliases_point_at_theme_tokens_not_copied_values():
    """`--line`·`--panel`은 **var()로 이어야** 다크에서 따라간다.

    값을 복사해 넣으면 라이트 값이 다크에도 그대로 남아, 어두운 배경 위에 밝은
    카드 테두리가 남는다 — 역시 오류가 나지 않는다.
    """
    css = _css()
    for alias, target in (("--line", "--border"), ("--panel", "--surface"),
                          ("--border-2", "--border-sub"), ("--panel-2", "--surface-2")):
        assert re.search(rf"{alias}\s*:\s*var\(\s*{target}\s*\)", css), \
            f"{alias}가 {target}를 var()로 가리키지 않는다 — 다크 모드에서 갈라진다"


# ── ② 꺼진 Check가 KPI 카드에 남는다 ────────────────────────────────────────
@pytest.mark.synthetic
def test_the_kpi_cards_are_filtered_by_rule_state():
    """세팅에서 Check 5를 꺼도 「특수규칙 대상율 0.0%」가 남아 있었다.

    판정을 아예 안 하는 항목이 0.0%로 보이면 «검사했는데 0건»으로 읽힌다. 바로
    아래 Check 카드에서는 그 항목이 사라진 상태라, 같은 화면 안의 두 곳이 서로
    다른 말을 한다.
    """
    src = JS.read_text(encoding="utf-8")
    body = src[src.index("function renderKpiRec("):]
    body = body[:body.index("\nfunction ", 1)]

    assert "_ruleOn(" in body, \
        "renderKpiRec이 규칙 상태를 보지 않는다 — 꺼진 Check가 0.0%로 남는다"
    # 항목마다 번호가 있어야 거를 수 있다
    assert body.count("no:") >= 6, "KPI 항목에 Check 번호가 달려 있지 않다"
    # 개별 Check를 설명하는 «지금 상태»가 아닌 문구를 박아 두면 낡는다
    assert "TR-FC-G03 전환 필요" not in body, \
        "건수 대신 고정 문구가 박혀 있다 — 값이 바뀌어도 화면이 그대로다"


# ── ③ 프로젝트 규칙 번호(101~199)가 화면 목록에 못 들어온다 ─────────────────
@pytest.mark.synthetic
def test_active_meta_merges_the_project_rules_from_the_result():
    """`CHECK_META`는 1~20 고정이라 101~199가 들어올 자리가 없었다.

    결과 표의 배지는 서버가 준 색 이름을 쓰므로 멀쩡하지만, `_activeMeta()`를
    거치는 세 곳(Check 카드 · 도넛 범례 · `_checksParam()`)이 조용히 틀어진다.
    특히 `_checksParam()`은 101이 빠진 목록을 필터로 보내 **그 결함이 집계에서
    사라진다.** 지금 물량은 프로젝트 규칙이 0행이라 규칙이 처음 걸리는 날에야
    드러나고, 그날은 «새 규칙이 안 먹는다»로 보인다.
    """
    src = JS.read_text(encoding="utf-8")
    body = src[src.index("function _activeMeta("):]
    body = body[:body.index("\nfunction ", 1)]

    assert "project_checks" in body, \
        "_activeMeta가 결과의 프로젝트 규칙 스냅샷을 보지 않는다"
    assert "COLOR_TO_CLS" in body, "규칙 색을 화면 클래스로 옮기지 않는다"


@pytest.mark.synthetic
def test_the_project_band_is_categorised_by_number():
    """`RUYA1`은 표에 적지 않아도 «프로젝트»여야 한다.

    표에 적어 두면 규칙을 추가할 때마다 화면 코드를 고쳐야 하고, 빠뜨리면
    프로젝트 규칙이 «공통» 배지를 단다 — 구분을 화면에 내보내는 이유 자체가
    «프로젝트가 바뀌면 무엇을 다시 정해야 하는가»인데, 그게 거짓말이 된다.

    번호 대역(101~199)으로 가르던 때는 대역 상수를 보면 됐지만, 지금은
    **모양**으로 가른다 — 숫자면 공통, 아니면 프로젝트. 그래서 확인할 것도
    «대역이 적혀 있는가»가 아니라 «숫자 여부를 보는가»다.
    """
    body = _fn_body("function _ckCategory(")
    assert "프로젝트" in body, "_ckCategory에 프로젝트 구분이 없다"
    # 서버(`project_checks.is_common`)와 같은 기준 — 숫자로만 이루어졌는가
    assert "\\d+" in body and ".test(" in body, \
        "_ckCategory가 «숫자면 공통»으로 가르지 않는다 — 표를 다시 보는 형태로 돌아갔다"
    # **옛 번호 101~199는 숫자인데 프로젝트다.** 모양만 보면 «공통»으로 답해서,
    # 대시보드는 「공통」·프로젝트 세팅 탭은 「프로젝트」가 된다 — 같은 서버의
    # 두 화면이 다른 말을 한다. 서버 `is_common()`과 같은 예외를 둬야 한다.
    #
    # **주석을 걷어내고 본다.** 이 예외의 «이유»가 바로 위 주석에 적혀 있어서,
    # 그냥 훑으면 코드를 지워도 주석만으로 통과한다 — 실제로 음성 대조에서
    # 잡히지 않았다. 통과하는 테스트가 아무것도 지키지 않는 상태가 된다.
    code = _fn_code("function _ckCategory(")
    assert "101" in code and "199" in code, \
        "_ckCategory가 옛 프로젝트 대역(101~199)을 «공통»으로 답한다"


def _fn_body(head: str) -> str:
    """`function x(`부터 다음 최상위 `}`까지. 여러 테스트가 같은 잘림을 쓴다."""
    src = JS.read_text(encoding="utf-8")
    body = src[src.index(head):]
    return body[:body.index("\n}")]


def _fn_code(head: str) -> str:
    """주석을 걷어낸 함수 본문. «코드가 그렇게 되어 있는가»를 물을 때 쓴다."""
    return "\n".join(ln for ln in _fn_body(head).splitlines()
                     if not ln.strip().startswith(("//", "*", "/*")))


# ── 식별자가 문자열이 됐다 — 숫자로 가정한 자리가 남아 있는가 ─────────────────
#
# 이 부류는 **콘솔 오류가 나지 않는다.** `'14' === 14`는 그냥 false라, 찾던 것이
# 조용히 «없는 것»이 되고 동작만 사라진다. 실제로 한 번에 넷이 났다 —
# Check 14 그룹 뷰가 통째로 안 나오고, 프로젝트 세팅 체크박스가 상태를 안 바꾸고
# (껐다고 믿고 저장까지 누른다), 「고치기」가 빈 폼을 열고, 반복 패턴 모달이
# 안 열렸다. 헤드리스 브라우저가 잡았지만 여기 못을 박아 둔다.
#
# **정규식을 쓰지 않는다** — `\b`가 리터럴 백스페이스가 되어 영원히 매칭되지
# 않는 테스트가 두 번 통과한 적이 있다.
@pytest.mark.synthetic
def test_no_check_id_is_compared_against_a_number():
    """`check_no === 14` 꼴이 남아 있으면 그 기능이 통째로 죽는다."""
    bad = [ln.strip() for ln in JS.read_text(encoding="utf-8").splitlines()
           if ("check_no ===" in ln or "check_no !==" in ln) and "String(" not in ln
           # 주석은 이 규칙을 «설명하는» 자리라 걸리면 안 된다
           and not ln.strip().startswith(("//", "*", "/*"))]
    assert not bad, "식별자를 숫자와 직접 비교한다:\n  " + "\n  ".join(bad)


@pytest.mark.synthetic
def test_the_check_meta_table_uses_string_ids():
    """`CHECK_META`의 `no`가 숫자면 한 화면에 두 표현이 공존한다.

    서버가 주는 `check_no`는 문자열이다. 표만 숫자로 두면 `sel.has('14')`가
    빗나가 **Check 취사선택이 조용히 안 먹는다.**
    """
    src = JS.read_text(encoding="utf-8")
    block = src[src.index("const CHECK_META = ["):]
    block = block[:block.index("\n];")]
    assert "{no:1," not in block, "CHECK_META의 식별자가 숫자다"
    assert "{no:'1'," in block, "CHECK_META의 식별자가 문자열이 아니다"


@pytest.mark.synthetic
def test_check_ids_reach_inline_handlers_quoted():
    """따옴표 없이 넘기면 `RUYA1`이 **식별자로 해석되어** ReferenceError가 난다.

    `onclick="goToCheckDetail(14)"`는 지금 돌아간다. 그래서 더 나쁘다 —
    프로젝트 규칙이 하나라도 발급되는 순간 `goToCheckDetail(RUYA1)`이 되어
    그 카드만 안 눌리고, **새 프로젝트에서야 드러난다.**

    처음엔 «따옴표 없는 형태»를 **목록으로** 적어 뒀는데, 목록에 없던
    `deleteCheckRule(…, ' + i.check_no + ')` 하나가 그대로 빠져나갔다.
    그래서 열거하지 않고 **구조로** 본다 — 핸들러 안에서 `_jsq(...)` 호출을
    지운 뒤에도 식별자가 남아 있으면, 그건 인용을 거치지 않은 것이다.

    **줄 단위로 보면 안 된다.** 이 저장소의 핸들러는 여러 줄에 걸쳐 이어 붙인다:

        '<button onclick="deleteCheckRule(\\'' + _jsq(i.key) + \\
          '\\',' + i.check_no + ')">'          <- 여는 줄에 onclick이 없다

    그래서 «onclick이 있는 줄»만 보면 두 번째 줄이 통째로 빠진다 — 실제로 그
    틈으로 하나가 빠져나갔다. 여는 따옴표부터 닫는 `">`까지를 **한 덩어리로** 본다.
    """
    src = JS.read_text(encoding="utf-8")
    bad = []
    for m in re.finditer(r'on(?:click|change)="', src):
        region = src[m.end():m.end() + 400]
        end = region.find('">')
        region = region[:end if end >= 0 else 400]
        # 인용을 거친 자리를 통째로 걷어낸다. 남은 것이 곧 날것이다.
        rest = re.sub(r"_jsq\([^)]*\)", "", region)
        if "check_no" in rest or re.search(r"\bc\.no\b", rest):
            bad.append(" ".join(region.split())[:100])
    assert not bad, "핸들러에 식별자를 따옴표 없이 넘긴다:\n  " + "\n  ".join(bad)


@pytest.mark.synthetic
def test_the_settings_list_is_not_sorted_alphabetically():
    """목록 순서가 1·10·11·…·2·20이 되면 안 된다.

    키가 문자열이라 `sorted()`만 쓰면 사전순이다. 오류는 나지 않고 순서만
    뒤엉키는데, 판정 항목 목록은 **번호로 찾는** 화면이라 그게 곧 못 찾는 것이다.
    """
    src = (ROOT / "backend" / "routers" / "rules.py").read_text(encoding="utf-8")
    assert "sorted(cat, key=project_checks.sort_key)" in src, \
        "'프로젝트 세팅' 목록이 사전순으로 나간다"


# ── 인라인 핸들러가 가리키는 전역 함수 ──────────────────────────────────────
@pytest.mark.synthetic
def test_the_new_rule_editor_handlers_exist():
    """전역 함수 이름이 바뀌면 **콘솔에만** 오류가 나고 화면은 멀쩡해 보인다."""
    js = JS.read_text(encoding="utf-8")
    # 핸들러는 index.html에도, app.js가 만들어 내는 마크업 문자열에도 있다
    # (규칙 카드의 「고치기 / 빼기」는 후자다).
    markup = HTML.read_text(encoding="utf-8") + js
    for fn in ("previewCheckRule", "saveCheckRule", "clearCheckRuleForm",
               "editCheckRule", "deleteCheckRule"):
        assert f'"{fn}(' in markup or f"onclick=\"{fn}(" in markup or f"{fn}(" in markup, \
            f"{fn}을 부르는 인라인 핸들러가 없어졌다"
        assert re.search(rf"^(async )?function {fn}\(", js, re.M), \
            f"{fn}이 전역에 없다 — 버튼을 눌러도 콘솔 오류만 난다"


# ── Check 색이 다크 모드에서 보이는가 ───────────────────────────────────────
#
# `--ck-maroon`·`--ck-indigo`만 다크 변형이 없어, 어두운 표면 대비가 각각
# **1.69:1 · 1.79:1**이었다(비텍스트 UI 최소 3:1 미달). 나머지 14색은 전부
# 다크 블록에서 밝은 값으로 다시 정의돼 있었다.
#
# 오류가 나지 않는다 — 색이 «있긴 있어서» 카드도 배지도 그려진다. 다만 어두운
# 배경에 어두운 색이라 사실상 안 보인다. ui-regression-checker가 실측으로 잡았다.


def _luminance(hex_color: str) -> float:
    h = hex_color.lstrip("#")
    ch = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    ch = [(c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4) for c in ch]
    return 0.2126 * ch[0] + 0.7152 * ch[1] + 0.0722 * ch[2]


def _contrast(a: str, b: str) -> float:
    hi, lo = sorted((_luminance(a), _luminance(b)), reverse=True)
    return (hi + 0.05) / (lo + 0.05)


def _block(css: str, start: str, end: str) -> str:
    i = css.index(start)
    j = css.index(end, i)
    return css[i:j]


@pytest.mark.synthetic
def test_every_check_colour_is_defined_in_both_themes():
    """16색 전부가 라이트·다크 블록에 있어야 한다.

    한쪽에만 있으면 그 테마에서 **다른 테마의 값이 그대로 쓰인다** — 그게
    maroon·indigo가 다크에서 안 보이던 이유다.
    """
    css = _css()
    light = _block(css, ":root {", "@media (prefers-color-scheme: dark)")
    dark = _block(css, "@media (prefers-color-scheme: dark)", ":root[data-theme=dark]")

    names = set(re.findall(r"--ck-([a-z]+):\s*#", light))
    assert len(names) >= 16, f"라이트 블록의 색이 {len(names)}개뿐이다"
    missing = sorted(n for n in names if f"--ck-{n}:" not in dark)
    assert not missing, (
        f"다크 블록에 없는 색: {missing} — 그 테마에서 라이트 값이 그대로 쓰여 "
        "어두운 배경에 어두운 색이 된다"
    )


@pytest.mark.synthetic
def test_check_colours_meet_the_contrast_floor_in_dark_mode():
    """비텍스트 UI 요소의 최소 대비는 3:1이다 (WCAG 1.4.11).

    Check 카드의 강조선·도넛 범례·배지 글자가 전부 이 색을 쓴다.
    """
    css = _css()
    dark = _block(css, "@media (prefers-color-scheme: dark)", ":root[data-theme=dark]")
    surface = re.search(r"--surface:\s*(#[0-9A-Fa-f]{6})", dark)
    assert surface, "다크 블록에 --surface가 없다"

    weak = []
    for name, value in re.findall(r"--ck-([a-z]+):\s*(#[0-9A-Fa-f]{6})", dark):
        ratio = _contrast(surface.group(1), value)
        if ratio < 3.0:
            weak.append((name, value, round(ratio, 2)))
    assert not weak, f"다크 모드에서 대비 3:1 미달: {weak}"


@pytest.mark.synthetic
def test_every_check_colour_has_a_background_token():
    """`.p-*` 배지는 «옅은 배경 + 색 글자»다. `-bg`가 없으면 그 색만 다른
    모양이 된다 — maroon·indigo가 «단색 배경 + 흰 글자»로 혼자 튀었다."""
    css = _css()
    light = _block(css, ":root {", "@media (prefers-color-scheme: dark)")
    names = set(re.findall(r"--ck-([a-z]+):\s*#", light))
    bgs = set(re.findall(r"--ck-([a-z]+)-bg:", light))
    missing = sorted(names - bgs)
    assert not missing, f"-bg 토큰이 없는 색: {missing}"

    for name in sorted(names):
        rule = re.search(rf"\.p-{name}\s*{{([^}}]*)}}", css)
        assert rule, f".p-{name} 클래스가 없다"
        body = rule.group(1)
        assert f"--ck-{name}-bg" in body, f".p-{name}이 -bg를 안 쓴다: {body.strip()}"


# ── 대시보드의 «지금 보고 있는 기준» ────────────────────────────────────────
#
# 임시부재(1C)를 제외하거나 Check를 해제하면 **화면의 모든 블록이 같은 기준**을
# 써야 한다. 하나만 빠뜨리면 같은 화면 안에서 숫자가 어긋나고, 어느 쪽이 맞는지
# 보는 사람이 알 방법이 없다.
#
# 실제로 「주요 KPI 지표」만 집계를 안 받아 이렇게 나왔다(실측):
#
#     KPI 카드      판정 대상 374 · 결함 153 (40.9%)
#     Check 카드    CHECK 3 = 0
#     주요 KPI 지표  두께 허용범위 초과율 14.1% (Check 3 · 778건)
#
# 오류는 나지 않는다. ui-regression-checker가 잡았다.
@pytest.mark.synthetic
def test_every_dashboard_block_uses_the_aggregate():
    """대시보드를 그리는 세 블록이 전부 `agg`를 받아야 한다."""
    js = JS.read_text(encoding="utf-8")
    i = js.index("renderKpiCards(r, agg);")
    block = js[i:i + 200]
    for call in ("renderKpiCards(r, agg)", "renderCheckGrid(agg.cardStats)",
                 "renderKpiRec(r, agg)"):
        assert call in block, f"{call}이 호출부에 없다 — 이 블록만 기준이 달라진다"


@pytest.mark.synthetic
def test_the_kpi_summary_does_not_read_the_raw_result():
    """`r.stats`·`_judged(r)`를 그대로 쓰면 토글을 무시한다.

    폴백으로 남겨 두는 것은 괜찮지만(집계 실패 시), **집계가 있으면 집계를
    먼저 봐야 한다.**
    """
    js = JS.read_text(encoding="utf-8")
    body = js[js.index("function renderKpiRec("):]
    body = body[:body.index(chr(10) + "function ", 1)]

    assert "agg" in body.split("{", 1)[0], "renderKpiRec이 집계를 인자로 안 받는다"
    assert "agg.cardStats" in body, "건수를 Check 카드와 같은 집계에서 가져오지 않는다"
    assert "agg.flaggedRows + agg.cleanRows" in body,         "분모가 «지금 기준의 판정 대상»이 아니다"
