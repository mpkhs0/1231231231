"""
`backend/routers/agents.py` 회귀 테스트.

이 라우터는 '에이전트' 탭이 읽는 유일한 경로이고, 아래 두 가지가 사람 눈으로는
검증하기 어렵다:

- **경로 조작 방어** — 리포트 id로 저장소 밖 파일을 읽을 수 있으면 안 된다.
- **read_only 판정** — 화면에 "읽기 전용"(초록) 배지로 나가는 값이라, 잘못 True가 되면
  코드를 수정할 수 있는 에이전트를 안전한 것처럼 보여준다. 실제로 `tools:` 키를 생략한
  정의를 읽기 전용으로 표시하던 버그가 있었다(Claude Code에서 생략 = 전체 상속).

FastAPI 앱을 띄우지 않고 순수 함수만 부른다 — 서버도 실데이터도 필요 없다.
"""
from __future__ import annotations

import pytest

from backend.routers import agents as ag


# ── read_only 판정 ────────────────────────────────────────────────────────────
@pytest.mark.synthetic
@pytest.mark.parametrize(
    "tools_raw, expected, why",
    [
        ("Read, Grep, Glob, Bash", True, "읽기 도구만"),
        ("Read, Write, Edit, Bash", False, "Write/Edit 보유"),
        ("Read, Edit", False, "Edit만 있어도 수정 가능"),
        ("Read, NotebookEdit", False, "NotebookEdit도 수정 도구"),
        ("Read, MultiEdit", False, "MultiEdit도 수정 도구"),
        # 아래 넷이 과거에 잘못 True가 되던 입력이다
        (None, False, "tools 키 자체가 없으면 전체 상속(Write 포함)"),
        ("", False, "빈 값은 판단 불가 - 안전한 쪽"),
        ("*", False, "와일드카드는 전체 허용"),
        ('"*"', False, "따옴표 붙은 와일드카드"),
        ("[]", False, "빈 리스트 표기"),
    ],
)
def test_read_only_classification(tools_raw, expected, why):
    assert ag._is_read_only(tools_raw) is expected, why


@pytest.mark.synthetic
def test_read_only_never_true_when_write_tool_present():
    """어떤 표기로 적히든 Write 계열이 보이면 읽기 전용이 아니어야 한다."""
    for fmt in ("Read,Write", "Read, Write", " Read , Write ", "Read\nWrite"):
        assert ag._is_read_only(fmt) is False, fmt


# ── frontmatter 파싱 ──────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_split_frontmatter_basic():
    meta, body = ag._split_frontmatter(
        "---\nname: x\ndescription: hello\n---\n\n본문\n"
    )
    assert meta["name"] == "x"
    assert meta["description"] == "hello"
    assert body.strip() == "본문"


@pytest.mark.synthetic
@pytest.mark.parametrize(
    "text",
    [
        "",                                   # 빈 파일
        "본문만 있고 frontmatter 없음",
        "---\n닫히지 않은 frontmatter\n",       # 종료 구분자 없음
        "---\n---\n",                         # 내용 없는 frontmatter
        "---\n: 값만\n---\n본문",              # 키 없는 줄
        "---\nname\n---\n본문",                # 콜론 없는 줄
    ],
)
def test_split_frontmatter_never_raises(text):
    """파일 하나가 깨져도 목록 전체가 죽으면 안 된다."""
    meta, body = ag._split_frontmatter(text)
    assert isinstance(meta, dict)
    assert isinstance(body, str)


@pytest.mark.synthetic
def test_split_frontmatter_value_with_colon():
    """description에 콜론이 들어가도 첫 콜론에서만 잘라야 한다."""
    meta, _ = ag._split_frontmatter("---\ndescription: a: b: c\n---\n본문")
    assert meta["description"] == "a: b: c"


# ── 리포트 파일명 규칙 / 경로 조작 방어 ────────────────────────────────────────
@pytest.mark.synthetic
@pytest.mark.parametrize(
    "name",
    [
        "qc-data-verifier__2026-08-03_090852.md",
        "ui-regression-checker__2026-01-01_000000.md",
        "a__2026-12-31_235959.md",
    ],
)
def test_report_name_accepted(name):
    assert ag._REPORT_RE.match(name) is not None


@pytest.mark.synthetic
@pytest.mark.parametrize(
    "bad",
    [
        "../../CLAUDE.md",
        "..\\..\\CLAUDE.md",
        "x__2026-08-03_090852.md.bak",     # 확장자 뒤에 덧붙임
        "x__2026-8-3_90852.md",            # 자릿수 부족
        "x__2026-08-03.md",                # 시각 없음
        "x.md",                            # 구분자 없음
        "__2026-08-03_090852.md",          # 에이전트 이름 없음
        "x__2026-08-03_090852.txt",        # 확장자 불일치
        "x__2026-08-03_090852.md\x00",     # 널 바이트
    ],
)
def test_report_name_rejected(bad):
    """id 형식 자체가 1차 방어선이다. 여기서 걸러지면 파일 접근까지 가지 않는다."""
    assert ag._REPORT_RE.match(bad) is None


@pytest.mark.synthetic
def test_report_id_traversal_blocked(tmp_path, monkeypatch):
    """리포트 디렉터리 밖의 파일은 읽을 수 없어야 한다.

    형식 정규식을 통과하더라도, resolve 후 리포트 디렉터리 하위인지 확인하는 2차
    방어가 있어야 한다. 실제 미끼 파일을 밖에 두고 확인한다.
    """
    from fastapi import HTTPException

    reports = tmp_path / "agent_reports"
    reports.mkdir()
    (reports / "ok__2026-08-03_090852.md").write_text(
        "---\nagent: ok\nverdict: PASS\n---\n안쪽", encoding="utf-8"
    )
    (tmp_path / "secret__2026-08-03_090852.md").write_text("바깥", encoding="utf-8")

    monkeypatch.setattr(ag.config, "AGENT_REPORTS_DIR", reports)

    assert ag.get_report("ok__2026-08-03_090852", "A551135")["agent"] == "ok"

    for bad in (
        "..\\secret__2026-08-03_090852",
        "../secret__2026-08-03_090852",
        "sub/../../secret__2026-08-03_090852",
    ):
        with pytest.raises(HTTPException) as e:
            ag.get_report(bad, "A551135")
        assert e.value.status_code in (400, 404), bad


# ── 인증 ──────────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
@pytest.mark.parametrize("endpoint", ["list_agents", "get_definition", "get_report"])
def test_endpoints_require_login(endpoint, monkeypatch):
    """사번 헤더 없이는 어떤 엔드포인트도 데이터를 내주면 안 된다.

    /api/result와 마찬가지로 이 응답도 사내 정보(에이전트 정의, 검증 리포트 본문)를
    담고 있고, 서버는 0.0.0.0으로 열려 있다.
    """
    from fastapi import HTTPException

    monkeypatch.setattr(ag, "require_login", _reject_anonymous)

    fn = getattr(ag, endpoint)
    args = {
        "list_agents": (None,),
        "get_definition": ("qc-data-verifier", None),
        "get_report": ("x__2026-08-03_090852", None),
    }[endpoint]

    with pytest.raises(HTTPException) as e:
        fn(*args)
    assert e.value.status_code == 401


def _reject_anonymous(x_employee_id):
    from fastapi import HTTPException

    if not x_employee_id:
        raise HTTPException(401, "로그인이 필요합니다")
    return str(x_employee_id).upper()


# ── 출처(origin) 분류 ─────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_origin_marker_and_fallback(tmp_path, monkeypatch):
    """전용/서브 구분은 본문의 origin 표식으로 하고, 없으면 추정한다."""
    d = tmp_path / "agents"
    d.mkdir()
    (d / "mine.md").write_text(
        "---\nname: mine\ntools: Read\n---\n<!-- origin: project -->\n본문",
        encoding="utf-8",
    )
    (d / "theirs.md").write_text(
        "---\nname: theirs\ntools: Read, Write\n---\n<!-- origin: vendor -->\n본문",
        encoding="utf-8",
    )
    (d / "guessed.md").write_text(
        "---\nname: guessed\ntools: Read\n---\n> 이 저장소의 제약 (원본 정의에 추가됨)\n본문",
        encoding="utf-8",
    )
    (d / "plain.md").write_text(
        "---\nname: plain\ntools: Read\n---\n표식 없음", encoding="utf-8"
    )
    monkeypatch.setattr(ag.config, "AGENTS_DIR", d)

    by_name = {a["name"]: a for a in ag._scan_agents()}
    assert by_name["mine"]["origin"] == "project"
    assert by_name["theirs"]["origin"] == "vendor"
    assert by_name["guessed"]["origin"] == "vendor", "제약 블록이 있으면 vendor로 추정"
    assert by_name["plain"]["origin"] == "project", "표식도 제약도 없으면 직접 작성으로 본다"

    assert by_name["mine"]["read_only"] is True
    assert by_name["theirs"]["read_only"] is False


@pytest.mark.synthetic
def test_scan_agents_missing_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(ag.config, "AGENTS_DIR", tmp_path / "없는폴더")
    assert ag._scan_agents() == []


@pytest.mark.synthetic
def test_scan_reports_skips_unknown_filenames(tmp_path, monkeypatch):
    """규칙에 안 맞는 파일이 섞여 있어도 목록이 죽지 않는다."""
    d = tmp_path / "reports"
    d.mkdir()
    (d / "메모.md").write_text("사람이 남긴 메모", encoding="utf-8")
    (d / "good__2026-08-03_090852.md").write_text(
        "---\nagent: good\nverdict: PASS\nsummary: ok\n---\n본문", encoding="utf-8"
    )
    monkeypatch.setattr(ag.config, "AGENT_REPORTS_DIR", d)

    items = ag._scan_reports()
    assert len(items) == 1
    assert items[0]["agent"] == "good"
    assert items[0]["verdict"] == "PASS"


@pytest.mark.synthetic
def test_report_verdict_normalized(tmp_path, monkeypatch):
    """verdict가 규정 밖 값이면 UNKNOWN으로 떨어뜨린다(화면 배지가 깨지지 않게)."""
    d = tmp_path / "reports"
    d.mkdir()
    (d / "a__2026-08-03_090852.md").write_text(
        "---\nagent: a\nverdict: 좋음\n---\n본문", encoding="utf-8"
    )
    (d / "b__2026-08-03_090853.md").write_text(
        "---\nagent: b\nverdict: pass\n---\n본문", encoding="utf-8"
    )
    monkeypatch.setattr(ag.config, "AGENT_REPORTS_DIR", d)

    got = {r["agent"]: r["verdict"] for r in ag._scan_reports()}
    assert got["a"] == "UNKNOWN"
    assert got["b"] == "PASS", "소문자 표기는 대문자로 정규화"


@pytest.mark.synthetic
def test_reports_sorted_newest_first(tmp_path, monkeypatch):
    d = tmp_path / "reports"
    d.mkdir()
    for ts in ("2026-08-01_090000", "2026-08-03_120000", "2026-08-02_235959"):
        (d / f"x__{ts}.md").write_text(
            f"---\nagent: x\nverdict: PASS\n---\n{ts}", encoding="utf-8"
        )
    monkeypatch.setattr(ag.config, "AGENT_REPORTS_DIR", d)

    ts_list = [r["ts"] for r in ag._scan_reports()]
    assert ts_list == sorted(ts_list, reverse=True)


# ── 실제 저장소 정의 파일 상태 ────────────────────────────────────────────────
@pytest.mark.realdata
def test_repo_agent_definitions_are_wellformed():
    """저장소에 실제로 들어 있는 정의들이 화면에서 올바르게 분류되는지."""
    agents = ag._scan_agents()
    if not agents:
        pytest.skip(".claude/agents 가 없는 환경")

    for a in agents:
        assert a["name"], "name이 비어 있으면 화면에서 식별 불가"
        assert a["origin"] in ("project", "vendor"), a["name"]
        # 정의 파일에 tools가 명시돼 있으면 read_only 판정이 그 내용과 맞아야 한다
        if a["tools"]:
            expected = not ({"Write", "Edit", "NotebookEdit", "MultiEdit"} & set(a["tools"]))
            assert a["read_only"] is expected, a["name"]
