"""
판정 항목 카탈로그 — «무슨 검사인지»와 «어느 구분인지»가 코드와 어긋나지 않는지.

## 왜 필요한가

카탈로그는 판정을 하지 않는다. 그래서 틀려도 **아무 데서도 오류가 나지 않고**,
화면에는 그럴듯한 설명이 뜬다. 글은 그림보다도 더 믿기 때문에, 틀린 설명은
틀린 판정보다 오래 남는다.

특히 두 가지가 갈라지기 쉽다:

1. Check를 추가하고 카탈로그에 안 넣는다 -> '프로젝트 세팅'에서 그 항목이
   설명 없이 뜨거나 아예 안 뜬다
2. 구분(공통/프로젝트)이 서버와 화면에서 다르다 -> 결함 카드의 배지와 세팅 탭이
   서로 다른 말을 한다
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

from backend.services import rule_catalog as R
from backend.services import verifier as V

APP_JS = Path(__file__).resolve().parent.parent / "frontend" / "static" / "js" / "app.js"


@pytest.mark.synthetic
def test_every_check_has_a_catalog_entry():
    missing = sorted(set(V.CHECK_NAMES) - set(R.CATALOG) - {V.CHECK_UNWORKED})
    assert not missing, f"카탈로그에 없는 Check: {missing} — rule_catalog.CATALOG에 넣어라"


@pytest.mark.synthetic
def test_catalog_has_no_ghost_entries():
    ghost = sorted(set(R.CATALOG) - set(V.CHECK_NAMES))
    assert not ghost, f"판정 엔진에 없는 번호가 카탈로그에 있다: {ghost}"


@pytest.mark.synthetic
def test_every_entry_explains_itself():
    """카드 이름만으로는 무슨 검사인지 알 수 없다 — 그래서 요약과 로직을 강제한다."""
    for no, spec in R.CATALOG.items():
        assert spec.get("summary"), f"Check {no}에 한 줄 요약이 없다"
        assert len(spec.get("logic", "")) > 40, f"Check {no}의 판정 로직 설명이 너무 짧다"
        assert spec.get("category") in (R.COMMON, R.PROJECT), \
            f"Check {no}의 구분이 공통/프로젝트가 아니다"


@pytest.mark.synthetic
def test_category_matches_the_frontend():
    """서버와 화면의 구분이 같아야 한다.

    갈라지면 결함 카드의 배지와 '프로젝트 세팅' 탭이 서로 다른 말을 한다.
    화면은 «공통이 기본»이므로 프로젝트 항목만 적는다.
    """
    src = APP_JS.read_text(encoding="utf-8")
    m = re.search(r"const CHECK_CATEGORY = \{(.*?)\};", src, re.S)
    assert m, "app.js에 CHECK_CATEGORY가 없다"
    front = {int(k) for k in re.findall(r"(\d+):\s*'프로젝트'", m.group(1))}
    server = {no for no, spec in R.CATALOG.items() if spec["category"] == R.PROJECT}
    assert front == server, f"구분이 다르다 — 서버 {sorted(server)} / 화면 {sorted(front)}"


@pytest.mark.synthetic
def test_disabled_is_opt_out_not_opt_in(tmp_path, monkeypatch):
    """설정에 없는 Check는 **켜진 것**으로 본다.

    새 Check를 추가했을 때 설정 파일에 없다고 꺼지면, 검사를 만들어 놓고도 아무
    일이 일어나지 않는다. 예외도 경고도 없어서 발견이 아주 늦다.
    """
    from backend import config

    monkeypatch.setattr(config, "PROJECT_RULES_FILE", tmp_path / "rules.json")
    assert R.is_enabled(3) is True, "설정 파일이 없으면 전부 켜져 있어야 한다"

    R.save_enabled({3: False})
    assert R.is_enabled(3) is False
    assert R.is_enabled(4) is True, "적지 않은 항목까지 꺼졌다"


@pytest.mark.synthetic
def test_requests_survive_a_settings_save(tmp_path, monkeypatch):
    """신규 규칙 요청과 취사선택이 같은 파일에 있다 — 한쪽 저장이 다른 쪽을
    날리면 현업이 적어 둔 요청이 사라진다."""
    from backend import config

    monkeypatch.setattr(config, "PROJECT_RULES_FILE", tmp_path / "rules.json")
    R.add_request({"title": "시험 규칙", "condition": "c", "verdict": "v"})
    R.save_enabled({3: False})
    reqs = R.settings()["requests"]
    assert len(reqs) == 1 and reqs[0]["title"] == "시험 규칙"

    R.add_request({"title": "둘째", "condition": "c", "verdict": "v"})
    assert [r["id"] for r in R.settings()["requests"]] == [1, 2], "요청 번호가 겹친다"
    assert R.enabled_map()["3"] is False, "취사선택이 날아갔다"


@pytest.mark.synthetic
def test_broken_settings_file_falls_back_to_all_on(tmp_path, monkeypatch):
    """설정이 깨졌을 때 «전부 꺼짐»으로 떨어지면 검증이 통째로 조용해진다."""
    from backend import config

    p = tmp_path / "rules.json"
    p.write_text("{ 깨진", encoding="utf-8")
    monkeypatch.setattr(config, "PROJECT_RULES_FILE", p)
    assert R.is_enabled(3) is True


# ---- 프로젝트별 프로파일 --------------------------------------------------
#
# 이 시스템은 한 프로젝트 전용이 아니다. 이름으로 설정을 불러와 바꾼 뒤 파일을
# 올려 돌리는 방식으로 쓴다. 그래서 설정이 «하나»가 아니라 «이름 붙은 여러 벌»이다.
@pytest.fixture
def rules_file(tmp_path, monkeypatch):
    from backend import config
    p = tmp_path / "project_rules.json"
    monkeypatch.setattr(config, "PROJECT_RULES_FILE", p)
    return p


@pytest.mark.synthetic
def test_profiles_keep_their_own_settings(rules_file):
    R.save_enabled({18: False}, project="A 프로젝트")
    assert R.active_profile_name() == "A 프로젝트"
    assert R.is_enabled(18) is False

    R.switch_profile("B 프로젝트")
    assert R.is_enabled(18) is True, "새 프로파일은 전부 켜져 있어야 한다"

    R.switch_profile("A 프로젝트")
    assert R.is_enabled(18) is False, "돌아왔을 때 설정이 남아 있어야 한다"
    assert set(R.profile_names()) == {"A 프로젝트", "B 프로젝트"}


@pytest.mark.synthetic
def test_active_profile_cannot_be_deleted(rules_file):
    """활성 프로파일을 지우면 «무엇을 기준으로 판정 중인지»가 사라진다."""
    R.save_enabled({}, project="쓰는 중")
    assert R.delete_profile("쓰는 중") is False
    R.switch_profile("다른 것")
    assert R.delete_profile("쓰는 중") is True
    assert R.delete_profile("없는 것") is False


@pytest.mark.synthetic
def test_requests_are_shared_across_projects(rules_file):
    """규칙 요청은 «이 프로젝트에서 무엇을 켤까»가 아니라 «시스템에 무엇을
    추가할까»다. 프로젝트를 바꿨다고 사라지면 안 된다."""
    R.save_enabled({}, project="A")
    R.add_request({"title": "요청1", "condition": "c", "verdict": "v"})
    R.switch_profile("B")
    assert [r["title"] for r in R.settings()["requests"]] == ["요청1"]
    assert R.settings()["requests"][0]["project"] == "A", "어느 프로젝트에서 냈는지 남아야 한다"


@pytest.mark.synthetic
def test_old_flat_format_is_migrated(rules_file):
    """프로파일이 없던 옛 형식을 옮겨 담는다 — 무시하면 꺼 둔 항목이 조용히
    다시 켜진다."""
    import json

    rules_file.write_text(json.dumps(
        {"project": "옛 프로젝트", "enabled": {"18": False}, "requests": []},
        ensure_ascii=False), encoding="utf-8")
    assert R.active_profile_name() == "옛 프로젝트"
    assert R.is_enabled(18) is False
    assert R.profile_names() == ["옛 프로젝트"]


# ---- 끄면 «2차 패스»도 멈춰야 한다 ----------------------------------------
#
# 취사선택 필터를 `_check_row()` 끝에만 두었더니 Check 13·14가 그 길을 지나지
# 않아 «껐는데 938건이 그대로» 나왔다. 2차 패스는 `_register_flag`로 뒤늦게
# 합류하므로 그쪽에도 같은 문이 있어야 한다.
#
# CLAUDE.md가 «2단계 패스가 가장 자주 깨지는 곳»이라고 적어 둔 자리이고,
# 이 세션에서만 세 번째다(용접사 집계 257행, NDT 번호, 그리고 이것).
@pytest.mark.synthetic
def test_second_pass_respects_the_project_settings():
    src = open(V.__file__, encoding="utf-8").read()
    body = src[src.index("def _register_flag"):]
    body = body[:body.index("\n    def ", 10)]
    assert "self._rule_on(flag.check_no)" in body, \
        "2차 패스(_register_flag)가 취사선택을 무시한다 — 껐는데 그대로 나온다"
    # 문이 «집계를 건드리기 전»에 있어야 한다. 뒤에 있으면 플래그는 안 생기는데
    # 부서/용접사 집계만 올라가 결함 행수와 Check 합계가 어긋난다.
    gate = body.index("self._rule_on(flag.check_no)")
    assert gate < body.index("self.stats[flag.check_no] += 1")


@pytest.mark.synthetic
def test_first_pass_gate_is_still_there():
    src = open(V.__file__, encoding="utf-8").read()
    assert "return [f for f in flags if self._rule_on(f.check_no)]" in src


@pytest.mark.synthetic
def test_a_run_records_what_it_was_judged_with():
    """결과에 «무엇으로 판정했는지»가 박혀야 한다.

    이름만으로는 부족하다 — 같은 프로젝트 안에서 항목을 켜고 끄면 이름은 같고
    내용만 다르다. 그래서 취사선택도 함께 남긴다.
    """
    import inspect

    src = inspect.getsource(V.run_verification)
    assert "rules_snapshot = rule_catalog.enabled_map()" in src
    assert '"project":         active_project,' in src
    assert '"rules":' in src
    # 회차 안에서는 «한 기준»이어야 한다 — 행마다 파일을 다시 읽으면
    # 앞뒤 행이 다른 기준으로 판정될 수 있다
    assert "checker._enabled = dict(rules_snapshot)" in src


@pytest.mark.synthetic
def test_verify_rejects_an_unknown_project():
    """검증이 «없는 프로젝트 이름»으로 새 프로파일을 만들면 안 된다.

    qc-data-verifier가 실제로 밟았다: 셸에서 이름을 넘길 때 cp949로 깨져
    전달됐는데, `switch_profile()`이 그 이름으로 **전 항목 켜진 새 프로파일을
    조용히 만들어** 그 기준으로 검증했다. 결과에는 그 깨진 이름이 박히므로
    나중에도 알기 어렵다 — «시나리오로 돌렸는데 왜 그대로냐»로만 보인다.

    새로 만드는 길은 '프로젝트 세팅' 탭 하나뿐이어야 한다.
    """
    import inspect

    from backend.routers import verify as V_router

    src = inspect.getsource(V_router.run_verify)
    assert "rule_catalog.has_profile(project)" in src, \
        "없는 프로젝트 이름을 거르지 않는다 - 오타가 «전 항목 켬»이 된다"
    # 거절이 «검증 시작»보다 앞에 있어야 한다
    assert src.index("has_profile") < src.index('_state["status"] == "running"')


@pytest.mark.synthetic
def test_has_profile_only_knows_saved_ones(rules_file):
    R.save_enabled({}, project="있는 것")
    assert R.has_profile("있는 것") is True
    assert R.has_profile("없는 것") is False
    assert R.has_profile("") is False
    # 활성 이름은 파일에 프로파일이 없어도 «있는 것»으로 본다
    assert R.has_profile(R.active_profile_name()) is True
