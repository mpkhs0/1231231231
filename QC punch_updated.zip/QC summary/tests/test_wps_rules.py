"""
`backend/services/wps_rules.py` — WPS 규칙 설정화 + 죽은 규칙 경고 테스트.

이 모듈의 존재 이유는 설정화 자체가 아니라 **"이 규칙은 지금 죽어 있다"를 알리는 것**이다.
원본 매크로의 WPS 접두사는 `RU-`인데 코드는 `TR-`을 쓴다(§11-9). 접두사가 다른
프로젝트가 들어오면 Check 5/8/9가 조용히 전부 0건이 되고, 그걸 "문제가 없다"로
읽게 된다. 그 사고를 막는 것이 `check_rules_alive()`다.

그래서 테스트의 중심도 두 가지다:
  1. 설정 파일이 없을 때 **지금 동작이 그대로여야 한다** (기본값 = 기존 하드코딩)
  2. 규칙이 참조하는 WPS가 없을 때 **반드시 경고가 나와야 한다**
"""
from __future__ import annotations

import json

import pytest

from backend import config
from backend.services import wps_rules


@pytest.fixture(autouse=True)
def _clear_cache():
    """설정은 모듈 수준에서 캐시되므로 테스트마다 비운다."""
    wps_rules._cache = None
    yield
    wps_rules._cache = None


# ── DEFAULTS에는 «프로젝트 값»이 없어야 한다 ─────────────────────────────────
@pytest.mark.synthetic
def test_defaults_carry_no_project_values(tmp_path, monkeypatch):
    """DEFAULTS는 어느 프로젝트에서나 성립하는 것만 담는다.

    예전에는 여기에 TRION 값이 박혀 있었고 `data/wps_rules.json`이 없어서 늘
    쓰였다. **다른 프로젝트를 올리면 그대로 물려받았다** — 그게 이 작업이 없앤
    사고다. 지금은 '프로젝트 세팅'의 프로파일 `params`가 채운다.
    """
    monkeypatch.setattr(config, "WPS_RULES_FILE", tmp_path / "없음.json")
    monkeypatch.setattr(config, "PROJECT_RULES_FILE", tmp_path / "없음2.json")
    wps_rules.invalidate()

    assert wps_rules.repair_prefix() == "", "수리 WPS 접두사가 DEFAULTS에 남아 있다"
    assert wps_rules.check8()["target_wps"] == ""
    assert wps_rules.check9()["target_wps"] == ""
    assert wps_rules.wps_corrections() == {}
    # `temp_member`만 예외다 — `1C`는 **조선소 공통 규약**이라 어느 프로젝트에서나
    # 같다(현업 확인 2026-08-13). 위 셋은 WPS 이름이라 프로젝트마다 진짜로 다르다.
    assert wps_rules.temp_member_prefixes() == ("1C",)

    # 폐지된 Check 5의 설정도 지웠다 — 남으면 「끈 줄 알았는데 왜 안 되냐」가 된다
    assert "check5" not in wps_rules.DEFAULTS
    assert not hasattr(wps_rules, "check5")

    # 두께 규칙은 별도 검증항목(101~199)이 됐다. 옛 접근자는 없어야 한다.
    assert not hasattr(wps_rules, "wps_thickness_override")
    assert not hasattr(wps_rules, "material_thickness_override")

    # 공통 값은 남는다
    assert wps_rules.inspection_grace_days() == 30


@pytest.mark.synthetic
def test_empty_project_values_are_warned_not_silent(tmp_path, monkeypatch):
    """값이 비면 «규칙이 안 도는» 상태다. 조용히 넘어가면 «검사를 돌렸는데
    아무것도 안 나왔다»를 «문제가 없다»로 읽게 된다.

    특히 `repair_prefix`가 비면 `_is_repair_wps()`가 항상 False가 되어 수리 WPS까지
    Check 4·11이 지적한다 — 과거 600건 규모 오탐의 재발이다.
    """
    monkeypatch.setattr(config, "WPS_RULES_FILE", tmp_path / "없음.json")
    monkeypatch.setattr(config, "PROJECT_RULES_FILE", tmp_path / "없음2.json")
    wps_rules.invalidate()

    findings = wps_rules.check_rules_alive(set(), set())
    msgs = " / ".join(f["msg"] for f in findings)
    assert "수리 WPS 접두사" in msgs, "빈 repair_prefix가 조용히 넘어갔다"
    assert any(f["level"] == "missing" for f in findings)
    assert "WPS 보정" in msgs
    # 임시부재는 이제 DEFAULTS에 값이 있어 경고 대상이 아니다. 경고가 남아 있으면
    # **모든 프로젝트에서 항상 뜨는 소음**이 되어 진짜 경고를 가린다.
    assert "임시부재" not in msgs


@pytest.mark.synthetic
def test_user_file_overrides(tmp_path, monkeypatch):
    """`wps_rules.json` 층만 본다.

    **활성 프로파일의 `params`를 함께 격리해야 한다** — 그게 마지막 층이라
    격리하지 않으면 이 테스트가 실제 `data/project_rules.json`(운영 값)을
    읽어, 개발 PC의 설정에 따라 결과가 달라진다.
    """
    monkeypatch.setattr(config, "PROJECT_RULES_FILE", tmp_path / "project_rules.json")
    wps_rules.invalidate()
    p = tmp_path / "wps_rules.json"
    p.write_text(json.dumps({
        "project": "다른 프로젝트",
        "repair_prefix": "RU-FC-R",

    }, ensure_ascii=False), encoding="utf-8")
    monkeypatch.setattr(config, "WPS_RULES_FILE", p)

    assert wps_rules.repair_prefix() == "RU-FC-R"
    # 부분 지정한 키는 기본값이 남아야 한다 (재귀 병합)
    assert wps_rules.check8()["max_thickness"] == 12.0


@pytest.mark.synthetic
def test_broken_file_falls_back(tmp_path, monkeypatch):
    """설정 하나가 깨졌다고 검증 전체가 멈추면 안 된다."""
    p = tmp_path / "wps_rules.json"
    p.write_text("{ 이건 JSON이 아니다", encoding="utf-8")
    monkeypatch.setattr(config, "WPS_RULES_FILE", p)
    assert wps_rules.repair_prefix() == "TR-FC-R"


# ── 죽은 규칙 경고 (이 모듈의 존재 이유) ──────────────────────────────────────
@pytest.mark.synthetic
def test_missing_wps_is_flagged(tmp_path, monkeypatch):
    """규칙이 참조하는 WPS가 목록에 아예 없으면 'missing' 경고.

    접두사가 다른 프로젝트가 들어온 상황을 그대로 재현한다.
    """
    monkeypatch.setattr(config, "WPS_RULES_FILE", tmp_path / "없음.json")
    known = {"RU-FC-G01", "RU-FC-G03"}          # 매크로 원문 접두사
    used = {"RU-FC-G01"}
    findings = wps_rules.check_rules_alive(known, used)

    missing = {f["wps"] for f in findings if f["level"] == "missing"}
    assert "TR-FC-G01" in missing, "규칙이 죽었는데 경고가 없다"
    assert "TR-FC-G03" in missing
    assert "TR-SMFC-G01" in missing


@pytest.mark.synthetic
def test_unused_wps_is_informational(tmp_path, monkeypatch):
    """목록에는 있으나 시공에 안 쓰인 WPS는 'unused' — 0건이 정상이라는 뜻."""
    monkeypatch.setattr(config, "WPS_RULES_FILE", tmp_path / "없음.json")
    known = set(wps_rules.referenced_wps())
    used = {"TR-FC-G01"}
    findings = wps_rules.check_rules_alive(known, used)

    levels = {f["wps"]: f["level"] for f in findings}
    assert "TR-FC-G01" not in levels, "쓰이고 있는 WPS는 지적 대상이 아니다"
    assert levels.get("TR-FC-G03") == "unused"
    assert not any(f["level"] == "missing" for f in findings)


@pytest.mark.synthetic
def test_all_alive_is_silent(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "WPS_RULES_FILE", tmp_path / "없음.json")
    all_wps = set(wps_rules.referenced_wps())
    assert wps_rules.check_rules_alive(all_wps, all_wps) == []


@pytest.mark.synthetic
def test_referenced_wps_covers_every_rule(tmp_path, monkeypatch):
    """규칙을 추가했는데 referenced_wps()에 안 넣으면 경고가 안 나온다."""
    monkeypatch.setattr(config, "WPS_RULES_FILE", tmp_path / "없음.json")
    refs = set(wps_rules.referenced_wps())
    r = wps_rules.load()
    # Check 5는 폐지됐다. 폐지된 규칙에 «죽어 있다» 경고를 내면 소음이 되어
    # 진짜 경고를 가린다.
    for key in ("check8", "check9"):
        if r[key]["target_wps"]:
            assert r[key]["target_wps"].upper() in refs, key
    # 보정 대상 WPS도 «죽은 규칙» 경고 범위에 들어와야 한다 — 보정이 걸릴 WPS가
    # 목록에 없으면 Check 4·11이 옛날처럼 오탐을 내기 시작한다.
    for w in wps_rules.wps_corrections():
        assert w.upper() in refs


@pytest.mark.synthetic
def test_case_insensitive(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "WPS_RULES_FILE", tmp_path / "없음.json")
    lower = {w.lower() for w in wps_rules.referenced_wps()}
    assert wps_rules.check_rules_alive(lower, lower) == [], "대소문자로 오탐이 나면 안 된다"


# ── 실데이터 ─────────────────────────────────────────────────────────────────
@pytest.mark.realdata
def test_real_result_reports_g03_unused(result):
    """실데이터에서 TR-FC-G03이 'unused'로 보고돼야 한다.

    이 프로젝트는 G03을 한 번도 시공에 쓰지 않았고, 그래서 Check 8·10이 0건이다.
    화면이 그 이유를 설명할 수 있어야 한다.
    """
    health = (result or {}).get("rule_health")
    if health is None:
        pytest.skip("rule_health가 없는 결과(재검증 전)")
    # `rule_health`는 이제 WPS 경고 + 프로젝트 규칙 경고를 함께 담는다.
    # 프로젝트 규칙 항목에는 `wps` 키가 없으므로 골라내야 한다.
    by = {f["wps"]: f["level"] for f in health if "wps" in f}
    assert by.get("TR-FC-G03") == "unused"
    assert "missing" not in by.values(), f"규칙이 죽어 있다: {health}"


# ---- 재귀 병합 + 프로파일 params 계층 --------------------------------------
#
# 값의 우선순위:  DEFAULTS  <  data/wps_rules.json  <  활성 프로파일 params
#
# 프로파일에 두는 이유는 «전환할 때 켬/끔과 값이 한 번에 바뀌어야» 하기 때문이다.
# 파일 하나에만 두면 프로젝트를 바꿔도 앞 프로젝트의 두께 규칙이 그대로 남는다 —
# 그게 이 작업이 없애려는 사고다.
@pytest.fixture
def rule_files(tmp_path, monkeypatch):
    from backend import config
    from backend.services import wps_rules as W

    monkeypatch.setattr(config, "WPS_RULES_FILE", tmp_path / "wps_rules.json")
    monkeypatch.setattr(config, "PROJECT_RULES_FILE", tmp_path / "project_rules.json")
    W.invalidate()
    yield tmp_path
    W.invalidate()


@pytest.mark.synthetic
def test_nested_dict_merge_keeps_siblings(rule_files):
    """예전 1단계 병합은 한 WPS의 일부만 덮어도 나머지 보정이 통째로 날아갔다.

    이제 층이 둘이다(파일 · 프로파일 params). 아래층이 WPS 보정 전체를 주고
    위층이 그중 한 키만 덮을 때, **같은 WPS의 다른 키와 다른 WPS가 살아남아야**
    한다.
    """
    import json

    from backend.services import rule_catalog as R
    from backend.services import wps_rules as W

    (rule_files / "wps_rules.json").write_text(json.dumps({
        "wps_corrections": {
            "WPS-A": {"add_joint_detail": ["PJP", "PP"], "add_materials": ["원래재질"]},
            "WPS-B": {"add_materials": ["다른WPS"]},
        }}, ensure_ascii=False), encoding="utf-8")
    W.invalidate()

    R.save_enabled({}, project="P")
    data = R.settings()
    data["profiles"]["P"]["params"] = {
        "wps_corrections": {"WPS-A": {"add_materials": ["새재질"]}}}
    R._write(data)

    corr = W.load()["wps_corrections"]
    assert corr["WPS-A"]["add_materials"] == ["새재질"]
    assert corr["WPS-A"]["add_joint_detail"] == ["PJP", "PP"], \
        "같은 WPS의 다른 보정이 날아갔다"
    assert "WPS-B" in corr, "다른 WPS가 날아갔다"


@pytest.mark.synthetic
def test_lists_are_replaced_wholesale(rule_files):
    """`material_thickness`는 **순서가 곧 의미**다(좁은 조건이 앞).

    인덱스로 병합하면 `S355KT-40`이 'KT-40' 대신 'KT'에 걸리는 식으로 조용히
    뒤집힌다.
    """
    import json

    from backend.services import wps_rules as W

    (rule_files / "wps_rules.json").write_text(json.dumps(
        {"material_thickness": [{"match": ["ONLY"], "range": "1~2"}]},
        ensure_ascii=False), encoding="utf-8")
    assert W.load(force=True)["material_thickness"] == [{"match": ["ONLY"], "range": "1~2"}]


@pytest.mark.synthetic
def test_profile_params_win_and_follow_the_switch(rule_files):
    from backend.services import rule_catalog as R
    from backend.services import wps_rules as W

    import json

    (rule_files / "wps_rules.json").write_text(
        json.dumps({"repair_prefix": "TR-FC-R"}, ensure_ascii=False), encoding="utf-8")
    assert W.load(force=True)["repair_prefix"] == "TR-FC-R"

    R.save_enabled({}, project="RUYA")
    data = R.settings()
    data["profiles"]["RUYA"]["params"] = {"repair_prefix": "RU-FC-R"}
    R._write(data)
    assert W.load()["repair_prefix"] == "RU-FC-R", "프로파일 params가 안 먹었다"

    # TRION 프로파일에는 params가 없다 -> 아래층(파일)의 값으로 돌아가야 한다
    R.switch_profile("TRION")
    assert W.load()["repair_prefix"] == "TR-FC-R", \
        "프로파일을 바꿨는데 옛 값이 남았다 — 캐시 무효화가 안 됐다"


@pytest.mark.synthetic
def test_writing_settings_invalidates_the_cache(rule_files):
    """캐시를 안 버리면 화면은 새 프로젝트를 가리키는데 판정은 옛 값을 쓴다.
    오류가 나지 않아 발견이 아주 늦다."""
    import inspect

    from backend.services import rule_catalog as R

    assert "wps_rules.invalidate()" in inspect.getsource(R._write)


@pytest.mark.synthetic
def test_profile_params_beat_the_file(tmp_path, monkeypatch):
    """우선순위는 `DEFAULTS < wps_rules.json < 활성 프로파일 params`다.

    프로파일이 마지막인 이유: 프로젝트를 바꾸면 **값도 함께** 바뀌어야 한다.
    파일 하나가 이기면 프로파일을 전환해도 앞 프로젝트의 값이 남는다.
    """
    from backend.services import rule_catalog

    monkeypatch.setattr(config, "WPS_RULES_FILE", tmp_path / "wps_rules.json")
    monkeypatch.setattr(config, "PROJECT_RULES_FILE", tmp_path / "project_rules.json")
    config.WPS_RULES_FILE.write_text(
        json.dumps({"repair_prefix": "파일값"}, ensure_ascii=False), encoding="utf-8")
    wps_rules.invalidate()
    assert wps_rules.repair_prefix() == "파일값".upper()

    rule_catalog.save_enabled({}, project="P")
    data = rule_catalog.settings()
    data["profiles"]["P"]["params"] = {"repair_prefix": "프로파일값"}
    rule_catalog._write(data)
    assert wps_rules.repair_prefix() == "프로파일값".upper()


# ---- 설정이 «실제로» 판정에 먹히는가 --------------------------------------
#
# 예전에는 `check8.max_thickness`·`check9.thickness` 같은 키가 설정에 있는데
# 코드는 리터럴을 썼다. 설정을 바꿔도 판정이 안 바뀌고 **예외도 경고도 나지
# 않았다** — 이 모듈이 경계하던 «조용히 죽는» 패턴이 설정값 쪽에서 재현된 것이다.
#
# 그래서 리터럴 부재를 grep으로 확인하지 않고 **행동으로** 잡는다.
@pytest.mark.synthetic
def test_check8_limit_actually_follows_the_setting(rule_files):
    import json

    from backend.services import verifier as V
    from tests.test_checks_16_17 import FakeLoader, make_row

    (rule_files / "wps_rules.json").write_text(json.dumps({
        "check8": {"target_wps": "W-G03", "max_thickness": 20.0,
                   "impact_temp_c": -40.0}}, ensure_ascii=False), encoding="utf-8")
    wps_rules.invalidate()

    c = V.QCChecker(FakeLoader())
    row = make_row(MATERIAL1="NV-EO420", THICKNESS1=15)   # -40급 재질 · 15mm
    assert c._c8_tr_fc_g03(row, "W-G03") is not None, \
        "상한을 20으로 올렸는데 15mm가 안 걸린다 — 설정이 판정에 안 먹는다"

    (rule_files / "wps_rules.json").write_text(json.dumps({
        "check8": {"target_wps": "W-G03", "max_thickness": 12.0,
                   "impact_temp_c": -40.0}}, ensure_ascii=False), encoding="utf-8")
    wps_rules.invalidate()
    assert c._c8_tr_fc_g03(row, "W-G03") is None, "상한 12로 되돌렸는데 15mm가 걸린다"


@pytest.mark.synthetic
def test_check9_banned_thickness_follows_the_setting(rule_files):
    """Check 9는 «API 재질 + 금지 두께»다 (현업 확인 2026-08-13).

    예전에는 «대상 WPS + 두께 12.7 -> 확인 필요»였고 재질 조건이 없었다. 번호는
    9를 그대로 쓴다 — 검토 기록 키가 `…|Check No`라 옮기면 과거 의견이 고아가 된다.

    금지 두께 목록도 **설정에서 온다.** 소스에 박아 두면 설정을 바꿔도 판정이
    안 따라오는데 예외도 경고도 나지 않는다.
    """
    import json

    from backend.services import verifier as V
    from tests.test_checks_16_17 import FakeLoader, make_row

    (rule_files / "wps_rules.json").write_text(json.dumps({
        "check9": {"target_wps": "W-SMFC", "banned_thickness": [20.0],
                   "tolerance": 0.05}}, ensure_ascii=False), encoding="utf-8")
    wps_rules.invalidate()

    c = V.QCChecker(FakeLoader())
    api = dict(MATERIAL1="API-5L-X52")
    assert c._c9_tr_smfc_g01(make_row(THICKNESS1=20.0, **api), "W-SMFC") is not None
    assert c._c9_tr_smfc_g01(make_row(THICKNESS1=12.7, **api), "W-SMFC") is None, \
        "설정을 20으로 바꿨는데 12.7이 여전히 걸린다"
    # 재질 조건이 빠지면 API가 아닌 행까지 걸린다 — 그게 예전 동작이다
    assert c._c9_tr_smfc_g01(make_row(THICKNESS1=20.0, MATERIAL1="ASTM-A36"),
                             "W-SMFC") is None, "API 재질이 아닌데 걸린다"
    # K열도 본다 — 이종재 이음에서 한쪽만 금지 두께인 경우가 빠지면 안 된다
    assert c._c9_tr_smfc_g01(
        make_row(THICKNESS1=9.5, THICKNESS2=20.0, MATERIAL2="API5L-GRB"),
        "W-SMFC") is not None


@pytest.mark.synthetic
def test_an_empty_target_wps_matches_nothing(rule_files):
    """대상 WPS가 비면 «아무것도 안 걸린다»여야 한다.

    빈 문자열을 `wps_no.upper() != ""`로 비교하면 모든 행이 대상이 된다.
    """
    from backend.services import verifier as V
    from tests.test_checks_16_17 import FakeLoader, make_row

    wps_rules.invalidate()
    c = V.QCChecker(FakeLoader())
    assert c._c8_tr_fc_g03(make_row(MATERIAL1="NV-EO420", THICKNESS1=5), "") is None
    assert c._c9_tr_smfc_g01(make_row(THICKNESS1=12.7), "") is None


@pytest.mark.synthetic
def test_check18_has_only_one_switch():
    """켬/끔 스위치가 둘이면 **JSON이 UI를 이긴다.**

    '프로젝트 세팅'에서 켰는데 아무 일도 안 일어나고, 결과의 `rules` 스냅샷에는
    «18 = 켬»으로 기록되어 결과가 거짓말을 한다.
    """
    assert not hasattr(wps_rules, "check18_enabled")
    assert "check18" not in wps_rules.DEFAULTS


@pytest.mark.synthetic
def test_the_temp_member_prefix_is_a_yard_wide_default():
    """`1C`는 **조선소 공통 규약**이라 DEFAULTS에 있다 (현업 확인 2026-08-13).

    프로파일 `params`에만 두었더니 새 프로젝트마다 같은 사고가 반복됐다 —
    RUYA에서 「임시부재 제외」 토글이 아무것도 못 걸렀고, 그 물량의 **95%가
    1C 도면**이었다. 오류도 경고도 아닌 «안 걸러진다»로만 보인다.

    `repair_prefix`·`wps_corrections`는 WPS 이름이라 여전히 빈 채로 둔다 —
    프로젝트마다 진짜로 다르고, 임의로 채우면 조용히 틀린 판정이 된다.
    """
    assert wps_rules.DEFAULTS["temp_member"]["drawing_prefixes"] == ["1C"]
    assert wps_rules.DEFAULTS["repair_prefix"] == "", "WPS 이름은 프로젝트마다 다르다"
    assert wps_rules.DEFAULTS["wps_corrections"] == {}


@pytest.mark.synthetic
def test_a_profile_without_params_still_gets_the_temp_prefix(rule_files):
    """`params`가 아예 없는 프로파일 — «새 프로젝트를 처음 돌리는» 상태다."""
    import json

    (rule_files / "project_rules.json").write_text(json.dumps({
        "active": "새프로젝트", "profiles": {"새프로젝트": {}}},
        ensure_ascii=False), encoding="utf-8")
    wps_rules.invalidate()
    assert wps_rules.temp_member_prefixes() == ("1C",)


@pytest.mark.synthetic
def test_a_profile_can_still_override_the_prefix(rule_files):
    """다른 규약을 쓰는 프로젝트는 프로파일에서 덮어쓴다."""
    import json

    (rule_files / "project_rules.json").write_text(json.dumps({
        "active": "특이", "profiles": {"특이": {
            "params": {"temp_member": {"drawing_prefixes": ["9Z"]}}}}},
        ensure_ascii=False), encoding="utf-8")
    wps_rules.invalidate()
    assert wps_rules.temp_member_prefixes() == ("9Z",)


# ── WPS 이름 맨 앞은 «프로젝트 번호»다 ──────────────────────────────────────
#
# 현업 확인(2026-08-14): `TR-FC-G01`의 `TR`은 프로젝트 번호다. RUYA는 TRION 자료를
# 기반으로 WPS를 새로 만들어서 **뒤쪽 구분은 같고 앞자리만 바뀐다.**
#
# 이름을 통째로 비교하면 프로젝트가 바뀌는 순간 `wps_corrections`도
# `repair_prefix`도 `check8/9.target_wps`도 **한 행에도 안 맞고 조용히 죽는다.**
# 오류도 경고도 나지 않는다 — 그냥 그 검사가 0건이 된다.
@pytest.mark.synthetic
def test_wps_core_drops_the_project_code():
    assert wps_rules.wps_core("TR-FC-G01") == "FC-G01"
    assert wps_rules.wps_core("RU-FC-G01") == "FC-G01"
    assert wps_rules.wps_core("TR-SMFC-G01") == "SMFC-G01"
    assert wps_rules.wps_core("ru-fc-g01") == "FC-G01", "대소문자를 가리면 안 된다"


@pytest.mark.synthetic
def test_wps_core_leaves_short_names_alone():
    """**세 마디 이상일 때만** 뗀다.

    `FC-G01`처럼 접두사가 없는 이름에서 첫 마디를 떼면 `G01`만 남아 너무
    헐거워진다 — 접두사를 안 쓰는 프로젝트를 망가뜨린다.
    """
    assert wps_rules.wps_core("FC-G01") == "FC-G01"
    assert wps_rules.wps_core("G01") == "G01"
    assert wps_rules.wps_core("") == ""


@pytest.mark.synthetic
def test_corrections_attach_across_project_codes(rule_files):
    """보정 키가 `TR-FC-G01`이어도 RUYA의 `RU-FC-G01`에 붙어야 한다."""
    import json

    (rule_files / "project_rules.json").write_text(json.dumps({
        "active": "RUYA", "profiles": {"RUYA": {"params": {"wps_corrections": {
            "TR-FC-G01": {"add_joint_detail": ["PJP", "PP"]}}}}}},
        ensure_ascii=False), encoding="utf-8")
    wps_rules.invalidate()

    table = {"RU-FC-G01": {"joint_detail": "SB, DB", "materials": []}}
    touched = wps_rules.apply_corrections(table)
    assert touched, "프로젝트 코드가 달라 보정이 붙지 않았다"
    assert "PJP" in table["RU-FC-G01"]["joint_detail"]
    assert "PP" in table["RU-FC-G01"]["joint_detail"]


@pytest.mark.synthetic
def test_corrections_do_not_leak_to_a_different_wps(rule_files):
    """뒤쪽 구분이 다르면 남이다 — `G01` 보정이 `G03`에 붙으면 안 된다."""
    import json

    (rule_files / "project_rules.json").write_text(json.dumps({
        "active": "RUYA", "profiles": {"RUYA": {"params": {"wps_corrections": {
            "TR-FC-G01": {"add_joint_detail": ["PJP"]}}}}}},
        ensure_ascii=False), encoding="utf-8")
    wps_rules.invalidate()

    table = {"RU-FC-G03": {"joint_detail": "SB", "materials": []}}
    assert not wps_rules.apply_corrections(table)
    assert table["RU-FC-G03"]["joint_detail"] == "SB"
