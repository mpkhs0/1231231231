"""
검사기 자체를 검증한다 (합성 데이터 전용, 실데이터 불필요).

`test_invariants.py` 는 "위반이 없다"만 확인하므로, 검사기가 언제나 빈 리스트를
돌려주도록 잘못 짜여 있어도 초록불이 된다. 그래서 여기서는 합성 결과를 **일부러
깨뜨려** 각 검사기가 실제로 그 위반을 잡아내는지 본다.

특히 `test_detects_second_pass_welder_backfill_bug` 와
`test_detects_legacy_feedback_key_sharing` 은 이 프로젝트에서 실제로 비용을 치른
버그 2건을 축소 재현한 것이다. 이 두 개가 빨간불이 되지 않는다면 나머지 테스트도
믿을 수 없다.
"""
from __future__ import annotations

import pytest

import qc_invariants as inv
import synthetic

pytestmark = pytest.mark.synthetic


@pytest.fixture()
def base() -> dict:
    return synthetic.build_result()


# ---------------------------------------------------------------------------
# 합성 데이터가 애초에 기대한 모양인지 (빌더 자체의 sanity check)
# ---------------------------------------------------------------------------
def test_synthetic_shape(base: dict) -> None:
    assert base["total_rows"] == 14
    assert base["deleted_rows"] == 1
    assert base["active_rows"] == 13
    assert base["unworked_rows"] == 3
    assert base["judged_rows"] == 10
    assert base["flagged_rows"] == 7
    assert base["clean_rows"] == 3
    # flags (11) > defect rows (7): the fixture must contain rows carrying several
    # checks, otherwise the 2-2 "rows vs flags" unit confusion cannot be detected.
    assert base["total_flags"] == 11
    assert base["total_flags"] > base["flagged_rows"]
    # the second-pass checks and the C6 scenario must actually be present
    checks = {f["check_no"] for f in base["flags"]}
    assert {"6", "13", "14"} <= checks


def test_synthetic_passes_every_invariant(base: dict) -> None:
    broken = {k: v for k, v in inv.run_all(base).items() if v}
    assert not broken, f"synthetic fixture is inconsistent: {broken}"


# ---------------------------------------------------------------------------
# 각 mutator 가 대응 검사기에 걸리는지
# ---------------------------------------------------------------------------
def test_detects_row_accounting_break(base: dict) -> None:
    assert inv.check_row_accounting(synthetic.break_row_accounting(base))


def test_detects_row_vs_flag_unit_confusion(base: dict) -> None:
    """flagged_rows 자리에 total_flags 를 넣은 상태 (실제로 있었던 혼선)."""
    broken = synthetic.break_flag_row_unit_confusion(base)
    assert inv.check_flag_accounting(broken)


def test_detects_wrong_denominator(base: dict) -> None:
    """결함률 분모로 judged_rows 가 아니라 active_rows 를 쓴 상태."""
    broken = synthetic.break_denominator(base)
    assert inv.check_row_accounting(broken) or inv.check_department_rollup(broken)


def test_detects_department_rollup_break(base: dict) -> None:
    assert inv.check_department_rollup(synthetic.break_department_rollup(base))


def test_detects_team_rollup_break(base: dict) -> None:
    """부서까지만 맞고 팀에서 어긋나는 경우 - 팀 단위까지 내려가야 잡힌다."""
    broken = synthetic.break_team_rollup(base)
    assert inv.check_team_rollup(broken)


def test_detects_second_pass_welder_backfill_bug(base: dict) -> None:
    """
    실제 버그 재현: 1차에 C6 만 있던 행이 2차 패스에서 C13/C14 를 얻었는데
    `is_new_defect_row` 분기 탓에 welder_defects 에 반영되지 않은 상태.
    실데이터에서는 257행 / 용접사 7명이 영향받았다.
    """
    broken = synthetic.break_second_pass_welder_backfill(base)
    assert broken != base, "mutator did not change anything (fixture lacks the scenario)"
    assert inv.check_welder_defects(broken), "welder defect recomputation missed the bug"
    assert inv.check_second_pass_backfill(broken), "second-pass backfill check missed the bug"


def test_detects_second_pass_stats_not_backfilled(base: dict) -> None:
    broken = synthetic.break_second_pass_stats(base)
    assert inv.check_second_pass_backfill(broken)
    assert inv.check_flag_accounting(broken)


def test_detects_welder_rate_break(base: dict) -> None:
    assert inv.check_welder_rates(synthetic.break_welder_rate(base))


def test_detects_welder_date_stats_break(base: dict) -> None:
    assert inv.check_welder_date_stats(synthetic.break_welder_date_stats(base))


def test_detects_unworked_counted_as_defect(base: dict) -> None:
    """미작업 행이 결함으로 집계되면 분모/분자가 모두 오염된다."""
    broken = synthetic.break_unworked_counted_as_defect(base)
    assert inv.check_unworked(broken)


# ---------------------------------------------------------------------------
# 2-7 검토 키 - 도면번호가 빠진 구 키가 실제로 조인트를 뒤섞는지
# ---------------------------------------------------------------------------
def test_detects_legacy_feedback_key_sharing(base: dict) -> None:
    """
    Joint No 는 도면 안에서만 유일하다. 도면번호를 뺀 구 키(joint|wps|check)로
    묶으면 서로 다른 도면의 조인트가 한 키를 공유한다.
    """
    legacy = inv.group_flags_by_feedback_key(base, include_drawing=False)
    shared = {k: v for k, v in legacy.items() if len(v) > 1}
    assert shared, "synthetic fixture must contain the same joint on different drawings"

    current = inv.group_flags_by_feedback_key(base, include_drawing=True)
    assert all(len(v) == 1 for v in current.values()), (
        "current 4-part key must never span more than one drawing"
    )
    assert not inv.check_feedback_key_scope(base)


def test_feedback_key_has_four_parts() -> None:
    key = inv.feedback_key("D-001", "J-20", "TR-A", 3)
    assert key.count("|") == 3
    assert key.startswith("D-001|")


def test_feedback_record_check_detects_legacy_key() -> None:
    legacy = {"J-20|TR-A|3": {"drawing_no": "D-001", "joint_no": "J-20",
                              "wps_no": "TR-A", "check_no": 3}}
    assert inv.check_feedback_records(legacy)

    good_key = inv.feedback_key("D-001", "J-20", "TR-A", 3)
    good = {good_key: {"drawing_no": "D-001", "joint_no": "J-20",
                       "wps_no": "TR-A", "check_no": 3}}
    assert not inv.check_feedback_records(good)


def test_feedback_record_check_detects_empty_drawing() -> None:
    key = inv.feedback_key("", "J-20", "TR-A", 3)
    records = {key: {"drawing_no": "", "joint_no": "J-20", "wps_no": "TR-A", "check_no": 3}}
    assert inv.check_feedback_records(records)


# ---------------------------------------------------------------------------
# 메시지 인코딩 - cp949 콘솔에서 죽지 않아야 한다
# ---------------------------------------------------------------------------
def test_violation_messages_are_ascii_safe(base: dict) -> None:
    """
    부서명/용접사명이 한글이라, 위반 메시지에 원문 그대로 넣으면 cp949 콘솔
    출력 시 UnicodeEncodeError 로 pytest 가 죽는다. 전부 이스케이프돼야 한다.
    """
    broken = synthetic.break_department_rollup(synthetic.break_team_rollup(base))
    messages = [m for msgs in inv.run_all(broken).values() for m in msgs]
    assert messages, "expected at least one violation message to inspect"
    for m in messages:
        m.encode("cp949")  # 예외가 나면 실패
        assert m.isascii(), f"non-ascii violation message: {m!r}"
