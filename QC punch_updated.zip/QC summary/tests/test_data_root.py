"""데이터 폴더 분리 — «코드 한 벌 · 프로젝트마다 다른 데이터».

## 이 분리가 조용히 틀리는 방식

경로 상수 하나를 옮기지 않고 남겨 두면 **두 프로젝트가 그 파일 하나를 함께 쓴다.**
예외는 나지 않는다. 검토 기록이라면 남의 프로젝트 의견이 붙고, 결과 DB라면
나중에 돌린 쪽이 앞의 결과를 덮어쓴다. 둘 다 «받은 사람이 말해 주기 전에는
알 수 없는» 종류다.

반대로 **너무 많이 옮겨도** 조용히 틀린다 — 사번 목록을 프로젝트별로 가르면
서버를 하나 더 띄울 때마다 등록을 다시 해야 하고, 빠뜨린 쪽은 «로그인이
안 된다»가 된다.

그래서 «어느 쪽인가»를 상수마다 여기에 적어 둔다.
"""
from __future__ import annotations

import importlib
import os

import pytest

from backend import config


# 프로젝트마다 갈라져야 하는 것 — 이 프로젝트의 «내용»이다
PER_PROJECT = [
    "UPLOADS_DIR", "RESULTS_DIR", "EXPORTS_DIR", "WPS_REF",
    "WPS_CACHE", "WPS_RULES_FILE", "PROJECT_RULES_FILE",
    "RESULT_DB", "APP_STATE_FILE", "FEEDBACK_FILE",
    "DEPT_RECIPIENTS_FILE", "TEAM_RECIPIENTS_FILE",
]

# 이 PC의 것 / 코드의 것 — 프로젝트가 바뀌어도 같아야 한다
SHARED = [
    "EMPLOYEES_FILE",     # 사번을 두 번 등록하게 만들지 않는다
    "OUTLOOK_SETTINGS",   # 발신 계정은 PC의 것이다
    "FRONTEND_DIR", "STATIC_DIR",
    "AGENTS_DIR", "AGENT_REPORTS_DIR", "ANALYSIS_DOC",
]


def _reload(monkeypatch, **env):
    for k, v in env.items():
        if v is None:
            monkeypatch.delenv(k, raising=False)
        else:
            monkeypatch.setenv(k, v)
    return importlib.reload(config)


@pytest.fixture(autouse=True)
def _restore():
    """이 모듈이 config를 다시 임포트하므로 **끝나면 원래대로 돌려놓는다.**
    안 그러면 뒤따르는 테스트가 임시 폴더를 가리킨 채로 돈다."""
    yield
    for k in ("QC_DATA_DIR", "QC_PROJECT", "QC_WPS_REF"):
        os.environ.pop(k, None)
    importlib.reload(config)


@pytest.mark.synthetic
def test_the_default_is_exactly_where_it_used_to_be(monkeypatch):
    """환경변수가 없으면 **예전과 완전히 같다.**

    기본값이 바뀌면 이미 쓰고 있는 설치가 «그동안의 결과가 사라졌다»가 된다 —
    실제로는 빈 폴더를 새로 보고 있을 뿐이라 원인을 찾기 어렵다.
    """
    c = _reload(monkeypatch, QC_DATA_DIR=None, QC_PROJECT=None, QC_WPS_REF=None)
    assert c.DATA_ROOT == c.BASE.resolve()
    assert c.PROJECT_NAME == "", "폴더를 안 나눴는데 프로젝트 배지가 뜬다"
    assert c.RESULT_DB == c.BASE / "data" / "qc.db"
    assert c.UPLOADS_DIR == c.BASE / "qc_uploads"


@pytest.mark.synthetic
def test_every_per_project_path_moves(monkeypatch, tmp_path):
    root = tmp_path / "RUYA"
    c = _reload(monkeypatch, QC_DATA_DIR=str(root), QC_PROJECT=None, QC_WPS_REF=None)
    left = [n for n in PER_PROJECT
            if not str(getattr(c, n)).startswith(str(root.resolve()))]
    assert not left, (
        f"프로젝트별이어야 하는데 저장소에 남아 있다: {left} — "
        "두 프로젝트가 이 파일을 함께 쓰게 되고, 예외는 나지 않는다"
    )


@pytest.mark.synthetic
def test_shared_paths_stay_put(monkeypatch, tmp_path):
    c = _reload(monkeypatch, QC_DATA_DIR=str(tmp_path / "RUYA"),
                QC_PROJECT=None, QC_WPS_REF=None)
    moved = [n for n in SHARED
            if not str(getattr(c, n)).startswith(str(c.BASE.resolve()))]
    assert not moved, (
        f"공용이어야 하는데 프로젝트 폴더로 갔다: {moved} — "
        "사번을 두 번 등록해야 하고, 빠뜨린 쪽은 «로그인이 안 된다»가 된다"
    )


@pytest.mark.synthetic
def test_the_project_name_comes_from_the_folder_or_the_env(monkeypatch, tmp_path):
    """이름은 화면 배지가 된다. **두 서버를 동시에 띄워 놓고 어느 쪽을 보고
    있는지 모르는 것**이 이 구조에서 가장 현실적인 사고다."""
    c = _reload(monkeypatch, QC_DATA_DIR=str(tmp_path / "RUYA"),
                QC_PROJECT=None, QC_WPS_REF=None)
    assert c.PROJECT_NAME == "RUYA"

    c = _reload(monkeypatch, QC_DATA_DIR=str(tmp_path / "RUYA"),
                QC_PROJECT="RUYA FPU", QC_WPS_REF=None)
    assert c.PROJECT_NAME == "RUYA FPU", "환경변수가 폴더 이름을 이겨야 한다"


# ── WPS 참조 파일 ───────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_the_wps_reference_is_found_by_extension_not_by_name(monkeypatch, tmp_path):
    """파일 **이름**을 코드에 박으면 새 프로젝트가 파일을 제자리에 놓고도
    «WPS를 못 읽는다»가 되고, 원인이 파일 이름이라는 것은 알기 어렵다."""
    raw = tmp_path / "RUYA" / "Raw data"
    raw.mkdir(parents=True)
    (raw / "전혀 다른 이름(R2).xlsm").write_bytes(b"")
    c = _reload(monkeypatch, QC_DATA_DIR=str(tmp_path / "RUYA"),
                QC_PROJECT=None, QC_WPS_REF=None)
    assert c.WPS_REF.name == "전혀 다른 이름(R2).xlsm"


@pytest.mark.synthetic
def test_excel_lock_files_are_not_mistaken_for_the_reference(monkeypatch, tmp_path):
    """엑셀로 열어 두면 `~$이름.xlsm`이 같은 폴더에 생긴다. 이름순으로는
    `~`가 뒤라 지금 구조에선 안 걸리지만, **열어 둔 것이 참조 파일이 되는**
    사고는 재현이 어렵고 원인도 안 보인다. 아예 거른다."""
    raw = tmp_path / "RUYA" / "Raw data"
    raw.mkdir(parents=True)
    (raw / "~$진짜.xlsm").write_bytes(b"")
    (raw / "진짜.xlsm").write_bytes(b"")
    c = _reload(monkeypatch, QC_DATA_DIR=str(tmp_path / "RUYA"),
                QC_PROJECT=None, QC_WPS_REF=None)
    assert c.WPS_REF.name == "진짜.xlsm"


@pytest.mark.synthetic
def test_a_missing_reference_still_points_inside_the_project(monkeypatch, tmp_path):
    """파일이 없어도 **죽지 않는다.** 없는 것은 정상 상태다(캐시로 돌 수 있고,
    처음 띄우는 프로젝트는 아직 파일이 없다). 다만 경로는 «어디를 봐야 하는지»를
    가리켜야 한다 — 저장소를 가리키면 남의 프로젝트 파일을 읽는다.
    """
    root = tmp_path / "RUYA"
    c = _reload(monkeypatch, QC_DATA_DIR=str(root), QC_PROJECT=None, QC_WPS_REF=None)
    assert not c.WPS_REF.exists()
    assert str(c.WPS_REF).startswith(str(root.resolve()))
    assert c.WPS_REF.parent.name == "Raw data"


@pytest.mark.synthetic
def test_an_explicit_override_wins(monkeypatch, tmp_path):
    other = tmp_path / "어딘가" / "WPS.xlsm"
    other.parent.mkdir(parents=True)
    other.write_bytes(b"")
    c = _reload(monkeypatch, QC_DATA_DIR=str(tmp_path / "RUYA"),
                QC_PROJECT=None, QC_WPS_REF=str(other))
    assert c.WPS_REF == other


# ── 목록과 생사 ─────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_a_dead_server_does_not_kill_the_list():
    """한 프로젝트 서버가 꺼져 있다는 이유로 **다른 프로젝트로도 못 들어가면**
    안 된다. probe에서 예외가 새면 목록 전체가 500이 되고, 그러면 로그인
    화면에서 선택지가 통째로 사라진다."""
    from backend.services import project_servers

    assert project_servers.probe(1, timeout=0.2)["up"] is False   # 안 듣는 포트


@pytest.mark.synthetic
def test_the_list_falls_back_when_the_file_is_missing(tmp_path, monkeypatch):
    from backend.services import project_servers

    monkeypatch.setattr(project_servers, "PROJECTS_FILE", tmp_path / "없음.json")
    assert project_servers.load_projects(), "목록 파일이 없으면 선택지가 사라진다"

    (tmp_path / "깨짐.json").write_text("{ 이건 JSON이 아니다", encoding="utf-8")
    monkeypatch.setattr(project_servers, "PROJECTS_FILE", tmp_path / "깨짐.json")
    assert project_servers.load_projects(), "깨진 파일이 로그인 화면을 죽이면 안 된다"


# ── 프로젝트를 «고르는 자리»는 로그인 화면 안이다 ───────────────────────────
#
# 예전에는 앞에 «프로젝트를 고르는» 페이지(포트 8000)를 따로 뒀다. 그러면 브랜드
# 배경과 로고가 있는 로그인 화면이 뒤로 밀리고 **아무 꾸밈 없는 흰 화면이 이
# 시스템의 첫인상**이 된다. 사용자가 그래서 걷어내라고 했다 — 배경 영상까지
# 만들어 둔 화면이 뒤로 밀릴 이유가 없다.
#
# 대신 로그인 화면 안에 둔다. 자리는 **둘**이어야 한다:
#
#     로그인 화면의 목록   처음 들어오는 사람
#     상단 배지 드롭다운   이미 로그인해 둔 사람 — 로그인 화면을 아예 지나가지 않는다
#
# 둘 중 하나가 빠져도 예외는 나지 않는다. 그냥 «선택지가 없는 화면»이 될 뿐이다.
@pytest.mark.synthetic
def test_the_project_server_serves_the_list():
    """목록은 **로그인 전에** 나가야 한다 — 서버를 고르기 전에 로그인해야 하면
    순환이다."""
    from backend import main

    paths = {r.path for r in main.app.routes if hasattr(r, "path")}
    assert "/api/projects" in paths, \
        "프로젝트 서버가 목록을 안 내준다 — 로그인 화면에 선택지가 사라진다"


@pytest.mark.synthetic
def test_the_project_list_needs_no_login():
    """서버를 고르기 전에 로그인해야 하면 순환이다. 나가는 것은 이름·포트·생사뿐이다."""
    import inspect

    from backend import main

    src = inspect.getsource(main.projects)
    assert "require_login" not in src and "x_employee_id" not in src


@pytest.mark.synthetic
def test_both_switch_points_exist_in_the_frontend():
    from pathlib import Path

    root = Path(__file__).resolve().parent.parent
    html = (root / "frontend" / "index.html").read_text(encoding="utf-8")
    js = (root / "frontend" / "static" / "js" / "app.js").read_text(encoding="utf-8")

    assert 'id="login-proj-list"' in html, "로그인 화면에 프로젝트 목록 자리가 없다"
    assert 'id="server-menu"' in html, "상단 배지에 전환 메뉴 자리가 없다"
    assert "toggleProjectMenu(" in html and "function toggleProjectMenu(" in js, \
        "배지를 눌러도 아무 일이 없다 — 이미 로그인한 사람은 전환할 길이 사라진다"

    # 두 자리가 **같은 목록**을 그린다. 따로 그리면 한쪽만 고쳐지고, 어느 쪽이
    # 맞는지 보는 사람은 알 수 없다.
    assert js.count("_projRowsHtml(") >= 3, \
        "로그인 화면과 드롭다운이 목록을 따로 만든다"


@pytest.mark.synthetic
def test_a_stopped_server_is_not_a_link():
    """꺼진 서버를 링크로 만들면 눌러 봐야 브라우저 오류 화면이 뜨고,
    그건 «이 프로그램이 고장났다»로 읽힌다."""
    from pathlib import Path

    js = (Path(__file__).resolve().parent.parent
          / "frontend" / "static" / "js" / "app.js").read_text(encoding="utf-8")
    body = js[js.index("function _projRowsHtml("):]
    body = body[:body.index("\nfunction ", 1)]
    assert "if (!p.up)" in body and "lp-down" in body
    # 링크를 만드는 줄이 «살아 있음»보다 뒤에 있어야 한다
    assert body.index("if (!p.up)") < body.index("<a class=")


@pytest.mark.synthetic
def test_there_is_no_separate_entry_page():
    """앞단 페이지를 되살리면 **브랜드 화면이 다시 뒤로 밀린다.**

    첫인상은 배경 영상과 로고가 있는 로그인 화면이어야 한다. 프로젝트 선택은
    그 안에 이미 있으므로 앞에 화면을 하나 더 둘 이유가 없다.
    """
    from pathlib import Path

    root = Path(__file__).resolve().parent.parent
    assert not (root / "backend" / "landing.py").exists(), \
        "앞단 페이지가 되살아났다 — 흰 화면이 다시 첫인상이 된다"
    # 주석에 «예전에 8000이 있었다»고 적혀 있는 것은 이력이다. 실제로 띄우는지를 본다.
    ps = (root / "start_all.ps1").read_text(encoding="utf-8-sig")
    assert "backend.landing" not in ps, "시작 스크립트가 아직 앞단 페이지를 띄운다"
    assert "$firstPort" in ps, "목록의 첫 프로젝트를 열지 않는다"


@pytest.mark.synthetic
def test_the_powershell_scripts_carry_a_bom():
    """PowerShell 5.1은 BOM이 없으면 `.ps1`을 ANSI(cp949)로 읽는다.

    한글 주석이 깨지는 데서 끝나지 않는다 — 깨진 바이트가 따옴표와 맞물려
    **파싱이 통째로 실패한다.** 실제로 세 스크립트가 그렇게 죽었고, 화면에는
    «까만 창이 뜨자마자 닫히는» 것으로만 보였다.
    """
    from pathlib import Path

    import codecs

    root = Path(__file__).resolve().parent.parent
    missing = [p.name for p in root.glob("*.ps1")
               if not p.read_bytes().startswith(codecs.BOM_UTF8)]
    assert not missing, (
        f"UTF-8 BOM이 없는 PowerShell 스크립트: {missing} — "
        "cp949로 읽혀 한글과 따옴표가 어긋나고 파싱이 실패한다"
    )


@pytest.mark.synthetic
def test_the_picker_shows_names_only():
    """고르는 자리에는 **이름만** 둔다. 데이터 폴더 경로·포트·«지금 이 서버»는
    관리자 정보라 소음이다 — 지금 어느 서버인지는 초록 테두리가 말해 준다.

    남기는 것은 «중지됨» 하나다. 설명이 아니라 «누를 수 없다»는 사실이고,
    없으면 흐린 줄이 왜 안 눌리는지 알 방법이 없다.
    """
    from pathlib import Path

    js = (Path(__file__).resolve().parent.parent
          / "frontend" / "static" / "js" / "app.js").read_text(encoding="utf-8")
    body = js[js.index("function _projRowsHtml("):]
    body = body[:body.index("\nfunction ", 1)]
    # 설명 칸은 **한 번만** 나온다 — 그것이 «중지됨»이다.
    # (`title="서버가 실행 중이 아닙니다"`는 hover 툴팁이라 화면 글자가 아니다.)
    assert body.count("lp-note") == 1, "설명 칸이 늘었다"
    assert '<span class="lp-note">중지됨</span>' in body
    for noise in ("data_root", "lp-port", "지금 이 서버"):
        assert noise not in body, f"고르는 자리에 «{noise}»가 다시 들어왔다"


# ── 배포 직후에 아무도 못 들어가는 교착 ────────────────────────────────────
#
# `data/`가 `.gitignore` 대상이라 새 PC에 복사하면 `employees.json`이 없다.
# 그때 「등록되지 않은 사번」이라고 하면 관리자는 사번을 등록하려 하는데,
# **등록하려면 관리자 로그인이 필요하다** — 교착이다.
#
# 그래서 셋을 갈라야 한다:
#     파일이 없다      -> 503 «예시를 복사하라»
#     목록이 비었다    -> 503 «관리자를 등록하라»
#     그 사번이 없다   -> 401 «등록되지 않은 사번»
@pytest.fixture
def employees_file(tmp_path, monkeypatch):
    from backend import config as C

    monkeypatch.setattr(C, "EMPLOYEES_FILE", tmp_path / "employees.json")
    return tmp_path / "employees.json"


@pytest.mark.synthetic
def test_a_missing_employee_list_says_so(employees_file):
    import json

    from fastapi import HTTPException

    from backend.routers import auth

    with pytest.raises(HTTPException) as e:
        auth.login(auth.LoginRequest(employee_id="A551135"))
    assert e.value.status_code == 503, "«등록되지 않은 사번»으로 뭉개면 교착이다"
    assert "example" in str(e.value.detail), "무엇을 해야 하는지 말해 주지 않는다"

    employees_file.write_text('{"employees": []}', encoding="utf-8")
    with pytest.raises(HTTPException) as e2:
        auth.login(auth.LoginRequest(employee_id="A551135"))
    assert e2.value.status_code == 503

    employees_file.write_text(json.dumps(
        {"employees": [{"id": "A551135", "admin": True}]}), encoding="utf-8")
    assert auth.login(auth.LoginRequest(employee_id="A551135"))["is_admin"] is True

    # 목록이 있는데 그 사번이 없는 것은 **다른 상황**이다
    with pytest.raises(HTTPException) as e3:
        auth.login(auth.LoginRequest(employee_id="Z999999"))
    assert e3.value.status_code == 401


@pytest.mark.synthetic
def test_the_example_files_are_tracked():
    """`data/`가 통째로 무시되면 예시도 함께 사라져 배포가 막힌다.

    `.gitignore`가 `data/`가 아니라 `data/*`여야 한다 — 디렉터리 자체를
    제외하면 git이 그 안으로 내려가지 않아 `!data/*.example.json`이 먹지 않는다.
    """
    import subprocess

    for name in ("employees.example.json", "projects.example.json"):
        f = config.BASE / "data" / name
        assert f.exists(), f"{name}이 없다 — 배포하면 만들 근거가 없다"
        r = subprocess.run(["git", "check-ignore", "-q", str(f)],
                           cwd=str(config.BASE), capture_output=True)
        assert r.returncode != 0, f"{name}이 .gitignore에 걸려 커밋되지 않는다"


@pytest.mark.synthetic
def test_the_employee_example_has_an_admin():
    """**최소 한 명은 admin**이어야 한다. 아무도 아니면 화면에서 사번을
    추가할 수 없어 다시 교착이다."""
    import json

    data = json.loads((config.BASE / "data" / "employees.example.json")
                      .read_text(encoding="utf-8"))
    assert any(e.get("admin") for e in data["employees"])
