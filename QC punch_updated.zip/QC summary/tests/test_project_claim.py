"""
프로젝트 규칙이 공통 Check 3을 «선점»하는 경로.

## 실데이터로는 확인할 수 없다

이 물량에는 F03·G05 WPS가 없고 S355KT 계열 재질도 없다 — 규칙 5개가 **전부
0행**이다. 그래서 여기가 유일한 확인 수단이다. `rule_health`의 «0행 경고»도
바로 이 상태를 알리려고 만든 것이다.

## 지키는 것 네 가지

1. **선점은 «일치»에서 일어난다** — 통과도 프로젝트 규칙의 판정이다.
   위반일 때만 선점하면 범위 «안»인 행이 G열 판정으로 흘러가 없던 Check 3이 생긴다.
2. **억제는 side(J/K) 단위다** — 행 단위면 J만 매칭된 행에서 K열 판정이 사라진다.
3. **규칙을 끄면 공통이 돌아온다** — 꺼진 규칙이 공통을 눈멀게 하면 판정 구멍이다.
4. **Check 10 짝짓기가 살아 있다** — 두께 플래그 번호가 3이 아닐 수 있다.
"""
from __future__ import annotations

import pytest

from backend.services import project_checks as P
from backend.services import verifier as V
from backend.services.verifier import Col

from tests.test_checks_16_17 import FakeLoader, make_row


# WPS List G열은 3~24만 허용한다. 프로젝트 규칙은 12~50이다.
# 두 범위가 갈라지는 지점(30mm)에서 «누가 판정했는지»가 드러난다.
WPS_TABLE = {
    "TR-FC-F01": {"process": "FCAW", "joint_detail": ["SB"],
                  "materials": [{"base_metal": "ASTM A36", "thk_range": "3~24"}]},
}

RULE = {"key": "thk-mat-kt40", "no": "P1", "name": "재질 KT-40 두께",
        "color": "Blue", "kind": "thickness_range",
        "when": {"material_contains": ["KT-40"]},
        "param": {"range": "12~50"}, "overrides": [3], "cols": "J · K"}


def checker(rules: list[dict] | None = None,
            enabled: dict[int, bool] | None = None) -> V.QCChecker:
    c = V.QCChecker(FakeLoader(WPS_TABLE))
    c._rules, c._rule_problems = P.parse(rules if rules is not None else [RULE])
    c._enabled = enabled if enabled is not None else {}
    return c


def judge(c: V.QCChecker, **cells):
    row = make_row(WPS_NO="TR-FC-F01", **cells)
    return c._c3_thickness(row, "TR-FC-F01")


# ── 선점은 «일치»에서 ────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_a_matching_row_is_judged_by_the_project_rule():
    """30mm는 G열(3~24) 밖이지만 프로젝트 규칙(12~50) 안이다 -> 무플래그.

    위반일 때만 선점하면 이 행이 G열 판정으로 흘러가 **없던 Check 3이 생긴다.**
    """
    assert judge(checker(), MATERIAL1="S355KT-40", THICKNESS1=30) is None


@pytest.mark.synthetic
def test_a_matching_row_that_violates_gets_the_project_number():
    """55mm는 프로젝트 규칙(12~50) 밖 -> Check 3이 아니라 **101**로 나온다."""
    f = judge(checker(), MATERIAL1="S355KT-40", THICKNESS1=55)
    assert f is not None
    assert f.check_no == "P1", "공통 번호로 나오면 화면 배지가 «공통»이라고 거짓말한다"
    assert "공통 Check 3 대신 판정" in f.msg
    assert "12~50" in f.expected


@pytest.mark.synthetic
def test_a_row_the_rule_does_not_claim_still_gets_the_common_check():
    """대상이 아닌 재질은 지금 그대로 G열(3~24)로 판정된다."""
    f = judge(checker(), MATERIAL1="ASTM-A36", THICKNESS1=30)
    assert f is not None and f.check_no == "3"


# ── 억제는 side 단위 ────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_the_k_side_keeps_its_judgement_after_j_is_claimed():
    """J가 선점돼 **통과**해도 K열은 여전히 판정을 받아야 한다.

    행 단위로 억제하면 K열 판정이 조용히 사라진다. 두 side가 같은 재질이면
    지금도 각각 본다 — 감사에서 «J는 정상, K만 초과» 8건을 찾아낸 그 판정이다.

    (재질이 **서로 다르면** 낮은 두께만 본다 — 현업 확인 2026-08-13.
    아래 `test_a_dissimilar_joint_is_judged_on_the_thinner_side`가 그쪽이다.)
    """
    f = judge(checker(), MATERIAL1="S355KT-40", THICKNESS1=30,
              MATERIAL2="S355KT-40", THICKNESS2=60)
    assert f is not None, "K열 판정이 사라졌다"
    assert f.check_no == "P1" and f.col == Col.THICKNESS2, \
        "J가 통과한 뒤 K가 범위를 벗어났는데 안 잡힌다"


@pytest.mark.synthetic
def test_a_dissimilar_joint_is_judged_on_the_thinner_side():
    """이종재 이음은 **낮은 두께**만 본다 (현업 확인 2026-08-13).

    WPS를 상위 그레이드 재질과 낮은 두께 기준으로 고르기 때문이다. 실측 12행이
    여기 해당했다 — 전부 `ASTM-A36` 정상 + `SM355A` 25T 범위 밖이었다.

    **같은 재질이면 여전히 각 side를 본다.** 범위를 넓히면 위 8건 유형을 놓친다.
    """
    # J=30(규칙 12~50 통과) · K=40(G열 3~24 밖) — 재질이 다르므로 낮은 J만 본다
    assert judge(checker(), MATERIAL1="S355KT-40", THICKNESS1=30,
                 MATERIAL2="ASTM-A36", THICKNESS2=40) is None

    # 낮은 쪽이 범위를 벗어나면 그건 잡는다
    f = judge(checker(), MATERIAL1="ASTM-A36", THICKNESS1=40,
              MATERIAL2="S355KT-40", THICKNESS2=55)
    assert f is not None and f.col == Col.THICKNESS1, "낮은 쪽(J=40)이 안 잡혔다"


@pytest.mark.synthetic
def test_each_side_can_be_claimed_independently():
    """J·K가 모두 대상이면 J가 먼저다(행당 두께 플래그 최대 1건)."""
    f = judge(checker(), MATERIAL1="S355KT-40", THICKNESS1=55,
              MATERIAL2="S355KT-40", THICKNESS2=55)
    assert f is not None and f.check_no == "P1" and f.col == Col.THICKNESS1


# ── 규칙을 끄면 공통이 돌아온다 ─────────────────────────────────────────────
# 공통이 «아는» 재질에 걸리는 규칙. 끄고 켜는 것을 관찰하려면 이래야 한다 —
# 매핑표에 없는 재질(S355KT-40 등)은 규칙을 꺼도 공통이 판정할 수 없어서
# «돌아오는지»를 볼 수 없다(그건 아래에서 따로 본다).
RULE_ON_KNOWN = dict(RULE, key="thk-mat-a36", no="P2", name="재질 A36 두께",
                     when={"material_contains": ["ASTM-A36"]},
                     param={"range": "12~50"})


@pytest.mark.synthetic
def test_turning_the_rule_off_restores_the_common_check():
    """꺼진 규칙이 공통 판정을 눈멀게 하면 «조용히 0건»이 된다.

    30mm는 G열(3~24) 밖이고 규칙(12~50) 안이다. 규칙이 켜져 있으면 무플래그,
    끄면 Check 3이 **나와야** 한다.
    """
    on = judge(checker(rules=[RULE_ON_KNOWN]), MATERIAL1="ASTM-A36", THICKNESS1=30)
    assert on is None, "규칙이 켜져 있는데 공통이 판정했다"

    off = judge(checker(rules=[RULE_ON_KNOWN], enabled={"P2": False}),
                MATERIAL1="ASTM-A36", THICKNESS1=30)
    assert off is not None and off.check_no == "3", "규칙을 껐는데 공통도 함께 죽었다"


@pytest.mark.synthetic
def test_an_unmapped_material_is_only_judged_by_the_project_rule():
    """공통 재질 매핑표에 없는 재질은 **프로젝트 규칙만** 판정할 수 있다.

    `S355KT-40`·`S355KL-0`은 `_get_material_key()`가 None을 준다. 그래서
    선점을 재질 키 조회보다 **앞**에 둬야 한다 — 순서를 반대로 하면 프로젝트
    재질이 선점에 닿지도 못하고 조용히 판정에서 빠진다(실제로 그랬다).

    이 재질은 규칙을 끄면 «공통으로 돌아가는» 것이 아니라 판정 대상이 아니게 된다.
    """
    from backend.services.verifier import _get_material_key

    assert _get_material_key("S355KT-40") is None, "전제가 바뀌었다"
    assert judge(checker(), MATERIAL1="S355KT-40", THICKNESS1=55).check_no == "P1"
    assert judge(checker(enabled={"P1": False}),
                 MATERIAL1="S355KT-40", THICKNESS1=55) is None


@pytest.mark.synthetic
def test_turning_it_off_also_stops_the_suppression_count():
    c = checker(enabled={"P1": False})
    judge(c, MATERIAL1="S355KT-40", THICKNESS1=30)
    assert not c._suppressed and not c._rule_matched


# ── 선점·억제가 세어진다 ────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_a_passing_row_is_still_counted():
    """통과해서 플래그가 없는 경우는 **이 카운터가 아니면 어디에도 안 보인다.**"""
    c = checker()
    assert judge(c, MATERIAL1="S355KT-40", THICKNESS1=30) is None
    assert c._rule_matched["P1"] == 1
    assert c._suppressed[("P1", "3")] == 1


# ── Check 10 짝짓기 ─────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_check10_still_pairs_when_the_thickness_flag_is_a_project_rule():
    """두께 플래그 번호가 3이 아닐 수 있다.

    `f3.check_no == "3"`으로 좁히면 프로젝트 규칙이 선점한 행에서 **Check 10이
    조용히 0건**이 된다.
    """
    import inspect

    # 주석에도 같은 문구가 있다. **코드 줄만** 본다 — 안 그러면 설명을 코드로
    # 착각해 테스트가 스스로를 잡는다(실제로 그랬다).
    src = "\n".join(ln for ln in inspect.getsource(V.QCChecker._check_row).splitlines()
                    if not ln.strip().startswith("#"))
    assert "if f3 and f8:" in src
    assert 'f3.check_no == "3"' not in src, \
        "두께 플래그를 공통 번호로 좁히고 있다 — Check 10이 조용히 0건이 된다"


# ── 규칙이 없으면 지금과 똑같다 ─────────────────────────────────────────────
@pytest.mark.synthetic
def test_no_rules_means_the_old_behaviour():
    c = checker(rules=[])
    assert judge(c, MATERIAL1="ASTM-A36", THICKNESS1=30).check_no == "3"
    assert judge(c, MATERIAL1="ASTM-A36", THICKNESS1=20) is None
    # 매핑표에 없는 재질은 규칙이 없으면 판정 대상이 아니다(기존 동작)
    assert judge(c, MATERIAL1="S355KT-40", THICKNESS1=30) is None


# ── 접두사가 비면 «수리 WPS 없음»이다 ───────────────────────────────────────
#
# `startswith("")`는 **항상 True**다. 4단계에서 DEFAULTS의 `repair_prefix`를
# 비운 뒤, params가 없는 프로파일에서는 모든 WPS가 수리로 분류되어
# **Check 2·4·11이 통째로 빠졌다.** 실측: Check 4 36 -> 0, Check 11 94 -> 0.
#
# params가 없는 프로파일은 «새 프로젝트를 처음 돌리는» 경로 그 자체라, 이 결함은
# 가장 중요한 순간에 «결함이 거의 없는 깨끗한 결과»를 만들어 낸다.
# qc-data-verifier가 실데이터로 재현해 잡았다.
@pytest.mark.synthetic
def test_an_empty_repair_prefix_means_no_repair_wps(monkeypatch):
    from backend.services import wps_rules as W

    monkeypatch.setattr(W, "repair_prefix", lambda: "")
    assert V._is_repair_wps("TR-FC-R01") is False, \
        "접두사가 비었는데 수리 WPS로 분류된다 — Check 2·4·11이 통째로 빠진다"
    assert V._is_repair_wps("아무거나") is False

    monkeypatch.setattr(W, "repair_prefix", lambda: "TR-FC-R")
    assert V._is_repair_wps("TR-FC-R01") is True
    assert V._is_repair_wps("TR-FC-F01") is False


@pytest.mark.synthetic
def test_checks_still_judge_when_the_prefix_is_empty(monkeypatch):
    """접두사가 비어도 Check 4는 «판정»해야 한다 — 건너뛰면 안 된다."""
    from backend.services import wps_rules as W

    monkeypatch.setattr(W, "repair_prefix", lambda: "")
    c = V.QCChecker(FakeLoader({"TR-FC-F01": {
        "process": "FCAW", "joint_detail": "SB",
        "materials": [{"base_metal": "ASTM A36", "thk_range": "3~24"}]}}))
    c._rules, c._rule_problems = [], []
    c._enabled = {}
    row = make_row(WPS_NO="TR-FC-F01", WPS_PROCESS="FCAW", GROOVE="XX")  # SB만 허용
    flags = c._check_row(row)
    assert any(x.check_no == "4" for x in flags),         "접두사가 비어 Check 4가 통째로 빠졌다 — 모든 WPS가 수리로 분류됐다"


@pytest.mark.synthetic
def test_the_empty_prefix_warning_matches_what_actually_happens():
    """경고 문구가 **지금 동작**을 말해야 한다.

    고치기 전에는 빈 접두사가 «모든 WPS = 수리»를 뜻해서 Check 2·4·11이 통째로
    빠졌고, 경고도 그렇게 적혀 있었다. 고친 뒤에는 반대다 — 아무 행도 수리로
    분류되지 않아 **수리 시공 행까지 지적한다.**

    경고는 사람이 읽고 판단하는 유일한 근거다. 문구가 반대면 «결함이 적게 나온다»고
    믿고 반대 방향으로 조사하게 된다.
    """
    import inspect

    from backend.services import wps_rules as W

    src = inspect.getsource(W.check_rules_alive)
    i = src.index("repair_prefix")
    msg = src[i:i + 400]
    assert "건너" not in msg, "빈 접두사가 판정을 «건너뛴다»고 적혀 있다 — 지금은 반대다"
    assert "오탐" in msg
