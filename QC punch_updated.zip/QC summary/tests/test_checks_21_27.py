"""Check 21~27 — 2026-08-13 현업 확인으로 추가된 공통 판정.

손으로 만든 행 튜플로 돈다. **판정 조건을 코드 없이 읽을 수 있어야** 하기
때문이다(`test_checks_19_20.py`와 같은 모양).

각 검사의 실데이터 건수는 정본 문서에 적혀 있다. 여기서는 «규칙이 무엇인가»만
고정한다 — 건수는 물량이 바뀌면 달라지지만 규칙은 아니다.
"""
from __future__ import annotations

import re

import pytest

from backend.services import project_checks as P
from backend.services import verifier as V
from backend.services.verifier import Col

from tests.test_checks_16_17 import FakeLoader, make_row


WPS_TABLE = {
    "TR-FC-F01":    {"process": "FCAW", "joint_detail": ["SB"],
                     "materials": [{"base_metal": "ASTM A36", "thk_range": "3~24"}]},
    "TR-SMFC-G01":  {"process": "SMFC", "joint_detail": ["SB"],
                     "materials": [{"base_metal": "ASTM A36", "thk_range": "3~24"}]},
    "TR-SMFC-GK01": {"process": "SMFC", "joint_detail": ["SB"],
                     "materials": [{"base_metal": "ASTM A36", "thk_range": "3~24"}]},
    "TR-FC-R01":    {"process": "FCAW", "joint_detail": ["SB"],
                     "materials": [{"base_metal": "ASTM A36", "thk_range": "3~24"}]},
    "TR-FC-Q01":    {"process": "FCAW", "joint_detail": ["SB"],
                     "materials": [{"base_metal": "ASTM A36", "thk_range": "3~24"}]},
}


def checker() -> V.QCChecker:
    c = V.QCChecker(FakeLoader(WPS_TABLE))
    c._enabled = {}
    c._rules, c._rule_problems = [], []
    return c


# ── Check 21 — 혼합 프로세스 용접재료 ────────────────────────────────────────
#
# GTFC·SMFC는 한 이음에서 두 프로세스를 쓰므로 소모품도 둘이다.
# 실데이터: 혼합 40행 중 2행이 재료 하나뿐이었다(`TR-GTFC-G01`).
@pytest.mark.synthetic
def test_c21_mixed_process_needs_two_consumables():
    c = checker()
    one = make_row(CONSUMABLE_LOT="F902A4L5D7")
    two = make_row(CONSUMABLE_LOT="F902A4L5D7, K71TG-1")

    assert c._c21_mixed_consumables(one, "GTFC") is not None
    assert c._c21_mixed_consumables(two, "GTFC") is None
    assert c._c21_mixed_consumables(one, "SMFC") is not None


@pytest.mark.synthetic
def test_c21_ignores_single_process_and_empty_lot():
    """단일 프로세스는 하나면 되고, **공란은 Check 18의 몫**이다.

    둘 다 걸면 같은 원인에 플래그가 둘 붙어, 하나를 고쳐도 계속 걸리는 것처럼 보인다.
    """
    c = checker()
    assert c._c21_mixed_consumables(make_row(CONSUMABLE_LOT="F902A4L5D7"), "FCAW") is None
    assert c._c21_mixed_consumables(make_row(CONSUMABLE_LOT=""), "GTFC") is None


@pytest.mark.synthetic
def test_c21_strips_quotes_and_blanks():
    """엑셀에서 따옴표가 섞여 오고, 쉼표 뒤가 비기도 한다."""
    c = checker()
    assert c._c21_mixed_consumables(make_row(CONSUMABLE_LOT='"A1", "B2"'), "SMFC") is None
    assert c._c21_mixed_consumables(make_row(CONSUMABLE_LOT="A1, "), "SMFC") is not None


# ── Check 22 — NDT 100% 구간의 리포트 번호 ───────────────────────────────────
#
# 번호 끝의 `*`는 «촬영하지 않은 수량» 표기다. 100% 구간은 전수 검사라
# 별표가 있으면 안 된다. 20%·10% 구간의 별표는 정상이다(Check 26이 본다).
@pytest.mark.synthetic
def test_c22_flags_star_and_blank_on_full_coverage():
    c = checker()
    base = dict(NDT_PLAN_DATE="2026-07-08", NDT_EXT_UT="100")

    assert c._c22_ndt_report_pending(make_row(UT_REPORT="MSOU04738", **base)) is None
    assert c._c22_ndt_report_pending(make_row(UT_REPORT="MSOU04738*", **base)) is not None
    assert c._c22_ndt_report_pending(make_row(UT_REPORT="", **base)) is not None


@pytest.mark.synthetic
def test_c22_leaves_partial_coverage_alone():
    """20% 구간의 별표는 **정상**이다 — 애초에 전수를 찍지 않는다.

    여기서 걸면 248행이 통째로 오탐이 되고, 진짜 문제인 100% 구간이 묻힌다.
    """
    c = checker()
    assert c._c22_ndt_report_pending(make_row(
        NDT_PLAN_DATE="2026-07-08", NDT_EXT_UT="20", UT_REPORT="MSOU04738*")) is None


@pytest.mark.synthetic
def test_c22_needs_a_plan_date():
    """계획/신청일이 없으면 «검사를 걸어 두지 않은» 행이라 볼 것이 없다."""
    c = checker()
    assert c._c22_ndt_report_pending(make_row(
        NDT_EXT_UT="100", UT_REPORT="")) is None


# ── Check 23 — 수리 표기 대비 수리 WPS ───────────────────────────────────────
#
# E열(헤더 `RE`)에 값이 있으면 수리 시공이다. 표기는 `RE`·`R1`·`U1`·`M1`처럼
# 다양하고 **비어 있지 않기만 하면 해당**이다.
@pytest.mark.synthetic
def test_c23_repair_row_needs_a_repair_wps():
    c = checker()
    assert c._c23_repair_wps_mark(make_row(REPAIR_MARK="U1"), "TR-FC-R01") is None
    assert c._c23_repair_wps_mark(make_row(REPAIR_MARK="U1"), "TR-FC-F01") is not None
    assert c._c23_repair_wps_mark(make_row(REPAIR_MARK="RE"), "TR-FC-F01") is not None


@pytest.mark.synthetic
def test_c23_ignores_blank_mark():
    c = checker()
    assert c._c23_repair_wps_mark(make_row(REPAIR_MARK=""), "TR-FC-F01") is None
    assert c._c23_repair_wps_mark(make_row(REPAIR_MARK="  "), "TR-FC-F01") is None


# ── Check 24 — TKY 이음 전용 WPS ─────────────────────────────────────────────
#
# Q열이 `TT`면 TKY 이음이라 WPS의 **마지막 구분**이 `GK`로 시작해야 한다.
# 앞의 프로세스 표기는 프로젝트마다 다르므로 보지 않는다.
@pytest.mark.synthetic
def test_c24_tky_needs_a_gk_wps():
    c = checker()
    assert c._c24_tky_wps(make_row(JOINT_TYPE="TT"), "TR-SMFC-GK01") is None
    assert c._c24_tky_wps(make_row(JOINT_TYPE="TT"), "TR-SMFC-G01") is not None


@pytest.mark.synthetic
def test_c24_only_looks_at_the_last_token():
    """`GK`가 앞에 있어도 마지막 구분이 아니면 대상이 아니다."""
    c = checker()
    assert c._c24_tky_wps(make_row(JOINT_TYPE="TT"), "TR-GK-F01") is not None
    assert c._c24_tky_wps(make_row(JOINT_TYPE="TT"), "RU-FC-GK02") is None


@pytest.mark.synthetic
def test_c24_ignores_other_joint_types():
    c = checker()
    for t in ("T", "B", ""):
        assert c._c24_tky_wps(make_row(JOINT_TYPE=t), "TR-SMFC-G01") is None


# ── Check 25 — Q01 WPS의 이음 Type ───────────────────────────────────────────
@pytest.mark.synthetic
def test_c25_q01_only_on_type_b():
    c = checker()
    assert c._c25_q01_joint_type(make_row(JOINT_TYPE="B"), "TR-FC-Q01") is None
    assert c._c25_q01_joint_type(make_row(JOINT_TYPE="T"), "TR-FC-Q01") is not None
    # Q열이 비면 판정 근거가 없다
    assert c._c25_q01_joint_type(make_row(JOINT_TYPE=""), "TR-FC-Q01") is None
    # Q01이 아니면 대상이 아니다
    assert c._c25_q01_joint_type(make_row(JOINT_TYPE="T"), "TR-FC-F01") is None


# ── Check 27 — 이종재 상위 그레이드 [보류] ───────────────────────────────────
#
# **전체 등급표가 아직 없다.** 지금은 시험온도(-40 > -20)와 S355 < S420만
# 비교할 수 있고, 나머지는 판정하지 않는다 — 근거 없이 찍으면 오탐이다.
@pytest.mark.synthetic
def test_c27_knows_only_what_it_was_told():
    hi = V._higher_material_grade
    # ① 재질명 끝의 시험온도 — 낮을수록 상위 (RUYA식 `S355KT-40` 표기)
    assert hi("S355KL-20", "S355KT-40") == "S355KT-40"
    assert hi("S355KL-0", "S355KL-50Z") == "S355KL-50Z"
    # ② 선급강 등급 문자 — `_material_impact_temp_c()`가 이미 안다
    assert hi("NV-E36", "NV-DW36") == "NV-E36", "E36(-40) > DW36(-20)"
    # ③ 등급표 — 지금 아는 것은 S355 < S420 하나뿐이다
    assert hi("S355KT-40", "S420KT-40") == "S420KT-40"
    # ④ 그 외는 판단 불가. 실데이터 이종재 21건 중 17건이 여기다
    assert hi("ASTM-A36", "SM355A") is None
    assert hi("ASTM-A36", "NV-DW36") is None, "한쪽만 알면 비교할 수 없다"
    # 같은 재질은 애초에 이종재가 아니다
    assert hi("ASTM-A36", "ASTM-A36") is None


@pytest.mark.synthetic
def test_c27_does_not_read_a_grade_number_as_a_temperature():
    """`ASTM-A36`의 36을 -36℃로 읽으면 **A36이 최상위 등급이 된다.**

    끝의 «-숫자»를 그냥 온도로 잡으면 그렇게 된다. 온도 등급 문자(`KT`·`KL`)
    뒤의 것만 읽는다.
    """
    assert V._temp_from_name("ASTM-A36") is None
    assert V._temp_from_name("NV-EW420Z") is None
    assert V._temp_from_name("S355KT-40") == -40
    assert V._temp_from_name("S355KL-50Z") == -50


@pytest.mark.synthetic
def test_c27_stays_silent_without_a_grade_table():
    """판단 근거가 없으면 **아무 말도 하지 않는다.**

    오탐은 «이 검사는 못 믿는다»로 이어져 진짜 결함까지 묻는다. 등급표를 받으면
    `verifier._GRADE_ORDER`를 채워 완성한다.
    """
    c = checker()
    assert c._c27_dissimilar_grade(
        make_row(MATERIAL1="ASTM-A36", MATERIAL2="SM355A"), "TR-FC-F01") is None


@pytest.mark.synthetic
def test_the_grade_table_is_still_marked_as_pending():
    """[보류] 표식이 사라지면 «완성된 검사»로 읽힌다.

    등급표가 오기 전까지 이 검사는 대상이 0건이다. 표식이 없으면 그게 «문제
    없음»으로 보이고, 아무도 등급표를 다시 묻지 않는다.
    """
    from backend.services import rule_catalog

    spec = rule_catalog.CATALOG[27]
    assert "[보류]" in spec["summary"] or "[보류]" in spec["logic"]
    assert "_GRADE_ORDER" in spec["logic"], "어디를 채워야 하는지 적혀 있어야 한다"


# ── Check 20 보완 — FW와 N열 (2026-08-13) ───────────────────────────────────
@pytest.mark.synthetic
def test_c20_treats_fw_like_fl():
    """`FW`도 필릿이라 FCAW를 쓴다.

    실데이터에 `FW`가 0건이라 지금은 결과가 안 바뀐다. 그래서 더 위험하다 —
    들어오는 순간 SMFC를 요구해 오탐이 되고, 아무도 이 검사를 의심하지 않는다.
    """
    c = checker()
    for groove in ("FL", "FW"):
        row = make_row(MATERIAL1="API-5L-X52", GROOVE=groove)
        assert c._c20_api_groove_process(row, "FCAW") is None, f"{groove}+FCAW가 걸린다"
        assert c._c20_api_groove_process(row, "SMFC") is not None, f"{groove}+SMFC가 통과한다"


@pytest.mark.synthetic
def test_c20_looks_at_both_material_columns():
    """한쪽만 API인 이종재 이음이 빠져 있었다."""
    c = checker()
    row = make_row(MATERIAL1="ASTM-A36", MATERIAL2="API5L-GRB", GROOVE="SB")
    assert c._c20_api_groove_process(row, "FCAW") is not None, "N열 API가 안 보인다"


# ── 프로젝트 규칙의 P열 조건 — «시작»이지 정확일치가 아니다 ──────────────────
@pytest.mark.synthetic
def test_project_rule_ndt_cat_matches_by_prefix():
    """실데이터 P열은 `A6`·`A5`·`A1`·`C5`·`S4`처럼 문자+숫자다.

    정확일치로 받으면 «A»가 **아무것도 못 잡는다** — 규칙이 조용히 0행이 되고,
    그건 «위반이 없다»로 읽힌다.
    """
    from backend.services import project_checks as P

    rule = P.Rule({"key": "g05-cat", "no": "P1", "name": "G05 · Cat A/B 불가",
                   "color": "Indigo", "kind": "forbid",
                   "when": {"wps_contains": ["G05"], "ndt_cat_startswith": ["A", "B"]}})
    for cat in ("A6", "A1", "B2"):
        assert rule.matches_row(["ASTM-A36"], "RU-FC-G05", cat), f"{cat}가 안 걸린다"
    for cat in ("C5", "S4", ""):
        assert not rule.matches_row(["ASTM-A36"], "RU-FC-G05", cat), f"{cat}가 걸린다"


@pytest.mark.synthetic
def test_project_row_rules_need_every_condition():
    """조건은 **AND**다. 하나도 없으면 «전부»가 아니라 «아무것도»여야 한다 —
    빈 조건이 전체를 잡으면 규칙 하나가 물량 전체를 결함으로 만든다."""
    from backend.services import project_checks as P

    rule = P.Rule({"key": "g05-s420", "no": "P2", "name": "G05 · S420 불가",
                   "color": "Maroon", "kind": "forbid",
                   "when": {"wps_contains": ["G05"], "material_contains": ["S420"]}})
    assert rule.matches_row(["S420KT-40", ""], "RU-FC-G05", "C5")
    assert not rule.matches_row(["S355KT-40", ""], "RU-FC-G05", "C5"), "재질이 다른데 걸린다"
    assert not rule.matches_row(["S420KT-40", ""], "RU-FC-F01", "C5"), "WPS가 다른데 걸린다"

    empty = P.Rule({"key": "empty", "no": "P3", "name": "조건 없음",
                    "color": "Blue", "kind": "forbid", "when": {}})
    assert not empty.matches_row(["ASTM-A36"], "RU-FC-F01", "C5"), \
        "조건 없는 규칙이 전체를 잡는다"


# ── Check 26 — NDT 적용 요율 (2차 패스) ──────────────────────────────────────
@pytest.mark.synthetic
def test_c26_is_a_second_pass_check():
    """묶음 단위라 행 하나로는 판정할 수 없다.

    2차 패스는 `_register_flag()`를 거쳐야 `stats`·부서/팀·용접사 집계가 함께
    갱신된다. 직접 `row_flags`에 넣으면 257행이 용접사 집계에서 빠진 사고가 재현된다.
    """
    import inspect

    src = inspect.getsource(V.QCChecker._detect_check26_ndt_rate)
    # 독스트링에도 `row_flags`가 나온다(설명하려고). **코드 줄만** 본다 —
    # 안 그러면 설명을 코드로 착각해 테스트가 스스로를 잡는다(실제로 그랬다).
    body = src[src.index('"""', src.index('"""') + 3) + 3:]
    assert "_register_flag" in body
    assert "row_flags" not in body, "2차 패스가 집계를 건너뛰고 직접 쓴다"
    # 요구 요율이 섞이면 **최댓값** — 낮은 요율 조인트를 끼워 넣어 요구를 낮출 수 없다
    assert 'max(g["reqs"])' in body or "max(g['reqs'])" in body


@pytest.mark.synthetic
def test_c26_rate_is_counted_from_the_star_suffix():
    """`*`를 뗀 번호가 같으면 한 묶음이고, `*` 없는 것이 실제 촬영분이다."""
    reports = ["MSOU00001", "MSOU00001", "MSOU00001*", "MSOU00001*",
               "MSOU00001*", "MSOU00001*", "MSOU00001*", "MSOU00001*",
               "MSOU00001*", "MSOU00001*"]
    base = {r.rstrip("*") for r in reports}
    shot = sum(1 for r in reports if not r.endswith("*"))
    assert base == {"MSOU00001"} and shot == 2
    assert 100.0 * shot / len(reports) == 20.0


# ── 카탈로그가 판정과 어긋나지 않는가 ───────────────────────────────────────
#
# `rule_catalog.CATALOG`는 '프로젝트 세팅' 탭과 결함 카드 배지의 **유일한 출처**다.
# 판정을 바꾸고 여기를 안 고치면 **현업이 읽는 뜻이 사실상 반대가 된다.**
# 예외도 경고도 나지 않는다 — 실제로 오늘 Check 3·6·9가 그렇게 남아 있었다
# (qc-data-verifier가 잡았다).
#
# 판정 «내용»을 자동으로 대조할 방법은 없다. 대신 **바뀐 것이 확실한 문구**가
# 다시 들어오는 것을 막는다.
@pytest.mark.synthetic
def test_catalog_does_not_describe_the_old_check3():
    """Check 3은 이제 이종재일 때 낮은 두께만 본다."""
    from backend.services import rule_catalog

    logic = rule_catalog.CATALOG[3]["logic"]
    assert "재질이 서로 다르면" in logic, "이종재 분기가 설명에 없다"
    assert "낮은 두께" in logic


@pytest.mark.synthetic
def test_catalog_does_not_describe_the_old_check9():
    """Check 9는 «확인 대상 표시»가 아니라 «사용 불가»다.

    성격이 뒤집혔는데 설명이 옛것이면, 현업은 «확인해 보라는 뜻»으로 읽고
    넘어간다. 그게 이 표가 있는 이유 자체를 무너뜨린다.
    """
    from backend.services import rule_catalog

    spec = rule_catalog.CATALOG[9]
    assert "확인 대상으로 표시한다" not in spec["logic"], "옛 규칙 설명이 남아 있다"
    assert "API" in spec["logic"]
    # 요약이 «금지»로 읽혀야 한다. «확인»으로 남으면 현업이 넘어간다.
    assert "없다" in spec["summary"], f"요약이 금지로 안 읽힌다: {spec['summary']}"
    # 코드는 J·K를 둘 다 본다 — cols가 J 하나면 화면이 잘못된 열을 가리킨다
    assert "K" in spec["cols"] and "M" in spec["cols"]


@pytest.mark.synthetic
def test_catalog_covers_the_check6_relaxation():
    """혼합 프로세스 완화가 설명에 없으면 «왜 안 걸리지»가 된다."""
    from backend.services import rule_catalog

    logic = rule_catalog.CATALOG[6]["logic"]
    assert "혼합 프로세스" in logic and "한 명" in logic


@pytest.mark.synthetic
def test_every_judged_check_has_a_catalog_entry():
    """번호를 만들어 놓고 설명을 빠뜨리면 '프로젝트 세팅' 탭에 빈 카드가 뜬다."""
    from backend.services import rule_catalog
    from backend.services.verifier import CHECK_NAMES, CHECK_UNWORKED

    missing = [n for n in CHECK_NAMES
               if n != CHECK_UNWORKED and n not in rule_catalog.CATALOG]
    assert not missing, f"카탈로그에 없는 Check: {missing}"
    empty = [n for n, s in rule_catalog.CATALOG.items()
             if not s.get("summary") or not s.get("logic")]
    assert not empty, f"설명이 빈 Check: {empty}"


# ── Check 3의 «같은 재질» 분기 — 실데이터가 지켜 주지 않는다 ────────────────
#
# 2026-08-13에 «이종재면 낮은 두께만»으로 좁혔다. 같은 재질이면 J·K를 각각 보는
# 것이 그대로 남아야 하는데, **실데이터에 그 사례가 0건**이다:
#
#     TRION  K열이 있고 관재가 아닌 행 86 (동일재질 66 · 이종재 20)
#            그중 「J 정상 · K만 초과」 = 0건
#            (동일재질에서 K가 초과한 3건은 전부 J도 함께 초과)
#     RUYA   0건
#
# 예전 감사가 찾아낸 «K만 초과» 8건은 **전부 이종재**(`ASTM-A36`+`SM355A`)라
# 이번 변경으로 clean이 됐다. 즉 지금 이 분기를 지키는 것은 **이 테스트뿐**이다.
# qc-data-verifier가 합성 프로브로 분기가 살아 있음을 확인하고 고정을 권고했다.
@pytest.mark.synthetic
def test_c3_same_material_still_judges_each_side():
    """같은 재질이면 J가 통과해도 K를 따로 본다.

    ASME IX QW-451의 두께 자격범위는 이음을 구성하는 **각 부재**에 대해 성립해야
    한다. 이걸 «낮은 쪽만»으로 넓히면 그 유형을 통째로 놓치는데, 실데이터에
    사례가 없어 아무도 눈치채지 못한다.
    """
    c = checker()
    # WPS_TABLE의 TR-FC-F01은 ASTM A36을 3~24mm까지 허용한다
    f = c._c3_thickness(make_row(
        WPS_NO="TR-FC-F01",
        MATERIAL1="ASTM-A36", THICKNESS1=20.0,     # 범위 안 — 통과
        MATERIAL2="ASTM-A36", THICKNESS2=40.0,     # 범위 밖 — 여기가 걸려야 한다
    ), "TR-FC-F01")
    assert f is not None, "J가 통과한 뒤 K열 판정이 사라졌다"
    assert f.check_no == "3" and f.col == Col.THICKNESS2


@pytest.mark.synthetic
def test_c3_dissimilar_material_judges_only_the_thinner_side():
    """재질이 다르면 낮은 두께만 본다 — 위 테스트의 대조군.

    같은 J·K인데 N열 재질만 바꾸면 결과가 뒤집혀야 한다. 안 뒤집히면 둘 중
    한 분기가 죽어 있다는 뜻이다.
    """
    c = checker()
    # **양쪽 재질이 모두 판정 가능해야** 대조가 성립한다. K열 재질이 매핑표에
    # 없으면 분기가 죽어도 어차피 None이라 아무것도 검사하지 못한다(실제로
    # 그런 테스트를 쓸 뻔했다).
    assert V._get_material_key("NV-DW36") is not None, "전제가 바뀌었다"
    f = c._c3_thickness(make_row(
        WPS_NO="TR-FC-F01",
        MATERIAL1="ASTM-A36", THICKNESS1=20.0,     # 낮은 쪽 — 범위 안
        MATERIAL2="NV-DW36",  THICKNESS2=40.0,     # 높은 쪽 — 범위 밖이지만 안 본다
    ), "TR-FC-F01")
    assert f is None, "이종재인데 높은 쪽 두께로 판정했다"

    # 낮은 쪽이 범위를 벗어나면 그건 잡는다
    g = c._c3_thickness(make_row(
        WPS_NO="TR-FC-F01",
        MATERIAL1="ASTM-A36", THICKNESS1=40.0,
        MATERIAL2="NV-DW36",  THICKNESS2=60.0,
    ), "TR-FC-F01")
    assert g is not None and g.col == Col.THICKNESS1


@pytest.mark.synthetic
def test_c3_notation_differences_are_not_a_dissimilar_joint():
    """`ASTM-A36`과 `ASTMA36`은 **같은 강재**다 — 표기만 다르다.

    문자열을 그대로 비교하면 이종재로 보고 낮은 두께만 판정해서 **K열 판정이
    조용히 사라진다.** 실데이터에 두 표기가 각각 1,999행·70행 있고, 지금은 한
    행에 함께 오지 않아 드러나지 않는다.

    재질 «키»로 비교해도 안 된다 — 그건 두께 범위를 고르는 키라 `NV-E36`(-40℃)과
    `NV-DW36`(-20℃)이 둘 다 `E36`으로 뭉개진다. 그 둘은 등급이 달라 진짜 이종재다.
    """
    assert V._material_token("ASTM-A36") == V._material_token("ASTMA36")
    assert V._material_token("ASTM A36") == V._material_token("astm-a36")
    assert V._material_token("NV-E36") != V._material_token("NV-DW36")

    c = checker()
    f = c._c3_thickness(make_row(
        WPS_NO="TR-FC-F01",
        MATERIAL1="ASTM-A36", THICKNESS1=20.0,     # 범위 안
        MATERIAL2="ASTMA36",  THICKNESS2=40.0,     # 같은 강재 · 범위 밖 -> 걸려야 한다
    ), "TR-FC-F01")
    assert f is not None, "표기만 다른 같은 재질을 이종재로 봐서 K열 판정이 사라졌다"
    assert f.col == Col.THICKNESS2


# ── 프로젝트 코드가 달라도 같은 WPS로 본다 ──────────────────────────────────
@pytest.mark.synthetic
def test_repair_wps_is_recognised_across_project_codes(monkeypatch):
    """접두사가 `TR-FC-R`이어도 RUYA의 `RU-FC-R01`이 수리 WPS여야 한다.

    못 알아보면 **수리 시공 행까지 Check 2·4·11이 지적한다.** 오류는 안 난다.
    """
    from backend.services import wps_rules as W

    monkeypatch.setattr(W, "repair_prefix", lambda: "TR-FC-R")
    assert V._is_repair_wps("TR-FC-R01") is True
    assert V._is_repair_wps("RU-FC-R01") is True
    assert V._is_repair_wps("RU-FC-R02") is True
    # 뒤쪽 구분이 다르면 수리가 아니다
    assert V._is_repair_wps("RU-FC-F01") is False
    assert V._is_repair_wps("TR-FC-G01") is False


@pytest.mark.synthetic
def test_same_wps_ignores_only_the_leading_code():
    assert V._same_wps("RU-FC-G03", "TR-FC-G03") is True
    assert V._same_wps("FC-G03", "TR-FC-G03") is True
    assert V._same_wps("RU-FC-G01", "TR-FC-G03") is False, "뒤쪽 구분이 다르면 남이다"
    assert V._same_wps("", "TR-FC-G03") is False


# ── 「확인 필요」 표식 ───────────────────────────────────────────────────────
#
# 다른 프로젝트 값을 빌려 쓸 때 붙인다. RUYA가 TRION의 `wps_corrections`·
# `repair_prefix`를 빌렸다 — 지금은 두 프로젝트가 같은 WPS 참조 문서를 쓰고 있어
# 값이 맞지만, RUYA WPS 문서가 확정되면 다시 봐야 한다.
#
# **표식이 없으면 빌려 온 값으로 나온 숫자를 확정된 판정으로 읽게 된다.**
# 오류가 나지 않아 그냥 잊는다.
@pytest.mark.synthetic
def test_provisional_reaches_the_result(rule_files_for_prov):
    """켬/끔과 같은 이유로 **결과에 박힌다** — 나중에 설정을 고쳐도 «이 회차가
    무슨 상태에서 나온 숫자인가»는 변하지 않아야 한다."""
    from backend.services import wps_rules as W

    assert W.load().get("provisional") == {"4": "빌려 쓰는 중"}


@pytest.fixture
def rule_files_for_prov(tmp_path, monkeypatch):
    import json

    from backend import config
    from backend.services import wps_rules as W

    monkeypatch.setattr(config, "WPS_RULES_FILE", tmp_path / "wps_rules.json")
    monkeypatch.setattr(config, "PROJECT_RULES_FILE", tmp_path / "project_rules.json")
    (tmp_path / "project_rules.json").write_text(json.dumps({
        "active": "빌린프로젝트", "profiles": {"빌린프로젝트": {
            "params": {"provisional": {"4": "빌려 쓰는 중"}}}}},
        ensure_ascii=False), encoding="utf-8")
    W.invalidate()
    yield tmp_path
    W.invalidate()


@pytest.mark.synthetic
def test_the_screen_reads_provisional_from_the_result():
    """화면이 «지금 설정»이 아니라 «결과 스냅샷»을 읽어야 한다."""
    from pathlib import Path

    js = (Path(__file__).resolve().parent.parent
          / "frontend" / "static" / "js" / "app.js").read_text(encoding="utf-8")
    body = js[js.index("function _provReason("):]
    body = body[:body.index(chr(10) + "function ", 1)]
    assert "S.result" in body and "provisional" in body
    # 검증 카드와 규칙 카드 둘 다에 붙어야 한다
    assert "_provMark(c.no)" in js, "대시보드 Check 카드에 표식이 없다"
    assert "rl-prov" in js, "'프로젝트 세팅' 카드에 표식이 없다"


# ── 「0건」의 두 종류 ────────────────────────────────────────────────────────
#
#     대조했고 위반이 없다        -> 진짜 «문제 없음»
#     대조할 대상이 아예 없었다    -> 한 번도 판정하지 않았다
#
# 화면에서는 둘 다 그냥 «0건»으로 보인다. Check 25는 `Q01`로 끝나는 WPS가 한 행도
# 없어 한 번도 안 돌았는데 «통과»로 읽혔고, Check 15가 결번이 된 것도 「위반 0건」을
# 뒤늦게 「대조 조합 0건」으로 정정한 결과다.
#
# 실측(TRION): Check 8·25가 대상 0건 / Check 16은 5,831건 대조해 위반 0 —
# 후자는 «검사했고 문제없다»가 맞다.
@pytest.mark.synthetic
def test_scoped_checks_start_at_zero():
    """**관문을 한 번도 통과 못 한 검사가 빠지면 안 된다.**

    `Counter`는 키를 만들지 않으므로, 미리 0으로 채우지 않으면 순회할 때
    정작 잡아야 할 «대상 0건»이 목록에 없다. 실제로 그렇게 만들었다가 고쳤다.
    """
    c = checker()
    assert set(c._scope) == set(V._SCOPED_CHECKS)
    assert all(v == 0 for v in c._scope.values())


@pytest.mark.synthetic
def test_a_narrow_check_records_what_it_compared():
    """관문을 지난 행만 «대상»이다. 지나지 못한 행은 세지 않는다."""
    c = checker()
    # Q열이 TT가 아니면 Check 24의 대상이 아니다
    c._c24_tky_wps(make_row(JOINT_TYPE="T"), "TR-SMFC-G01")
    assert c._scope["24"] == 0
    # TT면 대상이다 — 위반이든 아니든
    c._c24_tky_wps(make_row(JOINT_TYPE="TT"), "TR-SMFC-GK01")   # 통과
    c._c24_tky_wps(make_row(JOINT_TYPE="TT"), "TR-SMFC-G01")    # 위반
    assert c._scope["24"] == 2, "통과한 행도 «대조한» 것이다"


@pytest.mark.synthetic
def test_noscope_warns_only_for_enabled_checks():
    """꺼 둔 검사가 0인 것은 당연하다 — 경고하면 소음이 된다."""
    c = checker()
    c._scope["24"] = 5          # 대상이 있었다
    on = V._noscope_findings(c, {n: True for n in V._SCOPED_CHECKS})
    nos = {f["check_no"] for f in on}
    assert 24 not in nos, "대상이 있는데 경고했다"
    assert "25" in nos, "대상 0건인데 경고가 없다"
    assert all(f["level"] == "noscope" for f in on)

    off = V._noscope_findings(c, {n: False for n in V._SCOPED_CHECKS})
    assert not off, "꺼 둔 검사까지 경고했다"


@pytest.mark.synthetic
def test_every_narrow_check_is_registered():
    """관문이 좁은 검사를 만들고 `_SCOPED_CHECKS`에 안 넣으면, 그 검사의 0건이
    «검사했고 문제없음»인지 «한 번도 안 돌았는지» 구분되지 않는다."""
    import inspect

    src = inspect.getsource(V)
    used = set(re.findall(r"self\._scope\[\"(\w+)\"\]", src))
    assert used == set(V._SCOPED_CHECKS), (
        f"계측 지점과 _SCOPED_CHECKS가 다르다: 코드 {sorted(used)} / "
        f"목록 {sorted(V._SCOPED_CHECKS)}"
    )


@pytest.mark.synthetic
def test_the_screen_reads_scope_from_the_result():
    from pathlib import Path

    js = (Path(__file__).resolve().parent.parent
          / "frontend" / "static" / "js" / "app.js").read_text(encoding="utf-8")
    body = js[js.index("function _noScope("):]
    body = body[:body.index(chr(10) + "function ", 1)]
    assert "S.result" in body and "scope" in body
    # **없는 번호와 0은 다르다** — 없으면 «전부가 대상», 0이면 «대상이 없다».
    assert "undefined" in body, "키 없음과 0을 구분하지 않는다"
    assert "_scopeMark(c.no)" in js, "대시보드 검증 카드에 표식이 없다"
    assert "rl-noscope" in js, "'프로젝트 세팅' 카드에 표식이 없다"

@pytest.mark.synthetic
def test_a_project_rule_reports_what_it_compared():
    """프로젝트 규칙도 «대조 대상 수»를 실어야 한다.

    프로젝트 규칙은 `_SCOPED_CHECKS`에 못 박을 수 없다 — 규칙마다 번호가 다르다.
    그런데 이쪽이야말로 **항상 관문이 좁다**(`when`이 재질·WPS·NDT Category를
    지목한다). 키가 없으면 화면이 「scope에 없으면 전부가 대상」 규칙을 적용해서,
    **대조 대상이 0건인 규칙에 「대상 없음」이 안 붙는다.**

    「위반 0」과 「대조 0」을 가르는 것이 이 표식의 존재 이유인데, 정작 그 구분이
    가장 필요한 쪽에서 빠진다. 예외도 경고도 나지 않는다.
    """
    c = checker()
    c._rules = [P.Rule({"key": "hit", "no": "P1", "name": "걸리는 규칙",
                                       "color": "Cyan", "kind": "thickness_range",
                                       "when": {"material_contains": ["A36"]},
                                       "param": {"min": 1, "max": 2}}),
                P.Rule({"key": "miss", "no": "P2", "name": "안 걸리는 규칙",
                                       "color": "Cyan", "kind": "thickness_range",
                                       "when": {"material_contains": ["없는재질"]},
                                       "param": {"min": 1, "max": 2}})]
    c._rule_matched = {"P1": 332}

    scope = V._scope_map(c)
    assert scope["P1"] == 332, "대조한 규칙의 수가 실리지 않는다"
    assert scope["P2"] == 0, "한 번도 안 걸린 규칙에 «대상 0건» 표식이 안 붙는다"
    assert scope["8"] == 0, "공통 검사의 계측이 덮였다"

