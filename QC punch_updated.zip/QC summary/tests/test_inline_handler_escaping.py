"""
인라인 이벤트 핸들러(`onclick=`, `onchange=` …)에 들어가는 값이 `_jsq()`를 거치는지
`app.js` 소스를 정적으로 검사한다.

왜 소스를 훑는 방식인가:
이 앱은 빌드 단계가 없어 `index.html`의 인라인 핸들러가 전역 함수 이름에 의존하고,
`app.js`가 그 핸들러 문자열을 템플릿 리터럴로 만들어 낸다. 여기에 값이 그대로 들어가면
**HTML 이스케이프만으로는 막히지 않는다** — HTML 파서가 `&#39;`를 `'`로 되돌린 뒤에
JS가 컴파일되기 때문이다. 실측 결과:

    _esc()만 : "o'brien"          -> onclick=null (핸들러가 아예 컴파일 실패)
    _esc()만 : "'),pwned(),f('"   -> 주입된 함수가 실제로 실행됨
    _jsq()   : 세 경우 모두 원문 그대로 전달, 실행 0건

`_jsq()`는 JS 문자열 이스케이프(`\\`, `'`)를 먼저 걸고 그 위에 HTML 이스케이프를 덧씌운다.

이 검사가 필요한 이유는 실제로 두 번 놓쳤기 때문이다:
1차 수정 때 `_esc()`로 충분하다고 판단했고(틀렸다),
2차 수정 때는 `onclick`만 훑어 `onchange` 한 곳(부서 선택 체크박스)을 빠뜨렸다.
그 한 곳은 Excel BF열의 부서명을 받으며 Outlook 발송 대상 지정에 쓰인다.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

APP_JS = Path(__file__).resolve().parent.parent / "frontend" / "static" / "js" / "app.js"

# on으로 시작하는 이벤트 속성 (onclick, onchange, oninput, onsubmit ...)
_ATTR_RE = re.compile(r"\bon[a-z]+\s*=")

# 인라인 핸들러 안에서 작은따옴표로 감싼 보간 자리
#   패턴 A: 템플릿 리터럴   '${...}'
#   패턴 B: 문자열 연결     \'' + ... + '\'
_INTERP_TPL = re.compile(r"'\$\{([^{}]+?)\}'")
_INTERP_CAT = re.compile(r"\\'' \+ ([^+]+?) \+ '\\'")


def _source() -> list[str]:
    return APP_JS.read_text(encoding="utf-8").split("\n")


def _offending_lines() -> list[tuple[int, str, str]]:
    """인라인 핸들러 인자 중 _jsq()를 거치지 않는 것들."""
    bad: list[tuple[int, str, str]] = []
    for idx, line in enumerate(_source(), start=1):
        if not _ATTR_RE.search(line):
            continue
        for pat in (_INTERP_TPL, _INTERP_CAT):
            for m in pat.finditer(line):
                expr = m.group(1).strip()
                if not expr.startswith("_jsq("):
                    bad.append((idx, expr, line.strip()[:120]))
    return bad


@pytest.mark.synthetic
def test_app_js_exists():
    assert APP_JS.is_file(), f"app.js를 찾을 수 없다: {APP_JS}"


@pytest.mark.synthetic
def test_all_inline_handler_args_go_through_jsq():
    bad = _offending_lines()
    if bad:
        detail = "\n".join(f"  app.js:{n}  {expr}\n      {src}" for n, expr, src in bad)
        pytest.fail(
            "인라인 핸들러 인자가 _jsq()를 거치지 않는다 "
            f"({len(bad)}건). _esc()만으로는 막히지 않는다:\n{detail}"
        )


@pytest.mark.synthetic
def test_jsq_is_defined_and_wraps_esc():
    """_jsq가 존재하고, JS 이스케이프를 먼저 건 뒤 _esc로 감싸는 순서인지.

    순서가 뒤바뀌면(HTML 이스케이프가 먼저) 백슬래시가 엔티티로 바뀌어
    JS 이스케이프가 의미를 잃는다.
    """
    src = APP_JS.read_text(encoding="utf-8")
    m = re.search(r"function _jsq\(s\)\s*\{(.*?)\n\}", src, re.S)
    assert m, "_jsq()가 정의돼 있지 않다"
    body = m.group(1)
    assert "_esc(" in body, "_jsq는 결과를 _esc로 감싸야 한다"
    esc_at = body.index("_esc(")
    for token in (r"\\\\", r"\\'"):
        assert token in body, f"_jsq에 JS 이스케이프({token})가 없다"
    # 백슬래시 치환이 _esc 호출 '안쪽'에 있어야 한다
    assert body.index("replace(") > esc_at, "JS 이스케이프가 _esc() 인자 안에 있어야 한다"


@pytest.mark.synthetic
def test_esc_escapes_the_characters_jsq_depends_on():
    """_jsq는 _esc가 `"`와 `&`를 막아주는 것에 기대고 있다."""
    src = APP_JS.read_text(encoding="utf-8")
    m = re.search(r"function _esc\(s\)\s*\{(.*?)\n\}", src, re.S)
    assert m, "_esc()가 정의돼 있지 않다"
    body = m.group(1)
    for ch, ent in (("&", "&amp;"), ("<", "&lt;"), ('"', "&quot;")):
        assert ent in body, f"_esc가 {ch!r}를 이스케이프하지 않는다"
    # &는 반드시 가장 먼저 치환해야 다른 엔티티가 이중 인코딩되지 않는다
    assert body.index("&amp;") < body.index("&lt;"), "_esc는 &를 가장 먼저 치환해야 한다"


@pytest.mark.synthetic
def test_no_raw_data_interpolation_in_handlers():
    """핸들러 인자에 이스케이프 없는 날 보간(`'${x.v}'`)이 남아 있지 않은지.

    상수만 들어가는 자리라도 예외를 두지 않는다 — 나중에 데이터가 흘러들어와도
    아무도 알아차리지 못하기 때문이다. 통과시키는 값이 상수면 _jsq를 거쳐도
    결과가 같으므로 비용이 없다.
    """
    bad = [(n, e) for n, e, _ in _offending_lines()]
    assert not bad, f"이스케이프 없는 보간: {bad}"


# ── 지연 로딩 슬롯의 경합 방어 ───────────────────────────────────────────────
#
# `_fillRawSlot()`은 응답을 기다린 뒤 `#raw-grid-slot`을 찾아 채운다. 그런데
# 모달 body를 다시 그릴 때마다 **같은 id의 슬롯이 새로 생긴다.** id만 보고 채우면
# 늦게 도착한 응답이 «없어진 슬롯»이 아니라 **새 행의 슬롯**을 덮어쓴다.
#
# ui-regression-checker가 CDP로 실증했고, 데이터 손상까지 확인됐다:
#
#     검토키  : 1C-CD000-260-05 | 1S01L002 | ...   <- 화면에 열려 있던 행
#     row_raw : 도면 1C-CD000-260-03 · Joint 1S03AT <- 다른 행의 원문
#
# 콘솔 오류가 나지 않아 단서가 없고, 캐시 때문에 평소엔 드러나지 않다가
# 응답이 느린 순간에만 틀린 기록을 남긴다. 그래서 «슬롯이 이 행의 것인가»를
# 반드시 대조해야 한다.
@pytest.mark.synthetic
def test_raw_slot_is_stamped_with_its_row():
    """슬롯에 행 번호가 박혀 있어야 한다."""
    src = APP_JS.read_text(encoding="utf-8")
    assert 'data-row="${_esc(String(rowNum))}"' in src, \
        "슬롯에 행 번호가 없다 - 늦은 응답이 어느 행의 것인지 대조할 수 없다"
    # 정의부(`function _rawSlotHtml(rowNum)`)가 아니라 «호출부»만 센다
    assert src.count("${_rawSlotHtml(rowNum)}") == 2, \
        "슬롯을 만드는 곳(결함 상세/미작업 상세) 두 곳 모두 행 번호를 넘겨야 한다"
    assert "${_rawSlotHtml()}" not in src, "행 번호를 안 넘기는 호출부가 남아 있다"


@pytest.mark.synthetic
def test_fill_raw_slot_checks_the_row_before_writing():
    """응답을 반영하기 전에 «지금 열려 있는 행»과 대조해야 한다."""
    src = APP_JS.read_text(encoding="utf-8")
    assert "if (!slot || slot.dataset.row !== String(rowNum)) return;" in src, \
        "행 대조 없이 슬롯을 덮어쓰고 있다 - 다른 행의 원문이 섞인다"

    # 대조가 S._modalRaw 대입보다 «앞»에 있어야 한다. 뒤에 있으면 화면은 멀쩡한데
    # 검토 의견에 첨부되는 스냅샷만 조용히 틀린다(가장 찾기 어려운 형태다).
    guard = src.index("slot.dataset.row !== String(rowNum)")
    assign = src.index("S._modalRaw = raw;")
    assert guard < assign, \
        "행 대조가 S._modalRaw 대입보다 뒤에 있다 - 화면은 맞고 저장만 틀린다"


# ── 플래그 전량을 받지 않는다 (6단계) ───────────────────────────────────────
@pytest.mark.synthetic
def test_no_full_flag_array_access_remains():
    """`/api/result`가 플래그를 싣지 않으므로 전량을 훑는 코드가 남으면 안 된다.

    실측 2,521KB(응답의 84%)였고 30만 행이면 ~76MB다. 한 화면이 쓰는 것은
    한 페이지뿐이라 서버가 조건에 맞는 페이지만 내준다.

    남아 있으면 «빈 배열을 훑어 조용히 0건»이 된다 — 예외가 나지 않아 발견이 늦다.
    """
    # 주석 안의 언급은 이력이라 남긴다. 실제 코드 줄만 본다.
    code = [ln for ln in APP_JS.read_text(encoding="utf-8").splitlines()
            if not ln.strip().startswith(("//", "*", "/*"))]
    for bad in ("S.result.flags", "r.flags ||", "_flagsByRow("):
        hit = [ln.strip() for ln in code if bad in ln]
        assert not hit, f"플래그 전량을 훑는 코드가 남아 있다 ({bad}): {hit[:3]}"


@pytest.mark.synthetic
def test_screen_queries_go_through_the_shared_helpers():
    """조회는 `fetchFlags` / `fetchAggregate`를 거친다.

    한 곳에 모아 두어야 «서버가 하는 필터»와 조건이 갈라지지 않는다. 갈라지면
    «전에는 나오던 게 안 나온다»가 되고, 현업은 그걸 판정이 바뀐 것으로 읽는다.
    """
    src = APP_JS.read_text(encoding="utf-8")
    assert "function fetchFlags(params)" in src
    assert "function fetchAggregate(params)" in src
    assert "function _checksParam(sel)" in src
    # 전부 해제와 필터 없음을 구분해야 한다
    assert "return picked.length ? picked.join(',') : '-1';" in src,         "Check를 전부 해제했을 때 «필터 없음»으로 뭉개고 있다"


@pytest.mark.synthetic
def test_late_responses_check_which_row_is_open():
    """늦게 도착한 응답이 다른 행의 화면을 덮어쓰면 안 된다.

    `row_raw`에서 이걸 빠뜨려 검토 기록에 다른 행의 원문이 섞인 사고가 있었다.
    Check 14 형제 행 패널도 같은 슬롯 방식이라 같은 가드가 필요하다.
    """
    src = APP_JS.read_text(encoding="utf-8")
    assert "if (!slot || slot.dataset.row !== String(rowNum)) return;" in src
    assert 'if (!after || after.dataset.row !== String(rowNum)) return;' in src,         "Check 14 슬롯에 행 대조가 없다"


@pytest.mark.synthetic
def test_stale_page_responses_are_discarded():
    """필터를 빠르게 바꾸면 옛 응답이 뒤늦게 도착해 표를 덮어쓸 수 있다."""
    src = APP_JS.read_text(encoding="utf-8")
    for seq in ("_resultSeq", "_mckSeq", "_deptDefectSeq"):
        assert f"const seq = ++{seq};" in src, f"{seq} 순번 발급이 없다"
        assert f"if (seq !== {seq}) return;" in src, f"{seq} 대조가 없다"


@pytest.mark.synthetic
def test_derived_caches_are_cleared_with_the_result():
    """새 검증 결과가 오면 파생 캐시를 함께 버려야 한다.

    옛 결과의 캐시가 남으면 새 화면에 옛 결함이 섞인다.
    """
    src = APP_JS.read_text(encoding="utf-8")
    assert "function _setResult(result)" in src
    for line in ("S._patternTeams = null;", "S._welderFlagCache = null;",
                 "S.resultPage = null;", "S.deptDefectData = null;",
                 "_deptDefectCache.clear();", "_teamFacetCache.clear();",
                 "_rawCache.clear();"):
        assert line in src, f"_setResult가 {line} 를 하지 않는다"
    assert "S.result = result;" not in src.split("function _setResult")[0],         "_setResult를 거치지 않고 S.result를 대입하는 곳이 있다"


# ── 목록을 «다시 열 때» 스크롤 복원 (ui-regression-checker 지적) ────────────
@pytest.mark.synthetic
def test_reopen_restores_scroll_after_the_table_is_filled():
    """표가 서버에서 오므로 스크롤은 **채워진 뒤에** 되돌려야 한다.

    먼저 대입하면 그 시점엔 tbody가 비어 스크롤 높이가 없고, 브라우저가 값을
    0으로 클램프한다. 메모리 배열에서 동기 렌더하던 시절엔 동작하던 코드다 —
    비동기 전환의 부작용이라 예외도 콘솔 오류도 나지 않는다.
    """
    src = APP_JS.read_text(encoding="utf-8")
    for fn in ("_mckReopen", "_rcpReopen", "_wdReopen"):
        assert f"async function {fn}()" in src, f"{fn}이 async가 아니다"
    for call in ("await openCheckListModal(", "await openRecurringModal(",
                 "await openWelderDetail("):
        assert call in src, f"{call}…) 를 기다리지 않는다"
    assert "function _restoreModalScroll(top)" in src
    # 옛 방식(동기 대입)이 남아 있으면 안 된다
    assert "body.scrollTop = savedScroll;" not in src
    assert "body.scrollTop = saved.scrollTop || 0;" not in src


@pytest.mark.synthetic
def test_openers_return_their_loading_promise():
    """`_*Reopen()`이 기다릴 수 있으려면 여는 쪽이 promise를 돌려줘야 한다."""
    src = APP_JS.read_text(encoding="utf-8")
    assert "return _mckFilter(false);" in src, \
        "openCheckListModal이 로딩 promise를 돌려주지 않는다"


@pytest.mark.synthetic
def test_saving_feedback_refreshes_the_sidebar_count():
    """검토를 저장하면 사이드바 '미검토'도 다시 물어야 한다.

    배지만 갱신하면 표는 바뀌는데 사이드바만 옛 숫자로 남는다 — 새로고침해야
    맞는 값이 나오는 상태다.
    """
    src = APP_JS.read_text(encoding="utf-8")
    save = src.index("_refreshReviewBadges();")
    assert "_refreshUnreviewedCount();" in src[save:save + 400], \
        "저장 직후 사이드바 미검토를 갱신하지 않는다"


@pytest.mark.synthetic
def test_dashboards_discard_stale_aggregates():
    """Check 카드를 빠르게 연달아 누를 때 늦게 온 집계가 덮어쓰면 안 된다."""
    src = APP_JS.read_text(encoding="utf-8")
    for seq in ("_dashSeq", "_deptDashSeq"):
        assert f"const seq = ++{seq};" in src, f"{seq} 순번 발급이 없다"
        assert f"if (seq !== {seq}) return;" in src, f"{seq} 대조가 없다"


# ── 도넛 범례는 걸린 Check를 «전부» 적는다 ──────────────────────────────────
@pytest.mark.synthetic
def test_donut_legend_is_built_from_stats_not_a_fixed_list():
    """예전에는 Check 4·5만 이름을 달고 나머지를 «기타»로 뭉쳤다.

    실제로 걸린 Check가 9종인데 범례에 4줄만 나와 화면이 실제와 달라 보였다.
    목록을 고정하지 않고 매번 `statsObj`에서 만든다 — 대시보드에서 Check를
    취사선택하면 구성이 바뀌기 때문이다.
    """
    src = APP_JS.read_text(encoding="utf-8")
    for gone in ("Check 5 (특수규칙)", "Check 4 (Groove)", "기타 Check"):
        assert gone not in src, f"고정 라벨이 남아 있다: {gone}"
    # `_activeMeta()`는 CHECK_META를 «이번 회차가 판정한 것»으로 거른 것이다 —
    # 끈 항목의 범례가 남으면 «껐는데 왜 보이냐»가 된다.
    assert "const parts = _activeMeta()" in src, "범례를 검사 목록에서 만들지 않는다"
    assert "function _ckColor(meta, st)" in src, \
        "Check별 색을 CSS 변수에서 읽는 헬퍼가 없다"


@pytest.mark.synthetic
def test_donut_states_how_the_defect_arc_is_split():
    """결함 조각을 «플래그 건수 비중»으로 나눈다는 것을 화면에 적어야 한다.

    한 행에 Check가 여럿 걸릴 수 있어(실측 결함 3,426행 / 플래그 4,508건)
    Check별 «행수»는 합해도 결함 행수가 되지 않는다. 안 적으면 보는 사람이
    조각 크기를 행수로 읽는다.
    """
    src = APP_JS.read_text(encoding="utf-8")
    assert "legend-note" in src, "설명 문구를 넣는 자리가 없다"
    assert "플래그 건수 비중으로 나눴습니다" in src


# ── Check 정의는 백엔드·프론트 **양쪽**에 있어야 한다 ───────────────────────
@pytest.mark.synthetic
def test_every_check_is_registered_in_the_frontend():
    """백엔드가 내는 Check가 `CHECK_META`에 없으면 조용히 사라진다.

    Check 18을 추가하면서 백엔드 5곳만 등록하고 프론트 3곳을 빠뜨렸다.
    그때는 0건이라 안 보였지만, 건수가 생기는 순간:

      - 대시보드에서 Check를 하나라도 해제하면 `_checksParam()`이 `CHECK_META`로
        목록을 만들기 때문에 **18이 영원히 제외**된다 (집계에서 조용히 빠진다)
      - 배지가 무색이 되고 이름이 빈 채로 나간다

    pytest가 백엔드 5곳만 강제하고 있어서 못 잡았다. 여기서 함께 본다.
    """
    from backend.services import verifier as V

    src = APP_JS.read_text(encoding="utf-8")
    # 식별자가 문자열이 됐다 — `{no:'14',`. 옛 `{no:14,` 형태를 찾으면
    # **전부 «없는 Check»로 잡혀** 정작 무엇이 빠졌는지 알 수 없다.
    nos = {int(m) for m in re.findall(r"\{no:\s*'(\d+)'\s*,", src)}
    missing = set(V.CHECK_NAMES) - nos - {0}
    assert not missing, f"CHECK_META에 없는 Check: {sorted(missing)}"


@pytest.mark.synthetic
def test_every_check_color_maps_to_a_css_class():
    """`COLOR_TO_CLS`와 CSS `.p-*` / `--ck-*`가 모든 색을 덮어야 한다."""
    from backend.services import verifier as V

    src = APP_JS.read_text(encoding="utf-8")
    css = (APP_JS.parent.parent / "css" / "style.css").read_text(encoding="utf-8")

    m = re.search(r"const COLOR_TO_CLS = \{(.*?)\};", src, re.S)
    assert m, "COLOR_TO_CLS가 없다"
    mapped = dict(re.findall(r"(\w+)\s*:\s*'([\w-]+)'", m.group(1)))

    for color in set(V.CHECK_COLORS.values()):
        assert color in mapped, f"COLOR_TO_CLS에 '{color}'가 없다 - 배지가 무색이 된다"
        cls = mapped[color]
        assert f".{cls} " in css or f".{cls}{{" in css, f"CSS에 .{cls} 규칙이 없다"

    # CSS 변수는 네 테마 블록 전부에 있어야 한다(라이트/다크/강제 두 가지)
    for color, cls in mapped.items():
        if color not in set(V.CHECK_COLORS.values()):
            continue
        var = "--ck-" + cls.removeprefix("p-")
        n = len(re.findall(re.escape(var) + r"\s*:", css))
        assert n >= 4, f"{var}가 {n}개 블록에만 있다 (테마 4곳 전부 필요)"


# ── 팝업은 «띄우는 줄»이 실행되어야 한다 ─────────────────────────────────────
#
# Check 카드를 눌러도 아무 일이 없다는 신고가 있었다. 원인은 팝업을 띄우는 줄이
# `return` **뒤에** 있어 영영 실행되지 않은 것이었다:
#
#     return _mckFilter(false);
#     document.getElementById('detail-modal').style.display = 'flex';   // 죽은 코드
#
# 목록은 정상적으로 만들어지고 제목까지 채워진다. 콘솔에도 오류가 없다.
# 화면에서는 «눌러도 반응이 없다»로만 보이고, 무엇이 잘못됐는지 단서가 없다.
# 스크롤 복원을 위해 promise를 돌려주도록 고치면서 `return`을 위에 끼워 넣었다.
@pytest.mark.synthetic
def test_no_unreachable_code_after_return():
    """`return` 다음에 오는 실행문은 전부 죽은 코드다.

    문법 오류가 아니라서 `node --check`도, 브라우저도 아무 말을 하지 않는다.
    """
    lines = APP_JS.read_text(encoding="utf-8").splitlines()
    dead: list[str] = []
    for i, ln in enumerate(lines):
        st = ln.strip()
        if not (st == "return;" or st.startswith("return ")) or not st.endswith(";"):
            continue
        ind = len(ln) - len(ln.lstrip())
        for j in range(i + 1, min(i + 6, len(lines))):
            nxt = lines[j]
            s2 = nxt.strip()
            if not s2 or s2.startswith(("//", "/*", "*")):
                continue
            if s2 in ("}", "};", "});") or (len(nxt) - len(nxt.lstrip())) < ind:
                break
            dead.append(f"app.js:{i + 1} return -> app.js:{j + 1} {s2[:70]}")
            break
    assert not dead, ("return 뒤에 실행되지 않는 코드가 있다:" + "\n  " + "\n  ".join(dead))


@pytest.mark.synthetic
def test_check_list_popup_is_actually_shown():
    """`openCheckListModal`이 팝업을 «띄우고» 나서 목록을 채워야 한다.

    순서가 뒤집히면(먼저 return) 목록만 만들어지고 팝업은 열리지 않는다.
    """
    src = APP_JS.read_text(encoding="utf-8")
    body = src[src.index("function openCheckListModal"):]
    body = body[:body.index("\nfunction ")]
    show = body.index("getElementById('detail-modal').style.display = 'flex'")
    ret = body.index("return _mckFilter(")
    assert show < ret, "팝업을 띄우기 «전»에 return한다 - 카드를 눌러도 아무 일이 없다"


@pytest.mark.synthetic
def test_check_cards_drill_down():
    """대시보드·부서 대시보드의 Check 카드가 팝업으로 이어져 있어야 한다."""
    src = APP_JS.read_text(encoding="utf-8")
    # **따옴표째로 못 박는다.** 벗기면 `goToCheckDetail(RUYA1)`이 되어 그 카드만
    # 조용히 안 눌린다 — 숫자 대역에서는 멀쩡하므로 새 프로젝트에서야 드러난다.
    assert "onclick=\"goToCheckDetail('${_jsq(c.no)}')\"" in src, "메인 대시보드 카드에 드릴다운이 없다"
    assert "onclick=\"goToCheckDetailScoped('${_jsq(c.no)}')\"" in src, "부서 대시보드 카드에 드릴다운이 없다"
    for fn in ("function goToCheckDetail(", "function goToCheckDetailScoped(",
               "function openCheckListModal("):
        assert fn in src, f"{fn} 가 없다"


# ── 없는 CSS 토큰을 지어 쓰지 마라 ──────────────────────────────────────────
@pytest.mark.synthetic
def test_css_variables_used_by_js_actually_exist():
    """`getComputedStyle`로 읽는 토큰이 CSS에 정의돼 있어야 한다.

    없는 이름을 쓰면 빈 문자열이 돌아와 **조용히 기본값(라이트 색)으로** 떨어진다.
    실제로 `--bg-1`·`--line-1`처럼 있을 법한 이름을 지어 써서, 다크 모드에서
    검사 로직 도식만 흰 바탕으로 남았다. 오류도 경고도 없었다.
    """
    js = APP_JS.read_text(encoding="utf-8")
    css = (APP_JS.parent.parent / "css" / "style.css").read_text(encoding="utf-8")
    used = set(re.findall(r"v\('(--[\w-]+)'", js))
    assert used, "CSS 토큰을 읽는 코드를 못 찾았다 - 검사가 무력해졌다"
    defined = set(re.findall(r"(--[\w-]+)\s*:", css))
    missing = sorted(used - defined)
    assert not missing, f"style.css에 없는 토큰: {missing}"


@pytest.mark.synthetic
def test_check_card_counts_follow_the_row_scope():
    """Check 카드 건수는 «행 범위»(1C 제외·부서/팀)를 따라야 한다.

    원본 stats를 그대로 쓰면 1C를 뺀 순간 바로 옆 막대그래프와 숫자가 어긋난다.
    반대로 Check 취사선택까지 반영하면 해제한 항목이 0으로 보여 다시 켤 수 없다.
    """
    src = APP_JS.read_text(encoding="utf-8")
    assert "cardStats:   cards.stats," in src, "행 범위만 반영한 집계를 따로 받지 않는다"
    assert "renderCheckGrid(agg.cardStats);" in src
    assert "_buildDeptDashCheckGridHtml(agg.cardStats);" in src
    assert "renderCheckGrid(r);" not in src, "원본 stats를 그대로 넘기고 있다"


@pytest.mark.synthetic
def test_popup_waits_for_the_team_options():
    """옵션이 채워지기 «전»에 select 값을 넣으면 조용히 무시된다.

    팝업 제목은 「… › 팀」인데 목록은 부서 전체가 나왔다(649건 vs 참값 166건).
    오류가 나지 않고 건수만 틀린다.
    """
    src = APP_JS.read_text(encoding="utf-8")
    assert "await _mckPopulateTeamFilter(team || '');" in src, \
        "팀 목록을 기다리지 않는다"
    assert "async function openCheckListModal(" in src
    assert "document.getElementById('mck-team-filter').value = team" not in src, \
        "옵션이 없는 상태에서 값을 대입하는 코드가 남아 있다"


# ---- 분모는 «지금 보고 있는 기준»이어야 한다 ------------------------------
#
# 임시부재(1C)를 제외한 화면에서 전체 판정 대상(5,516)으로 나누면, 374행만 보고
# 있는데 클린율이 6.3%로 찍힌다(실제 348/374 = 93.0%). 카드·도넛·막대가 서로
# 다른 기준을 쓰면 **같은 화면 안에서 숫자가 어긋난다.**
#
#   수정 전  판정 대상 5,516 · 결함 26(0.5%) · 클린 348(6.3%) · 도넛 6.3%
#   수정 후  판정 대상   374 · 결함 26(7.0%) · 클린 348(93.0%) · 도넛 93.0%
#
# `flaggedRows + cleanRows`가 곧 «지금 기준의 판정 대상»이다.
@pytest.mark.synthetic
def test_dashboards_use_the_visible_denominator():
    src = APP_JS.read_text(encoding="utf-8")
    assert "const judged    = agg.flaggedRows + agg.cleanRows;" in src,         "메인 대시보드가 전체 판정 대상으로 나눈다"
    # 도넛에 전체 판정 대상을 넘기는 호출이 남아 있으면 안 된다
    assert "agg.cleanRows, _judged(" not in src, "도넛 분모가 전체 판정 대상이다"
    assert "agg.cleanRows, scope.total_rows" not in src, "부서 도넛 분모가 버킷 전체다"
    assert src.count("agg.flaggedRows + agg.cleanRows") >= 4,         "카드·도넛 세 곳이 같은 분모를 쓰지 않는다"


@pytest.mark.synthetic
def test_chart_redraw_waits_for_the_aggregate():
    """`_dashAggregate`는 서버에 묻는 비동기 함수다.

    await 없이 쓰면 Promise가 들어와 `agg.stats`가 undefined가 되고, 테마 전환·
    창 크기 변경 때 차트가 **빈 채로** 다시 그려진다. 오류는 나지 않는다.
    """
    src = APP_JS.read_text(encoding="utf-8")
    assert "async function _redrawVisibleCharts()" in src
    assert "const agg = await _dashAggregate(" in src, "집계를 기다리지 않는다"
    assert "const agg = _dashAggregate(" not in src, "await 없는 호출이 남아 있다"


@pytest.mark.synthetic
def test_diagram_svg_is_trimmed_to_its_content():
    """Mermaid는 «그린 것보다 훨씬 큰 캔버스»를 들고 온다.

    실측: 색 우선순위 도식은 viewBox 3,109 x 2,055px인데 실제 내용은 3,127 x 78px
    이었다 — 높이의 25배가 빈 공간이다. 그대로 두면 카드 옆과 아래가 텅 비고,
    폭에 맞춰 줄이면 «내용»이 아니라 «빈 캔버스» 기준으로 줄어 글자만 작아진다.
    """
    src = APP_JS.read_text(encoding="utf-8")
    assert "root.getBBox" in src, "그린 내용의 실제 경계를 재지 않는다"
    assert "svg.setAttribute('viewBox'," in src, "viewBox를 다시 잡지 않는다"
    assert "LG_MIN_SCALE" in src, "축소 하한이 없다 - 한글 라벨이 뭉개진다"


# ── 끈 항목은 화면에서도 사라져야 한다 ──────────────────────────────────────
#
# '프로젝트 세팅'에서 끈 항목은 판정 자체를 하지 않으므로 영영 0건이다. 카드를
# 그대로 두면 «껐는데 왜 보이냐»가 되고, 0건이 «문제가 없다»인지 «판정을 안
# 했다»인지도 구분되지 않는다.
@pytest.mark.synthetic
def test_dashboard_hides_checks_the_run_did_not_judge():
    src = APP_JS.read_text(encoding="utf-8")
    assert "function _ruleOn(no)" in src and "function _activeMeta()" in src

    # 카드·선택집합·범례·필터가 모두 «판정한 것»만 다뤄야 한다
    for must in ("return _activeMeta().map(c => {",
                 "new Set(_activeMeta().map(c => c.no))",
                 "const parts = _activeMeta()",
                 "const all = _activeMeta().map(c => c.no);"):
        assert must in src, f"«판정한 것»만 쓰지 않는 곳이 있다: {must}"

    # 카드를 CHECK_META 전체로 그리는 코드가 남아 있으면 안 된다
    assert "return CHECK_META.map(c => {" not in src, \
        "카드가 아직 전체 목록으로 그려진다"


@pytest.mark.synthetic
def test_basis_comes_from_the_run_not_the_current_settings():
    """기준은 «현재 설정»이 아니라 «결과에 박힌 스냅샷»이다.

    화면이 보여주는 것은 이 회차의 결과다. 검증 뒤에 설정을 바꿔도 그 회차가
    무엇으로 판정됐는지는 변하지 않아야 한다.
    """
    src = APP_JS.read_text(encoding="utf-8")
    body = src[src.index("function _ruleOn(no)"):]
    body = body[:body.index("function _activeMeta()")]
    assert "S.result && S.result.rules" in body, "현재 설정을 보고 있다"
    # 스냅샷이 없으면(옛 회차) 전부 보여준다 — 모르는 것과 꺼진 것은 다르다
    assert "return true;" in body
