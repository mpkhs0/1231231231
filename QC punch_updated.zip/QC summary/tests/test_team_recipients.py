"""
팀별 수신인과 팀 범위 발송.

## 왜 부서와 «짝»으로만 다루는가

팀 이름만으로 키를 잡으면, 같은 이름의 팀이 두 부서에 생기는 순간 한쪽 수신인이
다른 부서의 리포트를 받는다. 지금 데이터에서는 23개 팀이 서로 겹치지 않지만
그건 이번 물량의 성질일 뿐 보장이 아니다. 그리고 이 사고는 **받은 사람이
말해 주기 전에는 알 수 없다** — 서버 로그에도 정상 발송으로 남는다.

그래서 저장 모양이 `{부서: {팀: [메일주소]}}`이고, 발송도 부서·팀을 함께 받는다.

## 왜 빈 목록을 «삭제»로 보는가

빈 배열을 남겨 두면 화면이 «설정됨»으로 읽어 발송 버튼이 활성화되고, 누르면
수신인 없이 400이 난다. 사용자는 «분명히 등록했는데 안 된다»로 받아들인다.
"""
from __future__ import annotations

import json

import pytest

from backend import config
from backend.routers import settings as st


@pytest.fixture
def recipients_file(tmp_path, monkeypatch):
    p = tmp_path / "team_recipients.json"
    monkeypatch.setattr(config, "TEAM_RECIPIENTS_FILE", p)
    return p


@pytest.mark.synthetic
def test_saved_under_the_department(recipients_file):
    st._update_team_recipients("건조5부", "340-구조3팀", ["a@x.com", "b@x.com"])
    data = json.loads(recipients_file.read_text(encoding="utf-8"))
    assert data == {"건조5부": {"340-구조3팀": ["a@x.com", "b@x.com"]}}
    assert st._team_recipients_of("건조5부", "340-구조3팀") == ["a@x.com", "b@x.com"]


@pytest.mark.synthetic
def test_same_team_name_in_two_departments_stays_separate(recipients_file):
    """이름이 같아도 부서가 다르면 다른 수신인이다 — 이 파일의 존재 이유."""
    st._update_team_recipients("건조5부", "1팀", ["five@x.com"])
    st._update_team_recipients("의장부", "1팀", ["fit@x.com"])
    assert st._team_recipients_of("건조5부", "1팀") == ["five@x.com"]
    assert st._team_recipients_of("의장부", "1팀") == ["fit@x.com"]


@pytest.mark.synthetic
def test_empty_list_removes_the_entry(recipients_file):
    st._update_team_recipients("건조5부", "340-구조3팀", ["a@x.com"])
    st._update_team_recipients("건조5부", "340-구조3팀", [])
    data = json.loads(recipients_file.read_text(encoding="utf-8"))
    assert data == {}, "빈 목록이 남으면 화면이 «설정됨»으로 읽는다"
    assert st._team_recipients_of("건조5부", "340-구조3팀") == []


@pytest.mark.synthetic
def test_other_teams_survive_a_save(recipients_file):
    """한 팀을 저장할 때 같은 부서의 다른 팀이 날아가면 안 된다."""
    st._update_team_recipients("건조5부", "A팀", ["a@x.com"])
    st._update_team_recipients("건조5부", "B팀", ["b@x.com"])
    st._update_team_recipients("건조5부", "A팀", ["a2@x.com"])
    assert st._load_team_recipients()["건조5부"] == {"A팀": ["a2@x.com"],
                                                    "B팀": ["b@x.com"]}


@pytest.mark.synthetic
def test_broken_file_does_not_take_the_screen_down(recipients_file):
    recipients_file.write_text("{ 깨진 JSON", encoding="utf-8")
    assert st._load_team_recipients() == {}


# ── 본문 ─────────────────────────────────────────────────────────────────────
def _bucket() -> dict:
    return {"total_rows": 100, "unworked_rows": 5, "defect_rows": 20,
            "check_stats": {"3": 20}, "welder_defect_rate": []}


def _defects() -> list[dict]:
    return [{"row": 12, "joint_no": "J-1", "block": "B", "wps_no": "TR-FC-F01",
             "ndt_report": "SAVI14996", "weld_date": "2026-05-05",
             "welder1_no": "2766",
             "checks": [{"check_no": 3, "check_name": "두께", "color": "Blue",
                         "msg": "m", "expected": "e", "actual": "a"}]}]


@pytest.mark.synthetic
def test_team_body_names_its_scope():
    html = st._build_dept_report_html("건조5부", _bucket(), _defects(),
                                      "2026-08-10 09:00", team="1Z1-(주)다성")
    assert "건조5부 &gt; 1Z1-(주)다성" in html or "건조5부 > 1Z1-(주)다성" in html, \
        "제목에 팀이 없으면 부서 리포트와 구분되지 않는다"
    assert "팀 실적" in html


@pytest.mark.synthetic
def test_department_body_is_unchanged_without_a_team():
    html = st._build_dept_report_html("건조5부", _bucket(), _defects(),
                                      "2026-08-10 09:00")
    assert "건조5부 결함 리포트 (부서 실적)" in html


@pytest.mark.synthetic
def test_body_carries_the_ndt_report_number():
    """부서·팀 리포트 본문에도 추적 키가 있어야 한다 — 첨부를 열지 않고 되짚는다."""
    html = st._build_dept_report_html("건조5부", _bucket(), _defects(),
                                      "2026-08-10 09:00")
    assert "NDT REPORT 번호" in html, "머리글이 없다"
    assert "SAVI14996" in html, "값이 실리지 않았다"


@pytest.mark.synthetic
def test_missing_report_number_shows_a_dash_not_none():
    """공란이 정상인 행이 44.8%다. 'None'이 찍히면 값처럼 읽힌다."""
    d = _defects()
    d[0]["ndt_report"] = ""
    html = st._build_dept_report_html("건조5부", _bucket(), d, "2026-08-10 09:00")
    assert ">None<" not in html
    assert ">-<" in html
