"""
판정 로직 도식이 «코드에서 나온 것»으로 남아 있는지 본다.

## 왜 도식에 테스트가 붙는가

도식은 이 저장소에서 가장 조용히 낡는 종류다. 판정 로직을 고쳐도 그림은
아무 말 없이 옛 모습으로 남고, **틀린 그림은 오류를 내지 않는다.** 그리고
보는 사람은 그림을 코드보다 먼저 믿는다.

그래서 도식을 손으로 그리지 않고 `verifier.py`에서 만들며, 여기서 그 성질이
유지되는지 확인한다:

  1. 모든 Check가 그림에 나온다 (하나 추가하고 그림을 잊는 일이 없다)
  2. 색은 `_FILLS`의 실제 RGB다 (그림만 다른 색인 일이 없다)
  3. 우선순위 순서는 `_PRIORITY` 그대로다
  4. 문서(`QC_검사로직_상세분석.md`)의 블록이 최신이다
"""
from __future__ import annotations

import re

import pytest

from backend.services import diagrams as D
from backend.services import verifier as V


# ── 코드에서 사실을 읽어 오는가 ──────────────────────────────────────────────
@pytest.mark.synthetic
def test_emitted_checks_matches_the_flag_calls():
    """`Flag(...)`를 만드는 번호만 «활성»이어야 한다.

    `CHECK_NAMES`에는 Check 5·7이 남아 있지만 규칙은 걷어냈다(현업 답변).
    이름을 지우지 않는 이유는 검토 기록 키가 그 번호를 쓰고 있어서다.
    그림이 그 둘을 활성으로 그리면 «없는 검사»를 있는 것처럼 보여준다.
    """
    em = D.emitted_checks()
    src = V.__file__ and open(V.__file__, encoding="utf-8").read()
    literal = {int(m) for m in re.findall(r"Flag\(\s*(\d+)", src)}
    assert set(em) == literal
    assert 5 not in em and 7 not in em, "걷어낸 규칙이 활성으로 잡힌다"
    assert {13, 14} <= set(em)


@pytest.mark.synthetic
def test_second_pass_checks_are_marked_as_such():
    """2차 패스 구분이 그림에 남아야 한다.

    이 구분이 중요한 이유는 2차 패스가 **집계를 소급 갱신해야** 하기 때문이다.
    그걸 빠뜨려 257행이 용접사 집계에서 통째로 빠진 적이 있다.
    """
    # 13 이상치 · 14 Joint 중복 · 26 NDT 요율 — 셋 다 «행 하나»로는 판정할 수
    # 없어 전체를 훑은 뒤 `_register_flag()`로 합류한다.
    SECOND = (13, 14, 26)
    em = D.emitted_checks()
    assert all(em[n]["pass"] == 2 for n in SECOND)
    assert all(em[n]["pass"] == 1 for n in em if n not in SECOND)


@pytest.mark.synthetic
def test_marking_columns_come_from_the_code():
    em = D.emitted_checks()
    assert em[17]["cols"] == {"BI"}, "Check 17은 VT 수행일(BI)을 칠한다"
    assert em[18]["cols"] == {"AL"}, "Check 18은 용접봉 Lot(AL)을 칠한다"
    assert em[14]["cols"] == {"D"},  "Check 14는 Joint No(D)를 칠한다"
    # 행마다 열이 달라지는 검사는 '*'로 표시된다 (두께 J/K, C16은 검사별 수행일)
    assert "*" in em[3]["cols"] and "*" in em[16]["cols"]


# ── 그림에 빠진 것이 없는가 ─────────────────────────────────────────────────
@pytest.mark.synthetic
def test_every_check_appears_in_the_map():
    src = D.checks()
    for no in V.CHECK_NAMES:
        if no == V.CHECK_UNWORKED:
            continue
        assert f"C{no}[" in src, f"Check {no}가 지도에 없다"
        assert V.CHECK_NAMES[no] in src, f"Check {no}의 이름이 지도에 없다"


@pytest.mark.synthetic
def test_every_check_is_assigned_to_an_axis():
    """축 분류는 사람이 정한 것이라 코드에서 유도할 수 없다.

    Check를 추가하고 축을 지정하지 않으면 조용히 '번호만 남은 것'으로 떨어져,
    **판정하는 검사가 «판정하지 않는 것»들 사이에 놓인다.** 그러면 그림이
    사실과 반대되는 것을 말한다.
    """
    assigned = {n for _, _, members in D._AXES for n in members}
    active = set(D.emitted_checks())
    missing = active - assigned
    assert not missing, (
        f"축이 지정되지 않은 활성 Check: {sorted(missing)} — "
        f"diagrams._AXES에 넣어라")


@pytest.mark.synthetic
def test_retired_number_is_shown_as_reserved():
    """Check 15는 «없는 것»이 아니라 «비워 둔 것»이다.

    번호를 재사용하면 검토 기록 키(`…|Check No`)가 과거 의견을 무관한 항목에
    붙인다. 그림이 15를 아예 안 보여주면 다음 사람이 재사용해도 이상하지 않다.
    """
    assert 15 in D._RETIRED_NOTE
    assert 15 not in V.CHECK_NAMES, "결번이 이름 표에 들어왔다"
    assert "R15[" in D.checks()


# ── 색 ──────────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_colors_are_the_real_fill_colors():
    """그림의 색이 Excel 마킹 색과 같아야 한다 — 다르면 화면과 산출물이 갈린다."""
    src = D.checks()
    for no, color in V.CHECK_COLORS.items():
        if no == V.CHECK_UNWORKED:
            continue
        rgb = str(V._FILLS[color].start_color.rgb)[-6:]
        assert f"style C{no} fill:#{rgb}" in src, f"Check {no}({color}) 색이 다르다"


@pytest.mark.synthetic
def test_priority_order_is_the_priority_table():
    src = D.priority()
    order = [c for c, _ in sorted(V._PRIORITY.items(), key=lambda kv: kv[1])]
    for a, b in zip(order, order[1:]):
        assert f"{a} -->|이긴다| {b}" in src, f"{a} 다음이 {b}가 아니다"
    assert order[0] == "Black", "가장 센 색이 바뀌었다 — 의도한 변경인지 확인하라"


# ── 행 회계 ─────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_flow_without_a_result_has_no_numbers():
    """검증 전에도 구조는 보여야 한다. 없는 수치를 0으로 적으면 «결함 0건»으로 읽힌다."""
    src = D.flow(None)
    # 「유효 행」처럼 «행»으로 끝나는 라벨이 있으므로 «숫자+행»만 본다
    assert not re.search(r"[0-9][0-9,]*행", src), "결과가 없는데 수치가 들어갔다"
    assert "판정 대상" in src and "미작업" in src


@pytest.mark.synthetic
def test_flow_carries_the_row_accounting():
    src = D.flow({"total_rows": 10034, "deleted_rows": 4, "active_rows": 10030,
                  "unworked_rows": 4475, "judged_rows": 5516,
                  "flagged_rows": 3245, "clean_rows": 2271,
                  "temp_judged_rows": 5142})
    for n in ("10,034", "4,475", "5,516", "3,245", "2,271", "5,142"):
        assert n in src, f"{n}이 그림에 없다"
    assert "모든 결함률의 분모" in src


# ── Mermaid 문법 ────────────────────────────────────────────────────────────
@pytest.mark.synthetic
@pytest.mark.parametrize("name", sorted(D.DIAGRAMS))
def test_diagram_is_a_connected_graph(name):
    """간선 없는 노드를 두지 마라.

    처음에는 축마다 subgraph만 두고 간선을 하나도 넣지 않았는데, Mermaid의
    레이아웃이 폭주해 viewBox가 16,530 × 16,463px가 됐다. 화면에서는 «점 하나»로
    줄어들어 아무것도 읽을 수 없었고, **오류는 나지 않았다.**
    """
    src = D.build(name)["mermaid"]
    assert src.startswith("flowchart ")
    ids = set(re.findall(r"^\s{2}([A-Za-z_][\w]*)[\[\({]", src, re.M))
    # 간선의 양끝을 모은다. 노드가 «정의와 함께» 이어지는 형태(`A["x"] --> B`)가
    # 있어서, 화살표 앞의 라벨/괄호를 먼저 지운 뒤에 식별자를 찾는다.
    stripped = re.sub(r"[\[\({][^\n]*?[\]\)}]", "", src)
    linked: set[str] = set()
    for line in stripped.splitlines():
        if "-->" not in line and "-.->" not in line and "-- " not in line:
            continue
        linked |= set(re.findall(r"[A-Za-z_][\w]*", line))
    lonely = ids - linked
    assert not lonely, f"간선이 없는 노드: {sorted(lonely)}"


@pytest.mark.synthetic
@pytest.mark.parametrize("name", sorted(D.DIAGRAMS))
def test_labels_do_not_use_bold_tags(name):
    """`<b>`를 쓰면 Mermaid가 상자 높이를 한 줄만큼 작게 잡아 글자가 잘린다.

    잘려도 오류가 나지 않아, 그림만 보면 «원래 두 줄인가 보다»로 읽힌다.
    """
    src = D.build(name)["mermaid"]
    assert "<b>" not in src and "<i>" not in src


@pytest.mark.synthetic
def test_every_diagram_has_a_title_and_a_hint():
    for name, spec in D.DIAGRAMS.items():
        assert spec["title"] and spec["hint"], f"{name}에 설명이 없다"


# ── 문서 ────────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_document_block_is_up_to_date():
    """`QC_검사로직_상세분석.md`의 도식이 코드와 같아야 한다.

    문서가 낡으면 화면과 문서가 서로 다른 것을 말한다. 문서만 보는 사람
    (현업·인수인계)이 그걸 알아챌 방법이 없다.
    """
    from backend import config

    path = config.BASE / "QC_검사로직_상세분석.md"
    text = path.read_text(encoding="utf-8")
    assert D.DOC_BEGIN in text and D.DOC_END in text, "도식 표식이 사라졌다"
    have = text.partition(D.DOC_BEGIN)[2].partition(D.DOC_END)[0]
    want = D.markdown_block().partition(D.DOC_BEGIN)[2].partition(D.DOC_END)[0]
    assert have == want, (
        "문서의 도식이 코드와 다르다. 다음을 실행하라:\n"
        "    python -m backend.services.diagrams")


@pytest.mark.synthetic
def test_document_block_has_no_run_specific_numbers():
    """문서에는 행 수치를 넣지 않는다 — 검증할 때마다 문서가 더러워진다."""
    block = D.markdown_block()
    assert not re.search(r"\d,\d{3}행", block), "회차별 수치가 문서에 섞였다"


# ---- 그림 옆의 설명 --------------------------------------------------------
#
# 도식만 놓으면 «무엇이 그려졌는지»는 보이지만 «왜 그런지»는 안 보인다. 그런데
# 사람이 실제로 묻는 것은 후자다. 설명도 코드에서 만든다 - 손으로 적으면 도식은
# 갱신되는데 설명만 옛말이 남고, 그건 그림이 틀린 것보다 나쁘다(글은 더 믿는다).
@pytest.mark.synthetic
@pytest.mark.parametrize("name", sorted(D.DIAGRAMS))
def test_every_diagram_carries_notes(name):
    notes = D.build(name)["notes"]
    assert notes, f"{name}에 설명이 없다"
    for n in notes:
        assert n["heading"] and n["body"], f"{name}의 설명이 비었다"
        assert len(n["body"]) > 20, f"{name}의 설명이 너무 짧다: {n['heading']}"


@pytest.mark.synthetic
def test_notes_follow_the_code():
    """설명에 적힌 «어느 Check가 몇 차인가»가 코드와 같아야 한다."""
    em = D.emitted_checks()
    body = " ".join(n["body"] for n in D.build("flow")["notes"])
    for no, info in em.items():
        assert f"C{no}" in body, f"Check {no}가 패스 설명에서 빠졌다"
    # 걷어낸 Check는 «판정한다»는 설명에 들어가면 안 된다
    for no in set(V.CHECK_NAMES) - set(em) - {V.CHECK_UNWORKED}:
        assert f"C{no}," not in body and f"C{no}가" not in body


@pytest.mark.synthetic
def test_notes_have_no_run_numbers_without_a_result():
    """결과가 없으면 «그 회차의» 수치를 넣지 않는다.

    문서에 박히면 검증할 때마다 문서가 더러워진다. 다만 「257행이 누락된 적이
    있다」처럼 **고정된 과거 사실**은 수치가 아니라 근거이므로 남는다. 그래서
    «숫자 일반»이 아니라 «이 회차에서 나온 값»이 새는지를 본다.
    """
    run = {"judged_rows": 1234567, "unworked_rows": 7654321,
           "temp_judged_rows": 9876543}
    leaked = [f"{v:,}" for v in run.values()]
    for name in D.DIAGRAMS:
        body = " ".join(n["body"] for n in D.build(name, None)["notes"])
        for v in leaked:
            assert v not in body, f"{name}에 회차 수치 {v}가 들어갔다"


@pytest.mark.synthetic
def test_notes_gain_numbers_when_a_result_is_given():
    notes = D.build("flow", {"judged_rows": 5516, "unworked_rows": 4475,
                             "temp_judged_rows": 5142})["notes"]
    body = " ".join(n["body"] for n in notes)
    assert "5,516" in body and "4,475" in body
    assert any("임시부재" in n["heading"] for n in notes),         "1C가 있는 회차인데 그 설명이 없다"
