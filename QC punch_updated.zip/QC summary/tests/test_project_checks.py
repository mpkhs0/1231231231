"""
프로젝트 판정규칙 — 공통을 덮어쓰지 않고 자기 번호로 판정하는 구조.

## 이 파일이 지키는 세 줄

1. **번호는 `key`에 붙고, `key`는 뜻에 붙는다.** 뜻이 바뀌면 새 `key` = 새 번호.
2. **선점은 «일치»에서 일어난다** — 위반일 때만 선점하면 범위 «안»인 행이
   공통 판정으로 흘러가 없던 플래그가 새로 생긴다.
3. **0행에 걸리는 것은 «문제 없음»이 아니라 경고다.**

실데이터로는 확인할 수 없다 — F03·G05·S355KT 계열이 현재 물량에서 정확히 0행이다.
그래서 여기가 유일한 안전장치다.
"""
from __future__ import annotations

import pytest

from backend.services import project_checks as P
from backend.services import verifier as V


def rule(**over) -> dict:
    d = {"key": "thk-mat-kt40", "no": "P1", "name": "재질 KT-40 두께 허용범위",
         "color": "Blue", "kind": "thickness_range",
         "when": {"material_contains": ["KT-40", "KT40", "KL-40"]},
         "param": {"range": "12~50"}, "overrides": [3], "cols": "J · K"}
    d.update(over)
    return d


# ── 스키마 검증 — 조용히 통과시키지 않는다 ──────────────────────────────────
@pytest.mark.synthetic
def test_a_well_formed_rule_loads():
    rules, problems = P.parse([rule()])
    assert len(rules) == 1 and not problems
    assert rules[0].overrides == ["3"]


@pytest.mark.synthetic
@pytest.mark.parametrize("bad,why", [
    ({"key": "BAD KEY"},              "key 형식"),
    ({"key": ""},                     "빈 key"),
    ({"color": "형광연두"},            "없는 색"),
    ({"kind": "무엇인가"},             "모르는 kind"),
    ({"no": 21},                      "공통 대역 침범"),
    ({"no": 200},                     "대역 초과"),
    ({"name": ""},                    "이름 없음"),
    ({"param": {}},                   "range 없음"),
    ({"when": {}},                    "대상 조건 없음"),
])
def test_broken_rules_are_rejected_with_a_reason(bad, why):
    rules, problems = P.parse([rule(**bad)])
    assert not rules, f"{why}인데 통과했다"
    assert len(problems) == 1 and problems[0], f"{why} 거부 사유가 비었다"


@pytest.mark.synthetic
def test_one_broken_rule_does_not_kill_the_rest():
    """깨진 규칙 하나가 검증 전체를 멈추면 안 된다 — 그 규칙만 빼고 경고."""
    rules, problems = P.parse([rule(), rule(key="bad key", no=102)])
    assert len(rules) == 1 and len(problems) == 1


@pytest.mark.synthetic
def test_duplicate_key_or_number_is_rejected():
    _, p1 = P.parse([rule(), rule(no=102)])                 # 같은 key
    _, p2 = P.parse([rule(), rule(key="other-key")])        # 같은 번호
    assert p1 and p2


@pytest.mark.synthetic
def test_color_must_exist_in_the_fill_table():
    """없는 색을 회색으로 떨어뜨리지 않고 거부한다.

    조용히 무색으로 나가면 Excel을 받는 사람이 그 항목만 못 본다. 색 이름으로
    키가 잡힌 다섯 곳(_FILLS·_PRIORITY·excel_report·style.css·COLOR_TO_CLS)을
    손대지 않으려면 기존 색 안에 있어야 한다.
    """
    for c in V._FILLS:
        rules, problems = P.parse([rule(color=c)])
        assert rules and not problems, f"기존 색 {c}가 거부됐다"


# ── 대상 판별 ───────────────────────────────────────────────────────────────
@pytest.mark.synthetic
@pytest.mark.parametrize("material,hit", [
    ("S355KT-40", True),      # 실데이터 표기
    ("S420KT-40", True),
    ("S355KL-40", True),
    ("s355kt-40", True),      # 대소문자 무시
    ("S355 KT-40", True),     # 공백 무시
    ("S355KL-0", False),      # 다른 등급 — 별도 규칙이 맡는다
    ("SM355A", False),        # 이 물량의 주 재질
    ("", False),
])
def test_material_matching(material, hit):
    r = P.parse([rule()])[0][0]
    assert r.matches(material, "TR-FC-F01") is hit


@pytest.mark.synthetic
def test_wps_condition_is_substring_too():
    """접두사가 프로젝트마다 다르다(원본 매크로는 `RU-`). 완전일치면 조용히 죽는다."""
    r = P.parse([rule(key="thk-wps-f03", when={"wps_contains": ["F03"]})])[0][0]
    assert r.matches("아무재질", "TR-FC-F03")
    assert r.matches("아무재질", "RU-FC-F03")
    assert not r.matches("아무재질", "TR-FC-F01")


@pytest.mark.synthetic
def test_both_conditions_must_hold():
    r = P.parse([rule(key="both", when={"material_contains": ["KT-40"],
                                        "wps_contains": ["F03"]})])[0][0]
    assert r.matches("S355KT-40", "TR-FC-F03")
    assert not r.matches("S355KT-40", "TR-FC-F01")
    assert not r.matches("SM355A", "TR-FC-F03")


# ── 선점 — 순서가 곧 의미다 ─────────────────────────────────────────────────
@pytest.mark.synthetic
def test_the_first_matching_rule_claims_it():
    """좁은 조건을 앞에 둬야 `S355KT-40`이 'KT'가 아니라 'KT-40'에 걸린다."""
    rules, _ = P.parse([
        rule(key="kt-40", no=101, when={"material_contains": ["KT-40"]},
             param={"range": "12~50"}),
        rule(key="kt", no=102, when={"material_contains": ["KT"]},
             param={"range": "6~50"}),
    ])
    assert P.claim_thickness(rules, "S355KT-40", "W").no == "101"
    assert P.claim_thickness(rules, "S355KT-20", "W").no == "102"


@pytest.mark.synthetic
def test_no_match_means_the_common_check_judges():
    """선점하지 않으면 None — 호출부가 공통 Check 3으로 내려간다."""
    rules, _ = P.parse([rule()])
    assert P.claim_thickness(rules, "SM355A", "TR-FC-F01") is None


@pytest.mark.synthetic
def test_judging_is_separate_from_claiming():
    """선점은 «일치»에서, 판정은 그 뒤에. 통과도 이 규칙의 판정이다."""
    r = P.parse([rule()])[0][0]
    assert r.judge_thickness(12.0) and r.judge_thickness(50.0)
    assert not r.judge_thickness(11.9) and not r.judge_thickness(50.1)


# ── 번호 할당대장 ───────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_the_same_key_keeps_its_number_across_profiles():
    """같은 뜻이면 같은 번호여야 검토 기록이 이어진다."""
    led: dict = {}
    a, new_a = P.assign_id(led, "thk-kt40", "KT-40", "TRION")
    b, new_b = P.assign_id(led, "thk-kt40", "KT-40", "RUYA")
    assert a == b == "TRION1" and new_a and not new_b


@pytest.mark.synthetic
def test_a_different_key_gets_a_new_number():
    led: dict = {}
    a, _ = P.assign_id(led, "first", "A", "P")
    b, _ = P.assign_id(led, "second", "B", "P")
    assert a != b


@pytest.mark.synthetic
def test_a_retired_number_is_never_reissued():
    """번호를 재사용하면 과거 검토 의견이 무관한 항목에 붙는다."""
    led: dict = {}
    P.assign_id(led, "gone", "사라질 것", "P")
    P.retire_missing(led, live_keys=set())
    assert led["P1"]["retired"] is True
    assert "P1" in led, "지우면 다음 발급이 재사용한다"

    new_no, _ = P.assign_id(led, "fresh", "새 규칙", "P")
    assert new_no == "P2", "폐기된 번호를 재발급했다"


@pytest.mark.synthetic
def test_retire_flips_back_when_the_rule_returns():
    led: dict = {}
    P.assign_id(led, "a", "A", "P")
    P.retire_missing(led, live_keys=set())
    P.retire_missing(led, live_keys={"a"})
    assert led["P1"]["retired"] is False


@pytest.mark.synthetic
def test_running_out_of_numbers_is_loud():
    led = {f"P{n}": {"key": f"k{n}"} for n in range(1, P.ID_MAX_SEQ + 1)}
    with pytest.raises(P.RuleError):
        P.assign_id(led, "one-too-many", "X", "P")


# ── 0행 경고 ────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_a_rule_matching_nothing_is_a_warning():
    """0행은 «문제 없음»이 아니라 «표기가 안 맞을 수 있다»이다.

    실제로 F03·G05·S355KT 계열이 현재 물량에서 0행인데, 그게 규칙이 맞아서인지
    죽어서인지 구분할 방법이 없었다.
    """
    rules, _ = P.parse([rule(key="a", no=101), rule(key="b", no=102)])
    h = P.health(rules, matched={"101": 7}, problems=[])
    unmatched = [x for x in h if x["level"] == "unmatched"]
    assert len(unmatched) == 1 and unmatched[0]["check_no"] == "102"


@pytest.mark.synthetic
def test_rejected_rules_reach_the_health_report():
    """거부를 로그에만 남기면 아무도 안 본다."""
    rules, problems = P.parse([rule(color="없는색")])
    h = P.health(rules, matched={}, problems=problems)
    assert any(x["level"] == "rejected" for x in h)


# ── 대역 ────────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_the_project_band_does_not_touch_the_common_range():
    """공통은 1~99에서 계속 늘어난다(지금 20개). 겹치면 번호 재사용 사고다."""
    assert P.LEGACY_ID_MIN > max(V.CHECK_NAMES)
    # 옛 번호 대역은 «이미 발급된 101~199를 프로젝트로 알아보는» 데만 쓴다
    assert P.LEGACY_ID_MIN == 101 and P.LEGACY_ID_MAX == 199
    assert not P.is_common("101") and P.is_common("99")


# ---- 화면에서 규칙을 편집한다 ----------------------------------------------
#
# **값만 정해진 틀로 받는다.** 판정 논리 자체는 코드(`KINDS`)에 있고, 화면은
# «대상 조건 · 허용 범위»만 정한다. 자유 서술로 두면 반영률이 떨어진다 —
# 실제로 「S355KL -40」이 실데이터 표기(`S355KT-40`)와 맞지 않아 한 번 막혔다.
@pytest.fixture
def api(tmp_path, monkeypatch):
    from backend import config
    from backend.services import rule_catalog as R
    from backend.services import wps_rules as W

    monkeypatch.setattr(config, "PROJECT_RULES_FILE", tmp_path / "project_rules.json")
    monkeypatch.setattr(config, "WPS_RULES_FILE", tmp_path / "wps_rules.json")
    W.invalidate()
    R.save_enabled({}, project="시험")
    from backend.routers import rules as api_mod
    return api_mod


@pytest.mark.synthetic
def test_a_korean_name_still_gets_a_unique_key(api):
    """한글은 ASCII 슬러그에서 통째로 사라진다.

    「시험 규칙 A36」과 「다른 규칙 A36」이 둘 다 `a36`이 되면 **번호가 겹치고
    검토 기록이 서로 섞인다.** 실제로 첫 시험에서 그랬다.
    """
    a = api._slugify("시험 규칙 A36")
    b = api._slugify("다른 규칙 A36")
    assert a != b, "한글 이름이 다른데 key가 같다"
    assert api._slugify("시험 규칙 A36") == a, "같은 이름이 다른 key를 받는다"
    assert P._KEY_RE.match(a), f"key 형식에 안 맞는다: {a}"


@pytest.mark.synthetic
def test_saving_a_rule_assigns_a_number_and_needs_reverify(api):
    body = api.CheckRuleIn(name="재질 A36 두께", range="12~50",
                           material_contains=["A36"])
    r = api.save_check_rule(body, x_employee_id="A551135")
    # 대역이 아니라 **모양**으로 본다 — 프로젝트 식별자는 숫자가 아니다
    assert not P.is_common(r["check_no"]), r["check_no"]
    assert r["needs_reverify"] is True, "판정 설정인데 재검증을 알리지 않는다"


@pytest.mark.synthetic
def test_a_project_rule_can_be_toggled_like_any_other(api):
    """프로젝트 규칙도 «취사선택»의 대상이다.

    식별자가 `RUYA1` 꼴이 되면서 저장 경로가 두 군데서 `int(k)`를 하고 있었다.
    끄려고 누르면 500이 나는데, 화면에는 **«저장이 안 된다»로만 보인다** —
    어느 항목 때문인지도, 서버가 무엇에 걸렸는지도 알 방법이 없다.
    공통 항목만 눌러 보면 멀쩡하므로 발견이 늦다.
    """
    body = api.CheckRuleIn(name="재질 A36 두께", range="12~50",
                           material_contains=["A36"])
    no = api.save_check_rule(body, x_employee_id="A551135")["check_no"]
    assert not P.is_common(no)

    r = api.save_rules(api.RulesIn(enabled={no: False}), x_employee_id="A551135")
    assert r["changed"] == [no], "끈 항목이 «바뀐 것»으로 안 잡힌다"
    assert r["needs_reverify"] is True, "판정 설정인데 재검증을 알리지 않는다"

    from backend.services import rule_catalog as R
    assert R.enabled_map()[no] is False, "껐는데 저장이 안 됐다"


@pytest.mark.synthetic
@pytest.mark.parametrize("kw,why", [
    ({"name": "", "range": "1~2", "material_contains": ["A"]}, "이름 없음"),
    ({"name": "x", "range": "", "material_contains": ["A"]}, "범위 없음"),
    ({"name": "x", "range": "1~2"}, "대상 조건 없음"),
])
def test_broken_input_is_refused_before_it_is_saved(api, kw, why):
    """깨진 규칙이 파일에 들어가면 다음 검증에서야 거부되고, 그때는 «왜 안
    걸리지»로만 보인다."""
    from fastapi import HTTPException

    with pytest.raises(HTTPException) as e:
        api.save_check_rule(api.CheckRuleIn(**kw), x_employee_id="A551135")
    assert e.value.status_code == 400, why


@pytest.mark.synthetic
def test_narrow_conditions_are_kept_in_front(api):
    """좁은 조건이 앞이어야 `S355KT-40`이 'KT'가 아니라 'KT-40'에 걸린다.

    사람이 순서를 신경 쓰지 않아도 되도록 저장할 때 정렬한다.
    """
    from backend.services import rule_catalog as R

    api.save_check_rule(api.CheckRuleIn(name="넓은 것", range="6~50",
                                        material_contains=["KT"]),
                        x_employee_id="A551135")
    api.save_check_rule(api.CheckRuleIn(name="좁은 것", range="12~50",
                                        material_contains=["KT-40"]),
                        x_employee_id="A551135")
    rules, _ = P.parse(R.active_checks())
    assert P.claim_thickness(rules, "S355KT-40", "W").range_text == "12~50"
    assert P.claim_thickness(rules, "S355KT-20", "W").range_text == "6~50"


@pytest.mark.synthetic
def test_deleting_a_rule_retires_its_number(api):
    from backend.services import rule_catalog as R

    r = api.save_check_rule(api.CheckRuleIn(name="뺄 것", range="1~2",
                                            material_contains=["X"]),
                            x_employee_id="A551135")
    key, no = r["key"], r["check_no"]
    api.delete_check_rule(key, x_employee_id="A551135")

    ledger = R.check_ledger()
    assert str(no) in ledger, "번호가 대장에서 사라졌다 — 다음 발급이 재사용한다"
    assert ledger[str(no)]["retired"] is True
    assert not R.active_checks()


@pytest.mark.synthetic
def test_preview_counts_rows_from_the_run(api, monkeypatch):
    """입력하는 자리에서 «몇 행 걸리는가»를 안다.

    저장하고 재검증을 돌린 뒤에야 «0건»을 보는 것과는 아주 다르다.
    """
    monkeypatch.setattr(api, "get_last_result", lambda: {"material_wps": [
        {"material": "SM355A", "wps": "TR-FC-F01", "rows": 1213},
        {"material": "SM355A", "wps": "TR-FC-G01", "rows": 799},
        {"material": "ASTM-A36", "wps": "TR-FC-F01", "rows": 1520},
    ]})
    hit = api.preview_check_rule(api.PreviewIn(material_contains=["SM355A"]),
                                 x_employee_id="A551135")
    assert hit["rows"] == 2012 and hit["combos"] == 2
    assert hit["samples"], "무엇에 걸렸는지 보여야 «엉뚱한 데 걸렸다»를 안다"

    # 실데이터와 안 맞는 표기 -> 0행. 이걸 그 자리에서 알아야 한다.
    miss = api.preview_check_rule(api.PreviewIn(material_contains=["S355KL -40"]),
                                  x_employee_id="A551135")
    assert miss["rows"] == 0

    # WPS 조각도 부분일치
    wps = api.preview_check_rule(api.PreviewIn(wps_contains=["F01"]),
                                 x_employee_id="A551135")
    assert wps["rows"] == 2733


@pytest.mark.synthetic
def test_preview_without_a_run_says_so(api, monkeypatch):
    monkeypatch.setattr(api, "get_last_result", lambda: None)
    r = api.preview_check_rule(api.PreviewIn(material_contains=["A"]),
                               x_employee_id="A551135")
    assert r["has_result"] is False and r["rows"] == 0
