"""
`backend/services/excel_report.py` — 범위별 결과 Excel 생성기 테스트.

이 모듈의 위험은 두 가지다:

1. **범위 필터가 틀리면 다른 부서 데이터가 새어 나간다.** 부서별 파일은 그 부서에
   보내는 것이라, 남의 부서 행이 한 줄이라도 섞이면 안 된다.
2. **원본 시트를 줄이면서 서식/주석이 날아갈 수 있다.** 색상 마킹과 주석이 이 산출물의
   핵심인데, delete_rows가 그것을 지우면 조용히 쓸모없는 파일이 된다.

원본 워크북(10,034행)을 여는 데만 8초가 걸리므로, 합성 워크북으로 검사한다.
"""
from __future__ import annotations

import pytest
from openpyxl import Workbook, load_workbook

from backend.services import excel_report as er


PRIORITY = {"Red": 1, "Orange": 2, "Blue": 3, "Cyan": 4, "Brown": 5}


@pytest.fixture
def qmg(tmp_path):
    """부서/팀 열이 있는 최소 QMG 유사 워크북. 데이터는 6행부터."""
    wb = Workbook()
    ws = wb.active
    ws.title = "QMG4520"
    ws.cell(row=1, column=1, value="Q.C Summary List")
    ws.cell(row=5, column=er.COL_DEPARTMENT, value="Dep't")
    ws.cell(row=5, column=er.COL_TEAM, value="Team")

    # 6~11행: A부서(팀1,팀2) 3행 + B부서 3행
    rows = [
        ("A-부서", "T1"), ("A-부서", "T1"), ("A-부서", "T2"),
        ("B-부서", "T9"), ("B-부서", "T9"), ("B-부서", "T9"),
    ]
    for i, (d, t) in enumerate(rows, start=6):
        ws.cell(row=i, column=1, value=f"DWG-{i}")
        ws.cell(row=i, column=4, value=f"J{i}")
        ws.cell(row=i, column=er.COL_DEPARTMENT, value=d)
        ws.cell(row=i, column=er.COL_TEAM, value=t)
    p = tmp_path / "qmg.xlsx"
    wb.save(p)
    return p


def _flag(row, dept, team, check_no=3, color="Blue"):
    return {
        "row": row, "col": 10, "col_letter": "J",
        "check_no": check_no, "check_name": f"검사{check_no}", "color": color,
        "msg": "메시지", "expected": "기준", "actual": "실제",
        "drawing_no": f"DWG-{row}", "joint_no": f"J{row}", "block": "BLK",
        "department": dept, "team": team, "welder1_no": "W1",
        "wps_no": "TR-FC-G01", "wps_process": "FCAW",
        "material1": "A36", "material2": "", "thickness1": "12", "thickness2": "",
        "weld_date": "2026-07-01", "ndt_date": "2026-07-02",
        "ndt_report": f"SAVI{14990 + row}",
    }


@pytest.fixture
def result():
    return {
        "run_at": "2026-08-03 10:00",
        "qmg_filename": "test.xlsx",
        "judged_rows": 6,
        "flagged_rows": 4,
        "unworked_rows": 0,
        "flags": [
            _flag(6, "A-부서", "T1"),
            _flag(7, "A-부서", "T1", check_no=5, color="Blue"),
            _flag(8, "A-부서", "T2", check_no=6, color="Orange"),
            _flag(9, "B-부서", "T9", check_no=3),
        ],
        "unworked_list": [
            {"row": 20, "drawing_no": "D", "joint_no": "J", "block": "B",
             "department": "A-부서", "team": "T1"},
        ],
        "departments": {
            "A-부서": {"total_rows": 3, "defect_rows": 3, "unworked_rows": 1,
                       "teams": {"T1": {"total_rows": 2, "defect_rows": 2, "unworked_rows": 1},
                                 "T2": {"total_rows": 1, "defect_rows": 1, "unworked_rows": 0}}},
            "B-부서": {"total_rows": 3, "defect_rows": 1, "unworked_rows": 0,
                       "teams": {"T9": {"total_rows": 3, "defect_rows": 1, "unworked_rows": 0}}},
        },
    }


# ── Scope ─────────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_scope_all():
    s = er.Scope()
    assert s.is_all and s.label == "전체"
    assert s.matches("아무부서", "아무팀")


@pytest.mark.synthetic
def test_scope_dept_and_team():
    s = er.Scope("A-부서")
    assert s.matches("A-부서", "T1") and not s.matches("B-부서", "T1")

    s2 = er.Scope("A-부서", "T1")
    assert s2.matches("A-부서", "T1")
    assert not s2.matches("A-부서", "T2"), "다른 팀이 통과하면 안 된다"


@pytest.mark.synthetic
def test_scope_team_without_dept_rejected():
    with pytest.raises(ValueError):
        er.Scope(None, "T1")


@pytest.mark.synthetic
def test_scope_slug_is_filename_safe():
    s = er.Scope("A/부서: 이름", "T\\1")
    slug = s.slug()
    for ch in '/\\:*?"<>|':
        assert ch not in slug, f"파일명에 쓸 수 없는 문자가 남았다: {ch}"


# ── 생성 결과 ─────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_build_all(qmg, result, tmp_path):
    out = tmp_path / "all.xlsx"
    info = er.build_report(qmg, result, out, priority=PRIORITY)
    assert info["flags"] == 4
    wb = load_workbook(out)
    assert wb.sheetnames[:2] == ["요약", "결함 목록"]
    assert wb.active.title == "요약", "열었을 때 요약부터 보여야 한다"
    assert wb["QMG4520"].max_row == 11, "전체 범위는 행을 지우지 않는다"


def _col_values(ws, header: str) -> set:
    """머리글 이름으로 열을 찾아 값 집합을 돌려준다.

    열 번호를 숫자로 박으면 열이 하나 늘 때마다 엉뚱한 열을 읽고,
    실패 메시지가 «부서가 섞였다»처럼 사실과 다른 것을 가리킨다.
    """
    hdr_row = next(r for r in range(1, 8)
                   if any(ws.cell(row=r, column=c).value == "원본 행"
                          for c in range(1, 30)))
    col = next(c for c in range(1, 40)
               if ws.cell(row=hdr_row, column=c).value == header)
    return {ws.cell(row=r, column=col).value
            for r in range(hdr_row + 1, ws.max_row + 1)
            if ws.cell(row=r, column=1).value is not None}


@pytest.mark.synthetic
def test_build_dept_filters_flags_and_rows(qmg, result, tmp_path):
    out = tmp_path / "a.xlsx"
    info = er.build_report(qmg, result, out, dept="A-부서", priority=PRIORITY)
    assert info["flags"] == 3, "A부서 플래그만 담겨야 한다"

    wb = load_workbook(out)
    ws = wb["결함 목록"]
    depts = _col_values(ws, "부서")
    assert depts == {"A-부서"}, f"다른 부서가 섞였다: {depts}"

    orig = wb["QMG4520"]
    seen = {orig.cell(row=r, column=er.COL_DEPARTMENT).value
            for r in range(er.HEADER_ROWS + 1, orig.max_row + 1)}
    assert seen == {"A-부서"}, f"원본 시트에 다른 부서가 남았다: {seen}"


@pytest.mark.synthetic
def test_build_team_scope(qmg, result, tmp_path):
    out = tmp_path / "t1.xlsx"
    info = er.build_report(qmg, result, out, dept="A-부서", team="T1", priority=PRIORITY)
    assert info["flags"] == 2

    wb = load_workbook(out)
    orig = wb["QMG4520"]
    teams = {orig.cell(row=r, column=er.COL_TEAM).value
             for r in range(er.HEADER_ROWS + 1, orig.max_row + 1)}
    assert teams == {"T1"}, f"다른 팀이 남았다: {teams}"


@pytest.mark.synthetic
def test_original_sheet_keeps_marking_and_comments(qmg, result, tmp_path):
    """색상 마킹과 주석이 이 산출물의 핵심이다 — 축소하면서 날아가면 안 된다."""
    out = tmp_path / "a.xlsx"
    er.build_report(qmg, result, out, dept="A-부서", priority=PRIORITY)

    ws = load_workbook(out)["QMG4520"]
    comments = [c for row in ws.iter_rows() for c in row if c.comment]
    assert len(comments) == 3, f"주석이 보존되지 않았다: {len(comments)}"
    assert "[Check" in comments[0].comment.text
    assert "기준값:" in comments[0].comment.text

    fills = [c for row in ws.iter_rows() for c in row
             if c.fill and c.fill.fgColor and c.fill.fgColor.rgb not in (None, "00000000")]
    assert fills, "색상 마킹이 사라졌다"


@pytest.mark.synthetic
def test_flag_sheet_has_expected_actual_as_values(qmg, result, tmp_path):
    """주석에만 있던 기준값/실제값이 실제 셀 값이어야 인쇄·검색·필터가 된다."""
    out = tmp_path / "a.xlsx"
    er.build_report(qmg, result, out, dept="A-부서", priority=PRIORITY)
    ws = load_workbook(out)["결함 목록"]
    headers = [ws.cell(row=4, column=c).value for c in range(1, ws.max_column + 1)]
    assert "기준값" in headers and "실제값" in headers
    i_exp = headers.index("기준값") + 1
    assert ws.cell(row=5, column=i_exp).value == "기준"


@pytest.mark.synthetic
def test_flag_sheet_has_autofilter_and_freeze(qmg, result, tmp_path):
    out = tmp_path / "a.xlsx"
    er.build_report(qmg, result, out, dept="A-부서", priority=PRIORITY)
    ws = load_workbook(out)["결함 목록"]
    assert ws.auto_filter.ref, "자동 필터가 없으면 받는 사람이 손으로 걸어야 한다"
    assert ws.freeze_panes, "머리글 고정이 없으면 스크롤 시 열 이름이 사라진다"


@pytest.mark.synthetic
def test_unworked_sheet_only_when_present(qmg, result, tmp_path):
    a = tmp_path / "a.xlsx"
    er.build_report(qmg, result, a, dept="A-부서", priority=PRIORITY)
    assert "미작업" in load_workbook(a).sheetnames

    b = tmp_path / "b.xlsx"
    er.build_report(qmg, result, b, dept="B-부서", priority=PRIORITY)
    assert "미작업" not in load_workbook(b).sheetnames, "0건이면 빈 시트를 만들지 않는다"


@pytest.mark.synthetic
def test_feedback_sheet_scoped(qmg, result, tmp_path):
    fb = {
        "k1": {"drawing_no": "DWG-6", "joint_no": "J6", "wps_no": "W", "check_no": 3,
               "result": "결함확정", "remark": "확인함", "reviewer_id": "A1",
               "updated_at": "2026-08-03", "flag_snapshot": {"department": "A-부서", "team": "T1"}},
        "k2": {"drawing_no": "DWG-9", "joint_no": "J9", "wps_no": "W", "check_no": 3,
               "result": "오탐", "remark": "", "reviewer_id": "A2",
               "updated_at": "2026-08-03", "flag_snapshot": {"department": "B-부서", "team": "T9"}},
    }
    out = tmp_path / "a.xlsx"
    er.build_report(qmg, result, out, dept="A-부서", feedback=fb, priority=PRIORITY)
    ws = load_workbook(out)["검토 기록"]
    vals = [ws.cell(row=r, column=1).value for r in range(5, ws.max_row + 1)]
    assert vals == ["DWG-6"], f"다른 부서 검토 기록이 섞였다: {vals}"


@pytest.mark.synthetic
def test_summary_numbers_match_scope(qmg, result, tmp_path):
    out = tmp_path / "a.xlsx"
    er.build_report(qmg, result, out, dept="A-부서", priority=PRIORITY)
    ws = load_workbook(out)["요약"]
    kv = {}
    for r in range(1, ws.max_row + 1):
        k = ws.cell(row=r, column=1).value
        v = ws.cell(row=r, column=2).value
        if isinstance(k, str) and isinstance(v, int):
            kv[k] = v
    assert kv["판정 대상"] == 3
    assert kv["결함 발생"] == 3
    assert kv["총 지적 건수"] == 3
    assert kv["미작업"] == 1


@pytest.mark.synthetic
def test_dept_ranking_only_in_full_export(qmg, result, tmp_path):
    """부서 파일에 다른 부서 순위표가 들어가면 정보 누출이다."""
    a = tmp_path / "a.xlsx"
    er.build_report(qmg, result, a, dept="A-부서", priority=PRIORITY)
    txt = " ".join(str(c.value) for row in load_workbook(a)["요약"].iter_rows() for c in row)
    assert "B-부서" not in txt, "부서 파일에 다른 부서명이 들어갔다"

    full = tmp_path / "full.xlsx"
    er.build_report(qmg, result, full, priority=PRIORITY)
    txt2 = " ".join(str(c.value) for row in load_workbook(full)["요약"].iter_rows() for c in row)
    assert "B-부서" in txt2, "전체 파일에는 부서 현황이 있어야 한다"


@pytest.mark.synthetic
def test_check_colors_match_verifier():
    """`excel_report._CHECK_COLOR`는 `verifier._FILLS`의 복사본이다.

    이 모듈은 순환 임포트를 피하려고 verifier를 임포트하지 않고 값을 다시 둔다
    (COL_DEPARTMENT 등과 같은 이유). 복사본은 반드시 어긋나므로 여기서 대조한다.

    어긋나면 조용히 틀린다 — 원본 시트는 새 색으로 칠해지는데 '결함 목록' 시트만
    색이 빠진 채 나가고, 예외는 나지 않는다.
    """
    from backend.services import verifier as V

    expected = {name: (fill.start_color.rgb or "")[-6:].upper()
                for name, fill in V._FILLS.items()}
    got = {k: v.upper() for k, v in er._CHECK_COLOR.items()}
    assert got == expected, "verifier._FILLS와 어긋난다 — 색을 추가할 때 양쪽을 함께 고쳐라"


# ── 플래그가 안 실린 결과로도 만들 수 있어야 한다 ───────────────────────────
@pytest.mark.synthetic
def test_report_pulls_flags_from_the_store_when_absent(qmg, result, tmp_path,
                                                       monkeypatch):
    """`/api/result`가 플래그를 싣지 않으므로 **호출부에 따라 없을 수 있다.**

    `verify.py`는 판정 직후 원본 dict(플래그 있음)를 넘기지만, `exports.py`는
    화면에 공개된 결과(플래그 없음)를 넘긴다. 그냥 훑으면 '결함 목록' 시트가
    헤더만 남고 원본 시트에 색도 안 칠해진다.

    **예외가 아니라 «0건짜리 정상 파일»이 나간다** — 받는 사람은 «우리 부서는
    결함이 없구나»로 읽는다. 실제로 그 상태로 한 번 만들어졌다.
    """
    from backend import config
    from backend.services import result_store as rs

    db = tmp_path / "qc.db"
    monkeypatch.setattr(config, "RESULT_DB", db)
    rs.save_run(result, path=db)

    light = dict(result, flags=[])          # exports.py가 넘기는 형태
    out = tmp_path / "light.xlsx"
    er.build_report(qmg, light, out, priority=PRIORITY)

    ws = load_workbook(out)["결함 목록"]
    rows = [r for r in ws.iter_rows(min_row=5, values_only=True) if r[0] is not None]
    assert len(rows) == len(result["flags"]), \
        f"결함 목록이 {len(rows)}행 — 저장소에서 플래그를 가져오지 못했다"


@pytest.mark.synthetic
def test_scoped_report_from_the_store_stays_in_scope(qmg, result, tmp_path,
                                                     monkeypatch):
    """저장소에서 가져올 때도 범위 밖 행이 섞이면 안 된다 — 정보 누출이다."""
    from backend import config
    from backend.services import result_store as rs

    db = tmp_path / "qc.db"
    monkeypatch.setattr(config, "RESULT_DB", db)
    rs.save_run(result, path=db)

    out = tmp_path / "dept.xlsx"
    er.build_report(qmg, dict(result, flags=[]), out,
                    dept="A-부서", priority=PRIORITY)

    ws = load_workbook(out)["결함 목록"]
    depts = _col_values(ws, "부서")
    assert depts == {"A-부서"}, f"범위 밖 부서가 섞였다: {depts}"


# ── NDT REPORT 번호 (BE열) ────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_defect_sheet_carries_the_ndt_report_number(qmg, result, tmp_path):
    """현업이 산출물을 되짚는 키는 도면번호가 아니라 NDT 리포트 번호다.

    이 열이 빠지면 표는 멀쩡해 보이는데 «이게 어느 검사 기록의 건인지»를
    되짚을 수 없다 — 받는 쪽에서만 드러나는 종류의 결손이다.
    """
    out = tmp_path / "r.xlsx"
    er.build_report(qmg, result, out, priority=PRIORITY)
    ws = load_workbook(out)["결함 목록"]
    assert _col_values(ws, "NDT REPORT 번호") == {"SAVI14996", "SAVI14997",
                                                  "SAVI14998", "SAVI14999"}


@pytest.mark.synthetic
def test_ndt_report_sits_before_the_drawing_number(qmg, result, tmp_path):
    """열 순서까지 고정한다 — 추적 키가 도면번호보다 앞이어야 눈에 먼저 든다."""
    names = [n for n, _, _ in er._FLAG_COLS]
    assert names.index("NDT REPORT 번호") == names.index("도면번호") - 1


# ---- 임시부재(1C) 제외 --------------------------------------------------------
#
# 범위별 내보내기에서 «1C를 빼고 받기»를 켜면 **파일 내용이 바뀐다.** 그래서
# 범위와 마찬가지로 파일 이름·캐시 키에 들어가야 한다. 이름이 같으면 같은 부서의
# 두 파일이 서로를 덮어써서 «뺀 줄 알고 받았는데 들어 있는» 파일이 나가고,
# 그건 받은 사람이 열어 보기 전에는 알 수 없다.
@pytest.fixture
def qmg_1c(tmp_path):
    """1C 도면과 일반 도면이 섞인 워크북."""
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.title = "QMG4520"
    ws.cell(row=5, column=er.COL_DEPARTMENT, value="Dep't")
    rows = [("1C-A", "A-부서", "T1"), ("101900-B", "A-부서", "T1"),
            ("1C-C", "A-부서", "T2"), ("101900-D", "B-부서", "T9")]
    for i, (dn, d, t) in enumerate(rows, start=6):
        ws.cell(row=i, column=er.COL_DRAWING_NO, value=dn)
        ws.cell(row=i, column=4, value=f"J{i}")
        ws.cell(row=i, column=er.COL_DEPARTMENT, value=d)
        ws.cell(row=i, column=er.COL_TEAM, value=t)
    p = tmp_path / "qmg1c.xlsx"
    wb.save(p)
    return p


@pytest.fixture
def result_1c():
    def flag(row, dn, dept, team):
        return {"row": row, "col": 10, "col_letter": "J", "check_no": 3,
                "check_name": "두께", "color": "Blue", "msg": "m",
                "expected": "e", "actual": "a", "drawing_no": dn,
                "joint_no": f"J{row}", "block": "BLK", "department": dept,
                "team": team, "welder1_no": "W1", "wps_no": "W", "wps_process": "P",
                "material1": "", "material2": "", "thickness1": "", "thickness2": "",
                "weld_date": "2026-07-01", "ndt_date": "", "ndt_report": "SAVI1"}
    return {"run_at": "2026-08-11 10:00", "qmg_filename": "t.xlsx",
            "judged_rows": 4, "flagged_rows": 4, "unworked_rows": 0,
            "flags": [flag(6, "1C-A", "A-부서", "T1"),
                      flag(7, "101900-B", "A-부서", "T1"),
                      flag(8, "1C-C", "A-부서", "T2"),
                      flag(9, "101900-D", "B-부서", "T9")],
            "departments": {}}


@pytest.mark.synthetic
def test_scope_marks_and_names_the_temp_exclusion():
    plain = er.Scope("A-부서")
    notemp = er.Scope("A-부서", exclude_temp=True)
    assert plain.slug() != notemp.slug(), "파일 이름이 같으면 서로를 덮어쓴다"
    assert "임시부재" in notemp.label and "임시부재" not in plain.label
    # 조직 범위가 «전체»여도 임시부재를 빼면 행을 걸러야 한다
    assert er.Scope().keeps_every_row
    assert not er.Scope(exclude_temp=True).keeps_every_row


@pytest.mark.synthetic
def test_scope_rejects_temp_rows():
    s = er.Scope("A-부서", exclude_temp=True)
    assert s.matches("A-부서", "T1", "101900-B")
    assert not s.matches("A-부서", "T1", "1C-A")
    # 도면번호를 안 주면 «임시부재 여부를 모른다» -> 통과시킨다(범위만 본다)
    assert s.matches("A-부서", "T1")


@pytest.mark.synthetic
def test_build_report_drops_temp_rows_everywhere(qmg_1c, result_1c, tmp_path):
    """결함 목록과 원본 시트 **양쪽에서** 빠져야 한다.

    한쪽만 빠지면 «표에는 없는데 원본 시트에는 있는» 파일이 되고, 받는 사람은
    어느 쪽을 믿어야 할지 알 수 없다.
    """
    out = tmp_path / "notemp.xlsx"
    info = er.build_report(qmg_1c, result_1c, out, exclude_temp=True,
                           priority=PRIORITY)
    assert info["flags"] == 2, "1C 플래그가 남아 있다"

    wb = load_workbook(out)
    assert _col_values(wb["결함 목록"], "도면번호") == {"101900-B", "101900-D"}
    orig = wb["QMG4520"]
    drawn = {orig.cell(row=r, column=er.COL_DRAWING_NO).value
             for r in range(er.HEADER_ROWS + 1, orig.max_row + 1)}
    assert drawn == {"101900-B", "101900-D"}, f"원본 시트에 1C가 남았다: {drawn}"


@pytest.mark.synthetic
def test_temp_exclusion_combines_with_a_department(qmg_1c, result_1c, tmp_path):
    out = tmp_path / "dept_notemp.xlsx"
    info = er.build_report(qmg_1c, result_1c, out, dept="A-부서",
                           exclude_temp=True, priority=PRIORITY)
    assert info["flags"] == 1, "부서 필터와 임시부재 제외가 함께 걸리지 않았다"
    assert _col_values(load_workbook(out)["결함 목록"], "도면번호") == {"101900-B"}
