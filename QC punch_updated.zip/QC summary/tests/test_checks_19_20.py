"""
Check 19(WPS Process 자격자 미투입) · Check 20(API 재질 Groove별 프로세스)과
프로젝트 두께 규칙을 고정한다.

## 왜 이 파일이 특히 필요한가

이 세 규칙은 **실데이터로 확인할 수 없다.**

    Check 19   이번 물량에서 2건 (TR-GTFC-G01 행)
    Check 20   0건 — API 행 6건이 전부 규칙에 맞다
    프로젝트 두께  0건 — F03·G05가 없고 S355KT 계열 재질도 없다

0건인 것은 «문제가 없다»가 아니라 «대조할 대상이 없다»이다. 대용량 원본으로
검증하기 전까지는 이 테스트가 유일한 안전장치다. 손으로 만든 행 튜플로 돌기
때문에 판정 조건을 코드 없이 읽을 수 있다.
"""
from __future__ import annotations

import pytest

from backend.services import verifier as V
from backend.services.verifier import Col

from tests.test_checks_16_17 import FakeLoader, make_row


def make_checker(welder_qual: dict | None = None) -> V.QCChecker:
    c = V.QCChecker(FakeLoader())
    c.loader.welder_qual = welder_qual or {}
    return c


# ── 자격이 시공 프로세스를 «덮는가» ──────────────────────────────────────────
#
# 현업 확인(2026-08-11): SMFC 자격 보유자는 FCAW 작업이 허용된다.
# 실데이터에서 Check 6의 «프로세스 자격 없음» 36건이 **전부** 이 경우였다.
@pytest.mark.synthetic
def test_smfc_covers_fcaw_but_not_the_other_way():
    assert V._process_covers("SMFC", "FCAW"), "SMFC 자격자의 FCAW 시공은 허용된다"
    assert not V._process_covers("FCAW", "SMFC"), "반대 방향까지 열면 안 된다"
    assert V._process_covers("SMFC", "SMFC")
    assert not V._process_covers("SAW", "FCAW")
    assert not V._process_covers("", "FCAW") and not V._process_covers("SMFC", "")


@pytest.mark.synthetic
def test_check6_accepts_smfc_welder_doing_fcaw():
    """Check 6과 Check 19가 **같은 함수**를 쓴다 — 갈라지면 같은 행에 서로
    모순되는 지적이 붙는다(6은 통과인데 19는 결함)."""
    c = make_checker({"W1": {"process": {"SMFC"}, "position": set()}})
    row = make_row(WELDER1_NO="W1", WELDER1_PROC="FCAW")
    assert c._c6_welders(row) == []

    c2 = make_checker({"W1": {"process": {"SAW"}, "position": set()}})
    flags = c2._c6_welders(row)
    assert len(flags) == 1 and flags[0].check_no == "6"


# ── Check 19 — WPS Process 자격자가 최소 한 명은 있었는가 ────────────────────
@pytest.mark.synthetic
def test_c19_passes_when_any_welder_holds_the_wps_process():
    """넷 중 **한 명만** 있으면 통과다.

    전원에게 요구하면 보조 용접사까지 걸려 시정할 수 없는 지적이 대량으로 나온다.
    """
    c = make_checker({"W1": {"process": {"FCAW"}, "position": set()},
                      "W2": {"process": {"GTFC"}, "position": set()}})
    row = make_row(WELDER1_NO="W1", WELDER2_NO="W2")
    assert c._c19_wps_process_welder(row, "GTFC") is None


@pytest.mark.synthetic
def test_c19_flags_when_nobody_holds_it():
    c = make_checker({"W1": {"process": {"FCAW", "SAW"}, "position": set()}})
    row = make_row(WELDER1_NO="W1")
    f = c._c19_wps_process_welder(row, "GTFC")
    assert f is not None and f.check_no == "19"
    assert f.col == Col.WPS_PROCESS
    assert "GTFC" in f.msg and "FCAW" in f.actual


@pytest.mark.synthetic
def test_c19_uses_the_same_coverage_rule_as_check6():
    """SMFC 자격자만 투입된 행에 WPS Process가 FCAW면 통과해야 한다."""
    c = make_checker({"W1": {"process": {"SMFC"}, "position": set()}})
    row = make_row(WELDER1_NO="W1")
    assert c._c19_wps_process_welder(row, "FCAW") is None


@pytest.mark.synthetic
def test_c19_stays_quiet_when_the_welders_are_unknown():
    """넷 다 자격 DB에 없으면 «자격이 없다»가 아니라 «알 수 없다»이다.

    그건 Check 6이 이미 «자격 DB 미등록»으로 지적한다. 여기서 또 지적하면
    같은 원인에 플래그가 둘 붙어, 현업이 두 번 검토하게 된다.
    """
    c = make_checker({})
    row = make_row(WELDER1_NO="모르는사람")
    assert c._c19_wps_process_welder(row, "GTFC") is None


@pytest.mark.synthetic
def test_c19_needs_both_a_process_and_a_welder():
    c = make_checker({"W1": {"process": {"FCAW"}, "position": set()}})
    assert c._c19_wps_process_welder(make_row(WELDER1_NO="W1"), "") is None
    assert c._c19_wps_process_welder(make_row(), "GTFC") is None


# ── Check 20 — API 재질은 Groove에 따라 허용 프로세스가 다르다 ───────────────
@pytest.mark.synthetic
@pytest.mark.parametrize("groove,process,flagged", [
    ("FL", "FCAW", False),      # FL -> FCAW 적용
    ("FL", "SMFC", True),       # FL인데 SMFC면 부적합
    ("SB", "SMFC", False),      # 그 외 Groove -> SMFC/GTFC
    ("SB", "GTFC", False),
    ("SB", "FCAW", True),       # SB에 FCAW 사용 불가 (현업 예시)
    ("DB", "FCAW", True),
])
def test_c20_api_material_groove_process(groove, process, flagged):
    c = make_checker()
    row = make_row(MATERIAL1="API-5L-X52", GROOVE=groove)
    f = c._c20_api_groove_process(row, process)
    assert (f is not None) == flagged, f"{groove} + {process}"
    if f:
        assert f.check_no == "20" and groove in f.msg


@pytest.mark.synthetic
def test_c20_only_applies_to_api_materials():
    """API가 아닌 재질에는 걸리면 안 된다 — 이 물량의 대부분이 SM355A·A36이다."""
    c = make_checker()
    for mat in ("SM355A", "ASTM-A36", "NV-DW420", ""):
        row = make_row(MATERIAL1=mat, GROOVE="SB")
        assert c._c20_api_groove_process(row, "FCAW") is None, mat


@pytest.mark.synthetic
def test_c20_needs_a_groove():
    c = make_checker()
    assert c._c20_api_groove_process(make_row(MATERIAL1="API5L-GRB"), "FCAW") is None


# ── 프로젝트 두께 규칙 ───────────────────────────────────────────────────────
#
# 이 물량에는 F03·G05가 없고 S355KT 계열 재질도 없다. 그래서 규칙이 «도는지»를
# 실데이터로 확인할 수 없다 — 대용량 원본을 넣을 때까지 여기가 유일한 확인이다.
# 두께 규칙은 이제 `wps_rules`의 override가 아니라 **별도 검증항목(101~199)**이다.
# 부분일치·좁은 조건 우선·재질 표기 같은 성질은 `tests/test_project_checks.py`가
# 규칙 단위로 본다. 여기서는 «공통 판정을 실제로 대신하는가»만 남긴다.


@pytest.mark.synthetic
def test_project_thickness_beats_the_wps_sheet():
    """프로젝트 규칙이 WPS List G열보다 우선한다 — 이 프로젝트의 합의값이다.

    메시지에 «프로젝트 규칙»이라고 남겨야 한다. 안 남기면 WPS 문서를 봐도 그
    범위가 어디서 나왔는지 알 수 없어, 받는 사람이 «WPS와 다르다»고 읽는다.
    """
    # 선점은 `_c3_side()`가 «재질 키 조회보다 앞에서» 한다. 순서를 반대로 하면
    # 매핑표에 없는 프로젝트 재질(S355KT-40)이 선점에 닿지도 못한다.
    from backend.services import project_checks as P

    c = make_checker()
    c._rules, c._rule_problems = P.parse([{
        "key": "thk-mat-kt40", "no": "P1", "name": "재질 KT-40 두께",
        "color": "Blue", "kind": "thickness_range",
        "when": {"material_contains": ["KT-40"]},
        "param": {"range": "12~50"}, "overrides": [3]}])
    c._enabled = {}
    wps = {"materials": [{"base_metal": "S355", "thk_range": "3~50"}]}
    f = c._c3_side(wps, "TR-FC-F03", 3.0, "S355KT-40", "J", Col.THICKNESS1)
    assert f is not None, "재질 규칙(12~50)에서 3mm는 하한 미달이다"
    assert f.check_no == "P1", "공통 번호로 나오면 배지가 «공통»이라고 거짓말한다"
    assert "프로젝트 규칙" in f.expected and "12~50" in f.expected

    assert c._c3_side(wps, "TR-FC-F03", 20.0, "S355KT-40", "J",
                      Col.THICKNESS1) is None
