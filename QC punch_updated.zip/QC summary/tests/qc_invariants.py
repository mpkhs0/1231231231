"""
qc-data-verifier 문서 §2의 불변식 8종을 순수 함수로 옮긴 모듈.

각 함수는 검증 결과 dict(`/api/result` 페이로드, 즉 verify.py `_state["result"]`)를 받아
**위반 사항 문자열 리스트**를 돌려준다. 빈 리스트면 통과다.

설계 원칙
---------
1. `backend.services.verifier`를 임포트하지 않는다. 판정 로직을 다시 부르면 같은
   버그를 그대로 재현할 뿐이고, 이 프로젝트에서 비용을 치른 버그 2건은 모두
   **집계값을 독립적으로 재계산해 대조**했을 때만 드러났다. 여기서는 결과 페이로드만
   보고 스스로 다시 센다.
2. 메시지에 넣는 값은 전부 ASCII로 이스케이프한다(`_a()`). cp949 콘솔에서 한글
   부서명/용접사명이 그대로 출력되면 UnicodeEncodeError로 pytest가 죽는다.
   같은 이유로 이 파일의 런타임 문자열에는 em-dash/화살표/그리스문자를 쓰지 않는다.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any

# row_raw 스냅샷에서 용접사 번호가 들어 있는 엑셀 열 (AP/AR/AT/AV = 용접사 1~4).
# 라벨(한글)이 아니라 열 문자로 찾는다 - 라벨 문구가 바뀌어도 깨지지 않고,
# 이 모듈의 문자열을 ASCII로 유지할 수 있다.
WELDER_COL_LETTERS = ("AP", "AR", "AT", "AV")

# Check 6(용접사 자격 미등록)은 서류 문제이지 그 행의 작업 품질 문제가 아니다.
# 용접사 결함 집계에서 제외해야 같은 행의 다른 용접사에게 오귀속되지 않는다.
# **문자열이다.** 판정 결과의 `check_no`가 공통 `"6"` · 프로젝트 `"RUYA1"`이라,
# 정수로 두면 `f["check_no"] != 6`이 **항상 참**이 되어 Check 6이 작업성 결함으로
# 섞인다 — 이 불변식이 잡으려던 바로 그 오귀속을 스스로 놓친다.
CHECK_UNQUALIFIED = "6"

# Check 0(미작업)은 결함이 아니다. flags/stats 어디에도 있으면 안 된다.
CHECK_UNWORKED = 0

# 2차 패스에서 뒤늦게 합류하는 Check (이상치 / Joint 중복).
SECOND_PASS_CHECKS = ("13", "14")


def _a(value: Any) -> str:
    """비ASCII 문자를 이스케이프해 cp949 콘솔에서도 안전하게 출력되도록 한다."""
    return str(value).encode("ascii", "backslashreplace").decode("ascii")


def _sort_key(check_id) -> tuple:
    """공통을 숫자순으로 먼저, 그다음 프로젝트를 이름·순번으로."""
    cid = str(check_id).strip()
    return (0, "", int(cid)) if cid.isdigit() else (1, cid.upper(), 0)


def _int_stats(stats: dict[str, int]) -> dict[str, int]:
    """식별자 키를 **문자열로** 정규화(0인 항목은 버린다).

    예전에는 `int(k)`였다. 프로젝트 식별자가 `RUYA1`이 되면 거기서 ValueError로
    죽고, 공통만 남기면 `int(k) != CHECK_UNQUALIFIED`가 **항상 참**이 되어
    Check 6이 작업성 결함으로 섞인다 — 이 불변식이 잡으려던 오귀속 그 자체다.
    """
    return {str(k): v for k, v in stats.items() if v}


def _sum_check_stats(buckets: list[dict]) -> dict[str, int]:
    agg: dict[str, int] = defaultdict(int)
    for b in buckets:
        for k, v in (b.get("check_stats") or {}).items():
            if v:
                agg[str(k)] += v
    return dict(agg)


def _cmp_maps(actual: dict[int, int], expected: dict[int, int], label: str) -> list[str]:
    out: list[str] = []
    # 공통과 프로젝트 식별자가 섞이므로 문자열 정렬로는 `10`이 `2`보다 앞이다.
    for k in sorted(set(actual) | set(expected), key=_sort_key):
        a, e = actual.get(k, 0), expected.get(k, 0)
        if a != e:
            out.append(f"{label}: Check {k} rollup={a} expected={e} (diff {a - e:+d})")
    return out


def welders_of_row(result: dict, row: int) -> set[str]:
    """
    row_raw 스냅샷에서 그 행에 참여한 용접사 번호 집합을 뽑는다.

    verifier가 `welder_totals`/`welder_defects`를 셀 때 쓰는 것과 같은 정의
    (AP/AR/AT/AV 네 열의 비어있지 않은 값 집합)를 결과 페이로드만으로 재현한 것.
    """
    snapshot = (result.get("row_raw") or {}).get(str(row)) or []
    return {
        str(cell.get("value", "")).strip()
        for cell in snapshot
        if cell.get("col") in WELDER_COL_LETTERS and str(cell.get("value", "")).strip()
    }


# ---------------------------------------------------------------------------
# 2-1. 행 수 회계
# ---------------------------------------------------------------------------
def check_row_accounting(result: dict) -> list[str]:
    r = result
    out: list[str] = []
    if r["total_rows"] != r["deleted_rows"] + r["active_rows"]:
        out.append(
            f"total_rows={r['total_rows']} != deleted_rows({r['deleted_rows']}) "
            f"+ active_rows({r['active_rows']})"
        )
    if r["active_rows"] != r["unworked_rows"] + r["judged_rows"]:
        out.append(
            f"active_rows={r['active_rows']} != unworked_rows({r['unworked_rows']}) "
            f"+ judged_rows({r['judged_rows']})"
        )
    if r["judged_rows"] != r["flagged_rows"] + r["clean_rows"]:
        out.append(
            f"judged_rows={r['judged_rows']} != flagged_rows({r['flagged_rows']}) "
            f"+ clean_rows({r['clean_rows']})"
        )
    # judged_rows 는 모든 결함률의 유일한 분모다. 0 이하이면 분모 자체가 성립하지 않는다.
    if r["judged_rows"] < 0:
        out.append(f"judged_rows={r['judged_rows']} is negative")
    return out


# ---------------------------------------------------------------------------
# 2-2. 플래그 회계 (행 단위 vs 플래그 단위 혼선 검출)
# ---------------------------------------------------------------------------
def check_flag_accounting(result: dict) -> list[str]:
    r = result
    out: list[str] = []
    stats_sum = sum(r["stats"].values())
    if r["total_flags"] != stats_sum:
        out.append(f"total_flags={r['total_flags']} != sum(stats)={stats_sum}")
    if len(r["flags"]) != r["total_flags"]:
        out.append(f"len(flags)={len(r['flags'])} != total_flags={r['total_flags']}")
    distinct_rows = len({f["row"] for f in r["flags"]})
    if r["flagged_rows"] != distinct_rows:
        out.append(
            f"flagged_rows={r['flagged_rows']} != distinct rows in flags={distinct_rows} "
            "(unit confusion: rows vs flags)"
        )
    # Check 별 플래그 수도 stats 와 일치해야 한다 (stats 를 행 단위로 센 적이 있었다).
    per_check: dict[int, int] = defaultdict(int)
    for f in r["flags"]:
        per_check[str(f["check_no"])] += 1
    out.extend(_cmp_maps(dict(per_check), _int_stats(r["stats"]), "stats vs flags"))
    return out


# ---------------------------------------------------------------------------
# 2-3. 부서 -> 전사 롤업
# ---------------------------------------------------------------------------
def check_department_rollup(result: dict) -> list[str]:
    r = result
    depts = list(r["departments"].values())
    out: list[str] = []
    pairs = [
        ("total_rows", sum(d["total_rows"] for d in depts), r["judged_rows"], "judged_rows"),
        ("unworked_rows", sum(d["unworked_rows"] for d in depts), r["unworked_rows"], "unworked_rows"),
        ("defect_rows", sum(d["defect_rows"] for d in depts), r["flagged_rows"], "flagged_rows"),
    ]
    for field, got, want, want_name in pairs:
        if got != want:
            out.append(
                f"sum(departments[*].{field})={got} != {want_name}={want} (diff {got - want:+d})"
            )
    out.extend(_cmp_maps(_sum_check_stats(depts), _int_stats(r["stats"]), "departments"))
    return out


# ---------------------------------------------------------------------------
# 2-4. 팀 -> 부서 롤업 (부서마다, 전수)
# ---------------------------------------------------------------------------
def check_team_rollup(result: dict) -> list[str]:
    out: list[str] = []
    for dept_name, d in result["departments"].items():
        teams = list((d.get("teams") or {}).values())
        tag = f"dept[{_a(dept_name)}]"
        if not teams:
            # 판정 대상 행이 있는데 팀 버킷이 하나도 없으면 드릴다운이 비어버린다.
            if d["total_rows"] or d["defect_rows"] or d["unworked_rows"]:
                out.append(f"{tag}: has rows but no team buckets")
            continue
        for field in ("total_rows", "unworked_rows", "defect_rows"):
            got = sum(t[field] for t in teams)
            if got != d[field]:
                out.append(
                    f"{tag}: sum(teams[*].{field})={got} != dept.{field}={d[field]} "
                    f"(diff {got - d[field]:+d})"
                )
        out.extend(_cmp_maps(_sum_check_stats(teams), _int_stats(d["check_stats"]), tag))
    return out


# ---------------------------------------------------------------------------
# 2-5. 용접사 집계 (가장 자주 깨지는 지점)
# ---------------------------------------------------------------------------
def recompute_welder_defects(result: dict) -> dict[str, int]:
    """
    welder_info[w]['defect'] 를 flags + row_raw 만으로 독립 재계산한다.

    정의: "C6 이 아닌 플래그가 하나라도 있는 행" 중 w 가 참여한 행의 수.
    - Check 6 제외
    - 행 단위 중복 제거 (한 행에 C3/C4 가 같이 걸려도 그 용접사에게는 1행)
    """
    workmanship_rows = {
        f["row"] for f in result["flags"] if str(f["check_no"]) != CHECK_UNQUALIFIED
    }
    counts: dict[str, int] = defaultdict(int)
    for row in workmanship_rows:
        for wno in welders_of_row(result, row):
            counts[wno] += 1
    return dict(counts)


def check_welder_defects(result: dict) -> list[str]:
    """2-5 핵심: welder_info[*].defect 재계산 대조."""
    out: list[str] = []
    recalc = recompute_welder_defects(result)
    info = result["welder_info"]

    # row_raw 가 없어 용접사를 복원할 수 없는 결함 행이 있으면 재계산 자체가 무의미해진다.
    workmanship_rows = {
        f["row"] for f in result["flags"] if str(f["check_no"]) != CHECK_UNQUALIFIED
    }
    orphan = [row for row in workmanship_rows if not welders_of_row(result, row)]
    if len(orphan) > len(workmanship_rows) * 0.5:
        out.append(
            f"row_raw missing welder columns for {len(orphan)}/{len(workmanship_rows)} "
            "workmanship rows: welder recomputation is not trustworthy"
        )
        return out

    for wno in sorted(set(info) | set(recalc)):
        reported = info.get(wno, {}).get("defect", 0)
        expected = recalc.get(wno, 0)
        # row_raw 를 복원하지 못한 행(orphan)은 재계산에서 빠지므로 과소평가될 수 있다.
        if reported != expected and not orphan:
            out.append(
                f"welder[{_a(wno)}].defect={reported} != recomputed={expected} "
                f"(diff {reported - expected:+d})"
            )
    return out


def check_welder_date_stats(result: dict) -> list[str]:
    """2-5 보조: date_stats 합계 == total / check_breakdown (C6 제외)."""
    out: list[str] = []
    for wno, v in result["welder_info"].items():
        date_stats = v.get("date_stats") or []
        got_total = sum(d["total"] for d in date_stats)
        if got_total != v["total"]:
            out.append(
                f"welder[{_a(wno)}]: sum(date_stats[*].total)={got_total} != total={v['total']}"
            )
        agg: dict[int, int] = defaultdict(int)
        for d in date_stats:
            for k, n in (d.get("checks") or {}).items():
                agg[str(k)] += n
        breakdown = {
            str(k): n
            for k, n in (v.get("check_breakdown") or {}).items()
            if str(k) != CHECK_UNQUALIFIED and n
        }
        out.extend(
            _cmp_maps(
                {k: n for k, n in agg.items() if n},
                breakdown,
                f"welder[{_a(wno)}] date_stats",
            )
        )
    return out


def check_welder_rates(result: dict) -> list[str]:
    """2-5 보조: rate == round(defect / total * 100, 1)."""
    out: list[str] = []
    for wno, v in result["welder_info"].items():
        total, defect = v["total"], v["defect"]
        expected = round(defect / total * 100, 1) if total else 0.0
        if v["rate"] != expected:
            out.append(f"welder[{_a(wno)}].rate={v['rate']} != expected {expected}")
        if total and defect > total:
            out.append(f"welder[{_a(wno)}].defect={defect} > total={total}")
    return out


def check_welder_defect_rate_list(result: dict) -> list[str]:
    """
    welder_defect_rate 리스트는 defect == 0 인 용접사를 의도적으로 제외한다.
    따라서 "전체 용접사 수와 다르다"는 오탐이고, 검사해야 할 것은
    "defect > 0 인 용접사 집합과 정확히 일치하는가" 이다.
    """
    out: list[str] = []
    listed = {w["welder_no"] for w in result["welder_defect_rate"]}
    expected = {w for w, v in result["welder_info"].items() if v["defect"] > 0}
    for wno in sorted(expected - listed):
        out.append(f"welder[{_a(wno)}] has defect>0 but is missing from welder_defect_rate")
    for wno in sorted(listed - expected):
        out.append(f"welder[{_a(wno)}] is in welder_defect_rate but has defect==0")
    by_no = {w["welder_no"]: w for w in result["welder_defect_rate"]}
    for wno in sorted(listed & expected):
        entry, info = by_no[wno], result["welder_info"][wno]
        if entry["defect"] != info["defect"] or entry["total"] != info["total"]:
            out.append(
                f"welder[{_a(wno)}] welder_defect_rate({entry['defect']}/{entry['total']}) "
                f"!= welder_info({info['defect']}/{info['total']})"
            )
    return out


# ---------------------------------------------------------------------------
# 2-6. 2차 패스(Check 13/14) 소급 반영
# ---------------------------------------------------------------------------
def check_second_pass_backfill(result: dict) -> list[str]:
    """
    Check 13/14 는 1차 판정이 끝난 뒤 `_register_flag()` 로 합류한다.
    합류 시 stats / 부서 / 팀 / 용접사 집계에 소급 반영되지 않으면 조용히 어긋난다.

    실제 버그: 1차에서 C6 만 있던 257행이 2차에서 C13/C14 를 얻었는데
    `is_new_defect_row` 로만 분기해 welder_defects 에서 누락됐다.
    아래 마지막 항목이 정확히 그 상황을 겨냥한다.
    """
    out: list[str] = []
    stats = _int_stats(result["stats"])
    dept_stats = _sum_check_stats(list(result["departments"].values()))

    for check_no in SECOND_PASS_CHECKS:
        n_flags = sum(1 for f in result["flags"] if str(f["check_no"]) == check_no)
        if stats.get(check_no, 0) != n_flags:
            out.append(
                f"Check {check_no}: stats={stats.get(check_no, 0)} != flags={n_flags} "
                "(second pass not reflected in stats)"
            )
        if dept_stats.get(check_no, 0) != n_flags:
            out.append(
                f"Check {check_no}: sum(departments check_stats)={dept_stats.get(check_no, 0)} "
                f"!= flags={n_flags} (second pass not backfilled into departments)"
            )

    # 2차 패스로 '처음' 작업성 결함이 된 행 (1차에는 C6 만 있었던 행) 을 특정해
    # 그 행의 용접사들이 실제로 결함 행으로 집계됐는지 본다.
    by_row: dict[int, set[str]] = defaultdict(set)
    for f in result["flags"]:
        by_row[f["row"]].add(str(f["check_no"]))
    late_rows = [
        row
        for row, checks in by_row.items()
        if checks - {CHECK_UNQUALIFIED} and not (checks - {CHECK_UNQUALIFIED} - set(SECOND_PASS_CHECKS))
        and CHECK_UNQUALIFIED in checks
    ]
    info = result["welder_info"]
    per_welder_late: dict[str, int] = defaultdict(int)
    for row in late_rows:
        for wno in welders_of_row(result, row):
            per_welder_late[wno] += 1
    for wno, n_late in sorted(per_welder_late.items()):
        if info.get(wno, {}).get("defect", 0) < n_late:
            out.append(
                f"welder[{_a(wno)}].defect={info.get(wno, {}).get('defect', 0)} < {n_late} rows "
                "that became defective only in the second pass (C6-only rows gaining C13/C14)"
            )
    return out


# ---------------------------------------------------------------------------
# 2-7. 검토 기록(feedback) 키 무결성
# ---------------------------------------------------------------------------
def feedback_key(drawing_no: str, joint_no: str, wps_no: str, check_no: int) -> str:
    """feedback_store._make_key 와 동일한 4요소 키 (독립 구현)."""
    return (
        f"{(drawing_no or '').strip()}|{(joint_no or '').strip()}"
        f"|{(wps_no or '').strip()}|{check_no}"
    )


def group_flags_by_feedback_key(result: dict, include_drawing: bool = True) -> dict[str, set[str]]:
    """검토 키 -> 그 키에 매칭되는 flags 의 도면번호 집합."""
    groups: dict[str, set[str]] = defaultdict(set)
    for f in result["flags"]:
        drawing = (f.get("drawing_no") or "").strip()
        if include_drawing:
            key = feedback_key(drawing, f.get("joint_no", ""), f.get("wps_no", ""), f["check_no"])
        else:
            # 도면번호가 빠져 있던 구 키 (회귀 재현용)
            key = (
                f"{(f.get('joint_no') or '').strip()}|"
                f"{(f.get('wps_no') or '').strip()}|{f['check_no']}"
            )
        groups[key].add(drawing)
    return dict(groups)


def check_feedback_key_scope(result: dict) -> list[str]:
    """
    Joint No 는 도면 안에서만 유일하다. 검토 키 하나가 2개 이상 도면에 걸치면,
    한 건을 검토했을 때 무관한 도면의 조인트까지 검토 완료로 표시된다.
    """
    out: list[str] = []
    for key, drawings in group_flags_by_feedback_key(result, include_drawing=True).items():
        if len(drawings) > 1:
            out.append(
                f"feedback key {_a(key)} spans {len(drawings)} drawings: "
                f"{_a(sorted(drawings)[:3])}"
            )
    return out


def check_feedback_records(records: dict[str, dict]) -> list[str]:
    """저장된 검토 기록의 키가 4요소(도면번호 포함) 형식이고 본문과 일치하는지."""
    out: list[str] = []
    for key, rec in records.items():
        if key.count("|") != 3:
            out.append(f"feedback key {_a(key)} is legacy 3-part (drawing_no missing)")
            continue
        expected = feedback_key(
            rec.get("drawing_no", ""),
            rec.get("joint_no", ""),
            rec.get("wps_no", ""),
            rec.get("check_no", 0),
        )
        if key != expected:
            out.append(f"feedback key {_a(key)} != key rebuilt from record {_a(expected)}")
        if not (rec.get("drawing_no") or "").strip():
            out.append(f"feedback record {_a(key)} has empty drawing_no")
    return out


# ---------------------------------------------------------------------------
# 2-8. Check 0 (미작업)
# ---------------------------------------------------------------------------
def check_unworked(result: dict) -> list[str]:
    r = result
    out: list[str] = []
    if r["stats"].get(str(CHECK_UNWORKED), 0):
        out.append(
            f"stats[0]={r['stats'][str(CHECK_UNWORKED)]}: unworked rows must not be counted as defects"
        )
    n_flag0 = sum(1 for f in r["flags"] if f["check_no"] == CHECK_UNWORKED)
    if n_flag0:
        out.append(f"{n_flag0} flags carry check_no=0: unworked is not a defect")
    unworked_list = r.get("unworked_list") or []
    if len(unworked_list) != r["unworked_rows"]:
        out.append(
            f"len(unworked_list)={len(unworked_list)} != unworked_rows={r['unworked_rows']}"
        )
    overlap = {u["row"] for u in unworked_list} & {f["row"] for f in r["flags"]}
    if overlap:
        out.append(
            f"{len(overlap)} rows are both unworked and flagged, e.g. {sorted(overlap)[:5]}"
        )
    # 결함률 분모에 미작업이 섞이지 않았는지 (분모는 judged_rows 여야 한다)
    if r["unworked_rows"] and r["judged_rows"] + r["unworked_rows"] != r["active_rows"]:
        out.append("unworked_rows leaked into the defect-rate denominator (judged_rows)")
    return out


# 문서 §2 항목 번호 -> 검사 함수. 테스트 파라미터화와 리포트 표에 함께 쓴다.
INVARIANTS = {
    "2-1 row accounting": check_row_accounting,
    "2-2 flag accounting": check_flag_accounting,
    "2-3 department rollup": check_department_rollup,
    "2-4 team rollup": check_team_rollup,
    "2-5a welder defects": check_welder_defects,
    "2-5b welder date stats": check_welder_date_stats,
    "2-5c welder rates": check_welder_rates,
    "2-5d welder defect rate list": check_welder_defect_rate_list,
    "2-6 second pass backfill": check_second_pass_backfill,
    "2-7 feedback key scope": check_feedback_key_scope,
    "2-8 unworked": check_unworked,
}


def run_all(result: dict) -> dict[str, list[str]]:
    """모든 불변식을 돌려 {항목: 위반목록} 을 돌려준다 (리포트/디버깅용)."""
    return {name: fn(result) for name, fn in INVARIANTS.items()}
