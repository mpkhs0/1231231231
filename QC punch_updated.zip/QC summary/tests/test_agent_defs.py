"""에이전트 정의(`.claude/agents/*.md`)가 **조용히 낡지 않았는가.**

## 왜 필요한가

`test-automator.md`가 열흘 동안 「현재 `tests/` 디렉터리도 테스트 러너도 없다.
골격을 세우는 것이 첫 임무다」라고 적어 두고 있었다. 그 사이 27개 파일 500여 건이
생겼다. 정의는 **에이전트가 읽는 유일한 맥락**이라, 이 상태로 태우면 거짓 전제에서
시작해 이미 있는 것을 다시 만들려 든다.

아무 데서도 오류가 나지 않는다. 에이전트는 시키는 대로 하고, 결과물은 그럴듯하다.

## 무엇을 잡는가

정의가 **파일이나 디렉터리를 지목했는데 그게 없는 경우**다. 자연어 주장(«…가 없다»)은
자동으로 검사할 수 없지만, 경로는 검사할 수 있다 — 그리고 낡은 정의는 대개 경로에서
먼저 어긋난다(옮긴 모듈, 지운 파일, 이름이 바뀐 디렉터리).
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
AGENTS = ROOT / ".claude" / "agents"

# 정의 안의 «파일처럼 생긴 것». **백틱 안팎을 모두** 본다 — frontmatter의
# `description`은 백틱을 쓰지 않는데, 거기에도 파일 이름이 적혀 있다.
# 확장자는 이 저장소에 실제로 있는 것들로 좁힌다(아무 점이나 잡으면 산문이 걸린다).
_PATHISH = re.compile(
    r"(?<![A-Za-z0-9_/.-])(?:[A-Za-z0-9_.-]+/)*"
    r"[A-Za-z0-9_-]+\.(?:py|js|css|html|json|md|bat|ps1|xlsm|db)\b"
)

# 백틱으로 감싼 «디렉터리»(`backend/routers/`). 위 정규식이 확장자를 요구해서 못 잡는다.
_DIRISH = re.compile(r"`((?:[A-Za-z0-9_.-]+/)+)`")

# 파일이 아니라 산문이다. 확장자만 보고 걸러낼 방법이 없어서 이름으로 적는다.
_NOT_FILES = {"Node.js", "Next.js", "Vue.js", "React.js", "D3.js"}

# 실행 시점에 만들어지는 것들. 없는 게 정상이다.
_RUNTIME = ("data/", "qc_uploads/", "qc_results/", "Raw data/", "output/", "logs/")

# 같은 것들을 **이름만으로** 부르는 자리가 많다(글이라 경로를 매번 안 쓴다).
# 런타임 폴더 안에 있어 저장소 검색으로는 못 찾으므로 여기서 이름으로 뺀다.
_RUNTIME_NAMES = {
    "projects.json", "project_rules.json", "employees.json", "wps_rules.json",
    "wps_cache.json", "flag_feedback.json", "app_state.json", "qc.db",
    "dept_recipients.json", "team_recipients.json", "outlook_settings.json",
}

# **일부러 없는 것들.** 정의가 «이건 없고 도입하지 않는다»고 말하려고 지목하거나,
# 에이전트가 실행 중에 스스로 만드는 파일이다. 존재를 요구하면 안 된다.
_DELIBERATELY_ABSENT = {
    "package.json",       # 빌드 단계 없음 — javascript-pro가 «도입하지 않는다»고 적는다
    "requirements.txt",   # 없다. 필요하면 pip install 한 줄
    "result.json",        # qc-data-verifier가 curl로 받아 만드는 임시 파일
    "tsconfig.json",
}

# 검색에서 제외할 디렉터리 — 여기서 이름이 맞아도 «있다»로 치지 않는다.
_SKIP_DIRS = {".git", "__pycache__", "node_modules", "data",
              "qc_uploads", "qc_results", "output", "Raw data"}


def _agent_files() -> list[Path]:
    return sorted(AGENTS.glob("*.md"))


@pytest.mark.synthetic
def test_there_are_agent_definitions():
    assert _agent_files(), f"{AGENTS}에 에이전트 정의가 없다"


def _exists_somewhere(name: str) -> bool:
    """이름만 적힌 파일(`verify.py`)이 저장소 어딘가에 있는가."""
    for p in ROOT.rglob(name):
        if not any(part in _SKIP_DIRS for part in p.relative_to(ROOT).parts):
            return True
    return False


@pytest.mark.synthetic
@pytest.mark.parametrize("path", _agent_files(), ids=lambda p: p.stem)
def test_every_path_an_agent_names_still_exists(path: Path):
    """정의가 지목한 파일이 실제로 있어야 한다.

    없으면 에이전트는 «찾을 수 없다»로 끝나거나, 더 나쁘게는 **비슷한 이름의 다른
    파일**을 골라 엉뚱한 곳을 고친다.

    경로(`backend/services/verifier.py`)는 그 자리에 있어야 하고, 이름만 적힌 것
    (`verify.py`)은 저장소 어딘가에 있으면 된다 — 정의는 사람이 읽는 글이라
    이름만 부르는 자리가 많고, 거기까지 전체 경로를 요구하면 글이 나빠진다.
    """
    text = path.read_text(encoding="utf-8")
    refs = set(_PATHISH.findall(text)) | set(_DIRISH.findall(text))
    missing = []
    for ref in sorted(refs):
        ref = ref.replace("\\", "/")
        if (ref.startswith(_RUNTIME) or "*" in ref or ref.startswith(".")
                or ref in _DELIBERATELY_ABSENT or ref in _NOT_FILES
                or ref in _RUNTIME_NAMES):
            continue
        # `routers/`처럼 이름 하나에 슬래시만 붙은 것은 «디렉터리 이름»이지 경로가 아니다
        bare = ref.rstrip("/")
        ok = (ROOT / ref).exists() if "/" in bare else _exists_somewhere(bare)
        if not ok:
            missing.append(ref)
    assert not missing, (
        f"{path.name}이 없는 경로를 가리킨다: {missing} — "
        "에이전트는 이 정의만 읽으므로, 없는 파일을 찾다가 비슷한 이름의 다른 "
        "파일을 고칠 수 있다. 일부러 없는 것이라면 _DELIBERATELY_ABSENT에 넣어라"
    )


@pytest.mark.synthetic
@pytest.mark.parametrize("path", _agent_files(), ids=lambda p: p.stem)
def test_every_agent_declares_its_origin(path: Path):
    """'에이전트' 탭이 전용/외부를 **본문 주석**의 표식으로 가른다.

    frontmatter가 아니라 본문에 두는 이유: frontmatter는 Claude Code가 파싱하는
    영역이라 임의 키를 넣지 않는다. HTML 주석은 화면 렌더에서 제거되므로 보이지도
    않는다. 표식이 빠지면 성격이 다른 둘을 같은 잣대로 읽게 된다.
    """
    head = path.read_text(encoding="utf-8")[:1200]
    assert re.search(r"<!--\s*origin:\s*(project|vendor)\s*-->", head), \
        f"{path.name}에 origin 표식이 없다"
    assert re.search(r"<!--\s*summary:", head), \
        f"{path.name}에 summary가 없다 — '에이전트' 탭에 한 줄 설명이 빈다"


@pytest.mark.synthetic
def test_the_test_suite_is_not_described_as_missing():
    """골격 수립은 2026-08-03에 끝났다.

    이 문장이 열흘 동안 남아 있었고, 그동안 이 에이전트를 태웠다면 이미 있는
    스위트를 다시 만들려 들었을 것이다. 다시 들어오는 것을 막는다.
    """
    src = (AGENTS / "test-automator.md")
    if not src.exists():          # 지웠다면 이 검사도 할 일이 없다
        pytest.skip("test-automator 정의가 없다")
    text = src.read_text(encoding="utf-8")
    body = text[:text.index("You are a senior")] if "You are a senior" in text else text
    assert "골격을 세우는 것이 첫 임무" not in body, \
        "테스트 골격이 없다고 적혀 있다 — 지금 27개 파일 500여 건이 있다"
    assert (ROOT / "tests" / "conftest.py").exists(), "전제가 바뀌었다"


# ── 스킬 ────────────────────────────────────────────────────────────────────
#
# 반복 작업을 «에이전트 하나를 더 띄우는 일»로 만들지 않기 위해 스킬로 뒀다.
# 스킬은 부르는 쪽의 맥락 안에서 돌아 cold start가 없다 — 저장소 사정을 다시
# 배우지 않는다.
#
# **스킬도 에이전트 정의처럼 조용히 낡는다.** 그래서 같은 잣대를 댄다:
# 지목한 파일·심볼이 실제로 있는가.
SKILLS = ROOT / ".claude" / "skills"


def _skill_files() -> list[Path]:
    return sorted(SKILLS.glob("*/SKILL.md"))


def _skill(name: str) -> Path:
    return SKILLS / name / "SKILL.md"


SKILL = _skill("검증")


@pytest.mark.synthetic
def test_there_are_skills():
    assert _skill_files(), f"{SKILLS}에 스킬이 없다"


@pytest.mark.synthetic
@pytest.mark.parametrize("path", _skill_files(), ids=lambda p: p.parent.name)
def test_every_skill_is_addressable(path: Path):
    """frontmatter가 없으면 스킬로 인식되지 않는다 — 파일은 있는데 부를 수가 없다."""
    head = path.read_text(encoding="utf-8")[:900]
    assert head.startswith("---"), f"{path.parent.name}: frontmatter가 없다"
    assert re.search(r"^name:\s*\S", head, re.M), f"{path.parent.name}: name이 없다"
    assert re.search(r"^description:\s*\S", head, re.M), \
        f"{path.parent.name}: description이 없으면 언제 쓸 스킬인지 판단할 근거가 사라진다"


@pytest.mark.synthetic
@pytest.mark.parametrize("path", _skill_files(), ids=lambda p: p.parent.name)
def test_every_path_a_skill_names_still_exists(path: Path):
    """스킬이 지목한 파일이 실제로 있어야 한다.

    에이전트 정의와 같은 이유다 — 스킬은 «이 저장소가 어떻게 생겼는가»를 적어 둔
    글이고, 코드가 움직이면 글만 남는다. 없는 파일을 찾다가 비슷한 이름의 다른
    파일을 고치는 것이 가장 나쁜 결말이다.
    """
    text = path.read_text(encoding="utf-8")
    refs = set(_PATHISH.findall(text)) | set(_DIRISH.findall(text))
    missing = []
    for ref in sorted(refs):
        ref = ref.replace("\\", "/")
        if (ref.startswith(_RUNTIME) or "*" in ref or ref.startswith(".")
                or ref in _DELIBERATELY_ABSENT or ref in _NOT_FILES
                or ref in _RUNTIME_NAMES):
            continue
        bare = ref.rstrip("/")
        ok = (ROOT / ref).exists() if "/" in bare else _exists_somewhere(bare)
        if not ok:
            missing.append(ref)
    assert not missing, f"{path.parent.name} 스킬이 없는 경로를 가리킨다: {missing}"


@pytest.mark.synthetic
def test_the_verify_skill_routes_to_agents_that_exist():
    """표가 없는 에이전트를 가리키면 «검증했다»고 하면서 아무것도 안 돈다."""
    text = SKILL.read_text(encoding="utf-8")
    # 정규식을 쓰지 않는다. 이 저장소에서 `\b`가 리터럴 백스페이스(0x08)가 되어
    # **영원히 매칭되지 않는 테스트**가 통과한 적이 두 번 있다 — 소스에 보이지도 않는다.
    have = {p.stem for p in _agent_files()}
    named = {n for n in ("qc-data-verifier", "ui-regression-checker") if n in text}
    assert named, "스킬이 어떤 에이전트도 지목하지 않는다"
    assert named <= have, f"없는 에이전트를 가리킨다: {sorted(named - have)}"


@pytest.mark.synthetic
def test_the_verify_skill_runs_pytest_before_agents():
    """에이전트는 한 번에 20분 넘게 걸린다. 불변식 8종은 이미 pytest에 있으므로
    **먼저 돌려야** 20분 뒤에 같은 말을 듣지 않는다."""
    # frontmatter의 description은 «언제 쓰는 스킬인가»라 순서와 무관하다.
    # 절차는 본문에 있으므로 본문만 본다.
    text = SKILL.read_text(encoding="utf-8")
    body = text[text.index("\n---", 3) + 4:]
    i_pytest = body.index("pytest tests/")
    i_agent = min(body.index("qc-data-verifier"), body.index("ui-regression-checker"))
    assert i_pytest < i_agent, "에이전트 얘기가 pytest보다 먼저 나온다"


@pytest.mark.synthetic
def test_the_verify_skill_uses_the_sandbox():
    """사용자 서버에서 재검증하면 보고 있던 결과가 사라진다(KEEP_RUNS = 1)."""
    text = SKILL.read_text(encoding="utf-8")
    assert "tools.sandbox_server" in text
    assert (ROOT / "tools" / "sandbox_server.py").exists()


# ── 판정항목 스킬 ───────────────────────────────────────────────────────────
#
# 새 Check 하나가 13곳에 닿는데 테스트가 강제하는 것은 5곳뿐이다. 나머지는
# 빠뜨려도 아무 데서도 오류가 나지 않는다 — 스킬의 체크리스트가 유일한 방어다.
# 그 체크리스트가 **없는 심볼**을 가리키면 방어가 조용히 사라진다.
#
# 심볼이 어느 파일에 있어야 하는지까지 못 박는다. 이름만 보면 옮겨 가도 모른다.
_CHECK_SURFACE = {
    "_FILLS": "backend/services/verifier.py",
    "CHECK_COLORS": "backend/services/verifier.py",
    "CHECK_NAMES": "backend/services/verifier.py",
    "_PRIORITY": "backend/services/verifier.py",
    "_CHECK_COLOR": "backend/services/excel_report.py",
    "_AXES": "backend/services/diagrams.py",
    "CATALOG": "backend/services/rule_catalog.py",
    "CHECK_META": "frontend/static/js/app.js",
    "COLOR_TO_CLS": "frontend/static/js/app.js",
    "_register_flag": "backend/services/verifier.py",
    "_check_row": "backend/services/verifier.py",
    "_workmanship_rows": "backend/services/verifier.py",
    "_SCOPED_CHECKS": "backend/services/verifier.py",
    "_scope": "backend/services/verifier.py",
}


@pytest.mark.synthetic
def test_the_check_skill_lists_every_place_a_check_touches():
    text = _skill("판정항목").read_text(encoding="utf-8")
    missing = [s for s in _CHECK_SURFACE if s not in text]
    assert not missing, (
        f"판정항목 스킬의 체크리스트에서 빠진 자리: {missing} — "
        "여기 없으면 새 Check가 그 자리를 건너뛰고, 오류는 나지 않는다"
    )


@pytest.mark.synthetic
@pytest.mark.parametrize("symbol,where", sorted(_CHECK_SURFACE.items()))
def test_the_check_surface_symbols_are_real(symbol: str, where: str):
    """스킬이 가리키는 심볼이 실제로 그 파일에 있어야 한다.

    이름이 바뀌거나 파일이 옮겨 가면 **스킬이 먼저 거짓이 된다** — 코드는 멀쩡히
    돌고, 다음 사람만 없는 것을 찾는다.
    """
    src = (ROOT / where).read_text(encoding="utf-8")
    assert symbol in src, f"{where}에 {symbol}이 없다 — 판정항목 스킬이 낡았다"


@pytest.mark.synthetic
def test_the_check_skill_keeps_the_number_rules():
    """번호 재사용은 **과거 검토 의견을 무관한 항목에 붙인다.** 검토 기록 키가
    `도면번호|Joint No|WPS No|Check No`이기 때문이다."""
    text = _skill("판정항목").read_text(encoding="utf-8")
    for must in ("15", "재사용", "101", "199"):
        assert must in text, f"번호 규칙에서 «{must}»가 빠졌다"

    from backend.services import project_checks

    assert str(project_checks.LEGACY_ID_MIN) in text and str(project_checks.LEGACY_ID_MAX) in text, \
        "스킬의 대역이 project_checks.LEGACY_ID_MIN/ID_MAX와 다르다"


# ── 새프로젝트 스킬 ─────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_the_onboarding_skill_covers_every_project_param():
    """`params` 키가 늘었는데 스킬이 모르면 **새 프로젝트가 그 값을 안 정하고
    지나간다.** 그 결과는 «결함이 거의 없는 깨끗한 거짓 결과»다 — 실제로
    `repair_prefix`가 비어 Check 2·4·11이 통째로 빠진 적이 있다.
    """
    from backend.services import wps_rules

    text = _skill("새프로젝트").read_text(encoding="utf-8")
    # 표시용 키는 빼고 «판정에 먹이는 값»만 본다
    keys = set(wps_rules.DEFAULTS) - {"project"}
    missing = sorted(k for k in keys if k not in text)
    assert not missing, (
        f"새프로젝트 스킬이 모르는 params 키: {missing} — "
        "새 프로젝트가 이 값을 안 정하고 첫 검증을 돌리게 된다"
    )


@pytest.mark.synthetic
def test_the_onboarding_skill_ends_on_rule_health():
    """온보딩의 끝은 «경고 0건»이다. 경고를 남긴 채 «완료»로 보고하면 그 결과는
    신뢰할 수 없는데, 화면에는 정상으로 보인다."""
    text = _skill("새프로젝트").read_text(encoding="utf-8")
    assert "rule_health" in text
    for must in ("projects.json", "data_dir", "sandbox_server"):
        assert must in text, f"온보딩 절차에서 «{must}»가 빠졌다"


# ── 열거할 수 있는 사실은 테스트로 못 박는다 ────────────────────────────────
#
# 정의와 문서가 «몇 개»를 적어 두면 그 숫자가 가장 먼저 낡는다. 실제로 화면 수가
# 네 곳에서 12 / 13 / 12 / 10으로 갈라져 있었고(실제 14), 정본 문서는 「14가지
# 검사(Check 1~14)」로 남아 있었다(실제 26가지).
#
# 줄 수처럼 매 커밋 흔들리는 숫자는 여기서 다루지 않는다 — 그건 문서에서 빼야 할
# 종류다. 뷰 목록·판정 항목 수는 **바뀔 때 문서도 함께 고쳐야 하는** 사실이다.
@pytest.mark.synthetic
def test_the_ui_agent_knows_how_many_views_there_are():
    """화면 수가 틀리면 에이전트가 «순회했다»면서 일부를 건너뛴다."""
    html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
    # `view-crumb`는 상단 빵부스러기라 뷰가 아니다
    views = {v for v in re.findall(r'id="(view-[a-z-]+)"', html) if v != "view-crumb"}
    text = (AGENTS / "ui-regression-checker.md").read_text(encoding="utf-8")
    assert f"{len(views)}개 화면" in text, (
        f"실제 뷰는 {len(views)}개인데 정의가 그 숫자를 말하지 않는다: {sorted(views)}"
    )
    # 부분 문자열로 세면 «4개 화면»이 «14개 화면» 안에서 걸린다 — 숫자를 통째로 뽑는다
    said = {int(x) for x in re.findall(r"(\d+)개 화면", text)}
    assert said == {len(views)}, f"정의에 다른 화면 수가 남아 있다: {sorted(said)}"


@pytest.mark.synthetic
def test_the_analysis_doc_knows_how_many_checks_there_are():
    """정본 문서 첫 문단의 «N가지 검사»가 실제 판정 항목 수와 같아야 한다."""
    from backend.services.verifier import CHECK_NAMES, CHECK_UNWORKED

    judged = [n for n in sorted(CHECK_NAMES) if n != CHECK_UNWORKED]
    doc = (ROOT / "QC_검사로직_상세분석.md").read_text(encoding="utf-8")
    head = doc[:2000]
    assert f"{len(judged)}가지" in head, (
        f"실제 판정 항목은 {len(judged)}개인데 문서 첫머리가 다른 수를 말한다"
    )
