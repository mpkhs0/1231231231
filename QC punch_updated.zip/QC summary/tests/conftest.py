"""
pytest 공통 설정 / 픽스처.

이 저장소에는 CI 가 없다. `python -m pytest tests/ -v` 하나로 끝나야 하고,
- scikit-learn / pywin32 / openpyxl 이 없어도 **수집(collection) 단계에서 깨지지 않아야** 하며,
- 사내 실데이터(`data/`)가 없는 PC 에서도 합성 데이터로 의미 있는 검사가 돌아야 한다.

그래서 무거운 모듈(backend.services.verifier 등)은 이 파일에서 임포트하지 않는다.
실데이터가 필요한 테스트는 `@pytest.mark.realdata` 로 표시하고 파일이 없으면 skip 한다.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
TESTS_DIR = Path(__file__).resolve().parent

# `backend` 패키지와 tests 헬퍼 모듈(qc_invariants / synthetic)을 임포트 가능하게 한다.
for _p in (str(REPO_ROOT), str(TESTS_DIR)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

# 실데이터 경로 (전부 .gitignore 대상 - 저장소에 커밋되지 않는다).
# QC_TESTS_DATA_DIR 로 다른 폴더를 가리킬 수 있다 - "실데이터가 없는 PC"에서의
# 동작(전부 skip 되고 합성 테스트만 도는지)을 실제로 확인해 보기 위한 장치다.
DATA_DIR = Path(os.environ.get("QC_TESTS_DATA_DIR") or (REPO_ROOT / "data"))
RESULT_DB = DATA_DIR / "qc.db"
APP_STATE_FILE = DATA_DIR / "app_state.json"
FEEDBACK_FILE = DATA_DIR / "flag_feedback.json"


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line(
        "markers",
        "realdata: requires data/qc.db or app_state.json "
        "(local company data, never committed)",
    )
    config.addinivalue_line(
        "markers", "synthetic: runs on generated data only, no local data needed"
    )


def _load_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # 손상된 파일도 skip 사유로 다룬다 (수집은 성공해야 한다)
        pytest.skip(f"cannot read {path.name}: {type(exc).__name__}")
        return None


@pytest.fixture(scope="session")
def synthetic_result() -> dict:
    """합성 검증 결과 (실데이터 불필요)."""
    import synthetic

    return synthetic.build_result()


@pytest.fixture(scope="session")
def real_result() -> dict:
    """
    마지막 실제 검증 결과. 서버를 띄우지 않고 저장소에서 바로 꺼낸다.

    **`data/qc.db`를 먼저 본다.** 저장소가 SQLite로 바뀐 뒤(개선계획 1번) 새 검증은
    DB에만 쌓이므로, JSON만 읽으면 **불변식 검사가 조용히 옛 결과를 대상으로 돈다** —
    판정 로직을 고쳤는데 테스트가 초록불인 최악의 형태다.

    `app_state.json`은 이관 전 데이터를 위한 폴백으로만 남긴다.
    """
    if RESULT_DB.exists():
        from backend.services import result_store

        result = result_store.load_latest(path=RESULT_DB)
        if result:
            # 저장소는 부서/팀 결함 목록을 «행 번호»로만 돌려준다(응답 크기 때문).
            # 여기서는 **판정 엔진이 만든 것과 같은 모양**으로 펴서 준다 — 불변식
            # 검사는 «화면에 실려 가는 형태»가 아니라 «판정 결과 전체»를 봐야 한다.
            return result_store.expand_result(result)

    if not APP_STATE_FILE.exists():
        pytest.skip("data/qc.db 와 app_state.json 둘 다 없음 (검증을 먼저 실행)")
    state = _load_json(APP_STATE_FILE)
    result = (state or {}).get("result")
    if not result:
        pytest.skip("저장된 검증 결과가 없음")
    return result


@pytest.fixture(scope="session")
def real_feedback() -> dict:
    """저장된 검토 기록(flag_feedback.json). 없으면 빈 dict (검토 전이면 정상)."""
    return _load_json(FEEDBACK_FILE) or {}


@pytest.fixture(params=["synthetic", "real"])
def result(request: pytest.FixtureRequest) -> dict:
    """
    불변식 검사를 합성/실데이터 **양쪽**에 같은 코드로 돌리기 위한 파라미터화 픽스처.

    실데이터가 없으면 그쪽만 skip 되고 합성 쪽은 계속 돈다.
    """
    if request.param == "real":
        request.applymarker(pytest.mark.realdata)
        return request.getfixturevalue("real_result")
    request.applymarker(pytest.mark.synthetic)
    return request.getfixturevalue("synthetic_result")
