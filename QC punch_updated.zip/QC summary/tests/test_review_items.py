"""
`backend/services/review_items.py` — 분석 문서 §11 파서/기록기 테스트.

이 모듈은 **사람이 손으로 고치는 마크다운 파일을 서버가 되쓴다**. 그래서 가장 큰 위험은
XSS가 아니라 **문서 훼손**이다: 답변을 기록하면서 다른 항목이나 §11 밖의 내용이
사라지거나, 답변 블록이 중복으로 쌓이거나, 헤딩이 바뀌면 안 된다.

실제 문서를 건드리지 않으려고 합성 문서를 tmp_path에 만들어 검사한다.
실데이터 문서에 대해서는 읽기 전용 검사만 한다.
"""
from __future__ import annotations

import pytest

from backend import config
from backend.services import review_items as ri


DOC = """# 제목

## 10. 앞 섹션

이 내용은 보존되어야 한다.

## 11. 확인 필요 사항 (전문가 협의 대기 — 이력 관리)

> 안내문. 여기 있는 양식 예시는 항목으로 잡히면 안 된다.

```markdown
#### [x] 현업 답변(YYYY-MM-DD, 답변자: 홍길동)

결론: (무엇으로 확정되었는지)
```

### 11-1. [~] 잠정결론(2026-08-02, 표준 조사 기반 — 현업 확인 대기) — 첫 번째 항목 제목

첫 항목 본문이다.

- 실데이터 영향: 100건

### 11-2. [ ] 미결 — 두 번째 항목(괄호 — 안에 대시 포함) 제목

둘째 항목 본문.

### 11-3. [x] 완료(2026-08-01, 결론: 이러이러함) — 세 번째 항목

셋째 항목 본문.

## 12. 뒤 섹션

이 내용도 보존되어야 한다.
"""


@pytest.fixture
def doc(tmp_path, monkeypatch):
    p = tmp_path / "분석.md"
    p.write_text(DOC, encoding="utf-8")
    monkeypatch.setattr(config, "ANALYSIS_DOC", p)
    return p


# ── 파싱 ──────────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_parses_all_items(doc):
    items = ri.load_items()
    assert [i["id"] for i in items] == ["11-1", "11-2", "11-3"]


@pytest.mark.synthetic
def test_code_fence_template_is_not_an_item(doc):
    """안내문의 답변 양식 예시가 항목이나 답변으로 잡히면 안 된다."""
    items = ri.load_items()
    assert len(items) == 3
    assert all(i["answer"] is None for i in items)


@pytest.mark.synthetic
def test_status_and_title_split(doc):
    """상태 괄호 안에도 em-dash가 들어간다 — 제목 구분자와 헷갈리면 안 된다."""
    items = {i["id"]: i for i in ri.load_items()}

    a = items["11-1"]
    assert a["mark"] == "~"
    assert a["status_label"] == "잠정결론"
    assert a["status_text"] == "잠정결론(2026-08-02, 표준 조사 기반 — 현업 확인 대기)"
    assert a["title"] == "첫 번째 항목 제목"

    b = items["11-2"]
    assert b["mark"] == " "
    assert b["status_label"] == "미결"
    assert b["title"] == "두 번째 항목(괄호 — 안에 대시 포함) 제목"

    c = items["11-3"]
    assert c["mark"] == "x"
    assert c["status_text"] == "완료(2026-08-01, 결론: 이러이러함)"
    assert c["title"] == "세 번째 항목"


@pytest.mark.synthetic
def test_body_is_scoped_to_its_item(doc):
    items = {i["id"]: i for i in ri.load_items()}
    assert "첫 항목 본문" in items["11-1"]["body"]
    assert "둘째 항목 본문" not in items["11-1"]["body"]
    # 다음 h2 섹션이 마지막 항목 본문에 딸려 들어가면 안 된다
    assert "## 12." not in items["11-3"]["body"]
    assert "뒤 섹션" not in items["11-3"]["body"]


@pytest.mark.synthetic
def test_missing_document(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "ANALYSIS_DOC", tmp_path / "없는파일.md")
    assert ri.load_items() == []
    assert ri.doc_info()["exists"] is False


@pytest.mark.synthetic
def test_document_without_section_11(tmp_path, monkeypatch):
    p = tmp_path / "x.md"
    p.write_text("# 제목\n\n## 1. 개요\n\n내용\n", encoding="utf-8")
    monkeypatch.setattr(config, "ANALYSIS_DOC", p)
    assert ri.load_items() == []


# ── 기록 ──────────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_save_answer_writes_block(doc):
    item = ri.save_answer("11-2", "이렇게 확정", "부연 설명", "김현업")
    assert item["answer"]["author"] == "김현업"
    assert "결론: 이렇게 확정" in item["answer"]["text"]
    assert "비고: 부연 설명" in item["answer"]["text"]

    raw = doc.read_text(encoding="utf-8")
    assert "답변자: 김현업" in raw


@pytest.mark.synthetic
def test_save_answer_preserves_everything_else(doc):
    """문서 훼손이 이 기능의 가장 큰 위험이다."""
    before = doc.read_text(encoding="utf-8")
    ri.save_answer("11-2", "결론", "", "홍길동")
    after = doc.read_text(encoding="utf-8")

    # §11 밖 섹션 보존
    assert "## 10. 앞 섹션" in after
    assert "이 내용은 보존되어야 한다." in after
    assert "## 12. 뒤 섹션" in after
    assert "이 내용도 보존되어야 한다." in after

    # 다른 항목의 헤딩과 본문 보존
    for frag in ("### 11-1.", "### 11-3.", "첫 항목 본문이다.", "셋째 항목 본문."):
        assert frag in after, frag

    # 대상 항목의 헤딩은 서버가 바꾸지 않는다
    assert "### 11-2. [ ] 미결 — 두 번째 항목" in after
    assert len(after) > len(before)


@pytest.mark.synthetic
def test_server_does_not_change_heading_status(doc):
    """답변이 왔다고 자동으로 [x] 완료가 되면 안 된다.

    헤딩 동기화와 판정 코드 반영은 답변을 읽은 담당자가 함께 판단할 일이다.
    서버가 먼저 완료로 바꾸면 '코드는 그대로인데 종결된 것처럼' 보인다.
    """
    item = ri.save_answer("11-2", "결론", "", "홍길동")
    assert item["mark"] == " ", "헤딩 상태가 바뀌었다"
    assert item["needs_followup"] is True, "반영 대기로 표시되어야 한다"


@pytest.mark.synthetic
def test_resave_replaces_instead_of_appending(doc):
    """같은 항목에 다시 쓰면 블록이 쌓이지 않고 갈아끼워져야 한다."""
    ri.save_answer("11-2", "첫 결론", "", "A")
    ri.save_answer("11-2", "둘째 결론", "", "B")

    items = {i["id"]: i for i in ri.load_items()}
    ans = items["11-2"]["answer"]
    assert ans["author"] == "B"
    assert "둘째 결론" in ans["text"]
    assert "첫 결론" not in ans["text"]

    # 본문에 이전 답변의 잔여물이 남으면 안 된다
    assert "현업 답변" not in items["11-2"]["body"]
    assert items["11-2"]["body"].count("결론:") == 0


@pytest.mark.synthetic
def test_answer_does_not_leak_to_other_items(doc):
    ri.save_answer("11-2", "결론", "", "A")
    items = {i["id"]: i for i in ri.load_items()}
    assert items["11-1"]["answer"] is None
    assert items["11-3"]["answer"] is None


@pytest.mark.synthetic
def test_save_to_last_item(doc):
    """마지막 항목은 뒤에 다음 헤딩이 없어 경계 처리가 다르다."""
    ri.save_answer("11-3", "마지막 항목 결론", "", "C")
    after = doc.read_text(encoding="utf-8")
    assert "## 12. 뒤 섹션" in after
    assert "이 내용도 보존되어야 한다." in after
    items = {i["id"]: i for i in ri.load_items()}
    assert items["11-3"]["answer"]["author"] == "C"


@pytest.mark.synthetic
@pytest.mark.parametrize(
    "conclusion, author, msg",
    [
        ("", "홍길동", "결론"),
        ("   ", "홍길동", "결론"),
        ("결론 있음", "", "답변자"),
        ("결론 있음", "  ", "답변자"),
    ],
)
def test_save_answer_requires_fields(doc, conclusion, author, msg):
    with pytest.raises(ValueError) as e:
        ri.save_answer("11-2", conclusion, "", author)
    assert msg in str(e.value)


@pytest.mark.synthetic
def test_save_answer_unknown_item(doc):
    with pytest.raises(ValueError):
        ri.save_answer("11-99", "결론", "", "홍길동")


@pytest.mark.synthetic
def test_save_answer_leaves_no_temp_file(doc):
    ri.save_answer("11-2", "결론", "", "홍길동")
    leftovers = list(doc.parent.glob("*.tmp"))
    assert leftovers == [], f"임시 파일이 남았다: {leftovers}"


@pytest.mark.synthetic
def test_roundtrip_special_characters(doc):
    """마크다운 특수문자가 들어가도 파싱이 깨지지 않아야 한다."""
    tricky = "결론에 `백틱`과 **굵게**, 그리고 — 대시와 (괄호)가 있다"
    ri.save_answer("11-2", tricky, "", "홍길동")
    items = {i["id"]: i for i in ri.load_items()}
    assert tricky in items["11-2"]["answer"]["text"]
    assert len(ri.load_items()) == 3, "항목 수가 바뀌면 안 된다"


# ── 실제 문서 (읽기 전용) ─────────────────────────────────────────────────────
@pytest.mark.realdata
def test_repo_document_parses():
    """저장소의 실제 분석 문서가 파싱되는지 — 읽기만 한다."""
    if not config.ANALYSIS_DOC.is_file():
        pytest.skip("분석 문서가 없는 환경")
    items = ri.load_items()
    assert items, "§11에서 항목을 하나도 못 찾았다"
    for it in items:
        assert it["id"].startswith("11-"), it["id"]
        assert it["mark"] in (" ", "~", "x"), (it["id"], it["mark"])
        assert it["title"], f"{it['id']} 제목이 비어 있다"
        # 상태 괄호 안의 em-dash가 제목으로 새어나오지 않았는지
        assert not it["title"].startswith(")"), it["title"]
        assert "현업 확인 대기)" not in it["title"], it["title"]


# ---- 문서에 있는 것이 화면에도 전부 나오는가 ------------------------------
#
# 이 파서가 실패하는 방식은 예외가 아니라 «조용한 누락»이다. 정규식이 한 줄을
# 못 맞추면 그 항목이 목록에서 통째로 사라지고, 로그에도 아무것도 남지 않는다.
# 실제로 두 번 그랬다:
#
#   1) 헤딩 상태에 괄호를 «중첩»했더니(결론: 기준일(…) 유지) 11-10이 사라졌다
#   2) 답변 헤딩 뒤에 요약을 붙였더니(현업 답변(날짜) — 요약) 답변 5건이
#      전부 «없음»으로 읽혀 «반영 대기» 표시도 뜨지 않았다
#
# 그래서 «문서에 있는 개수»와 «파서가 낸 개수»를 직접 맞춰 본다.
def _doc_text() -> str:
    from backend import config
    return (config.BASE / "QC_검사로직_상세분석.md").read_text(encoding="utf-8")


@pytest.mark.synthetic
def test_every_heading_in_the_document_is_parsed():
    import re as _re
    from backend.services import review_items as R

    heads = _re.findall(r"^### (11-\d+)\.", _doc_text(), _re.M)
    got = [i["id"] for i in R.load_items()]
    missing = [h for h in heads if h not in got]
    assert not missing, f"문서에 있는데 파서가 못 읽은 항목: {missing}"
    assert len(got) == len(heads)


@pytest.mark.synthetic
def test_every_answer_block_in_the_document_is_parsed():
    import re as _re
    from backend.services import review_items as R

    doc = _doc_text()
    # 형식 안내용 예시(YYYY-MM-DD)는 뺀다
    n_doc = len([m for m in _re.findall(r"^#### \[x\] 현업 답변\(([^)]*)\)", doc, _re.M)
                 if "YYYY" not in m])
    n_parsed = sum(1 for i in R.load_items() if i.get("answer"))
    assert n_parsed == n_doc, f"문서 답변 {n_doc}건 중 {n_parsed}건만 읽혔다"


@pytest.mark.synthetic
def test_heading_status_may_contain_nested_parentheses():
    from backend.services import review_items as R

    line = ("### 11-99. [x] 완료(2026-08-10, 결론: 기준일(데이터 내 최종 용접일) 유지)"
            " — 시험용 제목")
    m = R._ITEM_RE.search(line)
    assert m, "괄호가 한 겹 중첩되면 줄 전체를 못 맞춘다 - 항목이 조용히 사라진다"
    assert m.group("title") == "시험용 제목"


@pytest.mark.synthetic
def test_answer_heading_may_carry_a_summary():
    from backend.services import review_items as R

    line = "#### [x] 현업 답변(2026-08-10) — 두께범위는 `3~24`가 맞다"
    m = R._ANSWER_RE.search(line)
    assert m, "답변 헤딩에 요약을 붙이면 답변이 통째로 안 보인다"
    assert m.group("meta") == "2026-08-10"


# ── 두 서버가 같은 문서에 쓴다 ──────────────────────────────────────────────
#
# `threading.Lock`은 **한 프로세스 안에서만** 유효하다. 프로젝트별 서버를 둘 이상
# 띄우면(8001·8002) 둘 다 같은 `QC_검사로직_상세분석.md`에 읽고-고쳐-쓴다.
# 그 사이가 겹치면 답변 한 건이 조용히 사라진다:
#
#     8001 읽음 -> 8002 읽음 -> 8001 씀 -> 8002 씀   (8001의 답변이 없어짐)
#
# 파일이 깨지지는 않는다(`os.replace`가 원자적). **덮어써질 뿐이라 아무 데서도
# 오류가 나지 않는다** — 답변한 사람이 다시 열어 보기 전에는 모른다.
@pytest.fixture
def doc_copy(tmp_path, monkeypatch):
    import shutil

    from backend import config as C

    dst = tmp_path / "doc.md"
    shutil.copy(str(C.BASE / "QC_검사로직_상세분석.md"), str(dst))
    monkeypatch.setattr(C, "ANALYSIS_DOC", dst)
    return dst


@pytest.mark.synthetic
def test_the_file_lock_blocks_a_second_holder(doc_copy):
    """잠금을 쥔 채로 또 쥐려 하면 **기다리다 실패**해야 한다.
    조용히 통과하면 두 서버가 나란히 읽고-고쳐-쓴다."""
    from backend.services import review_items as RI

    with RI._file_lock():
        with pytest.raises(ValueError, match="다른 서버"):
            with RI._file_lock(timeout=0.2):
                pass


@pytest.mark.synthetic
def test_the_lock_is_released_even_when_the_body_raises(doc_copy):
    """잠금이 남으면 **아무도 답변을 못 남기는 상태**가 된다 — 잠금보다 나쁘다."""
    from backend.services import review_items as RI

    with pytest.raises(RuntimeError):
        with RI._file_lock():
            raise RuntimeError("본문에서 터졌다")
    with RI._file_lock(timeout=0.2):        # 다시 쥘 수 있어야 한다
        pass


@pytest.mark.synthetic
def test_a_stale_lock_is_stolen(doc_copy, monkeypatch):
    """프로세스가 죽으면 잠금 파일이 남는다. 영원히 막히면 안 된다."""
    from backend.services import review_items as RI

    lock = doc_copy.with_suffix(doc_copy.suffix + ".lock")
    lock.write_text("9999", encoding="utf-8")
    monkeypatch.setattr(RI, "_LOCK_STALE_SEC", -1.0)   # 무조건 오래된 것으로
    with RI._file_lock(timeout=1.0):
        pass
    assert not lock.exists()


@pytest.mark.synthetic
def test_an_outside_edit_is_not_overwritten(doc_copy, monkeypatch):
    """**사람이 편집기로 고치는 중**이면 잠금이 못 막는다.

    읽은 뒤 파일이 바뀌었으면 쓰지 않고 오류를 낸다 — 덮어써서 그 편집을
    조용히 없애는 것보다 낫다. 다시 누르면 새 내용 위에 얹힌다.
    """
    from backend.services import review_items as RI

    real_read = RI._read

    def read_then_someone_else_writes():
        text = real_read()
        marker = chr(10) + "<!-- 누군가 손으로 고쳤다 -->" + chr(10)
        doc_copy.write_text(text + marker, encoding="utf-8")
        return text

    monkeypatch.setattr(RI, "_read", read_then_someone_else_writes)
    with pytest.raises(ValueError, match="바뀌었습니다"):
        RI.save_answer("11-1", "결론", "비고", "A551135")

    # 바깥에서 넣은 내용이 그대로 살아 있어야 한다
    assert "누군가 손으로 고쳤다" in doc_copy.read_text(encoding="utf-8")


@pytest.mark.synthetic
def test_two_answers_in_a_row_both_survive(doc_copy):
    """정상 경로 — 잠금을 쥐고 놓기를 반복해도 둘 다 남는다."""
    from backend.services import review_items as RI

    RI.save_answer("11-1", "결론 A", "비고 A", "A551135")
    RI.save_answer("11-2", "결론 B", "비고 B", "A551135")
    t = doc_copy.read_text(encoding="utf-8")
    assert "비고 A" in t and "비고 B" in t


@pytest.mark.synthetic
def test_save_answer_takes_the_cross_process_lock(doc_copy, monkeypatch):
    """**`save_answer`가 그 잠금을 실제로 쥐는가.**

    잠금 함수만 테스트하고 여기를 빼면, `save_answer`에서 `_file_lock()`을
    떼어내도 테스트가 통과한다 — 실제로 그렇게 만들었다가 음성 대조에서 걸렸다.
    """
    from backend.services import review_items as RI

    monkeypatch.setattr(RI, "_LOCK_TIMEOUT", 0.2)
    with RI._file_lock():
        with pytest.raises(ValueError, match="다른 서버"):
            RI.save_answer("11-1", "결론", "비고", "A551135")
