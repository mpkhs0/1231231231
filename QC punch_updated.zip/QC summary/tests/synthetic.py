"""
합성(synthetic) 검증 결과 생성기.

실데이터(`data/app_state.json`)는 사내 데이터라 저장소에 커밋할 수 없다. 그래서
같은 **모양**의 결과 페이로드를 손으로 정의한 작은 행 테이블에서 만들어 낸다.
이 합성 결과의 역할은 두 가지다.

1. 실데이터가 없는 PC 에서도 `tests/qc_invariants.py` 의 검사기가 돌아가는지 확인한다.
2. 검사기를 **일부러 깨뜨려** (아래 `break_*` 함수들) 실제로 위반을 잡아내는지 증명한다.
   통과만 하는 테스트는 검사기가 항상 빈 리스트를 돌려줘도 초록불이 된다.

집계 규칙은 verifier.py 를 임포트해서 얻지 않고 qc-data-verifier 문서 §2 의
정의를 그대로 다시 구현했다. 구현을 가져다 쓰면 같은 버그를 재현할 뿐이다.
"""
from __future__ import annotations

import copy
from collections import defaultdict

CHECK_NAMES = {
    0: "unworked", 1: "schedule", 2: "wps-process", 3: "thickness", 4: "groove",
    5: "special-p-g01", 6: "welder-unqualified", 7: "duplicate-2-5", 8: "tr-fc-g03",
    9: "tr-smfc-g01", 10: "combined-3-8", 11: "material-wps", 12: "pipe-dia",
    13: "anomaly", 14: "joint-duplicate",
}

# 용접사 번호가 들어가는 엑셀 열 (AP/AR/AT/AV). qc_invariants.WELDER_COL_LETTERS 와 짝.
_WELDER_COLS = ("AP", "AR", "AT", "AV")

# ---------------------------------------------------------------------------
# 합성 행 테이블
#   state:   deleted / unworked / judged
#   checks:  그 행에 걸린 플래그의 check_no 목록 (같은 Check 가 두 번 걸릴 수도 있다)
#   c6:      Check 6 이 귀속되는 용접사 번호 (C6 는 개인 귀속이라 행 전체가 아니다)
#   late:    2차 패스(Check 13/14)에서 뒤늦게 붙은 check_no 목록. 집계상 구분은
#            없지만 "1차에는 C6 만 있던 행"이라는 시나리오를 문서화하기 위해 남긴다.
# ---------------------------------------------------------------------------
ROWS: list[dict] = [
    # -- 삭제 행 (판정 대상 아님) --
    {"row": 10, "state": "deleted"},

    # -- 미작업 행 (Check 0, 결함 아님, 결함률 분모 아님) --
    {"row": 20, "state": "unworked", "dept": "용접부", "team": "1팀",
     "drawing": "D-001", "joint": "J-1", "block": "B1"},
    {"row": 21, "state": "unworked", "dept": "용접부", "team": "2팀",
     "drawing": "D-001", "joint": "J-2", "block": "B1"},
    {"row": 22, "state": "unworked", "dept": "의장부", "team": "3팀",
     "drawing": "D-002", "joint": "J-1", "block": "B2"},

    # -- 판정 대상: 결함 없음 --
    {"row": 30, "state": "judged", "dept": "용접부", "team": "1팀",
     "drawing": "D-001", "joint": "J-10", "wps": "TR-A", "date": "2026-07-01",
     "welders": ["W1"], "checks": []},
    {"row": 31, "state": "judged", "dept": "용접부", "team": "1팀",
     "drawing": "D-001", "joint": "J-11", "wps": "TR-A", "date": "2026-07-01",
     "welders": ["W1", "W2"], "checks": []},
    {"row": 32, "state": "judged", "dept": "의장부", "team": "3팀",
     "drawing": "D-002", "joint": "J-10", "wps": "TR-B", "date": "2026-07-02",
     "welders": ["W3"], "checks": []},

    # -- 판정 대상: 단일 결함 --
    {"row": 40, "state": "judged", "dept": "용접부", "team": "1팀",
     "drawing": "D-001", "joint": "J-20", "wps": "TR-A", "date": "2026-07-01",
     "welders": ["W1"], "checks": [3]},

    # -- 한 행에 여러 Check (플래그 수 > 행 수 를 만드는 케이스) --
    {"row": 41, "state": "judged", "dept": "용접부", "team": "2팀",
     "drawing": "D-001", "joint": "J-21", "wps": "TR-A", "date": "2026-07-02",
     "welders": ["W2", "W4"], "checks": [3, 4, 11]},

    # -- C6 만 있는 행: 작업성 결함이 아니므로 용접사 결함행에 들어가면 안 된다 --
    {"row": 42, "state": "judged", "dept": "용접부", "team": "2팀",
     "drawing": "D-001", "joint": "J-22", "wps": "TR-A", "date": "2026-07-02",
     "welders": ["W2", "W5"], "checks": [6], "c6": "W5"},

    # -- 1차에는 C6 만, 2차 패스에서 C13 을 얻은 행 (실제 버그 257행의 축소판) --
    {"row": 43, "state": "judged", "dept": "용접부", "team": "2팀",
     "drawing": "D-001", "joint": "J-23", "wps": "TR-A", "date": "2026-07-03",
     "welders": ["W2", "W5"], "checks": [6, 13], "c6": "W5", "late": [13]},

    # -- 2차 패스에서 처음으로 결함이 된 행 (1차에는 아무 플래그도 없었다) --
    {"row": 44, "state": "judged", "dept": "의장부", "team": "3팀",
     "drawing": "D-002", "joint": "J-20", "wps": "TR-B", "date": "2026-07-02",
     "welders": ["W3"], "checks": [14], "late": [14]},

    # -- 다른 도면의 같은 Joint No + 같은 WPS + 같은 Check --
    #    (검토 키에 도면번호가 빠지면 이 두 행이 한 키를 공유해 버린다) --
    {"row": 45, "state": "judged", "dept": "의장부", "team": "4팀",
     "drawing": "D-003", "joint": "J-20", "wps": "TR-B", "date": "2026-07-03",
     "welders": ["W3", "W6"], "checks": [14], "late": [14]},

    # -- 용접일이 다른 날짜에도 참여하는 용접사 (date_stats 합계 검사용) --
    {"row": 46, "state": "judged", "dept": "의장부", "team": "4팀",
     "drawing": "D-003", "joint": "J-30", "wps": "TR-B", "date": "2026-07-04",
     "welders": ["W6"], "checks": [1, 1]},
]


def _snapshot(row: dict) -> list[dict]:
    """row_raw 스냅샷 (엑셀 원문). 용접사 열은 AP/AR/AT/AV 에 채운다."""
    welders = list(row.get("welders") or [])
    cells = [
        {"label": "drawing_no", "col": "A", "value": row.get("drawing", "")},
        {"label": "block", "col": "B", "value": row.get("block", "")},
        {"label": "joint_no", "col": "D", "value": row.get("joint", "")},
        {"label": "wps_no", "col": "AJ", "value": row.get("wps", "")},
        {"label": "weld_date", "col": "AM", "value": row.get("date", "")},
    ]
    for i, col in enumerate(_WELDER_COLS):
        cells.append(
            {"label": f"welder{i + 1}", "col": col,
             "value": welders[i] if i < len(welders) else ""}
        )
    cells.append({"label": "department", "col": "BF", "value": row.get("dept", "")})
    cells.append({"label": "team", "col": "BG", "value": row.get("team", "")})
    return cells


def _team_bucket() -> dict:
    return {
        "total_rows": 0, "unworked_rows": 0, "defect_rows": 0,
        "check_stats": defaultdict(int),
        "welder_totals": defaultdict(int), "welder_defects": defaultdict(int),
        "defects": [], "defect_by_date": defaultdict(int),
    }


def build_result(rows: list[dict] | None = None) -> dict:
    """행 테이블에서 `/api/result` 와 같은 모양의 결과 dict 를 만든다."""
    rows = ROWS if rows is None else rows

    deleted = unworked = judged = 0
    stats: dict[int, int] = defaultdict(int)
    flags: list[dict] = []
    row_raw: dict[str, list[dict]] = {}
    unworked_list: list[dict] = []
    flagged_rows = 0

    welder_totals: dict[str, int] = defaultdict(int)
    welder_defects: dict[str, int] = defaultdict(int)
    welder_missing: dict[str, int] = defaultdict(int)
    welder_checks: dict[str, dict[int, int]] = defaultdict(lambda: defaultdict(int))
    welder_date_totals: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    welder_date_checks: dict[str, dict[str, dict[int, int]]] = defaultdict(
        lambda: defaultdict(lambda: defaultdict(int))
    )
    defect_by_date: dict[str, int] = defaultdict(int)
    depts: dict[str, dict] = {}

    def _dept(name: str) -> dict:
        if name not in depts:
            d = _team_bucket()
            d["teams"] = {}
            depts[name] = d
        return depts[name]

    def _team(dept_name: str, team_name: str) -> dict:
        d = _dept(dept_name)
        if team_name not in d["teams"]:
            d["teams"][team_name] = _team_bucket()
        return d["teams"][team_name]

    for r in rows:
        state = r["state"]
        if state == "deleted":
            deleted += 1
            continue

        dept_name, team_name = r.get("dept", ""), r.get("team", "")
        d, t = _dept(dept_name), _team(dept_name, team_name)

        if state == "unworked":
            unworked += 1
            d["unworked_rows"] += 1
            t["unworked_rows"] += 1
            row_raw[str(r["row"])] = _snapshot(r)
            unworked_list.append({
                "row": r["row"], "drawing_no": r.get("drawing", ""),
                "joint_no": r.get("joint", ""), "block": r.get("block", ""),
                "department": dept_name, "team": team_name,
            })
            continue

        judged += 1
        d["total_rows"] += 1
        t["total_rows"] += 1

        checks = list(r.get("checks") or [])
        date = r.get("date", "")
        welders = set(r.get("welders") or [])
        has_workmanship = any(c != 6 for c in checks)

        for w in welders:
            welder_totals[w] += 1
            d["welder_totals"][w] += 1
            t["welder_totals"][w] += 1
            if has_workmanship:
                welder_defects[w] += 1
                d["welder_defects"][w] += 1
                t["welder_defects"][w] += 1
            if date:
                welder_date_totals[w][date] += 1

        if date:
            for c in checks:
                if c == 6:
                    continue
                for w in welders:
                    welder_date_checks[w][date][c] += 1

        if not checks:
            continue

        flagged_rows += 1
        row_raw[str(r["row"])] = _snapshot(r)
        d["defect_rows"] += 1
        t["defect_rows"] += 1
        if date:
            defect_by_date[date] += 1
            d["defect_by_date"][date] += 1
            t["defect_by_date"][date] += 1

        check_entries = []
        for c in checks:
            stats[c] += 1
            d["check_stats"][c] += 1
            t["check_stats"][c] += 1
            if c == 6:
                if r.get("c6"):
                    welder_missing[r["c6"]] += 1
            else:
                for w in welders:
                    welder_checks[w][c] += 1
            flags.append({
                # 판정 결과와 같은 모양이어야 한다 — 저장소를 왕복하면 문자열로
                # 돌아오므로, 정수로 두면 «저장 전/후가 다르다»가 된다.
                "row": r["row"], "check_no": str(c),
                "check_name": CHECK_NAMES.get(c, ""),
                "col": 1, "col_letter": "A", "color": "Red",
                "msg": f"synthetic flag check {c}", "expected": "", "actual": "",
                "drawing_no": r.get("drawing", ""), "joint_no": r.get("joint", ""),
                "block": r.get("block", ""), "wps_no": r.get("wps", ""),
                "weld_date": date, "ndt_date": "",
                "welder1_no": (r.get("welders") or [""])[0],
                "department": dept_name, "team": team_name,
                "material1": "", "material2": "", "thickness1": "", "thickness2": "",
                "wps_process": "",
            })
            check_entries.append({
                "check_no": str(c), "check_name": CHECK_NAMES.get(c, ""),
                "color": "Red", "msg": f"synthetic flag check {c}",
                "expected": "", "actual": "",
            })

        defect_entry = {
            "row": r["row"], "joint_no": r.get("joint", ""), "block": r.get("block", ""),
            "wps_no": r.get("wps", ""), "weld_date": date,
            "welder1_no": (r.get("welders") or [""])[0], "checks": check_entries,
        }
        d["defects"].append(defect_entry)
        t["defects"].append(defect_entry)

    def _breakdown(w: str) -> dict[str, int]:
        out = {str(n): 0 for n in CHECK_NAMES}
        for c, n in welder_checks.get(w, {}).items():
            out[str(c)] = n
        out["6"] = welder_missing.get(w, 0)
        return out

    welder_info: dict[str, dict] = {}
    for w in sorted(set(welder_totals) | set(welder_missing)):
        total, defect = welder_totals.get(w, 0), welder_defects.get(w, 0)
        welder_info[w] = {
            "name": f"WELDER {w}", "registered": True, "retired": False,
            "processes": [], "positions": [], "specs": [], "classes": [],
            "cert_count": 0, "first_cert_date": "", "last_cert_date": "",
            "total": total, "defect": defect,
            "rate": round(defect / total * 100, 1) if total else 0.0,
            "missing_flags": welder_missing.get(w, 0),
            "check_breakdown": _breakdown(w),
            "date_stats": [
                {"date": dt, "total": n,
                 "checks": {str(k): v for k, v in
                            sorted(welder_date_checks.get(w, {}).get(dt, {}).items())}}
                for dt, n in sorted(welder_date_totals.get(w, {}).items())
            ],
        }

    def _rate_list(bucket: dict) -> list[dict]:
        out = []
        for w, total in bucket["welder_totals"].items():
            defect = bucket["welder_defects"].get(w, 0)
            if defect == 0:
                continue
            out.append({"welder_no": w, "total": total, "defect": defect,
                        "rate": round(defect / total * 100, 1) if total else 0.0})
        out.sort(key=lambda x: (-x["rate"], -x["defect"]))
        return out

    departments: dict[str, dict] = {}
    for name, d in depts.items():
        departments[name] = {
            "total_rows": d["total_rows"], "unworked_rows": d["unworked_rows"],
            "defect_rows": d["defect_rows"],
            "check_stats": {str(k): v for k, v in d["check_stats"].items()},
            "welder_defect_rate": _rate_list(d), "defects": d["defects"],
            "defect_trend_by_date": [{"date": k, "count": v}
                                     for k, v in sorted(d["defect_by_date"].items())],
            "recurring_patterns": [],
            "teams": {
                tname: {
                    "total_rows": t["total_rows"], "unworked_rows": t["unworked_rows"],
                    "defect_rows": t["defect_rows"],
                    "check_stats": {str(k): v for k, v in t["check_stats"].items()},
                    "welder_defect_rate": _rate_list(t), "defects": t["defects"],
                    "defect_trend_by_date": [{"date": k, "count": v}
                                             for k, v in sorted(t["defect_by_date"].items())],
                }
                for tname, t in d["teams"].items()
            },
        }

    active = len(rows) - deleted
    return {
        "run_at": "2026-01-01 00:00",
        "qmg_filename": "synthetic.xlsx", "welder_filename": "synthetic_welders.xlsx",
        "total_rows": len(rows), "deleted_rows": deleted, "active_rows": active,
        "unworked_rows": unworked, "judged_rows": active - unworked,
        "flagged_rows": flagged_rows, "clean_rows": (active - unworked) - flagged_rows,
        "total_flags": len(flags),
        "stats": {str(k): v for k, v in sorted(stats.items())},
        "flags": flags, "row_raw": row_raw, "unworked_list": unworked_list,
        "welder_missing": {
            w: {"flag_count": n, "total": welder_totals.get(w, 0),
                "workmanship_defect": welder_defects.get(w, 0),
                "workmanship_rate": (round(welder_defects.get(w, 0) / welder_totals[w] * 100, 1)
                                     if welder_totals.get(w) else 0.0),
                "check_breakdown": _breakdown(w)}
            for w, n in welder_missing.items()
        },
        "welder_defect_rate": [
            {"welder_no": w, "total": v["total"], "defect": v["defect"],
             "rate": v["rate"], "check_breakdown": v["check_breakdown"]}
            for w, v in welder_info.items() if v["defect"] > 0
        ],
        "welder_info": welder_info,
        "defect_trend_by_date": [{"date": k, "count": v}
                                 for k, v in sorted(defect_by_date.items())],
        "departments": departments,
    }


# ---------------------------------------------------------------------------
# 회귀 재현용 mutator - 검사기가 실제로 위반을 잡는지 증명하기 위한 것들.
# 전부 깊은 복사본을 돌려주므로 원본 픽스처는 오염되지 않는다.
# ---------------------------------------------------------------------------
def break_row_accounting(result: dict) -> dict:
    """clean_rows 를 부풀려 judged = flagged + clean 회계를 깬다."""
    out = copy.deepcopy(result)
    out["clean_rows"] += 1
    return out


def break_flag_row_unit_confusion(result: dict) -> dict:
    """flagged_rows(행 단위) 자리에 total_flags(플래그 단위)를 넣는다."""
    out = copy.deepcopy(result)
    out["flagged_rows"] = out["total_flags"]
    return out


def break_denominator(result: dict) -> dict:
    """결함률 분모로 judged_rows 가 아니라 active_rows 를 쓴 상태를 흉내낸다."""
    out = copy.deepcopy(result)
    out["judged_rows"] = out["active_rows"]
    return out


def break_department_rollup(result: dict) -> dict:
    """부서 한 곳의 defect_rows 를 1 줄인다 (전사 합계와 어긋남)."""
    out = copy.deepcopy(result)
    for d in out["departments"].values():
        if d["defect_rows"]:
            d["defect_rows"] -= 1
            break
    return out


def break_team_rollup(result: dict) -> dict:
    """부서 합계는 그대로 두고 팀 하나의 check_stats 만 줄인다."""
    out = copy.deepcopy(result)
    for d in out["departments"].values():
        for t in d["teams"].values():
            for k, v in t["check_stats"].items():
                if v:
                    t["check_stats"][k] = v - 1
                    return out
    return out


def break_second_pass_welder_backfill(result: dict) -> dict:
    """
    실제로 있었던 버그의 재현: 1차에서 C6 만 있던 행이 2차 패스에서 C13/C14 를
    얻었는데 `is_new_defect_row` 가 False 라 welder_defects 에 반영되지 않은 상태.
    """
    out = copy.deepcopy(result)
    by_row: dict[int, set[str]] = defaultdict(set)
    for f in out["flags"]:
        by_row[f["row"]].add(str(f["check_no"]))
    targets = [row for row, checks in by_row.items()
               if "6" in checks and checks & {"13", "14"}
               and not (checks - {"6", "13", "14"})]
    for row in targets:
        for cell in out["row_raw"].get(str(row), []):
            w = str(cell.get("value", "")).strip()
            if cell.get("col") in _WELDER_COLS and w and w in out["welder_info"]:
                info = out["welder_info"][w]
                if info["defect"] > 0:
                    info["defect"] -= 1
                    info["rate"] = (round(info["defect"] / info["total"] * 100, 1)
                                    if info["total"] else 0.0)
    out["welder_defect_rate"] = [
        {"welder_no": w, "total": v["total"], "defect": v["defect"],
         "rate": v["rate"], "check_breakdown": v["check_breakdown"]}
        for w, v in out["welder_info"].items() if v["defect"] > 0
    ]
    return out


def break_second_pass_stats(result: dict) -> dict:
    """Check 13/14 플래그가 stats 에 소급 반영되지 않은 상태."""
    out = copy.deepcopy(result)
    for c in ("13", "14"):
        if out["stats"].get(c):
            out["total_flags"] -= out["stats"][c]
            out["stats"][c] = 0
    return out


def break_welder_rate(result: dict) -> dict:
    """rate 만 손으로 고쳐 defect/total 과 어긋나게 만든다."""
    out = copy.deepcopy(result)
    for v in out["welder_info"].values():
        if v["total"]:
            v["rate"] = round(v["rate"] + 1.0, 1)
            break
    return out


def break_unworked_counted_as_defect(result: dict) -> dict:
    """미작업 행을 결함(Check 0 플래그)으로 집계한 상태."""
    out = copy.deepcopy(result)
    u = out["unworked_list"][0]
    out["flags"].append({
        "row": u["row"], "check_no": 0, "check_name": "unworked",
        "col": 1, "col_letter": "A", "color": "Gray", "msg": "unworked",
        "expected": "", "actual": "", "drawing_no": u["drawing_no"],
        "joint_no": u["joint_no"], "block": u.get("block", ""), "wps_no": "",
        "weld_date": "", "welder1_no": "",
        "department": u["department"], "team": u["team"],
    })
    out["stats"]["0"] = out["stats"].get("0", 0) + 1
    out["total_flags"] += 1
    return out


def break_welder_date_stats(result: dict) -> dict:
    """date_stats 의 하루치 total 을 줄여 합계가 total 과 어긋나게 만든다."""
    out = copy.deepcopy(result)
    for v in out["welder_info"].values():
        if v["date_stats"]:
            v["date_stats"][0]["total"] += 1
            break
    return out
