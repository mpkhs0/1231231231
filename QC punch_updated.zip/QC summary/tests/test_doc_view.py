"""
정본 문서를 화면에서 읽게 하는 렌더러.

## 왜 직접 만들었나

이 문서에는 **현업이 화면에서 입력한 글이 들어온다** — `review_items`가 §11에
「현업 답변」 블록을 되쓰기 때문이다. 즉 신뢰할 수 없는 문자열이 섞이는 문서다.
범용 마크다운 라이브러리는 기본값이 HTML을 그대로 통과시키므로, **이스케이프를
먼저 하고 그 위에 태그를 얹는** 쪽을 택했다.

여기서 지키는 것은 하나다: **통과하는 HTML이 없어야 한다.** 문법 지원 범위가
좁아 문서가 덜 예쁘게 나오는 것은 감수한다 — 없는 태그가 실행되는 것보다 낫다.
"""
from __future__ import annotations

import pytest

from backend.services import doc_view as D


def html_of(md: str) -> str:
    return D.render(md)["html"]


# ── 이스케이프가 먼저다 ──────────────────────────────────────────────────────
@pytest.mark.synthetic
@pytest.mark.parametrize("md", [
    "<script>alert(1)</script>",
    "# <img src=x onerror=alert(1)>",
    "| <b>셀</b> | 값 |\n|---|---|\n| <script>x</script> | 2 |",
    "> <iframe src=evil></iframe>",
    "- <svg onload=alert(1)>",
    "```\n<script>x</script>\n```",
])
def test_no_raw_html_survives(md):
    """살아 있는 «태그»가 없어야 한다.

    이스케이프되어 «글자»로 남는 `onerror=`는 안전하다 — 속성이 아니라 본문이다.
    그래서 문자열 포함이 아니라 «여는 태그로 살아났는가»를 본다.
    """
    out = html_of(md).lower()
    for tag in ("script", "img", "iframe", "svg", "b onerror"):
        assert f"<{tag}" not in out, f"<{tag}가 통과했다: {md!r}"
    assert "&lt;" in out, "이스케이프 흔적이 없다 — 입력이 통째로 사라졌나?"


@pytest.mark.synthetic
def test_inline_formatting_still_works():
    out = html_of("**굵게**와 `코드`가 있는 문장")
    assert "<b>굵게</b>" in out and "<code>코드</code>" in out


@pytest.mark.synthetic
def test_bold_inside_escaped_text_does_not_revive_tags():
    """`**<b>x</b>**` 처럼 이스케이프된 태그가 굵게 처리로 되살아나면 안 된다."""
    out = html_of("**<b>위험</b>**")
    assert "<b>&lt;b&gt;위험&lt;/b&gt;</b>" in out


@pytest.mark.synthetic
@pytest.mark.parametrize("url,linked", [
    ("https://example.com", True),
    ("http://example.com", True),
    ("#section", True),
    ("javascript:alert(1)", False),
    ("data:text/html,<script>x</script>", False),
])
def test_only_safe_link_schemes_open(url, linked):
    out = html_of(f"[링크]({url})")
    assert ("<a href=" in out) == linked, url


# ── 문법 ────────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_headings_get_ids_and_outline():
    d = D.render("## 첫 절\n\n본문\n\n### 하위\n\n## 둘째 절")
    ids = [o["id"] for o in d["outline"]]
    assert len(ids) == 3 and len(set(ids)) == 3, "앵커가 겹치면 목차가 엉뚱한 곳으로 간다"
    assert [o["level"] for o in d["outline"]] == [2, 3, 2]
    for i in ids:
        assert f'id="{i}"' in d["html"]


@pytest.mark.synthetic
def test_duplicate_headings_get_distinct_ids():
    d = D.render("## 같은 제목\n\n## 같은 제목")
    a, b = [o["id"] for o in d["outline"]]
    assert a != b


@pytest.mark.synthetic
def test_table_renders_with_header():
    out = html_of("| 항목 | 값 |\n|---|---|\n| A | 1 |\n| B | 2 |")
    assert "<th>항목</th>" in out and out.count("<tr>") == 3


@pytest.mark.synthetic
def test_short_table_row_is_padded_not_dropped():
    """열 수가 머리글과 다른 행이 실제로 있다. 잘라내면 내용이 조용히 사라진다."""
    out = html_of("| A | B | C |\n|---|---|---|\n| 1 |")
    assert out.count("<td>") == 3


@pytest.mark.synthetic
def test_code_fence_is_not_treated_as_markup():
    out = html_of("```python\n# 제목이 아니다\n| 표 | 아니다 |\n```")
    assert "<pre><code>" in out
    assert "<h1" not in out and "<table" not in out


@pytest.mark.synthetic
def test_mermaid_fence_is_handed_to_the_frontend():
    """서버가 SVG를 굽지 않는다 — '판정 규칙 도식' 부탭과 만드는 경로가 갈린다."""
    out = html_of("```mermaid\nflowchart TD\n  A --> B\n```")
    assert 'class="doc-mermaid"' in out and "flowchart TD" in out


@pytest.mark.synthetic
def test_lists_and_quotes():
    out = html_of("- 하나\n- 둘\n\n1. 첫째\n2. 둘째\n\n> 인용문")
    assert out.count("<li>") == 4
    assert "<ul>" in out and "<ol>" in out and "<blockquote>" in out


# ── 실제 문서 ────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_the_real_document_renders():
    """정본 문서가 실제로 렌더되는지. 현업이 보는 화면이라 깨지면 바로 드러난다."""
    d = D.load_doc()
    assert d["ok"], d.get("error")
    assert len(d["html"]) > 10000, "문서가 거의 비어 있다"
    assert len(d["outline"]) > 20, "목차가 너무 적다 — 제목 파싱이 깨졌다"
    # 이번에 넣은 항목이 실제로 화면에 나오는지
    for text in ("Check 19", "Check 20", "NDT 리포트 번호",
                 "프로젝트별 두께 허용범위", "SMFC"):
        assert text in d["html"], f"'{text}'가 문서 화면에 없다"
    # 문서 끝(§11)까지 렌더돼야 한다 — 중간에 멈추면 절반만 보인다
    assert "11-11" in d["html"], "문서가 중간에서 끊겼다"


@pytest.mark.synthetic
def test_the_real_document_has_no_live_html():
    d = D.load_doc()
    low = d["html"].lower()
    for tag in ("<script", "<iframe", "onerror=", "onload="):
        assert tag not in low, f"{tag}가 통과했다"
