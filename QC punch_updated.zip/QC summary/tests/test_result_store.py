"""
`backend/services/result_store.py` — 검증 결과 SQLite 저장소 (개선계획 1번 1단계).

## 이 테스트가 지켜야 하는 것은 하나다

1단계는 **저장 방식만** 바꾼다. 판정도 집계도 화면도 그대로다. 그러므로 이 모듈이
책임지는 것은 딱 하나다:

    save_run(result) -> load_latest() 가 **완전히 같은 dict**를 돌려준다

「거의 같다」로는 부족하다. 숫자 하나가 문자열이 되거나(`"20"` -> `20.0`),
없던 키가 None으로 생기거나, 리스트 순서가 바뀌면 화면에서 조용히 틀린다.
그래서 아래 테스트는 대부분 `==` 하나로 끝난다 — 그게 요건이기 때문이다.

실데이터가 있으면 19.9MB 실결과로도 같은 왕복을 돌린다(`test_real_result_roundtrip`).
합성 데이터만으로는 실제 payload의 지저분한 부분(문자열로 들어온 두께, None 섞인
필드, 유니코드 부서명)을 재현하지 못한다.
"""
from __future__ import annotations

import json

import pytest

from backend.services import result_store as rs


def expanded(result: dict) -> dict:
    """저장소가 돌려준 결과를 «판정 엔진이 만든 모양»으로 되돌린다.

    4단계에서 계약이 바뀌었다. 응답에는 부서/팀 결함 목록이 **행 번호로만** 실린다 —
    항목 전체는 `flags`에서 만들 수 있어서(실측 부서·팀 사본 합이 payload의 44%였다)
    세 번 실을 이유가 없다. 그러므로 지켜야 할 것은 «되살리면 원본과 같다»이다:

        expand_result(load_latest()) == 원본

    펴는 규칙은 `result_store`에 하나만 두고 여기서도 그걸 쓴다. 테스트가 자기만의
    구현을 갖고 있으면 **둘 다 같이 틀렸을 때 통과한다.**
    """
    return rs.expand_result(result)


@pytest.fixture
def db(tmp_path):
    """테스트마다 새 DB 파일. 모듈 전역 상태가 없으므로 격리는 경로로 충분하다."""
    return tmp_path / "qc.db"


def make_result(n_flags: int = 3) -> dict:
    """실제 payload의 모양을 그대로 흉내낸 최소 결과.

    실데이터에서 실제로 관찰된 성질을 일부러 담았다:
      - `thickness1`이 **문자열** `"20"` (REAL로 저장하면 20.0이 되어 왕복이 깨진다)
      - 빈 문자열과 None이 섞여 있다
      - `row_raw`의 키가 문자열이다 (JSON을 거치며 int -> str이 된다)
    """
    rows = [10 + i for i in range(n_flags)]

    def flag(row: int) -> dict:
        # 키 순서까지 verifier가 내보내는 것과 같게 둔다
        return {
            "row": row, "check_no": "17", "check_name": "육안검사(VT) 미수행",
            "col": 61, "col_letter": "BI", "color": "Navy",
            "msg": "VT 미수행: 용접 후 62일 경과했으나 육안검사일 공란",
            "expected": "육안검사(VT) 수행일 기재 (유예 30일)",
            "actual": "VT 수행일 공란",
            "drawing_no": "1C-CD000-290-05", "joint_no": "1S02B001",
            "block": "CD000",
            "material1": "ASTM-A36", "material2": "",
            "thickness1": "20", "thickness2": "",
            "wps_no": "TR-FC-F01", "wps_process": "FCAW",
            "ndt_report": "SAVI14996",
            "weld_date": "2026-05-05", "ndt_date": "2026-05-07",
            "welder1_no": "2766",
            "department": "건조5부", "team": "340-구조3팀",
        }

    def defect(row: int) -> dict:
        return {
            "row": row, "joint_no": "1S02B001", "block": "CD000",
            "wps_no": "TR-FC-F01", "ndt_report": "SAVI14996",
            "weld_date": "2026-05-05", "welder1_no": "2766",
            "checks": [{"check_no": "17", "check_name": "육안검사(VT) 미수행",
                        "color": "Navy",
                        "msg": "VT 미수행: 용접 후 62일 경과했으나 육안검사일 공란",
                        "expected": "육안검사(VT) 수행일 기재 (유예 30일)",
                        "actual": "VT 수행일 공란"}],
        }

    defects = [defect(r) for r in rows]
    trend = [{"date": "2026-05-05", "count": n_flags}] if n_flags else []
    team = {
        "total_rows": 30, "unworked_rows": 0, "defect_rows": n_flags,
        "check_stats": {"17": n_flags} if n_flags else {},
        "welder_defect_rate": [], "defects": defects,
        "defect_trend_by_date": trend,
    }
    return {
        "run_at": "2026-08-08T01:30:00",
        # 이 회차를 «무엇으로» 판정했는가 — 이름과 그때의 취사선택
        "project": "시험 프로젝트",
        "rules": {"3": True, "18": False},
        "qmg_filename": "QMG.xlsx",
        "welder_filename": "welders.xlsx",
        "total_rows": 100, "deleted_rows": 1, "active_rows": 99,
        "unworked_rows": 40, "judged_rows": 59,
        "flagged_rows": n_flags, "clean_rows": 59 - n_flags,
        "total_flags": n_flags,
        "stats": {"17": n_flags} if n_flags else {},
        "flags": [flag(r) for r in rows],
        "row_raw": {str(r): [{"label": "도면번호", "col": "A",
                              "value": "1C-CD000-290-05"}] for r in rows},
        "unworked_list": [
            {"row": 500, "drawing_no": "D-1", "joint_no": "J-1",
             "block": "B1", "department": "건조5부", "team": "1팀"},
        ],
        "welder_missing": {},
        "welder_defect_rate": [],
        "welder_info": {"2766": {"name": "HONG(홍길동)"}},
        "defect_trend_by_date": trend,
        "departments": {
            "건조5부": {
                "total_rows": 59, "unworked_rows": 40, "defect_rows": n_flags,
                "check_stats": {"17": n_flags} if n_flags else {},
                "welder_defect_rate": [], "defects": defects,
                "defect_trend_by_date": trend,
                "teams": {"340-구조3팀": team},
                "recurring_patterns": [],
            }
        },
        "rule_health": [{"wps": "TR-FC-G03", "level": "unused", "msg": "…"}],
        "ml": {"unsupervised": {"meta": {"model": {"note": "매 검증마다 재학습"}}}},
    }


# ── 왕복 ─────────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_roundtrip_is_exact(db):
    """이 모듈의 존재 이유. 넣은 것과 꺼낸 것이 같아야 한다."""
    orig = make_result()
    rs.save_run(orig, path=db)
    assert expanded(rs.load_latest(path=db)) == orig


@pytest.mark.synthetic
def test_roundtrip_survives_json_dump(db):
    """API가 실제로 내보내는 형태(JSON)까지 같아야 한다.

    dict 비교만으로는 `20`과 `20.0`이 다르다는 걸 잡지만, 직렬화 결과가
    같은지는 별개다 — 프론트가 보는 것은 이쪽이다.
    """
    orig = make_result()
    rs.save_run(orig, path=db)
    back = expanded(rs.load_latest(path=db))
    assert json.dumps(back, ensure_ascii=False, sort_keys=True) == \
           json.dumps(orig, ensure_ascii=False, sort_keys=True)


@pytest.mark.synthetic
def test_thickness_stays_a_string(db):
    """실 payload의 두께는 문자열이다. REAL 열에 넣으면 `"20"` -> `20.0`이 된다.

    계획 문서의 스키마가 REAL이었는데, 그대로 갔으면 여기서 깨졌을 것이다.
    """
    orig = make_result()
    rs.save_run(orig, path=db)
    got = rs.load_latest(path=db)["flags"][0]["thickness1"]
    assert got == "20" and isinstance(got, str)


@pytest.mark.synthetic
def test_absent_keys_are_not_invented(db):
    """원래 dict에 없던 키가 None으로 생기면 안 된다.

    화면은 «키가 없음»과 «값이 None»을 다르게 그린다. 열이 NULL이라는 이유로
    키를 만들어 내면 상세 패널에 빈 줄이 늘어난다.
    """
    orig = make_result(1)
    del orig["flags"][0]["welder1_no"]
    del orig["flags"][0]["block"]
    rs.save_run(orig, path=db)
    back = rs.load_latest(path=db)["flags"][0]
    assert "welder1_no" not in back
    assert "block" not in back


@pytest.mark.synthetic
def test_unknown_flag_field_is_preserved(db):
    """`_FLAG_COLS`에 없는 키가 생겨도 조용히 사라지면 안 된다.

    Check를 추가하면서 필드가 늘어나는 일이 실제로 있었다. 그때 왕복이 깨지면
    «화면에서 뭔가 빈다»로만 드러나 원인을 찾기 어렵다.
    """
    orig = make_result(1)
    orig["flags"][0]["subcontractor"] = "C1-(주)해양서일"   # 개선계획 7번이 넣을 필드
    orig["flags"][0]["새필드"] = {"중첩": [1, 2]}
    rs.save_run(orig, path=db)
    back = rs.load_latest(path=db)["flags"][0]
    assert back["subcontractor"] == "C1-(주)해양서일"
    assert back["새필드"] == {"중첩": [1, 2]}


@pytest.mark.synthetic
def test_flag_order_is_preserved(db):
    """화면이 flags 순서에 의존한다. `ORDER BY seq`가 빠지면 조용히 섞인다."""
    orig = make_result(50)
    for i, f in enumerate(orig["flags"]):
        f["msg"] = f"메시지 {i}"
    rs.save_run(orig, path=db)
    back = rs.load_latest(path=db)
    assert [f["msg"] for f in back["flags"]] == [f"메시지 {i}" for i in range(50)]


@pytest.mark.synthetic
def test_empty_result_roundtrips(db):
    """결함 0건 — 플래그가 하나도 없는 깨끗한 검증도 저장돼야 한다."""
    orig = make_result(0)
    orig["row_raw"] = {}
    rs.save_run(orig, path=db)
    back = expanded(rs.load_latest(path=db))
    assert back == orig
    assert back["flags"] == [] and back["row_raw"] == {}


@pytest.mark.synthetic
def test_load_latest_is_none_when_empty(db):
    assert rs.load_latest(path=db) is None
    assert rs.has_result(path=db) is False


# ── 회차 ─────────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_latest_run_wins(db):
    a = make_result(1); a["run_at"] = "2026-08-01T00:00:00"
    b = make_result(2); b["run_at"] = "2026-08-08T00:00:00"
    rs.save_run(a, path=db)
    rs.save_run(b, path=db)
    assert rs.load_latest(path=db)["run_at"] == "2026-08-08T00:00:00"


@pytest.mark.synthetic
def test_old_runs_are_pruned(db):
    """`KEEP_RUNS`를 넘는 회차는 딸린 행까지 지워져야 한다.

    지금은 1회차만 남긴다 — app_state.json이 결과 하나만 들고 있던 것과 같다.
    딸린 flag/row_raw가 안 지워지면 30만 행에서 검증할 때마다 DB가 300MB씩 큰다.
    """
    for i in range(3):
        r = make_result(2)
        r["run_at"] = f"2026-08-0{i + 1}T00:00:00"
        rs.save_run(r, path=db)

    with rs.connect(db) as conn:
        assert conn.execute("SELECT COUNT(*) FROM run").fetchone()[0] == rs.KEEP_RUNS
        # CASCADE가 실제로 걸렸는지 — 고아 행이 남으면 안 된다
        for tbl in ("flag", "row_raw", "unworked"):
            orphan = conn.execute(
                f"SELECT COUNT(*) FROM {tbl} "
                "WHERE run_id NOT IN (SELECT id FROM run)").fetchone()[0]
            assert orphan == 0, f"{tbl}에 고아 행 {orphan}개가 남았다"


@pytest.mark.synthetic
def test_clear_removes_everything(db):
    rs.save_run(make_result(), path=db)
    rs.clear(path=db)
    assert rs.load_latest(path=db) is None


# ── 이름은 결과와 분리돼 있다 (개선의 절반) ──────────────────────────────────
@pytest.mark.synthetic
def test_names_are_saved_without_touching_the_result(db):
    """파일명 저장이 결과를 다시 쓰지 않는 것이 이 분리의 목적이다.

    예전에는 파일명만 바뀌는 업로드에도 20MB 결과 전체를 재직렬화했다.
    30만 건이면 파일 하나 올릴 때마다 6초를 버린다.
    """
    orig = make_result()
    rs.save_run(orig, path=db)
    rs.save_names("새QMG.xlsx", "새용접사.xlsx", "", path=db)

    assert rs.load_names(path=db) == {
        "qmg_name": "새QMG.xlsx", "welder_name": "새용접사.xlsx", "wps_name": ""}
    assert expanded(rs.load_latest(path=db)) == orig, "이름을 바꿨는데 결과가 변했다"


@pytest.mark.synthetic
def test_names_default_to_empty(db):
    assert rs.load_names(path=db) == {
        "qmg_name": "", "welder_name": "", "wps_name": ""}


@pytest.mark.synthetic
def test_names_are_overwritten_not_appended(db):
    rs.save_names("a.xlsx", "b.xlsx", "c.xlsx", path=db)
    rs.save_names("a2.xlsx", "b2.xlsx", "", path=db)
    assert rs.load_names(path=db)["qmg_name"] == "a2.xlsx"


# ── app_state.json 이관 ──────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_migration_moves_json_into_db(db, tmp_path):
    src = tmp_path / "app_state.json"
    orig = make_result()
    src.write_text(json.dumps(
        {"qmg_name": "옛QMG.xlsx", "welder_name": "옛용접사.xlsx",
         "wps_name": "", "result": orig}, ensure_ascii=False), encoding="utf-8")

    assert rs.migrate_from_json(src, path=db) is True
    assert expanded(rs.load_latest(path=db)) == orig
    assert rs.load_names(path=db)["qmg_name"] == "옛QMG.xlsx"
    assert src.exists(), "되돌릴 자리로 원본 JSON은 남겨 둔다"


@pytest.mark.synthetic
def test_migration_does_not_run_twice(db, tmp_path):
    """DB에 이미 결과가 있으면 건드리지 않는다.

    이게 없으면 서버를 재시작할 때마다 옛 JSON이 새 검증 결과를 덮어쓴다.
    """
    src = tmp_path / "app_state.json"
    old = make_result(1); old["run_at"] = "옛날"
    src.write_text(json.dumps({"result": old}, ensure_ascii=False), encoding="utf-8")

    new = make_result(2); new["run_at"] = "최신"
    rs.save_run(new, path=db)

    assert rs.migrate_from_json(src, path=db) is False
    assert rs.load_latest(path=db)["run_at"] == "최신"


@pytest.mark.synthetic
def test_migration_without_file_is_a_noop(db, tmp_path):
    assert rs.migrate_from_json(tmp_path / "없음.json", path=db) is False


@pytest.mark.synthetic
def test_migration_tolerates_broken_json(db, tmp_path):
    """잘린 JSON 하나 때문에 서버가 못 뜨면 안 된다."""
    src = tmp_path / "app_state.json"
    src.write_text('{"result": {"flags": [', encoding="utf-8")
    assert rs.migrate_from_json(src, path=db) is False


@pytest.mark.synthetic
def test_migration_of_names_only(db, tmp_path):
    """검증 전(결과 없이 파일만 올린 상태)에서 재시작해도 파일명은 남아야 한다."""
    src = tmp_path / "app_state.json"
    src.write_text(json.dumps({"qmg_name": "a.xlsx", "welder_name": "b.xlsx",
                               "wps_name": "", "result": None},
                              ensure_ascii=False), encoding="utf-8")
    assert rs.migrate_from_json(src, path=db) is True
    assert rs.load_names(path=db)["qmg_name"] == "a.xlsx"
    assert rs.load_latest(path=db) is None


# ── 실데이터 ─────────────────────────────────────────────────────────────────
@pytest.mark.realdata
def test_real_result_roundtrip(real_result, db):
    """19.9MB 실결과로 같은 왕복. 합성 데이터가 재현하지 못하는 것을 잡는다.

    실 payload에는 유니코드 부서명, 빈 문자열과 None이 섞인 필드, 문자열로 들어온
    두께, 7,901행짜리 `row_raw`가 들어 있다.
    """
    rs.save_run(real_result, path=db)
    assert expanded(rs.load_latest(path=db)) == real_result


# ── 2단계: flag에서 파생되는 집계 ────────────────────────────────────────────
@pytest.mark.synthetic
def test_derived_aggregates_are_not_stored(db):
    """파생 집계는 저장하지 않는다 — 저장하지 않으면 어긋날 수가 없다.

    `aggregate_json`에 `stats`나 부서 `defects`가 남아 있으면 그 값이 flag와
    따로 굳어 버린다. 이 프로젝트에서 비용을 치른 버그 두 건이 그 종류였다
    (2차 패스 소급 갱신 누락으로 257행이 용접사 집계에서 빠진 건).
    """
    rs.save_run(make_result(2), path=db)
    with rs.connect(db) as conn:
        agg = json.loads(conn.execute("SELECT aggregate_json FROM run").fetchone()[0])
    for key in ("stats", "total_flags", "flagged_rows", "defect_trend_by_date"):
        assert key not in agg, f"{key}가 저장돼 있다 - flag와 어긋날 수 있다"
    dept = agg["departments"]["건조5부"]
    for key in ("defect_rows", "check_stats", "defects", "defect_trend_by_date"):
        assert key not in dept, f"부서 버킷에 {key}가 저장돼 있다"
    # 분모는 반대로 «반드시» 저장돼 있어야 한다 (flag에서 만들 수 없다)
    assert dept["total_rows"] == 59


@pytest.mark.synthetic
def test_stats_are_rebuilt_from_flags(db):
    """flag가 진실이다. 저장된 집계가 틀려 있어도 꺼낼 때 바로잡혀야 한다.

    이게 2단계의 값어치다 — 집계와 flags가 어긋난 채로 화면에 나갈 수 없다.
    """
    orig = make_result(3)
    orig["stats"] = {"17": 999}                 # 일부러 어긋뜨린다
    orig["total_flags"] = 999
    orig["flagged_rows"] = 999
    orig["departments"]["건조5부"]["defect_rows"] = 999
    rs.save_run(orig, path=db)

    back = rs.load_latest(path=db)
    assert back["stats"] == {"17": 3}
    assert back["total_flags"] == 3
    assert back["flagged_rows"] == 3
    assert back["departments"]["건조5부"]["defect_rows"] == 3


@pytest.mark.synthetic
def test_department_defects_are_rebuilt_from_flags(db):
    orig = make_result(2)
    rs.save_run(orig, path=db)
    back = rs.load_latest(path=db)
    dept = back["departments"]["건조5부"]
    assert dept["defect_row_order"] == [10, 11]
    assert dept["check_stats"] == {"17": 2}
    assert "defects" not in dept, "항목이 그대로 실려 있다 - 44%가 안 줄었다"

    ent = rs.expand_defects(back, "건조5부")
    assert [e["row"] for e in ent] == [10, 11]
    assert ent[0]["checks"][0]["check_no"] == "17"
    assert ent[0]["checks"][0]["msg"].startswith("VT 미수행")
    assert ent == orig["departments"]["건조5부"]["defects"]


@pytest.mark.synthetic
def test_denominators_are_kept_not_derived(db):
    """분모는 flag에서 만들 수 없다 — 깨끗한 판정 행이 flag 테이블에 없기 때문이다.

    억지로 파생시켰다면 `total_rows`가 `defect_rows`와 같아져 부서 결함률이
    전부 100%가 됐을 것이다.
    """
    rs.save_run(make_result(2), path=db)
    dept = rs.load_latest(path=db)["departments"]["건조5부"]
    assert dept["total_rows"] == 59
    assert dept["unworked_rows"] == 40
    assert dept["defect_rows"] == 2


@pytest.mark.synthetic
def test_bucket_key_order_is_preserved(db):
    """부서/팀 버킷의 키 순서 — 파생값이 뒤로 밀리면 화면 코드가 아니라 사람이 헷갈린다."""
    orig = make_result(1)
    rs.save_run(orig, path=db)
    back = expanded(rs.load_latest(path=db))
    assert list(back["departments"]["건조5부"]) == list(orig["departments"]["건조5부"])
    assert list(back["departments"]["건조5부"]["teams"]["340-구조3팀"]) == \
           list(orig["departments"]["건조5부"]["teams"]["340-구조3팀"])


@pytest.mark.synthetic
def test_defect_order_survives_second_pass_rows(db):
    """2차 패스(Check 13/14)에서 처음 결함이 된 행은 목록 **끝**에 붙어 있다.

    row 번호로 정렬해 재현하면 이 순서가 깨진다. 실데이터에서 7개 부서 중 5개가
    row 정렬이 아니었다 — 화면에 보이는 표라 저장 방식을 바꾸면서 조용히 흔들면 안 된다.
    """
    orig = make_result(0)
    order = [20, 30, 10]                 # 10번이 2차 패스에서 뒤늦게 붙은 행
    orig["flags"] = [
        {"row": r, "check_no": "13" if r == 10 else "4", "check_name": "x",
         "col": 1, "col_letter": "A", "color": "Cyan", "msg": "m",
         "expected": "e", "actual": "a"}
        for r in order
    ]
    defects = [
        {"row": r, "joint_no": f"J{r}", "block": "B", "wps_no": "W",
         "weld_date": "2026-05-01", "welder1_no": "1",
         "checks": [{"check_no": "13" if r == 10 else "4", "check_name": "x",
                     "color": "Cyan", "msg": "m", "expected": "e", "actual": "a"}]}
        for r in order
    ]
    d = orig["departments"]["건조5부"]
    d["defects"] = defects
    d["teams"]["340-구조3팀"]["defects"] = defects

    rs.save_run(orig, path=db)
    back = rs.load_latest(path=db)
    d = back["departments"]["건조5부"]
    assert d["defect_row_order"] == order
    assert d["teams"]["340-구조3팀"]["defect_row_order"] == order
    assert [e["row"] for e in rs.expand_defects(back, "건조5부")] == order


@pytest.mark.realdata
def test_real_list_orders_are_preserved(real_result, db):
    """실결과에서 «순서가 중요한 것» 전부를 대조한다.

    객체 키 순서는 계약이 아니지만(모듈 독스트링의 계약 표), 아래 리스트들은
    화면의 표에 그대로 보이므로 바뀌면 안 된다.
    """
    rs.save_run(real_result, path=db)
    back = rs.load_latest(path=db)

    assert [(f["row"], f["check_no"]) for f in back["flags"]] == \
           [(f["row"], f["check_no"]) for f in real_result["flags"]]
    assert [u["row"] for u in back["unworked_list"]] == \
           [u["row"] for u in real_result["unworked_list"]]
    assert list(back["row_raw"]) == list(real_result["row_raw"])
    assert back["defect_trend_by_date"] == real_result["defect_trend_by_date"]

    for dept, d in real_result["departments"].items():
        assert back["departments"][dept]["defect_row_order"] == \
               [e["row"] for e in d["defects"]], f"{dept} 결함 목록 순서"
        assert rs.expand_defects(back, dept) == d["defects"], f"{dept} 결함 목록 내용"
        for team, t in (d.get("teams") or {}).items():
            assert back["departments"][dept]["teams"][team]["defect_row_order"] == \
                   [e["row"] for e in t["defects"]], f"{dept}/{team} 결함 목록 순서"
            assert rs.expand_defects(back, dept, team) == t["defects"], \
                f"{dept}/{team} 결함 목록 내용"


# ── 3단계: row_raw를 응답에서 빼고 행 단위로 가져온다 ────────────────────────
@pytest.mark.synthetic
def test_load_latest_can_omit_row_raw(db):
    """`row_raw`는 payload의 64.2%인데 화면은 클릭한 한 행만 쓴다.

    키 자체는 남겨야 한다 — 화면 코드가 `result.row_raw`를 그대로 훑는다.
    """
    orig = make_result(3)
    rs.save_run(orig, path=db)

    light = rs.load_latest(path=db, include_row_raw=False)
    assert light["row_raw"] == {}
    assert "row_raw" in light, "키까지 없애면 화면 코드가 undefined를 훑는다"
    # 나머지는 그대로여야 한다
    assert light["flags"] == orig["flags"]
    assert expanded(light)["departments"] == orig["departments"]


@pytest.mark.synthetic
def test_get_row_raw_returns_one_row(db):
    orig = make_result(3)
    rs.save_run(orig, path=db)
    assert rs.get_row_raw(10, path=db) == orig["row_raw"]["10"]
    assert rs.get_row_raw("10", path=db) == orig["row_raw"]["10"]
    assert rs.get_row_raw(999999, path=db) is None


@pytest.mark.synthetic
def test_get_row_raw_reads_the_latest_run_only(db):
    """옛 회차의 스냅샷을 돌려주면 «지금 화면의 행»과 다른 것을 보여주게 된다."""
    a = make_result(1)
    a["row_raw"] = {"10": [{"label": "도면번호", "col": "A", "value": "옛것"}]}
    rs.save_run(a, path=db)
    b = make_result(1)
    b["row_raw"] = {"10": [{"label": "도면번호", "col": "A", "value": "새것"}]}
    rs.save_run(b, path=db)
    assert rs.get_row_raw(10, path=db)[0]["value"] == "새것"


@pytest.mark.realdata
def test_real_payload_shrinks_without_row_raw(real_result, db):
    """실측으로 얼마나 줄어드는지 고정한다 — 이 값이 3단계의 이유다."""
    rs.save_run(real_result, path=db)
    full = json.dumps(rs.load_latest(path=db), ensure_ascii=False)
    light = json.dumps(rs.load_latest(path=db, include_row_raw=False),
                       ensure_ascii=False)
    shrink = 1 - len(light) / len(full)
    assert shrink > 0.5, f"row_raw를 빼도 {shrink:.1%}밖에 안 줄었다 - 구성이 바뀌었는지 확인"


# ── 4단계: 부서/팀 결함 목록은 행 번호만 보낸다 ─────────────────────────────
@pytest.mark.synthetic
def test_buckets_carry_row_order_not_entries(db):
    """항목 전체를 세 번(전역 flags + 부서 + 팀) 실을 이유가 없다.

    실측: 부서·팀 사본 합이 payload의 44%(2,737KB)였고, 행 번호 목록은 40.5KB다.
    """
    rs.save_run(make_result(2), path=db)
    back = rs.load_latest(path=db)
    for bucket in (back["departments"]["건조5부"],
                   back["departments"]["건조5부"]["teams"]["340-구조3팀"]):
        assert "defects" not in bucket
        assert bucket["defect_row_order"] == [10, 11]


@pytest.mark.synthetic
def test_expand_defects_matches_the_original_entries(db):
    orig = make_result(3)
    rs.save_run(orig, path=db)
    back = rs.load_latest(path=db)
    assert rs.expand_defects(back, "건조5부") == orig["departments"]["건조5부"]["defects"]
    assert rs.expand_defects(back, "건조5부", "340-구조3팀") == \
           orig["departments"]["건조5부"]["teams"]["340-구조3팀"]["defects"]


@pytest.mark.synthetic
def test_expand_defects_tolerates_the_old_shape(db):
    """항목이 실려 있는 옛 결과를 받아도 그대로 돌려줘야 한다.

    `app_state.json`에서 이관한 데이터가 이 모양이다.
    """
    orig = make_result(2)
    assert rs.expand_defects(orig, "건조5부") == orig["departments"]["건조5부"]["defects"]


@pytest.mark.synthetic
def test_saving_a_loaded_result_keeps_the_defect_list(db, tmp_path):
    """저장소가 꺼내 준 결과를 **다시 저장**해도 결함 목록이 살아 있어야 한다.

    `_extract_defect_rows`가 `defects`만 읽던 시절엔 이 경로에서 목록이 통째로
    비었다 — 예외가 아니라 «0건»으로 조용히 틀리는 형태다.
    """
    rs.save_run(make_result(3), path=db)
    once = rs.load_latest(path=db)

    db2 = tmp_path / "again.db"
    rs.save_run(once, path=db2)
    twice = rs.load_latest(path=db2)

    assert twice["departments"]["건조5부"]["defect_row_order"] == [10, 11, 12]
    assert twice["defect_trend_by_date"] == once["defect_trend_by_date"]
    assert rs.expand_defects(twice, "건조5부") == rs.expand_defects(once, "건조5부")


@pytest.mark.realdata
def test_real_payload_after_dedup(real_result, db):
    """중복 제거가 실제로 얼마나 줄이는지 고정한다."""
    rs.save_run(real_result, path=db)
    light = rs.load_latest(path=db, include_row_raw=False)
    full = rs.expand_result(light)
    shrink = 1 - len(json.dumps(light, ensure_ascii=False)) / \
                 len(json.dumps(full, ensure_ascii=False))
    assert shrink > 0.35, f"부서/팀 사본을 빼도 {shrink:.1%}밖에 안 줄었다"


# ── 5단계: 미작업 목록도 한 페이지씩 ────────────────────────────────────────
@pytest.mark.synthetic
def test_load_latest_can_omit_unworked(db):
    """실측 590KB(payload의 17%)인데 화면은 모달을 열었을 때만 한 페이지를 쓴다."""
    orig = make_result(1)
    orig["unworked_list"] = [
        {"row": 500 + i, "drawing_no": f"D-{i}", "joint_no": f"J-{i}",
         "block": "B1", "department": "건조5부", "team": "1팀"}
        for i in range(7)
    ]
    rs.save_run(orig, path=db)

    light = rs.load_latest(path=db, include_unworked=False)
    assert light["unworked_list"] == []
    assert "unworked_list" in light, "키까지 없애면 화면 코드가 undefined를 훑는다"
    assert light["unworked_rows"] == 40, "개수는 그대로 있어야 한다(제목 줄에 쓴다)"


@pytest.mark.synthetic
def test_get_unworked_paginates(db):
    orig = make_result(1)
    orig["unworked_list"] = [
        {"row": 500 + i, "drawing_no": f"D-{i}", "joint_no": f"J-{i}",
         "block": "B1", "department": "건조5부", "team": "1팀"}
        for i in range(7)
    ]
    rs.save_run(orig, path=db)

    page = rs.get_unworked(offset=0, limit=3, path=db)
    assert page["total"] == 7 and len(page["items"]) == 3
    assert [u["row"] for u in page["items"]] == [500, 501, 502]

    tail = rs.get_unworked(offset=6, limit=3, path=db)
    assert [u["row"] for u in tail["items"]] == [506], "마지막 페이지가 잘린다"

    assert rs.get_unworked(path=db)["total"] == 7          # limit 없으면 전량
    assert len(rs.get_unworked(path=db)["items"]) == 7


@pytest.mark.synthetic
def test_get_unworked_search_covers_the_visible_columns(db):
    """검색 범위가 화면 표에 보이는 열과 같아야 한다 — 다르면 «있는데 안 나온다»가 된다."""
    orig = make_result(0)
    orig["unworked_list"] = [
        {"row": 1, "drawing_no": "1C-CD000", "joint_no": "J-1",
         "block": "NF130", "department": "건조5부", "team": "1팀"},
        {"row": 2, "drawing_no": "9Z-XX999", "joint_no": "J-2",
         "block": "ZZ999", "department": "의장부", "team": "3팀"},
    ]
    rs.save_run(orig, path=db)
    for q, want in (("NF130", 1), ("cd000", 1), ("건조5부", 1),
                    ("J-", 2), ("없는값", 0)):
        got = rs.get_unworked(q=q, path=db)["total"]
        assert got == want, f"q={q!r} -> {got}건 (기대 {want})"


@pytest.mark.synthetic
def test_get_unworked_reads_the_latest_run_only(db):
    a = make_result(0)
    a["unworked_list"] = [{"row": 1, "drawing_no": "옛것", "joint_no": "J",
                           "block": "B", "department": "D", "team": "T"}]
    rs.save_run(a, path=db)
    b = make_result(0)
    b["unworked_list"] = [{"row": 1, "drawing_no": "새것", "joint_no": "J",
                           "block": "B", "department": "D", "team": "T"}]
    rs.save_run(b, path=db)
    assert rs.get_unworked(path=db)["items"][0]["drawing_no"] == "새것"


# ── 6단계: 플래그를 조건에 맞게 한 페이지씩 ─────────────────────────────────
def _flag(row: int, check_no: str, **over) -> dict:
    f = {"row": row, "check_no": str(check_no), "check_name": "n", "col": 1,
         "col_letter": "A", "color": "Cyan", "msg": "메시지", "expected": "e",
         "actual": "a", "drawing_no": "D", "joint_no": f"J-{row}", "block": "B",
         "material1": "", "material2": "", "thickness1": "", "thickness2": "",
         "wps_no": "TR-FC-F01", "wps_process": "FCAW", "weld_date": "2026-05-05",
         "ndt_date": "", "welder1_no": "1", "department": "건조5부",
         "team": "340-구조3팀"}
    f.update(over)
    return f


@pytest.fixture
def qdb(db):
    """필터 검사를 위한 여러 부서/Check/용접사가 섞인 결과."""
    r = make_result(0)
    r["flags"] = [
        _flag(10, 4),
        _flag(11, 17, department="의장부", team="1팀", welder1_no="2"),
        _flag(12, 4, joint_no="J-특수", msg="다른 메시지"),
        _flag(12, 17),                      # 같은 행에 두 번째 플래그
        _flag(13, 6, welder1_no="2", wps_no="TR-SMFC-G01"),
    ]
    # 부서 결함 목록도 flags와 앞뒤가 맞아야 한다 — 안 맞으면 defect_row가 비고,
    # dept_defects()가 «0건»으로 조용히 틀린다.
    def entry(row: int) -> dict:
        fl = [f for f in r["flags"] if f["row"] == row]
        h = fl[0]
        return {"row": row, "joint_no": h["joint_no"], "block": h["block"],
                "wps_no": h["wps_no"], "weld_date": h["weld_date"],
                "welder1_no": h["welder1_no"],
                "checks": [{k: f[k] for k in ("check_no", "check_name", "color",
                                              "msg", "expected", "actual")}
                           for f in fl]}

    seen: list[int] = []
    for f in r["flags"]:
        if f["row"] not in seen:
            seen.append(f["row"])
    d = r["departments"]["건조5부"]
    d["defects"] = [entry(x) for x in seen if x != 11]          # 11행은 의장부
    d["teams"]["340-구조3팀"]["defects"] = [e for e in d["defects"]]
    r["departments"]["의장부"] = {
        "total_rows": 20, "unworked_rows": 0, "defect_rows": 1,
        "check_stats": {"17": 1}, "welder_defect_rate": [],
        "defects": [entry(11)], "defect_trend_by_date": [],
        "teams": {"1팀": {"total_rows": 20, "unworked_rows": 0, "defect_rows": 1,
                          "check_stats": {"17": 1}, "welder_defect_rate": [],
                          "defects": [entry(11)], "defect_trend_by_date": []}},
        "recurring_patterns": [],
    }
    rs.save_run(r, path=db)
    return db


@pytest.mark.synthetic
def test_query_flags_filters(qdb):
    q = lambda **kw: [f["row"] for f in rs.query_flags(path=qdb, **kw)["items"]]  # noqa: E731
    assert q(check=4) == [10, 12]
    assert q(check=17) == [11, 12]
    assert q(dept="의장부") == [11]
    assert q(dept="건조5부", team="340-구조3팀") == [10, 12, 12, 13]
    assert q(welder="2") == [11, 13]
    assert q(rows=[12]) == [12, 12]
    assert q(checks=[4, 6]) == [10, 12, 13]


@pytest.mark.synthetic
def test_query_flags_search_matches_the_screen(qdb):
    """검색 범위가 화면의 필터와 같아야 한다 — 다르면 «있는데 안 나온다»가 된다.

    화면은 joint_no / wps_no / msg / block / ndt_report를 훑는다(app.js의 applyFilters).
    """
    assert rs._FLAG_SEARCH_COLS == ("joint_no", "wps_no", "msg", "block",
                                    "ndt_report")
    q = lambda s: [f["row"] for f in rs.query_flags(q=s, path=qdb)["items"]]  # noqa: E731
    assert q("특수") == [12]                       # joint_no
    assert q("smfc") == [13]                       # wps_no, 대소문자 무시
    assert q("다른 메시지") == [12]                 # msg
    assert q("없는값") == []
    # department는 검색 대상이 아니다(화면과 같음) — 별도 필터가 있다
    assert q("의장부") == []


@pytest.mark.synthetic
def test_query_flags_empty_selection_is_not_no_filter(qdb):
    """Check를 «전부 해제»한 것과 «필터 없음»은 다르다.

    뭉개면 화면에서 전부 해제했는데 전체가 나오는 상태가 된다.
    """
    assert rs.query_flags(checks=[], path=qdb)["total"] == 0
    assert rs.query_flags(rows=[], path=qdb)["total"] == 0
    assert rs.query_flags(path=qdb)["total"] == 5      # 필터 없음 = 전량


@pytest.mark.synthetic
def test_query_flags_paginates_in_payload_order(qdb):
    """정렬은 저장 당시 순서(seq) — 화면의 표가 이 순서에 의존한다."""
    a = rs.query_flags(offset=0, limit=2, path=qdb)
    b = rs.query_flags(offset=2, limit=2, path=qdb)
    assert a["total"] == b["total"] == 5
    assert [f["row"] for f in a["items"]] == [10, 11]
    assert [f["row"] for f in b["items"]] == [12, 12]
    assert rs.query_flags(offset=0, limit=0, path=qdb)["items"] == [], "limit=0은 개수만"
    assert rs.query_flags(offset=0, limit=0, path=qdb)["total"] == 5


@pytest.mark.realdata
def test_query_flags_matches_client_side_filtering(real_result, db):
    """서버 필터가 지금까지 화면이 하던 필터와 **완전히 같은 결과**를 내야 한다.

    옮기는 과정에서 조건이 미묘하게 달라지면 «전에는 나오던 게 안 나온다»가 되고,
    현업은 그걸 판정이 바뀐 것으로 읽는다.
    """
    rs.save_run(real_result, path=db)
    full = real_result["flags"]

    def same(kw, pred):
        got = rs.query_flags(path=db, **kw)
        want = [f for f in full if pred(f)]
        assert got["total"] == len(want), kw
        assert got["items"] == want, kw

    d0 = full[0]["department"]
    same({"check": 17}, lambda f: f["check_no"] == "17")
    same({"dept": d0}, lambda f: f["department"] == d0)
    same({"checks": [4, 17]}, lambda f: f["check_no"] in ("4", "17"))
    same({"q": "TR-FC-G01"},
         lambda f: any("tr-fc-g01" in (f.get(c) or "").lower()
                       for c in rs._FLAG_SEARCH_COLS))


@pytest.mark.synthetic
def test_aggregate_counts_rows_not_flags(qdb):
    """`flagged_rows`는 행 단위 중복 제거다 — 12행은 플래그가 둘인데 한 행이다."""
    a = rs.aggregate_flags(path=qdb)
    assert a["total_flags"] == 5
    assert a["flagged_rows"] == 4, "행 12의 플래그 두 개를 두 행으로 셌다"
    assert a["stats"] == {"4": 2, "6": 1, "17": 2}
    assert a["clean_rows"] == 59 - 4


@pytest.mark.synthetic
def test_aggregate_keeps_a_row_if_any_selected_check_hits(qdb):
    """한 행에 선택/제외 Check가 섞여 있어도 선택된 것이 하나면 결함 행이다."""
    a = rs.aggregate_flags(checks=[17], path=qdb)
    assert a["flagged_rows"] == 2 and a["total_flags"] == 2   # 11행, 12행
    assert a["stats"] == {"17": 2}


@pytest.mark.synthetic
def test_aggregate_with_nothing_selected(qdb):
    """전부 해제하면 결함 0, 깨끗한 행은 판정 대상 전량이다."""
    a = rs.aggregate_flags(checks=[], path=qdb)
    assert a == {"flagged_rows": 0, "clean_rows": 59, "total_flags": 0,
                 "stats": {}, "trend": []}


@pytest.mark.synthetic
def test_aggregate_trend_counts_rows_per_date(qdb):
    a = rs.aggregate_flags(path=qdb)
    assert a["trend"] == [{"date": "2026-05-05", "count": 4}]


@pytest.mark.synthetic
def test_aggregate_scoped_uses_the_bucket_denominator(qdb):
    """부서 범위면 분모도 그 부서의 판정 대상이어야 한다."""
    a = rs.aggregate_flags(dept="건조5부", path=qdb)
    assert a["flagged_rows"] == 3           # 10, 12, 13
    assert a["clean_rows"] == 59 - 3        # 부서 total_rows = 59


@pytest.mark.realdata
def test_aggregate_matches_client_side_calculation(real_result, db):
    """서버 집계가 지금까지 화면이 하던 계산과 같아야 한다."""
    rs.save_run(real_result, path=db)
    full = real_result["flags"]
    judged = real_result["judged_rows"]

    def client(sel):
        fl = [f for f in full if f["check_no"] in {str(x) for x in sel}]
        rows, stats = {}, {}
        for f in fl:
            stats[str(f["check_no"])] = stats.get(str(f["check_no"]), 0) + 1
            rows.setdefault(f["row"], f.get("weld_date") or "")
        dc: dict[str, int] = {}
        for d in rows.values():
            if d:
                dc[d] = dc.get(d, 0) + 1
        return {"flagged_rows": len(rows), "clean_rows": max(judged - len(rows), 0),
                "total_flags": len(fl), "stats": stats,
                "trend": [{"date": d, "count": c} for d, c in sorted(dc.items())]}

    allck = sorted({f["check_no"] for f in full})
    for sel in (allck, [4, 17], [c for c in allck if c != 6]):
        assert rs.aggregate_flags(checks=sel, path=db) == client(set(sel)), sel


@pytest.mark.synthetic
def test_flag_facets(qdb):
    """필터 select 값. 정렬은 화면(한국어 기준)이 하므로 여기서는 집합으로 본다."""
    fa = rs.flag_facets(path=qdb)
    assert set(fa["departments"]) == {"건조5부", "의장부"}
    assert set(fa["teams"]) == {"340-구조3팀", "1팀"}
    assert set(rs.flag_facets(dept="의장부", path=qdb)["teams"]) == {"1팀"}


@pytest.mark.synthetic
def test_dept_defects_paginates(qdb):
    got = rs.dept_defects("건조5부", path=qdb)
    assert got["total"] == 3                      # 10, 12, 13
    assert [e["row"] for e in got["items"]] == [10, 12, 13]
    assert [c["check_no"] for c in got["items"][1]["checks"]] == ["4", "17"], \
        "행 12의 플래그 두 개가 한 항목의 checks[]로 묶여야 한다"
    assert [e["row"] for e in rs.dept_defects("건조5부", offset=1, limit=1,
                                              path=qdb)["items"]] == [12]


@pytest.mark.synthetic
def test_dept_defects_search_matches_the_screen(qdb):
    """부서 결함 표의 검색은 Joint No와 용접사 번호를 훑는다."""
    assert rs.dept_defects("건조5부", q="특수", path=qdb)["total"] == 1
    assert rs.dept_defects("건조5부", q="j-10", path=qdb)["total"] == 1
    assert rs.dept_defects("건조5부", q="없는값", path=qdb)["total"] == 0


@pytest.mark.synthetic
def test_review_counts_uses_the_screen_key(qdb):
    """키는 `도면번호|Joint No|WPS No|Check No` — 화면의 _fbKey와 같아야 한다."""
    assert rs.review_counts({}, path=qdb) == {
        "total": 5, "reviewed": 0, "unreviewed": 5,
        "by_result": {}, "by_result_all": {}}
    fb = {"D|J-10|TR-FC-F01|4": {"result": "오탐"}}
    assert rs.review_counts(fb, path=qdb)["reviewed"] == 1


@pytest.mark.synthetic
def test_review_counts_separates_this_run_from_the_whole_file(qdb):
    """«이번 회차에 대조되는 라벨»과 «파일에 있는 라벨»은 다르다.

    규칙이 바뀌면 그 규칙으로 오탐 판정을 받은 플래그는 더 이상 생기지 않는다.
    라벨은 남지만 대조할 행이 없어서, 지금 회차만 보면 클래스가 한쪽뿐일 수
    있다. 두 숫자를 한 값으로 뭉개면 «학습 가능하다»고 잘못 읽는다.
    """
    fb = {
        "D|J-10|TR-FC-F01|4": {"result": "결함확정"},   # 이번 회차에 있는 행
        "없는도면|없는조인트|W|9": {"result": "오탐"},   # 규칙이 사라진 행
    }
    got = rs.review_counts(fb, path=qdb)
    assert got["by_result"] == {"결함확정": 1}, "이번 회차 내역이 아니다"
    assert got["by_result_all"] == {"결함확정": 1, "오탐": 1}, "파일 전체 내역이 아니다"


@pytest.mark.synthetic
def test_review_counts_for_a_welder_excludes_check6(qdb):
    """용접사별 미검토는 Check 6을 뺀다.

    플래그에는 welder1_no만 실려 있어 C6를 포함하면 2~4번 용접사의 자격 문제가
    1번 용접사에게 잘못 붙는다.
    """
    got = rs.review_counts({}, welder="2", path=qdb)
    assert got["total"] == 1, "welder 2의 플래그는 17(11행)과 6(13행) 둘인데 6은 빠져야 한다"


@pytest.mark.realdata
def test_dept_defects_matches_expand_defects(real_result, db):
    """페이지 버전과 전량 버전이 같은 것을 내야 한다 — 화면과 메일이 갈라지면 안 된다."""
    rs.save_run(real_result, path=db)
    light = rs.load_latest(path=db, include_row_raw=False, include_unworked=False)
    for dept in list(light["departments"])[:4]:
        assert rs.dept_defects(dept, path=db)["items"] == \
               rs.expand_defects(light, dept), dept


@pytest.mark.synthetic
def test_derived_aggregates_come_from_the_db_not_the_payload(qdb):
    """파생 집계는 **DB**에서 나와야 한다 — `result["flags"]`를 훑으면 안 된다.

    응답에서 플래그를 뺀 뒤 그 배열이 비는데, 거기서 세면 `stats`가 `{}`가 되어
    «결함 0건»으로 조용히 틀린다. 예외가 나지 않아 발견이 늦다(실제로 그랬다).
    """
    light = rs.load_latest(path=qdb, include_flags=False)
    assert light["flags"] == []
    assert "flags" in light, "키까지 없애면 화면 코드가 undefined를 훑는다"

    # 플래그를 안 실었어도 집계는 그대로다
    assert light["stats"] == {"4": 2, "17": 2, "6": 1}
    assert light["total_flags"] == 5
    assert light["flagged_rows"] == 4
    dept = light["departments"]["건조5부"]
    assert dept["check_stats"] == {"4": 2, "17": 1, "6": 1}
    assert dept["defect_rows"] == 3


@pytest.mark.synthetic
def test_expand_defects_falls_back_to_the_db(qdb):
    """플래그가 안 실린 결과로도 결함 목록을 낼 수 있어야 한다.

    부서 리포트 메일이 이 경로를 쓴다. 폴백이 없으면 checks[]가 전부 빈 목록이
    되어 «지적 내용 없는 결함»이 메일로 나간다.
    """
    light = rs.load_latest(path=qdb, include_flags=False)
    ent = rs.expand_defects(light, "건조5부", path=qdb)
    assert [e["row"] for e in ent] == [10, 12, 13]
    assert ent[1]["checks"] and ent[1]["checks"][0]["msg"], "지적 내용이 비었다"
    assert ent == rs.dept_defects("건조5부", path=qdb)["items"]


@pytest.mark.realdata
def test_payload_without_flags_is_small(real_result, db):
    """플래그를 빼면 응답이 얼마나 작아지는지 고정한다."""
    rs.save_run(real_result, path=db)
    full = json.dumps(rs.load_latest(path=db, include_row_raw=False,
                                     include_unworked=False), ensure_ascii=False)
    light = json.dumps(rs.load_latest(path=db, include_row_raw=False,
                                      include_unworked=False,
                                      include_flags=False), ensure_ascii=False)
    assert 1 - len(light) / len(full) > 0.8, "플래그를 빼도 80% 미만으로만 줄었다"


# ── 상한에 기대지 않고 «자연히 묶이게» 한다 ─────────────────────────────────
@pytest.mark.synthetic
def test_exact_match_narrows_check14_to_its_group(qdb):
    """Check 14 형제 행은 (도면번호, Joint No) **정확일치**로 묻는다.

    부분일치(`q`)로 받아 화면에서 다시 거르면 후보 수를 예측할 수 없어 상한에
    걸릴 수 있다. 정확일치면 결과가 그룹 크기로 자연히 묶인다.
    """
    got = rs.query_flags(drawing_no="D", joint_no="J-10", path=qdb)
    assert [f["row"] for f in got["items"]] == [10]
    # 부분일치는 다른 조인트까지 데려온다 — 그래서 정확일치가 필요하다
    assert rs.query_flags(q="J-1", path=qdb)["total"] > got["total"]


@pytest.mark.synthetic
def test_exact_match_is_not_a_substring(qdb):
    """`joint_no=J-1`이 `J-10`을 데려오면 안 된다."""
    assert rs.query_flags(joint_no="J-1", path=qdb)["total"] == 0
    assert rs.query_flags(joint_no="J-10", path=qdb)["total"] == 1


@pytest.mark.synthetic
def test_review_counts_by_welder_matches_single_queries(qdb):
    """일괄 조회가 한 명씩 물은 것과 같아야 한다.

    용접사 목록의 '미검토' 열이 146명분을 동시에 쓴다 — 한 명씩 물으면 146번을
    왕복한다. 두 경로가 갈라지면 목록과 상세의 숫자가 달라진다.
    """
    bulk = rs.review_counts_by_welder({}, path=qdb)
    for welder in bulk:
        one = rs.review_counts({}, welder=welder, path=qdb)
        assert bulk[welder]["total"] == one["total"], welder
        assert bulk[welder]["unreviewed"] == one["unreviewed"], welder


@pytest.mark.synthetic
def test_review_counts_by_welder_excludes_check6(qdb):
    """Check 6은 특정 용접사에게 귀속되는 플래그라 결함 열 기준에서 뺀다."""
    bulk = rs.review_counts_by_welder({}, path=qdb)
    # welder "2"는 17(11행)과 6(13행) 둘인데 6은 빠져야 한다
    assert bulk["2"]["total"] == 1


@pytest.mark.realdata
def test_welder_flag_count_stays_under_the_cap(real_result, db):
    """용접사 상세는 한 덩어리로 받는다 — 상한 안에 들어오는지 실측으로 본다.

    이 화면은 Check별 분포·검토 집계·월별 차트를 그 용접사의 전 플래그로 내므로
    페이지로 자를 수 없다. 상한에 닿으면 용접사 단위 페이지네이션이 따로 필요하다.
    """
    from backend import config

    rs.save_run(real_result, path=db)
    bulk = rs.review_counts_by_welder({}, path=db)
    worst = max(bulk.values(), key=lambda v: v["total"])["total"] if bulk else 0
    assert worst < config.MAX_FLAG_PAGE, (
        f"한 용접사가 {worst}건으로 상한({config.MAX_FLAG_PAGE})에 닿았다 — "
        "용접사 단위 페이지네이션이 필요하다")


# ── 임시부재(1C) 제외 토글 ──────────────────────────────────────────────────
@pytest.mark.synthetic
def test_exclude_temp_shrinks_both_sides(qdb):
    """임시부재를 빼면 **분모도 함께 줄어야 한다.**

    빼먹으면 결함률이 실제보다 낮게 나온다. 임시부재 중 «깨끗한 행»은 flag
    테이블에 없어 셀 수 없으므로, 판정 때 세어 둔 값(`temp_rows`)을 쓴다.
    """
    from backend.services import wps_rules

    assert wps_rules.is_temp_member("1C-CD000-130-05")
    assert not wps_rules.is_temp_member("101900-XSUPP-47501=NF110-B")

    full = rs.aggregate_flags(path=qdb)
    # 합성 데이터의 도면번호는 "D"라 임시부재가 아니다 — 제외해도 그대로여야 한다
    same = rs.aggregate_flags(exclude_temp=True, path=qdb)
    assert same == full, "임시부재가 없는데 수치가 바뀌었다"


@pytest.mark.synthetic
def test_exclude_temp_filters_1c_flags(db):
    """도면번호가 1C로 시작하는 플래그만 빠진다."""
    r = make_result(0)
    r["judged_rows"] = 10
    r["temp_judged_rows"] = 4          # 1C 판정행 4개(그중 2개가 결함)
    r["flags"] = [
        _flag(1, 4, drawing_no="1C-A"), _flag(2, 4, drawing_no="1C-B"),
        _flag(3, 4, drawing_no="101900-X"),
    ]
    d = r["departments"]["건조5부"]
    ent = lambda row: {"row": row, "joint_no": f"J-{row}", "block": "B",  # noqa: E731
                       "wps_no": "W", "weld_date": "", "welder1_no": "1",
                       "checks": [{"check_no": "4", "check_name": "x", "color": "Cyan",
                                   "msg": "m", "expected": "e", "actual": "a"}]}
    d["defects"] = [ent(1), ent(2), ent(3)]
    d["teams"]["340-구조3팀"]["defects"] = []
    rs.save_run(r, path=db)

    assert rs.aggregate_flags(path=db)["flagged_rows"] == 3
    got = rs.aggregate_flags(exclude_temp=True, path=db)
    assert got["flagged_rows"] == 1, "1C 플래그가 남아 있다"
    # 분모: 판정 10 - 임시부재 4 = 6, 결함 1 -> 클린 5
    assert got["clean_rows"] == 5, f"분모를 줄이지 않았다 (clean={got['clean_rows']})"


@pytest.mark.realdata
def test_real_temp_share_is_recorded(real_result):
    """임시부재 비중이 payload에 남아야 한다 — 화면이 «무엇을 뺐는지» 알려야 한다."""
    assert "temp_judged_rows" in real_result, \
        "판정 단계에서 임시부재 행수를 세지 않는다 - 토글이 분모를 줄일 수 없다"
    assert 0 <= real_result["temp_judged_rows"] <= real_result["judged_rows"]


@pytest.mark.synthetic
def test_dept_defects_handles_a_slash_in_the_department_name(db):
    """부서명에 `/`가 들어간다 — 실데이터의 `Q530-SMR/ITER생산부`.

    엔드포인트가 `/api/departments/{dept}/defects`였을 때, 슬래시가 경로
    구분자로 먹혀 이 부서만 404였다. 화면은 «결함 0건»이 아니라 표가 통째로
    비어 보였고, 실제로는 122건이 있었다. 지금은 질의 파라미터로 받는다.

    저장소 쪽은 처음부터 문제가 없었지만, 다시 경로 파라미터로 되돌리는 변경이
    있으면 라우터 테스트와 함께 여기서도 잡히도록 남긴다.
    """
    r = make_result(0)
    dept = "Q530-SMR/ITER생산부"
    r["departments"][dept] = dict(r["departments"]["건조5부"])
    r["departments"][dept]["defect_row_order"] = [10]
    r["flags"] = [_flag(10, 4, department=dept, team="1팀")]
    rs.save_run(r, path=db)

    got = rs.dept_defects(dept, path=db)
    assert got["total"] == 1, "슬래시 든 부서명으로 조회가 안 된다"
    assert got["items"][0]["row"] == 10
    assert rs.aggregate_flags(dept=dept, path=db)["flagged_rows"] == 1


@pytest.mark.synthetic
def test_bumping_the_schema_discards_stale_runs(db, monkeypatch):
    """`SCHEMA_VERSION`을 올리면 저장된 회차를 버리고 다시 만들어야 한다.

    DB에 든 것은 전부 재생성 가능한 파생물이라 마이그레이션을 쓰지 않는다.
    안 올리면 «없는 열» 오류가 실행 중에 터지고, 열이 늘지 않는 변경(예:
    `temp_judged_rows` 같은 새 집계)이면 **오류조차 나지 않고** 옛 회차가
    새 기능을 못 받는다 — 1C 토글이 분모를 줄이지 못하는 형태로 나타났다.
    """
    rs.save_run(make_result(2), path=db)
    assert rs.load_latest(path=db) is not None

    monkeypatch.setattr(rs, "SCHEMA_VERSION", rs.SCHEMA_VERSION + 1)
    assert rs.load_latest(path=db) is None, "옛 스키마의 회차가 그대로 살아 있다"

    # 버린 뒤에도 새로 저장하면 정상 동작해야 한다(테이블이 다시 만들어졌는지)
    rs.save_run(make_result(1), path=db)
    again = rs.load_latest(path=db)
    assert again is not None and again["total_flags"] == 1


@pytest.mark.synthetic
def test_temp_filter_is_defined_once(qdb):
    """임시부재 제외 조건이 여러 곳에 흩어지면 «화면에서 본 건수»와 «받은 파일의
    건수»가 갈라진다. `_add_temp_filter` 하나만 쓴다."""
    import inspect

    src = inspect.getsource(rs)
    # 조건식을 직접 쓴 곳이 남아 있으면 안 된다 (헬퍼 안의 한 번만 허용)
    assert src.count("NOT LIKE ?") == 1, "임시부재 조건이 여러 곳에 있다"


@pytest.mark.synthetic
def test_queries_can_exclude_temp(db):
    r = make_result(0)
    r["flags"] = [_flag(1, 3, drawing_no="1C-A"),
                  _flag(2, 3, drawing_no="101900-B")]
    d = r["departments"]["건조5부"]
    d["defect_row_order"] = [1, 2]
    rs.save_run(r, path=db)

    assert rs.query_flags(path=db)["total"] == 2
    assert rs.query_flags(exclude_temp=True, path=db)["total"] == 1
    assert rs.query_flags(exclude_temp=True, path=db)["items"][0]["row"] == 2

    got = rs.dept_defects("건조5부", exclude_temp=True, path=db)
    assert got["total"] == 1 and got["items"][0]["row"] == 2, \
        "부서 결함 목록이 1C를 걸러내지 않는다"


@pytest.mark.synthetic
def test_scope_defect_rows_counts_each_level(db):
    r = make_result(0)
    r["flags"] = [_flag(1, 3, drawing_no="1C-A", department="D1", team="T1"),
                  _flag(2, 3, drawing_no="101900-B", department="D1", team="T1"),
                  _flag(3, 4, drawing_no="101900-B", department="D1", team="T1"),
                  _flag(4, 3, drawing_no="101900-C", department="D2", team="T9")]
    rs.save_run(r, path=db)

    allc = rs.scope_defect_rows(path=db)
    assert allc[("", "")] == 4                    # 전체
    assert allc[("D1", "")] == 3                  # 부서
    assert allc[("D1", "T1")] == 3                # 팀
    # 행 3·2는 같은 행이 아니므로 3건, 1C를 빼면 2건
    notemp = rs.scope_defect_rows(exclude_temp=True, path=db)
    assert notemp[("", "")] == 3 and notemp[("D1", "")] == 2
