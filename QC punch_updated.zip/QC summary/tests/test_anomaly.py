"""
`backend/services/anomaly.py` — Check 13 이상치 탐지 + 화면용 부가 정보 테스트.

이 모듈의 위험은 «틀린 값»보다 «오해를 부르는 값»이다:

- 빈도 인코딩이 깨지면 산점도의 «바깥일수록 드묾»이라는 읽는 법이 성립하지 않는다
- 이탈도가 잘못 정렬되면 화면이 엉뚱한 피처를 «주된 이유»로 내세운다
- meta가 행수에 비례해 커지면 결과 JSON이 20만 행에서 감당이 안 된다

scikit-learn이 없는 환경에서도 수집이 깨지지 않아야 하므로 skipif로 감싼다.
"""
from __future__ import annotations

import json

import pytest

from backend.services import anomaly


pytestmark = pytest.mark.skipif(
    not anomaly.is_available(), reason="scikit-learn 미설치 환경"
)


def _rows(n_common: int = 200, n_rare: int = 3):
    """흔한 조합 다수 + 드문 조합 소수. 드문 쪽이 이상치로 잡혀야 한다."""
    rows = []
    r = 1
    for _ in range(n_common):
        rows.append((r, {
            'material_key': 'A36', 'wps_no': 'TR-FC-G01', 'groove': 'DB',
            'ndt_cat': 'C5', 'department': 'D1', 'team': 'T1',
            'thickness1': 12.0, 'thickness2': None, 'weld_to_ndt_days': 5,
        }))
        r += 1
    for _ in range(n_rare):
        rows.append((r, {
            'material_key': 'API5L', 'wps_no': 'TR-SMFC-G01', 'groove': 'FL',
            'ndt_cat': 'A1', 'department': 'D9', 'team': 'T9',
            'thickness1': 45.0, 'thickness2': None, 'weld_to_ndt_days': 180,
        }))
        r += 1
    return rows


# ── 기본 동작 ─────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_below_minimum_rows_skipped():
    out = anomaly.detect_anomalies(_rows(5, 1))
    assert out['anomalies'] == {}
    assert out['meta'] is None


@pytest.mark.synthetic
def test_rare_rows_are_flagged():
    rows = _rows()
    out = anomaly.detect_anomalies(rows)
    rare_rows = {r for r, f in rows if f['material_key'] == 'API5L'}
    flagged = set(out['anomalies'])
    assert rare_rows & flagged, "드문 조합이 하나도 안 잡혔다"


@pytest.mark.synthetic
def test_deterministic():
    """시드가 고정돼 있어 같은 입력이면 같은 결과여야 한다.

    검증을 두 번 돌렸을 때 결과가 흔들리면 «재검증했더니 숫자가 달라졌다»가 되어
    이 시스템이 조심스럽게 지켜온 정합성 검사가 무의미해진다.
    """
    rows = _rows()
    a = anomaly.detect_anomalies(rows)
    b = anomaly.detect_anomalies(rows)
    assert set(a['anomalies']) == set(b['anomalies'])
    for k in a['anomalies']:
        assert a['anomalies'][k]['score'] == b['anomalies'][k]['score']


# ── 피처별 이탈도 ─────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_deviation_sorted_and_complete():
    out = anomaly.detect_anomalies(_rows())
    info = next(iter(out['anomalies'].values()))
    devs = info['deviations']
    assert len(devs) == len(anomaly._CATEGORICAL_FIELDS) + len(anomaly._NUMERIC_FIELDS)
    vals = [d['deviation'] for d in devs]
    assert vals == sorted(vals, reverse=True), "이탈도가 내림차순이 아니면 화면이 엉뚱한 이유를 내세운다"
    assert all(0.0 <= v <= 1.0 for v in vals), "이탈도는 0~1로 정규화돼야 막대 길이가 맞는다"


@pytest.mark.synthetic
def test_rare_category_has_high_deviation():
    """드문 값일수록 이탈도가 커야 한다 — 막대 길이가 곧 «얼마나 드문가»다."""
    rows = _rows()
    out = anomaly.detect_anomalies(rows)
    info = next(iter(out['anomalies'].values()))
    by_field = {d['field']: d for d in info['deviations']}
    assert by_field['material_key']['deviation'] > 0.9
    assert by_field['material_key']['share'] < 0.05


@pytest.mark.synthetic
def test_reason_matches_top_deviation():
    out = anomaly.detect_anomalies(_rows())
    info = next(iter(out['anomalies'].values()))
    top = info['deviations'][0]
    assert str(top['value']) in info['reason'], "주된 이유가 최상위 이탈 피처와 달라졌다"


@pytest.mark.synthetic
def test_missing_numeric_does_not_crash():
    rows = _rows()
    rows.append((9999, {
        'material_key': None, 'wps_no': None, 'groove': None, 'ndt_cat': None,
        'department': None, 'team': None,
        'thickness1': None, 'thickness2': None, 'weld_to_ndt_days': None,
    }))
    out = anomaly.detect_anomalies(rows)
    assert out['meta'] is not None


# ── 동종 그룹 ─────────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_peer_groups_consistent():
    out = anomaly.detect_anomalies(_rows())
    info = next(iter(out['anomalies'].values()))
    assert info['peers'], "동종 그룹 비교가 비어 있다"
    for p in info['peers']:
        assert p['match'] <= p['base'], "해당 건수가 모집단보다 많을 수 없다"
        assert 0.0 <= p['pct'] <= 100.0


# ── meta (화면용) ─────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_meta_shape():
    out = anomaly.detect_anomalies(_rows())
    m = out['meta']
    assert m['total_rows'] == 203
    assert m['anomaly_count'] == len(out['anomalies'])
    assert len(m['histogram']['counts']) == 40
    assert len(m['histogram']['bins']) == 41
    p = m['projection']
    assert p['grid'] == anomaly._GRID
    assert len(p['density']) == anomaly._GRID
    assert all(len(row) == anomaly._GRID for row in p['density'])
    assert len(p['centroid']) == 2
    assert len(m['fields']) == len(anomaly._CATEGORICAL_FIELDS) + len(anomaly._NUMERIC_FIELDS)


@pytest.mark.synthetic
def test_meta_size_does_not_grow_with_rows():
    """20만 행에서도 화면에 보내는 양이 일정해야 한다.

    meta는 격자·히스토그램으로 요약돼 있으므로 행수가 늘어도 크기가 거의 같아야 한다.
    여기가 깨지면 결과 JSON(이미 18MB)이 감당 못 할 크기로 불어난다.
    """
    small = anomaly.detect_anomalies(_rows(200, 3))['meta']
    large = anomaly.detect_anomalies(_rows(4000, 60))['meta']
    s = len(json.dumps(small))
    l = len(json.dumps(large))
    assert l < s * 1.5, f"meta가 행수에 따라 커진다: {s} -> {l}"


@pytest.mark.synthetic
def test_anomaly_xy_within_projection_range():
    """이상치 좌표가 투영 범위 밖이면 산점도에서 캔버스를 벗어나 안 보인다."""
    out = anomaly.detect_anomalies(_rows())
    p = out['meta']['projection']
    for info in out['anomalies'].values():
        x, y = info['xy']
        assert p['x_range'][0] <= x <= p['x_range'][1], (x, p['x_range'])
        assert p['y_range'][0] <= y <= p['y_range'][1], (y, p['y_range'])


@pytest.mark.synthetic
def test_density_normalized():
    out = anomaly.detect_anomalies(_rows())
    dens = out['meta']['projection']['density']
    flat = [v for row in dens for v in row]
    assert all(0.0 <= v <= 1.0 for v in flat), "밀도는 0~1이어야 알파값으로 쓸 수 있다"
    assert max(flat) > 0.5, "밀도 최대가 너무 낮으면 정상 영역이 화면에 안 보인다"


@pytest.mark.synthetic
def test_model_note_states_no_persistence():
    """«매번 새로 학습한다»는 사실이 화면 문구로 나가야 한다.

    누적 학습 모델로 오해하면 «작년 데이터로 배운 것»이라고 잘못 읽는다.
    """
    m = anomaly.detect_anomalies(_rows())['meta']
    assert '저장하지 않' in m['model']['note']


# ── 실데이터 ─────────────────────────────────────────────────────────────────
@pytest.mark.realdata
def test_real_result_has_ml_block(result):
    ml = (result or {}).get('ml', {}).get('unsupervised')
    if not ml or not ml.get('available'):
        pytest.skip("이상치 분석이 없는 결과(재검증 전이거나 sklearn 없음)")
    assert ml['meta']['anomaly_count'] == len(ml['detail'])
    for row_key, d in ml['detail'].items():
        assert row_key.isdigit()
        assert d['deviations'] and d['xy']
