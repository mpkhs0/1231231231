"""
검증 완료 시점의 **순서**를 고정한다 (`backend/routers/verify.py`).

## 왜 순서가 계약인가

화면은 `/api/status`를 폴링하다가 `done`을 보는 **즉시** `/api/result`를 부른다.
그래서 «결과를 화면에 공개하는 순간»에는 아래 둘이 이미 끝나 있어야 한다:

1. `result_store.save_run()` — 저장이 끝나기 전에 done을 세우면, 그 틈에 서버가
   죽었을 때 «화면에는 결과가 있었는데 재시작하면 없는» 상태가 된다.
2. `row_raw` 분리 — 떼어내기 전에 done을 세우면 그 틈에 들어온 요청에만
   18MB 응답이 나간다. 재현이 어렵고 «가끔 느리다»로만 드러난다.

실제로 2번을 뒤에 뒀다가 신규 검증 경로에서만 17MB가 나가는 것을 잡았다
(복원 경로는 멀쩡해서 처음 측정에서는 6.66MB로 보였다).

## 왜 소스 순서를 보나

이 구간은 백그라운드 스레드 안의 지역 함수라 단위 테스트로 부르기 어렵고,
경쟁 상태라 실행 테스트로는 **안정적으로 재현되지 않는다**(그게 이 버그가
처음에 안 잡힌 이유다). 이 저장소에는 이미 소스를 정적으로 훑는 회귀 테스트
선례가 있다(`test_inline_handler_escaping.py`).
"""
from __future__ import annotations

import inspect

import pytest

from backend.routers import verify


def _normalize(src: str) -> str:
    """줄바꿈·들여쓰기로 나뉜 호출을 한 줄로 눌러 비교한다.

    인자가 늘어 줄이 접히면 문자열 검사가 통째로 헛돈다. 실제로 `include_unworked`를
    추가하면서 세 개가 한꺼번에 깨졌다 — 코드는 멀쩡한데 테스트만 틀린 경우다.
    """
    return " ".join(src.split())


@pytest.mark.synthetic
def test_result_is_saved_and_stripped_before_being_published():
    """저장 · row_raw 분리 · done 공개의 순서."""
    # 검증 실행 함수 안에서만 본다. 같은 대입문이 복원 경로(_load_app_state)에도
    # 있어서 파일 전체를 훑으면 그쪽이 먼저 잡힌다.
    whole = inspect.getsource(verify)
    start = whole.find("def run_verify(")
    assert start != -1, "run_verify를 찾지 못했다"
    src = whole[start:]

    save = src.find("_save_result(result)")
    reload_ = src.find("published = result_store.load_latest(")
    publish = src.find('_state["result"]       = published')

    assert save != -1, "_save_result(result) 호출을 찾지 못했다"
    assert reload_ != -1, "저장소에서 다시 읽는 지점을 찾지 못했다"
    assert publish != -1, "결과 공개 지점을 찾지 못했다"

    assert save < reload_ < publish, (
        "저장 -> 다시 읽기 -> 공개 순서가 아니다. 저장이 공개보다 뒤면 그 틈에 "
        "서버가 죽었을 때 «화면에는 있는데 재시작하면 없는» 결과가 되고, "
        "다시 읽지 않으면 판정 엔진의 무거운 dict가 그대로 나간다")


@pytest.mark.synthetic
def test_save_result_takes_the_result_as_an_argument():
    """`_state`에서 읽으면 «공개 전에 저장한다»가 성립하지 않는다.

    인자로 받게 해 두면 옛 순서로 되돌리는 순간 호출부가 깨져 눈에 띈다.
    """
    params = list(inspect.signature(verify._save_result).parameters)
    assert params == ["result"], (
        f"_save_result의 인자가 {params} — _state에서 읽는 형태로 되돌아가면 "
        "저장이 공개보다 뒤로 밀린다")


@pytest.mark.synthetic
def test_published_result_comes_from_the_store():
    """화면에 내보내는 것은 «저장소가 돌려준 것»이어야 한다.

    판정 엔진이 만든 dict를 그대로 내보내면 «방금 검증한 직후»와 «재시작 후 복원»이
    다른 모양이 된다. 실제로 두 번 어긋났다 — row_raw(payload의 64%)와 부서/팀
    결함 목록(44%). 한쪽만 고치면 다른 쪽이 조용히 남는다.
    """
    src = _normalize(inspect.getsource(verify))
    assert '_state["result"]       = published' in inspect.getsource(verify), \
        "판정 엔진의 dict를 그대로 공개하고 있다"
    assert "published = result_store.load_latest(include_row_raw=False, " \
           "include_unworked=False, include_flags=False) or result" in src, \
        "공개하는 결과가 저장소를 거치지 않았거나, 무거운 부분을 그대로 싣고 있다"


@pytest.mark.synthetic
def test_restore_path_does_not_load_row_raw():
    """복원 경로도 같은 모양이어야 한다.

    한쪽만 `row_raw`를 갖고 있으면 상세 모달이 «어떤 경로로 들어왔는지»에 따라
    다르게 동작한다 — 개발 중에는 멀쩡해 보이고 재시작 뒤에만 깨진다(또는 그 반대).
    """
    src = _normalize(inspect.getsource(verify))
    assert "load_latest(include_row_raw=False, include_unworked=False, " \
           "include_flags=False)" in src, (
        "복원 시 무거운 부분을 통째로 읽고 있다 — 30만 행이면 서버 메모리에 "
        "~430MB가 올라간다")
