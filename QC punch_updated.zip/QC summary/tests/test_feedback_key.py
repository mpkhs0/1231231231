"""
2-7 검토 기록(feedback) 키 무결성.

검토 키는 `도면번호|Joint No|WPS No|Check No` 4요소다. Joint No 는 도면 안에서만
유일해서(같은 번호가 최대 41개 도면에 존재) 도면번호가 빠지면 무관한 조인트들이
검토 기록을 공유한다 - 실측으로 전체 플래그의 72.6%가 영향권이었다.

주의: `feedback_store.load_feedback()` 은 구 키를 발견하면 **파일을 다시 쓴다**.
테스트가 사용자 데이터를 건드리면 안 되므로 여기서는 파일을 직접 읽기만 하고
(`real_feedback` 픽스처), 키 생성 함수만 호출한다.
"""
from __future__ import annotations

import pytest

import qc_invariants as inv


@pytest.fixture(scope="module")
def make_key():
    """backend 의 실제 키 생성 함수. 임포트 실패 시 skip (수집은 성공해야 한다)."""
    try:
        from backend.services.feedback_store import _make_key
    except Exception as exc:  # pragma: no cover - 환경 문제
        pytest.skip(f"cannot import backend.services.feedback_store: {type(exc).__name__}")
    return _make_key


# ---------------------------------------------------------------------------
# 키 생성 함수 자체 (실데이터 불필요)
# ---------------------------------------------------------------------------
@pytest.mark.synthetic
def test_key_includes_drawing_no(make_key) -> None:
    """같은 Joint/WPS/Check 라도 도면이 다르면 키가 달라야 한다."""
    a = make_key("D-001", "J-20", "TR-A", 3)
    b = make_key("D-002", "J-20", "TR-A", 3)
    assert a != b, "keys collide across drawings: drawing_no is missing from the key"
    assert a.count("|") == 3 and b.count("|") == 3


@pytest.mark.synthetic
def test_key_matches_independent_implementation(make_key) -> None:
    """테스트 쪽 독립 구현과 backend 구현이 같은 키를 낸다 (한쪽이 바뀌면 드러난다)."""
    cases = [
        ("D-001", "J-20", "TR-A", 3),
        ("  D-001  ", " J-20 ", " TR-A ", 14),
        ("", "", "", 0),
    ]
    for args in cases:
        assert make_key(*args) == inv.feedback_key(*args)


@pytest.mark.synthetic
def test_key_strips_whitespace(make_key) -> None:
    assert make_key(" D-001 ", " J-20 ", " TR-A ", 3) == make_key("D-001", "J-20", "TR-A", 3)


# ---------------------------------------------------------------------------
# 저장된 검토 기록 (실데이터)
# ---------------------------------------------------------------------------
@pytest.mark.realdata
def test_stored_feedback_keys_are_drawing_scoped(real_feedback: dict) -> None:
    if not real_feedback:
        pytest.skip("no feedback records yet (data/flag_feedback.json is empty or absent)")
    violations = inv.check_feedback_records(real_feedback)
    assert not violations, "\n".join(f"  - {v}" for v in violations[:20])


@pytest.mark.realdata
def test_stored_feedback_keys_match_backend_key_function(real_feedback: dict, make_key) -> None:
    if not real_feedback:
        pytest.skip("no feedback records yet")
    for key, rec in real_feedback.items():
        if key.count("|") != 3:
            continue  # 마이그레이션 불가로 남겨둔 구 키는 위 테스트에서 별도로 잡는다
        rebuilt = make_key(rec.get("drawing_no", ""), rec.get("joint_no", ""),
                           rec.get("wps_no", ""), rec.get("check_no", 0))
        assert key == rebuilt, (
            f"stored key {inv._a(key)} != {inv._a(rebuilt)} rebuilt from the record"
        )


@pytest.mark.realdata
def test_every_stored_feedback_key_maps_to_one_drawing(real_feedback: dict,
                                                       real_result: dict) -> None:
    """
    저장된 검토 키로 flags 를 되짚었을 때 도면이 2개 이상 나오면,
    한 건을 검토한 것이 무관한 도면의 조인트까지 검토 완료로 만든다.
    """
    if not real_feedback:
        pytest.skip("no feedback records yet")
    groups = inv.group_flags_by_feedback_key(real_result, include_drawing=True)
    for key in real_feedback:
        drawings = groups.get(key)
        if not drawings:
            continue  # 이번 검증 결과에는 없는 과거 기록 (재검증으로 사라진 플래그)
        assert len(drawings) == 1, (
            f"feedback key {inv._a(key)} matches flags on {len(drawings)} drawings"
        )


@pytest.mark.realdata
def test_legacy_key_would_have_shared_records(real_result: dict) -> None:
    """
    회귀 재현: 도면번호가 빠진 구 키로 묶으면 실데이터에서 실제로 충돌이 생긴다.
    이 테스트가 통과한다는 것은 "도면번호를 키에 넣어야 하는 이유"가
    지금 데이터에서도 여전히 유효하다는 뜻이다.
    """
    legacy = inv.group_flags_by_feedback_key(real_result, include_drawing=False)
    shared = {k: v for k, v in legacy.items() if len(v) > 1}
    current = inv.group_flags_by_feedback_key(real_result, include_drawing=True)
    assert all(len(v) == 1 for v in current.values()), (
        "current 4-part key spans multiple drawings: the historical bug is back"
    )
    if not shared:
        pytest.skip("this dataset has no joint number reused across drawings")
    # 정보성: 구 키였다면 몇 개가 섞였을지 (실패 조건이 아니다)
    assert len(shared) > 0


# ── 일괄 라벨링 (현업 확인 결과 반영) ───────────────────────────────────────
@pytest.mark.synthetic
def test_upsert_many_writes_all_records(tmp_path, monkeypatch):
    """현업 확인 한 번으로 수백 건의 성격이 정해지는 경우가 있다.

    예: 「TR-FC-G01이 PJP를 포함한다」는 답변 하나로 Check 4의 600건이 오탐이 된다.
    한 건씩 쓰면 그때마다 파일을 통째로 읽고 쓴다.
    """
    from backend import config
    from backend.services import feedback_store as fb

    monkeypatch.setattr(config, "FEEDBACK_FILE", tmp_path / "fb.json")
    recs = [{"drawing_no": f"D-{i}", "joint_no": "J-1", "wps_no": "W",
             "check_no": 4, "result": "오탐"} for i in range(50)]
    assert fb.upsert_many(recs, reviewer_id="A551135", remark="근거") == 50

    data = fb.load_feedback()
    assert len(data) == 50
    assert all(v["result"] == "오탐" for v in data.values())
    assert all(v["reviewer_id"] == "A551135" for v in data.values())


@pytest.mark.synthetic
def test_upsert_many_records_why(tmp_path, monkeypatch):
    """`remark`에 근거가 남아야 한다.

    이 기록은 지도학습 라벨이 된다. 나중에 «왜 이렇게 붙었는지»를 되짚을 수
    없으면 라벨 자체를 신뢰할 수 없다.
    """
    from backend import config
    from backend.services import feedback_store as fb

    monkeypatch.setattr(config, "FEEDBACK_FILE", tmp_path / "fb.json")
    fb.upsert_many([{"drawing_no": "D", "joint_no": "J", "wps_no": "W",
                     "check_no": 5, "result": "오탐"}],
                   reviewer_id="A551135", remark="[현업확인 2026-08-10] 규칙 삭제")
    rec = next(iter(fb.load_feedback().values()))
    assert "현업확인" in rec["remark"]
    assert rec["updated_at"]


@pytest.mark.synthetic
def test_upsert_many_rejects_unknown_result(tmp_path, monkeypatch):
    """허용되지 않은 판정값이 들어오면 **한 건도 저장하지 않는다.**

    일부만 저장되면 «어디까지 반영됐는지» 알 수 없어 라벨을 믿을 수 없게 된다.
    """
    from backend import config
    from backend.services import feedback_store as fb

    monkeypatch.setattr(config, "FEEDBACK_FILE", tmp_path / "fb.json")
    with pytest.raises(ValueError):
        fb.upsert_many([{"drawing_no": "D", "joint_no": "J", "wps_no": "W",
                         "check_no": 4, "result": "오탐"},
                        {"drawing_no": "E", "joint_no": "J", "wps_no": "W",
                         "check_no": 4, "result": "정상아님"}],
                       reviewer_id="A551135", remark="x")
    assert fb.load_feedback() == {}, "일부만 저장됐다"
