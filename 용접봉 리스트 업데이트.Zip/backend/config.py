import os
from pathlib import Path

BASE           = Path(__file__).parent.parent

# ─── 코드는 한 벌, 데이터는 프로젝트마다 따로 ─────────────────────────────────
#
# 프로젝트가 바뀌면 WPS도 재질별 두께도 부서 구성도 전부 다르다. 한 폴더를 함께
# 쓰면 **RUYA를 돌린 결과가 TRION의 결과 DB를 덮어쓰고**, 검토 기록 키
# (`도면번호|Joint No|WPS No|Check No`)가 프로젝트를 가리지 않아 남의 프로젝트
# 의견이 붙는다. 그래서 저장소는 하나로 두고 **데이터 폴더만** 갈라 놓는다.
#
#     QC_DATA_DIR=c:\QC data\TRION   포트 8001
#     QC_DATA_DIR=c:\QC data\RUYA    포트 8002
#
# **기본값은 지금 자리(BASE)다.** 환경변수를 안 주면 예전과 완전히 같게 돈다 —
# 이미 쓰고 있는 설치를 옮기지 않아도 된다.
DATA_ROOT = Path(os.environ.get("QC_DATA_DIR") or BASE).resolve()
_DATA     = DATA_ROOT / "data"
_SHARED   = BASE / "data"

# 어느 프로젝트의 서버인가. 화면 상단에 띄운다 — **두 서버를 동시에 띄워 놓고
# 어느 쪽을 보고 있는지 모르는 것**이 이 구조에서 가장 현실적인 사고다.
# 표시용일 뿐이고, 판정 기준은 여전히 `project_rules.json`의 활성 프로파일이다.
PROJECT_NAME = os.environ.get("QC_PROJECT") or (
    "" if DATA_ROOT == BASE.resolve() else DATA_ROOT.name)

UPLOADS_DIR    = DATA_ROOT / "qc_uploads"
RESULTS_DIR    = DATA_ROOT / "qc_results"
# 부서/팀 범위별 결과 Excel. 재검증하면 통째로 버린다(routers/exports.invalidate).
EXPORTS_DIR    = RESULTS_DIR / "scoped"


def _find_wps_ref() -> Path:
    """WPS 참조 .xlsm을 찾는다. **파일 이름을 코드에 박지 않는다.**

    프로젝트마다 파일 이름이 다르다(`…For Structure(테스트R5).xlsm`은 TRION의
    이번 회차 이름일 뿐이다). 이름을 박아 두면 새 프로젝트는 파일을 제자리에
    놓고도 «WPS를 못 읽는다»가 되고, 원인이 파일 이름이라는 것은 알기 어렵다.

    `Raw data/`의 `.xlsm` 하나를 쓴다. 둘 이상이면 이름순 첫 번째 —
    고르지 못해 죽는 것보다 낫고, 어느 것을 썼는지는 로그와 화면에 나온다.
    없으면 그 폴더를 가리키는 경로를 돌려준다(오류 메시지가 어디를 봐야 하는지
    말해 준다). `QC_WPS_REF`로 직접 지정할 수도 있다.
    """
    override = os.environ.get("QC_WPS_REF")
    if override:
        return Path(override)
    raw = DATA_ROOT / "Raw data"
    try:
        found = sorted(p for p in raw.glob("*.xlsm") if not p.name.startswith("~$"))
    except OSError:
        found = []
    return found[0] if found else raw / "WPS_참조파일을_여기에_두세요.xlsm"


WPS_REF          = _find_wps_ref()
WPS_CACHE        = _DATA / "wps_cache.json"
# 승인 용접봉 리스트(Lot No. 집합). WPS 캐시와 같은 성격 — **프로젝트별**이다.
# 승인 목록은 프로젝트마다 다르고, 공용에 두면 남의 프로젝트 목록으로 판정한다.
CONSUMABLE_CACHE = _DATA / "consumable_cache.json"
# WPS 번호에 묶인 판정 규칙(Check 5/8/9, 수리 WPS 접두사, §11-1 override).
# 없으면 wps_rules.DEFAULTS를 쓰므로 동작이 바뀌지 않는다.
WPS_RULES_FILE   = _DATA / "wps_rules.json"
FRONTEND_DIR     = BASE / "frontend"
STATIC_DIR       = FRONTEND_DIR / "static"
# 로그인 사번과 Outlook 발신 설정은 **이 PC의 것**이지 프로젝트의 것이 아니다.
# 프로젝트마다 갈라 두면 서버를 하나 더 띄울 때마다 사번을 다시 등록해야 하고,
# 등록을 빠뜨린 쪽은 «로그인이 안 된다»가 된다. 그래서 저장소에 함께 둔다.
EMPLOYEES_FILE   = _SHARED / "employees.json"
OUTLOOK_SETTINGS = _SHARED / "outlook_settings.json"
APP_STATE_FILE   = _DATA / "app_state.json"
# 검증 결과 저장소. app_state.json을 대체한다 (개선계획 1번).
# JSON은 30만 행에서 609MB가 되어 «느린»게 아니라 성립하지 않는다.
# app_state.json이 있고 DB가 없으면 첫 기동에 1회 옮겨 담는다 (result_store.migrate).
RESULT_DB        = _DATA / "qc.db"

# `/api/flags` 한 요청이 돌려줄 수 있는 최대 플래그 수.
#
# 화면 대부분은 한 페이지(50건)만 쓰지만, **한 덩어리로 봐야 하는 화면 둘**이
# 전량을 받는다:
#   - 용접사 상세 — Check별 분포·검토 집계·월별 차트를 그 용접사의 전 플래그로 낸다
#   - Check 14 그룹 보기 — 그룹 단위라 페이지로 자를 수 없다
#
# 실측(1만 행)에서 가장 많은 용접사가 382건이라 30만 행이면 ~11,000건이 된다.
# 그래서 여유를 두되 무제한으로 두지는 않는다 — 잘못된 질의 하나가 서버 메모리를
# 통째로 먹는 것을 막는 마지막 방어선이다. 플래그 1건이 약 0.56KB다.
MAX_FLAG_PAGE    = 20000
DEPT_RECIPIENTS_FILE = _DATA / "dept_recipients.json"
# 팀별 수신인. `{부서: {팀: [메일주소]}}` — 부서 아래 중첩해 둔다.
# 팀 이름만으로 키를 잡지 않는 이유: 팀 이름이 부서 안에서만 유일하다는 보장이 없다
# (현재 데이터에서는 23개 팀이 서로 겹치지 않지만, 그건 이번 물량의 성질일 뿐이다).
TEAM_RECIPIENTS_FILE = _DATA / "team_recipients.json"
FEEDBACK_FILE    = _DATA / "flag_feedback.json"
# 프로젝트별 판정 항목 취사선택 + 현업이 낸 신규 규칙 요청.
# **끈 항목은 판정 자체를 하지 않으므로 바꾸면 재검증이 필요하다.**
PROJECT_RULES_FILE = _DATA / "project_rules.json"

# 서브에이전트 정의(.claude/agents/*.md)와 그 실행 리포트.
# 리포트는 Claude Code에서 에이전트를 실행할 때마다 에이전트 자신이 파일로 남기고,
# 서버는 읽기만 한다 ('에이전트' 탭). 서버가 에이전트를 실행하지는 않는다.
# 에이전트 정의와 리포트는 **코드에 대한 것**이라 프로젝트별로 갈라지지 않는다.
AGENTS_DIR         = BASE / ".claude" / "agents"
AGENT_REPORTS_DIR  = _SHARED / "agent_reports"

# 검사 로직 정본 문서. §11(확인 필요 사항)이 '현업 검증사항' 탭의 데이터 원본이며,
# 서버가 현업 답변을 이 파일에 되쓴다 (backend/services/review_items.py).
# 소스코드와 함께 git으로 추적되는 파일이라 data/ 아래가 아니라 저장소 루트에 있다.
ANALYSIS_DOC       = BASE / "QC_검사로직_상세분석.md"
