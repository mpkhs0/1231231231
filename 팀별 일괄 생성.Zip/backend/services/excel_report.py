"""
결과 Excel 생성기 — 요약/결함목록/원본마킹/미작업/검토기록 시트를 한 파일로 묶는다.

## 왜 원본 시트만으로는 부족했나

기존 산출물은 QMG 원본(10,034행 x 78열)을 복사해 결함 셀에 색을 칠하고 주석을 다는
방식이었다. 현장 양식 그대로라는 장점이 있지만:

- 주석이 **hover로만** 보여서 인쇄하거나 스캔하면 지적 내용이 사라진다
- 원본 위 색칠이라 **필터/정렬/피벗이 불가능**하다 - 받는 사람이 "우리 팀 Check 3만"을
  뽑아보려면 손으로 찾아야 한다
- 결함 46행을 받자고 10,034행짜리 파일을 뒤져야 하는 부서가 있다

그래서 원본 시트는 **그대로 두고**(현장이 익숙한 양식을 깨지 않는다) 그 앞에
집계/평면 시트를 얹는다. '결함 목록' 시트가 핵심으로, 플래그 1건이 1행이 되어
엑셀에서 자유롭게 다룰 수 있다.

## 전부 «흘려보내며» 쓴다 — 38만 행에서 먹통이 됐다

예전에는 원본 워크북을 `load_workbook()`으로 통째로 올려 색을 칠하고, 범위 밖 행을
`delete_rows`로 지웠다. 둘 다 규모에 무너졌다:

    전체 로드    행 수에 그대로 비례. 실측 프로세스 최대 메모리
                 10,034행 590MB · 60,179행 2,864MB -> 38만 행 약 17GB (OOM)
    delete_rows  '남길 행 수'가 아니라 '흩어진 정도'에 비례
                 Q520(4,430행 유지, 연속구간 79개): 삭제만 39초

지금은 `read_only`로 읽어 `write_only`로 쓴다. 범위 밖 행은 **쓰지 않으면 그만**이라
삭제 비용이 아예 사라지고, 메모리가 행 수와 무관해진다.

    10,034행   590MB -> 223MB
    60,179행 2,864MB -> 681MB          38만 행 외삽 17GB -> 3.6GB

    (남는 3.6GB는 이 모듈이 아니라 판정 결과 payload 쪽이다)

**시간은 조금 늘었다**(60k 기준 146초 -> 210초). 셀마다 객체를 만들어 서식 색인을
꽂는 값이다. 백그라운드에서 도는 단계이고, 대신 예전에는 아예 끝나지 않았다.

## 옛 방식과 결과가 «같은지» 대조해서 만들었다

`tests/test_excel_streaming.py`가 옛 구현(`_mark_original` + `_shrink_to_scope`)으로
만든 파일과 셀 단위로 비교한다 — 값·채움·글꼴·테두리·정렬·표시형식·주석까지.
그 대조가 실제로 둘을 잡았다:

1. 본문 글꼴이 원본 Arial 9pt에서 엑셀 기본값 Calibri 11pt로 바뀌던 것
2. 마킹이 **공유 서식 색인을 덮어써서** 결함 4,321건이 8만 6천 셀을 물들이던 것

둘 다 예외가 나지 않고, 파일만 열어 보면 그럴듯하다.
"""

from __future__ import annotations

import io
import logging
import os
import re
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter, defaultdict
from copy import copy
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from . import project_checks
from openpyxl import Workbook, load_workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.styles.cell_style import StyleArray
from openpyxl.utils import get_column_letter
from openpyxl.utils.cell import coordinate_to_tuple
from openpyxl.worksheet.dimensions import ColumnDimension
from openpyxl.worksheet.worksheet import Worksheet

from . import wps_rules

logger = logging.getLogger(__name__)

# 시트/스타일 XML의 네임스페이스. 부품을 직접 읽을 때 쓴다.
_XL_NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"

# 원본 시트에서 부서/팀을 읽는 열 (1-based). verifier.Col과 같은 값이지만
# 이 모듈이 verifier를 임포트하지 않도록 여기 다시 둔다 - 순환 임포트를 피하고,
# 이 파일만 봐도 무엇을 읽는지 알 수 있게 한다.
COL_DRAWING_NO = 1    # A
COL_DEPARTMENT = 58   # BF
COL_TEAM = 59         # BG

# 원본 시트에서 헤더로 보존할 상단 행 수. verifier의 헤더 탐지와 무관하게,
# 실데이터에서 데이터가 6행부터 시작하므로 5행까지는 무조건 남긴다.
HEADER_ROWS = 5

_HDR_FILL = PatternFill("solid", start_color="1F3864", end_color="1F3864")
_HDR_FONT = Font(color="FFFFFF", bold=True, size=10)
_TITLE_FONT = Font(bold=True, size=14)
_SUB_FONT = Font(color="808080", size=9)
_THIN = Side(style="thin", color="BFBFBF")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

# Check 색상 -> 엑셀 채움색 (verifier._FILLS와 같은 값).
#
# 위 COL_* 와 같은 이유로 verifier를 임포트하지 않고 값을 다시 둔다. 대신 어긋나면
# `tests/test_excel_report.py::test_check_colors_match_verifier`가 잡는다 —
# Check를 추가할 때 원본 시트는 새 색으로 칠해지는데 '결함 목록' 시트만 색이
# 빠지는 일이 생기고, 예외가 나지 않아 발견이 늦기 때문이다.
_CHECK_COLOR = {
    "Red": "FF0000", "Green": "00B050", "Blue": "0070C0", "Yellow": "FFFF00",
    "Orange": "FF7F00", "Black": "000000", "Purple": "7030A0", "Teal": "008080",
    "Gray": "BFBFBF", "Cyan": "00B0C0", "Brown": "833C00",
    "Olive": "808000", "Navy": "1F3864", "Rose": "C0504D",
    "Maroon": "7B2E2E", "Indigo": "4B3F8F",
}

def _source_handle(qmg_path: str | Path):
    """원본을 여는 «손잡이». DRM이면 변환본 bytes, 아니면 경로 그대로.

    ## 왜 필요한가

    이 모듈은 원본을 **네 번** 연다 — 기본 글꼴(styles.xml) · 열너비/병합
    (시트 XML) · 반복 머리말(workbook.xml) · 본문 스트리밍. 앞의 셋은
    속도 때문에 `zipfile`로 **직접** 여는데, DRM 파일은 zip이 아니라
    `BadZipFile`로 죽는다.

    그렇다고 열 때마다 변환하면 Excel COM subprocess가 네 번 뜬다. 그래서
    **한 번만 변환해 bytes를 돌려쓴다.**

    DRM이 아니면 `None`을 돌려준다 — 경로로 여는 편이 메모리를 안 쓴다.
    """
    try:
        from . import drm_convert
    except ImportError:
        return None                      # DRM 모듈이 없는 설치
    p = Path(qmg_path)
    if not drm_convert.is_drm(p):
        return None
    logger.info("DRM 원본 — 결과 Excel 생성용으로 1회 변환한다: %s", p.name)
    return drm_convert.convert_to_bytes(p)


def _open_zip(qmg_path: str | Path, raw: bytes | None):
    """부품(styles/workbook/시트 XML)을 읽으려고 zip으로 연다."""
    return zipfile.ZipFile(io.BytesIO(raw) if raw is not None else str(qmg_path))


def _open_source(qmg_path: str | Path, raw: bytes | None, **kw):
    """본문을 흘려보내려고 워크북으로 연다."""
    return load_workbook(io.BytesIO(raw) if raw is not None else str(qmg_path), **kw)


def _save_atomically(wb: Any, out: Path) -> None:
    """**옆에 쓰고 마지막에 바꿔 끼운다.** 최종 경로에 직접 쓰지 않는다.

    ## 왜

    이 파일은 **쓰는 동안에도 다운로드 대상**이다(`GET /api/result/excel`).
    최종 경로에 바로 쓰면 그 시간 내내 «크기는 있는데 열리지 않는 파일»이
    거기 놓여 있다.

    38만 행이면 그 창이 20분을 넘는다. 실제로 회사 PC에서 브라우저가
    「다운로드할 수 없음」을 띄우고 **부분 파일만 남았다.** 내려받는 도중에
    파일이 계속 자라면 Content-Length가 맞지 않아 브라우저가 연결을 끊는다.

    `excel_status == "generating"` 가드가 있지만 그건 **메모리 상태**다.
    서버를 재시작하거나 생성이 도중에 죽으면(38만 행 OOM이 정확히 그랬다)
    그 가드가 사라지고 반쯤 쓰인 파일만 남는다. 게다가 복원 판단이 mtime만
    보므로 **반쪽짜리가 «새것»으로 통과한다.**

    `os.replace()`는 같은 볼륨 안에서 원자적이다. 그래서 받는 쪽에서 보이는
    것은 **언제나 «옛 완성본» 아니면 «새 완성본»**이고, 그 중간은 없다.
    이 저장소가 정본 문서를 되쓸 때 쓰는 방식과 같다(`review_items`).
    """
    tmp = out.with_name(f"~{out.stem}.tmp{out.suffix}")
    try:
        wb.save(str(tmp))
        os.replace(str(tmp), str(out))
    finally:
        # 저장이 실패하면 찌꺼기가 남는다. 다음 회차가 같은 이름을 다시 쓰긴
        # 하지만, `~`로 시작해 엑셀 잠금 파일처럼 보이므로 치워 둔다.
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                logger.warning("임시 파일을 지우지 못했다: %s", tmp)


def _adopt_default_font(dst_wb: Any, qmg_path: str | Path,
                        raw: bytes | None = None) -> None:
    """대상 워크북의 **기본 글꼴**을 원본 것으로 맞춘다.

    예전에는 원본 워크북을 열어서 시작했으므로 기본 글꼴(이 양식은 돋움 11pt)을
    저절로 물려받았다. 새 워크북에서 시작하면 엑셀 기본값인 Calibri가 된다.

    이건 **서식을 지정하지 않은 모든 셀**에 적용된다 — 요약·결함목록·미작업·
    검토기록 네 시트가 통째로 해당한다. 값도 색도 그대로라 diff로는 «값 0 차이»가
    나오고, 받는 사람만 「글꼴이 왜 달라졌지」 하게 된다.

    **`load_workbook()`으로 열지 않는다.** `read_only=True`라도 여는 것만으로
    파일 크기에 비례하는 일을 한다 — 실측 10,034행 0.05초 / 60,179행 **12.4초**다.
    글꼴 하나 보려고 그 값을 치를 이유가 없고, 38만 행이면 혼자 1분을 넘는다.

    `xl/styles.xml`의 첫 `<font>`가 곧 기본 글꼴이다. 이건 34KB짜리 부품이라
    통째로 읽어도 **0.002초**다. openpyxl이 같은 파일에서 읽어 내는 값과
    일치함을 확인했다.
    """
    try:
        with _open_zip(qmg_path, raw) as z:
            root = ET.fromstring(z.read("xl/styles.xml"))
        fonts = root.find(f"{_XL_NS}fonts")
        if fonts is not None and len(fonts):
            dst_wb._fonts[0] = Font.from_tree(fonts[0])
    except Exception:
        logger.exception("원본의 기본 글꼴을 읽지 못했다 — 엑셀 기본값으로 진행한다")


def _style_porter(src_wb: Any, dst_wb: Any) -> Callable[[Any], Any]:
    """원본 셀의 서식을 대상 워크북 «색인»으로 옮기는 변환기를 만든다.

    ## 왜 항목별 복사가 아닌가

    `cell.font = copy(src.font)` 식으로 여섯 항목을 옮기면 **셀마다 여섯 번**
    등록이 일어난다. 38만 행 x 78열이면 1억 8천만 번이라 끝나지 않는다.

    엑셀은 서식을 셀마다 들고 있지 않다 — 워크북의 표를 가리키는 **색인**만
    들고 있다(`StyleArray`). 실데이터에서 서로 다른 서식은 **124종**뿐이다.
    그래서 종류마다 한 번씩만 옮겨 두고, 셀에는 색인을 그대로 꽂는다.

    ## 이걸 안 하면 조용히 바뀐다

    빠뜨리면 본문 글꼴이 원본 Arial 9pt에서 **Calibri 11pt(엑셀 기본값)** 로
    바뀐다. 값도 색도 주석도 멀쩡해서 diff로는 안 잡히고, 받는 사람이 «폰트가
    왜 달라졌지» 하고 넘긴다. 실제로 첫 구현에서 그렇게 나왔다.
    """
    cache: dict[tuple, Any] = {}

    def port(sa: Any) -> Any:
        key = tuple(sa)
        got = cache.get(key)
        if got is None:
            got = StyleArray()
            got.fontId = dst_wb._fonts.add(copy(src_wb._fonts[sa.fontId]))
            got.fillId = dst_wb._fills.add(copy(src_wb._fills[sa.fillId]))
            got.borderId = dst_wb._borders.add(copy(src_wb._borders[sa.borderId]))
            got.alignmentId = dst_wb._alignments.add(copy(src_wb._alignments[sa.alignmentId]))
            got.protectionId = dst_wb._protections.add(
                copy(src_wb._protections[sa.protectionId]))
            # 164 미만은 엑셀 내장 표시형식이라 표에 없다 — 번호를 그대로 쓴다.
            nf = sa.numFmtId
            got.numFmtId = (164 + dst_wb._number_formats.add(src_wb._number_formats[nf - 164])
                            if nf >= 164 else nf)
            cache[key] = got
        return got

    return port


# ─── 범위 필터 ────────────────────────────────────────────────────────────────
class Scope:
    """내보낼 범위. dept/team이 모두 None이면 전체.

    `exclude_temp`는 임시부재(도면번호 1C*)를 파일에서 통째로 뺀다 — 대시보드
    토글과 같은 규칙이다. **범위와 함께 파일 이름·캐시 키에 들어가야 한다.**
    같은 부서인데 내용이 다른 두 파일이 생기므로, 구분되지 않으면 «1C를 뺀 줄
    알고 받았는데 들어 있는» 파일이 나간다. 그건 받은 사람이 열어 보기 전에는
    알 수 없다.
    """

    def __init__(self, dept: str | None = None, team: str | None = None,
                 exclude_temp: bool = False):
        self.dept = (dept or "").strip() or None
        self.team = (team or "").strip() or None
        self.exclude_temp = bool(exclude_temp)
        if self.team and not self.dept:
            raise ValueError("팀을 지정하려면 부서도 지정해야 합니다")

    @property
    def is_all(self) -> bool:
        """조직 범위가 «전체»인가. 임시부재 제외와는 무관하다."""
        return self.dept is None

    @property
    def keeps_every_row(self) -> bool:
        """행을 하나도 걸러내지 않는가 — 원본 시트를 줄일 필요가 있는지 판단."""
        return self.is_all and not self.exclude_temp

    @property
    def label(self) -> str:
        base = f"{self.dept} > {self.team}" if self.team else (self.dept or "전체")
        return base + (" · 임시부재 제외" if self.exclude_temp else "")

    def slug(self) -> str:
        """파일명에 쓸 수 있는 형태. 경로 구분자/공백을 없앤다."""
        raw = "전체" if self.is_all else (
            f"{self.dept}_{self.team}" if self.team else self.dept)
        out = "".join(ch for ch in raw if ch.isalnum() or ch in "-_가-힣" or ord(ch) > 127)
        return out + ("_임시부재제외" if self.exclude_temp else "")

    def matches(self, dept: Any, team: Any, drawing_no: Any = None) -> bool:
        if self.exclude_temp and wps_rules.is_temp_member(drawing_no):
            return False
        if self.is_all:
            return True
        if (dept or "").strip() != self.dept:
            return False
        if self.team and (team or "").strip() != self.team:
            return False
        return True

    def filter_flags(self, flags: list[dict]) -> list[dict]:
        if self.keeps_every_row:
            return flags
        return [f for f in flags
                if self.matches(f.get("department"), f.get("team"),
                                f.get("drawing_no"))]


# ─── 스트리밍 쓰기 어댑터 ─────────────────────────────────────────────────────
#
# ## 왜 필요한가 — 38만 행에서 먹통이 됐다
#
# 예전에는 원본 워크북을 `load_workbook()`으로 통째로 올려 색을 칠했다. openpyxl은
# 셀 하나마다 파이썬 객체를 만들므로 비용이 **행 수에 그대로 비례**한다. 실측:
#
#     10,034행 x 78열 -> 19.8초 / 275MB      (행당 28KB)
#     380,000행 외삽  -> 12.5분 / 10,200MB
#
# 일반 PC에서는 스왑으로 죽는다. 화면에는 「검증은 끝났는데 Excel이 안 나온다」로만
# 보인다. 판정은 `read_only=True`로 이미 스트리밍하고 있었는데, **마킹 단계만**
# 전체 로드였다.
#
# `write_only=True`로 바꾸면 메모리가 행 수와 무관해진다. 다만 그 모드의 시트는
# `append()`만 받고 `ws.cell(row=, column=)`을 못 쓴다 — 요약·결함목록·미작업·
# 검토기록 네 시트가 전부 그 방식으로 쓰여 있다.
#
# 그 네 곳을 고쳐 쓰는 대신 **어댑터를 하나 둔다.** 네 시트 모두 위에서 아래로만
# 쓰므로(행 번호가 되돌아가지 않는다), 행이 넘어가는 순간 앞 행을 흘려보내면
# 같은 코드가 그대로 돈다. 시트 코드를 건드리지 않는 편이 서식이 조용히 어긋날
# 여지가 적다.

# 첫 행을 내보내기 전에 몇 행까지 손에 들고 있을 것인가.
#
# **write_only는 `<sheetView>`와 `<cols>`를 행보다 «먼저» 쓴다.** 그래서 첫
# `append()` 뒤에 건 틀 고정·열 너비는 **조용히 버려진다** — 예외도 경고도 없다.
# 네 시트 모두 `_title`(1~2행) 다음 `_write_header`(4행)에서 그 둘을 거는데,
# 버퍼가 없으면 제목 두 줄이 먼저 나가 버려서 전부 사라진다. 실제로 그렇게 나왔다
# (열 너비 34개·틀 고정 3개가 통째로 빠졌고 셀 단위 비교로는 안 잡혔다).
#
# 머리말 구간은 어느 시트든 열 손가락 안쪽이다. 넉넉히 잡아도 64행 x 20열이라
# 메모리에 영향이 없다.
_HEADER_BUFFER = 64


class _StreamSheet:
    """`ws.cell(row=, column=)`으로 쓰는 코드를 write_only 시트에 얹는다.

    **행 번호가 되돌아가면 예외를 낸다.** 스트리밍은 지나간 행을 고칠 수 없어서,
    조용히 무시하면 그 셀이 결과 파일에서 사라진다 — 오류 없이 빈 칸이 된다.

    첫 `_HEADER_BUFFER`행은 손에 들고 있는다 — 그 사이에 걸린 틀 고정·열 너비만
    파일에 남기 때문이다. 그 뒤에 걸면 **예외를 낸다**(`freeze_panes`). 조용히
    버려지면 「스크롤하면 머리말이 사라진다」로만 드러나고, 그건 아무도 신고하지
    않는 종류의 결함이다.
    """

    def __init__(self, ws: Any) -> None:
        object.__setattr__(self, "_ws", ws)
        object.__setattr__(self, "_row", 0)       # 지금 모으는 중인 행
        object.__setattr__(self, "_cells", {})    # column -> WriteOnlyCell
        object.__setattr__(self, "_emitted", 0)   # 이미 내보낸 마지막 행
        object.__setattr__(self, "_buffer", [])   # 아직 안 내보낸 행들
        object.__setattr__(self, "_started", False)

    # ── 행/열 접근 ──────────────────────────────────────────────────────────
    def cell(self, row: int, column: int, value: Any = None):
        if row < self._row:
            raise ValueError(
                f"이미 지나간 행({row} < {self._row})에 쓰려고 했다 — "
                "스트리밍 쓰기에서는 되돌아갈 수 없다")
        if row != self._row:
            self._emit_through(row - 1)
            object.__setattr__(self, "_row", row)
            object.__setattr__(self, "_cells", {})
        c = self._cells.get(column)
        if c is None:
            c = WriteOnlyCell(self._ws, value=value)
            # `_write_header`가 `freeze_panes = ws.cell(...)`로 셀을 넘긴다.
            # 좌표가 있어야 그게 그대로 동작한다.
            c.row, c.column = row, column
            self._cells[column] = c
        elif value is not None:
            c.value = value
        return c

    def __getitem__(self, coord: str):
        row, col = coordinate_to_tuple(coord)
        return self.cell(row=row, column=col)

    def __setitem__(self, coord: str, value: Any) -> None:
        self.__getitem__(coord).value = value

    # ── 시트 속성은 그대로 넘긴다 ───────────────────────────────────────────
    def __getattr__(self, name: str) -> Any:
        return getattr(self._ws, name)

    def __setattr__(self, name: str, value: Any) -> None:
        if name == "freeze_panes" and self._started:
            raise ValueError(
                "행을 내보내기 시작한 뒤에 틀 고정을 걸었다 — write_only는 "
                "`<sheetView>`를 행보다 먼저 쓰므로 이 설정은 파일에 남지 않는다")
        setattr(self._ws, name, value)

    # ── 흘려보내기 ──────────────────────────────────────────────────────────
    def _emit_through(self, last: int) -> None:
        """`_emitted+1`부터 `last`까지 «버퍼에» 넣는다. 빈 행은 빈 행으로."""
        for r in range(self._emitted + 1, last + 1):
            if r == self._row and self._cells:
                width = max(self._cells)
                self._buffer.append([self._cells.get(i) for i in range(1, width + 1)])
            else:
                self._buffer.append([])
        object.__setattr__(self, "_emitted", max(self._emitted, last))
        if len(self._buffer) > _HEADER_BUFFER:
            self._drain()

    def _drain(self) -> None:
        """버퍼를 실제 시트로 흘려보낸다. 이 시점부터 머리말 설정은 늦는다."""
        if self._buffer:
            object.__setattr__(self, "_started", True)
            for row in self._buffer:
                self._ws.append(row)
            object.__setattr__(self, "_buffer", [])

    def close(self) -> None:
        self._emit_through(self._row)
        self._drain()


def _stream_sheet(wb: Any, title: str, index: int | None = None) -> _StreamSheet:
    ws = wb.create_sheet(title) if index is None else wb.create_sheet(title, index)
    return _StreamSheet(ws)


# ─── 원본 시트의 «본문 밖» 정보 ───────────────────────────────────────────────
def _source_layout(path: str | Path, raw: bytes | None = None) -> dict[str, Any]:
    """열 너비·병합·자동필터를 **본문을 훑지 않고** 가져온다.

    `read_only` 워크시트는 이것들을 내주지 않는다(`column_dimensions`가 없다).
    그렇다고 전체 로드로 돌아갈 수는 없어서 시트 XML에서 직접 뽑는다.

        <cols>        맨 앞          (sheetData 앞)
        <mergeCells>  맨 뒤
        <autoFilter>  맨 뒤

    앞 64KB와 **뒤 256KB**만 본다. 뒤쪽은 압축 스트림이라 끝으로 건너뛸 수 없어
    한 번 흘려보내되, 꼬리 버퍼만 남겨 메모리를 묶는다. 실측 0.07초.

    없으면 빈 값을 돌려준다 — 이 정보가 빠져도 값은 멀쩡하므로, 여기서 예외를
    내면 «서식 때문에 산출물이 아예 안 나오는» 상태가 된다.
    """
    head_n, tail_n = 64 * 1024, 256 * 1024
    try:
        with _open_zip(path, raw) as z:
            names = sorted(n for n in z.namelist()
                           if n.startswith("xl/worksheets/sheet"))
            if not names:
                return {"cols": [], "merges": [], "auto_filter": None}
            with z.open(names[0]) as fh:
                head = fh.read(head_n)
                tail = head
                while True:
                    chunk = fh.read(1024 * 1024)
                    if not chunk:
                        break
                    tail = (tail + chunk)[-tail_n:]
    except Exception:
        logger.exception("원본 시트 레이아웃을 읽지 못했다 — 열 너비/병합 없이 진행한다")
        return {"cols": [], "merges": [], "auto_filter": None}

    cols = []
    for m in re.finditer(rb'<col ([^>]*?)/?>', head):
        a = m.group(1).decode("utf-8", "replace")
        def attr(k: str) -> str | None:
            mm = re.search(rf'{k}="([^"]*)"', a)
            return mm.group(1) if mm else None
        lo, hi, w = attr("min"), attr("max"), attr("width")
        if lo and hi and w:
            cols.append((int(lo), int(hi), float(w), attr("hidden") == "1"))
    merges = [m.group(1).decode() for m in re.finditer(rb'<mergeCell ref="([^"]+)"', tail)]
    af = re.search(rb'<autoFilter ref="([^"]+)"', tail)

    # 인쇄 설정도 함께 가져온다. 예전에는 원본 워크북을 열어서 시작했으니 저절로
    # 물려받았다 — 새 워크북에서 시작하면 «가로/세로»와 «반복할 머리말 행»이
    # 사라진다. 현장에서 출력해 쓰는 시트라 이건 실제로 눈에 띈다.
    page: dict[str, Any] = {}
    pm = re.search(rb'<pageSetup ([^>]*)>', tail)
    if pm:
        a = pm.group(1).decode("utf-8", "replace")
        for k in ("orientation", "paperSize", "scale", "fitToWidth", "fitToHeight"):
            v = re.search(rf'{k}="([^"]*)"', a)
            if v:
                page[k] = v.group(1)
    mm = re.search(rb'<pageMargins ([^>]*)>', tail)
    if mm:
        a = mm.group(1).decode("utf-8", "replace")
        page["margins"] = {k: float(v) for k, v in
                           re.findall(r'(left|right|top|bottom|header|footer)="([^"]*)"', a)}

    return {"cols": cols, "merges": merges, "page": page,
            "auto_filter": af.group(1).decode() if af else None,
            # `_xlnm.Print_Titles`는 시트가 아니라 **워크북**의 정의된 이름에 있다.
            "print_titles": _print_titles(path, raw)}


def _print_titles(path: str | Path, raw: bytes | None = None) -> str | None:
    """원본의 «반복할 머리말 행»(`$1:$5`). 워크북 XML에서 뽑는다."""
    try:
        with _open_zip(path, raw) as z:
            wbx = z.read("xl/workbook.xml").decode("utf-8", "replace")
    except Exception:
        return None
    m = re.search(r'<definedName name="_xlnm\.Print_Titles"[^>]*>(.*?)</definedName>', wbx)
    if not m:
        return None
    # `'QMG4520'!$1:$5` -> `1:5`
    ref = m.group(1).split("!")[-1].replace("$", "")
    return ref or None


# ─── 시트 공통 헬퍼 ───────────────────────────────────────────────────────────
def _write_header(ws: Worksheet, row: int, headers: list[tuple[str, int]]) -> None:
    """헤더 행 + 열 너비 + 자동필터 + 틀 고정을 한 번에."""
    for i, (name, width) in enumerate(headers, start=1):
        c = ws.cell(row=row, column=i, value=name)
        c.fill = _HDR_FILL
        c.font = _HDR_FONT
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = _BORDER
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.auto_filter.ref = f"A{row}:{get_column_letter(len(headers))}{row}"
    ws.freeze_panes = ws.cell(row=row + 1, column=1)


def _title(ws: Worksheet, text: str, sub: str) -> int:
    """시트 제목 2줄을 쓰고 다음 사용 가능 행을 돌려준다."""
    ws["A1"] = text
    ws["A1"].font = _TITLE_FONT
    ws["A2"] = sub
    ws["A2"].font = _SUB_FONT
    return 4


def _setup_print(ws: Worksheet, landscape: bool = True, repeat_row: int | None = None) -> None:
    """인쇄 설정 — 현장에서 출력해 쓰는 경우가 많다."""
    ws.page_setup.orientation = "landscape" if landscape else "portrait"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    if repeat_row:
        ws.print_title_rows = f"{repeat_row}:{repeat_row}"


# ─── ① 요약 시트 ──────────────────────────────────────────────────────────────
def _sheet_summary(wb, result: dict, scope: Scope, flags: list[dict]) -> None:
    ws = _stream_sheet(wb, "요약", 0)
    r = _title(ws, f"QC 검증 요약 — {scope.label}",
               f"검증 실행 {result.get('run_at', '')} · 원본 {result.get('qmg_filename', '')}")

    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 14
    ws.column_dimensions["C"].width = 46

    def kv(label: str, value: Any, note: str = "") -> None:
        nonlocal r
        ws.cell(row=r, column=1, value=label).font = Font(bold=True)
        c = ws.cell(row=r, column=2, value=value)
        c.alignment = Alignment(horizontal="right")
        ws.cell(row=r, column=3, value=note).font = _SUB_FONT
        r += 1

    # 범위에 맞는 집계를 고른다. 전체면 최상위 값, 부서/팀이면 그 버킷 값.
    bucket = _scope_bucket(result, scope)
    judged = bucket.get("total_rows", 0)
    defect_rows = len({f["row"] for f in flags})
    clean = max(judged - defect_rows, 0)

    kv("판정 대상", judged, "삭제/미작업을 제외한 행 — 모든 결함률의 분모")
    kv("결함 발생", defect_rows, f"판정 대상의 {defect_rows / judged * 100:.1f}%" if judged else "")
    kv("이상 없음", clean, f"판정 대상의 {clean / judged * 100:.1f}%" if judged else "")
    kv("미작업", bucket.get("unworked_rows", 0), "Check 0 — 결함이 아니며 분모에서 제외")
    kv("총 지적 건수", len(flags), "한 행에 여러 Check가 걸릴 수 있어 결함 행수보다 많다")
    r += 1

    # Check별
    ws.cell(row=r, column=1, value="검사 항목별 지적 건수").font = Font(bold=True, size=11)
    r += 1
    _write_header(ws, r, [("Check", 10), ("건수", 10), ("검사 이름", 46)])
    hdr = r
    r += 1
    by_check = Counter(f["check_no"] for f in flags)
    names = {f["check_no"]: f["check_name"] for f in flags}
    colors = {f["check_no"]: f["color"] for f in flags}
    # 식별자가 «3»과 «RUYA1»로 섞인다 — 기본 정렬은 문자열 순이라
    # `10`이 `2`보다 앞에 온다. 공통을 숫자순으로 먼저 둔다.
    for no, cnt in sorted(by_check.items(), key=lambda kv: project_checks.sort_key(kv[0])):
        ws.cell(row=r, column=1, value=f"Check {project_checks.label(no)}").border = _BORDER
        cc = ws.cell(row=r, column=1)
        rgb = _CHECK_COLOR.get(colors.get(no, ""), None)
        if rgb:
            cc.fill = PatternFill("solid", start_color=rgb, end_color=rgb)
            if rgb in ("000000", "833C00", "7030A0", "0070C0", "FF0000"):
                cc.font = Font(color="FFFFFF", bold=True)
            else:
                cc.font = Font(bold=True)
        ws.cell(row=r, column=2, value=cnt).border = _BORDER
        ws.cell(row=r, column=3, value=names.get(no, "")).border = _BORDER
        r += 1
    ws.auto_filter.ref = None   # 요약 시트는 필터를 걸지 않는다
    ws.freeze_panes = None
    r += 1

    # 전체 범위일 때만 부서 순위를 넣는다 (부서 파일에는 자기 부서만 있으므로 무의미)
    if scope.is_all:
        ws.cell(row=r, column=1, value="부서별 현황").font = Font(bold=True, size=11)
        r += 1
        _write_header(ws, r, [("부서", 26), ("결함 행", 10), ("판정 대상", 46)])
        ws.auto_filter.ref = None
        ws.freeze_panes = None
        r += 1
        depts = result.get("departments") or {}
        for name, d in sorted(depts.items(), key=lambda x: -x[1].get("defect_rows", 0)):
            ws.cell(row=r, column=1, value=name).border = _BORDER
            ws.cell(row=r, column=2, value=d.get("defect_rows", 0)).border = _BORDER
            tot = d.get("total_rows", 0)
            rate = f"{d.get('defect_rows', 0) / tot * 100:.1f}%" if tot else "-"
            ws.cell(row=r, column=3, value=f"{tot}행 중 {rate}").border = _BORDER
            r += 1

    _setup_print(ws, landscape=False)
    ws.close()


def _scope_bucket(result: dict, scope: Scope) -> dict:
    """범위에 해당하는 집계 버킷. 전체면 최상위 result를 그대로 쓴다."""
    if scope.is_all:
        return {
            "total_rows": result.get("judged_rows", 0),
            "unworked_rows": result.get("unworked_rows", 0),
        }
    dept = (result.get("departments") or {}).get(scope.dept) or {}
    if scope.team:
        return (dept.get("teams") or {}).get(scope.team) or {}
    return dept


# ─── ② 결함 목록 시트 ─────────────────────────────────────────────────────────
_FLAG_COLS: list[tuple[str, int, str]] = [
    ("원본 행",   9,  "row"),
    ("Check",     8,  "_check"),
    ("검사 이름", 24, "check_name"),
    # NDT REPORT 번호(BE열)를 도면번호 «앞»에 둔다 — 현업이 산출물을 되짚을 때
    # 쥐고 있는 추적 키가 도면번호가 아니라 이 번호다. 값이 없는 행이 44.8%인데,
    # 그건 NDT 계획 자체가 없는 행이라 비어 있는 것이 정상이다.
    ("NDT REPORT 번호", 18, "ndt_report"),
    ("도면번호",  26, "drawing_no"),
    ("Joint No",  14, "joint_no"),
    ("블록",      10, "block"),
    ("부서",      22, "department"),
    ("팀",        20, "team"),
    ("용접사",    10, "welder1_no"),
    ("WPS",       15, "wps_no"),
    ("Process",   9,  "wps_process"),
    ("재질",      14, "material1"),
    ("두께",      8,  "thickness1"),
    ("용접일",    12, "weld_date"),
    ("NDT일",     12, "ndt_date"),
    ("마킹 열",   9,  "col_letter"),
    ("기준값",    38, "expected"),
    ("실제값",    38, "actual"),
    ("지적 내용", 46, "msg"),
]


def _sheet_flags(wb, result: dict, scope: Scope, flags: list[dict]) -> None:
    """플래그 1건 = 1행. 이 시트가 이 파일의 핵심 작업면이다.

    원본 시트는 색칠+주석이라 필터도 정렬도 안 되지만, 여기서는 엑셀 기능을
    그대로 쓸 수 있다. 주석에만 있던 기준값/실제값도 실제 셀 값이 되어
    인쇄와 검색이 된다.
    """
    ws = _stream_sheet(wb, "결함 목록", 1)
    r = _title(ws, f"결함 목록 — {scope.label}",
               f"총 {len(flags)}건 · 자동 필터가 걸려 있습니다 (열 머리글의 화살표)")

    _write_header(ws, r, [(n, w) for n, w, _ in _FLAG_COLS])
    hdr_row = r
    r += 1

    for f in sorted(flags, key=lambda x: (x.get("row", 0), x.get("check_no", 0))):
        for i, (_, _, key) in enumerate(_FLAG_COLS, start=1):
            if key == "_check":
                val = f.get("check_no")
            else:
                val = f.get(key, "")
            c = ws.cell(row=r, column=i, value=val)
            c.border = _BORDER
            c.alignment = Alignment(vertical="top", wrap_text=(key in ("expected", "actual", "msg")))
        # Check 번호 칸에 색을 칠해 화면과 같은 기준으로 읽히게 한다
        rgb = _CHECK_COLOR.get(f.get("color", ""), None)
        if rgb:
            cc = ws.cell(row=r, column=2)
            cc.fill = PatternFill("solid", start_color=rgb, end_color=rgb)
            cc.font = Font(color="FFFFFF" if rgb in ("000000", "833C00", "7030A0", "0070C0", "FF0000") else "000000",
                           bold=True)
            cc.alignment = Alignment(horizontal="center", vertical="center")
        r += 1

    _setup_print(ws, landscape=True, repeat_row=hdr_row)
    ws.close()


# ─── ③ 미작업 시트 ────────────────────────────────────────────────────────────
def _sheet_unworked(wb, result: dict, scope: Scope) -> int:
    # `/api/result` 응답에서 미작업 목록을 뺐으므로(payload의 17%), 여기서는
    # 저장소에서 직접 가져온다. result에 남아 있으면 그걸 쓴다 — 판정 직후처럼
    # 아직 저장을 거치지 않은 결과도 받을 수 있어야 한다.
    src = result.get("unworked_list")
    if not src:
        from . import result_store
        src = result_store.get_unworked()["items"]
    rows = [u for u in src
            if scope.matches(u.get("department"), u.get("team"))]
    if not rows:
        return 0
    ws = _stream_sheet(wb, "미작업")
    r = _title(ws, f"미작업 수량 (Check 0) — {scope.label}",
               f"총 {len(rows)}건 · 결함이 아닙니다. WPS No(AJ열)가 비어 있어 아직 시공되지 않은 계획 물량입니다")
    _write_header(ws, r, [("원본 행", 9), ("도면번호", 26), ("Joint No", 14),
                          ("블록", 10), ("부서", 22), ("팀", 20)])
    hdr = r
    r += 1
    for u in sorted(rows, key=lambda x: x.get("row", 0)):
        for i, key in enumerate(("row", "drawing_no", "joint_no", "block", "department", "team"), start=1):
            ws.cell(row=r, column=i, value=u.get(key, "")).border = _BORDER
        r += 1
    _setup_print(ws, repeat_row=hdr)
    ws.close()
    return len(rows)


# ─── ④ 검토 기록 시트 ─────────────────────────────────────────────────────────
def _sheet_feedback(wb, result: dict, scope: Scope, feedback: dict) -> int:
    """현업이 앱에서 남긴 검토 결과. 검토 키는 도면|Joint|WPS|Check 4요소다."""
    rows = []
    for key, rec in (feedback or {}).items():
        snap = rec.get("flag_snapshot") or {}
        if not scope.matches(snap.get("department"), snap.get("team")):
            continue
        rows.append((key, rec, snap))
    if not rows:
        return 0

    ws = _stream_sheet(wb, "검토 기록")
    r = _title(ws, f"현업 검토 기록 — {scope.label}",
               f"총 {len(rows)}건 · 앱에서 남긴 검토 결과입니다")
    _write_header(ws, r, [("도면번호", 26), ("Joint No", 14), ("WPS", 15), ("Check", 8),
                          ("검토 결과", 12), ("의견", 46), ("검토자", 12), ("검토 일시", 18)])
    hdr = r
    r += 1
    for key, rec, snap in sorted(rows, key=lambda x: x[1].get("updated_at", "")):
        vals = [rec.get("drawing_no", ""), rec.get("joint_no", ""), rec.get("wps_no", ""),
                rec.get("check_no", ""), rec.get("result", ""), rec.get("remark", ""),
                rec.get("reviewer_id", ""), rec.get("updated_at", "")]
        for i, v in enumerate(vals, start=1):
            c = ws.cell(row=r, column=i, value=v)
            c.border = _BORDER
            c.alignment = Alignment(vertical="top", wrap_text=(i == 6))
        r += 1
    _setup_print(ws, repeat_row=hdr)
    ws.close()
    return len(rows)


# ─── ⑤ 원본 시트 마킹 + 범위 축소 ─────────────────────────────────────────────
def _best_marks(flags: list[dict], priority: dict[str, int]) -> dict[int, dict[int, dict]]:
    """행 -> 열 -> «그 셀을 칠할 플래그». 한 셀에 여럿이 걸리면 우선순위로 하나만."""
    best: dict[int, dict[int, dict]] = defaultdict(dict)
    for f in flags:
        row, col = f["row"], f["col"]
        prev = best[row].get(col)
        if prev is None or priority[f["color"]] < priority[prev["color"]]:
            best[row][col] = f
    return best


def _apply_mark(cell: Any, f: dict) -> None:
    """결함 셀에 색을 칠하고 기준값/실제값을 주석으로 단다 (기존 동작 그대로)."""
    rgb = _CHECK_COLOR.get(f["color"])
    if rgb:
        cell.fill = PatternFill("solid", start_color=rgb, end_color=rgb)
    if f["color"] == "Black":
        cell.font = Font(color="FFFFFF")
    lines = [f"[Check {f['check_no']}] {f['check_name']}"]
    if f.get("expected") or f.get("actual"):
        lines.append(f"기준값: {f.get('expected', '')}")
        lines.append(f"실제값: {f.get('actual', '')}")
    else:
        lines.append(f["msg"])
    cm = Comment("\n".join(lines), "QC Verifier")
    cm.width, cm.height = 320, 110
    cell.comment = cm


def _mark_original(ws: Worksheet, flags: list[dict], priority: dict[str, int]) -> None:
    """전체 로드 방식의 마킹. **지금은 쓰지 않는다** — 테스트가 스트리밍 결과를
    이것과 대조하는 «정답»으로 쓴다. 지우면 대조할 상대가 없어진다."""
    for row_num, col_map in _best_marks(flags, priority).items():
        for col, f in col_map.items():
            _apply_mark(ws.cell(row=row_num, column=col), f)


def _original_open(wb: Any, title: str, layout: dict[str, Any]) -> Any:
    """원본 시트를 만들고 열 정의를 옮긴다. 행을 쓰기 «전»에 끝나야 하는 것들이다."""
    ws = wb.create_sheet(title)
    # **범위를 펼치지 마라.** 원본에 `min="81" max="16384"`가 있어서, 한 열씩
    # 만들면 열 정의가 16,384개로 불어난다(원본은 77개다). 파일만 커지고
    # 열어 보면 똑같다 — 그래서 알아채기 어렵다.
    for lo, hi, width, hidden in layout["cols"]:
        d = ColumnDimension(ws, min=lo, max=hi, width=width, hidden=hidden,
                            customWidth=True)
        ws.column_dimensions[get_column_letter(lo)] = d
    return ws


def _original_close(ws: Any, layout: dict[str, Any]) -> None:
    """병합·자동필터·인쇄 설정. 본문 «뒤»에 와야 하므로 다 쓴 다음에 건다.

    범위를 좁혀도 머리말(1~5행)은 항상 남으므로 머리말 병합은 그대로 유효하다.
    """
    for ref in layout["merges"]:
        try:
            ws.merged_cells.add(ref)
        except Exception:
            logger.warning("병합 범위를 옮기지 못했다: %s", ref)
    if layout["auto_filter"]:
        ws.auto_filter.ref = layout["auto_filter"]

    page = layout.get("page") or {}
    for key in ("orientation", "paperSize", "scale", "fitToWidth", "fitToHeight"):
        if key in page:
            v = page[key]
            setattr(ws.page_setup, key, v if key == "orientation" else int(v))
    if page.get("margins"):
        for k, v in page["margins"].items():
            setattr(ws.page_margins, k, v)
    if layout.get("print_titles"):
        ws.print_title_rows = layout["print_titles"]


def _sheet_original(wb: Any, qmg_path: str | Path, flags: list[dict],
                    priority: dict[str, int], scope: Scope,
                    progress: Callable[[str], None] | None = None,
                    raw: bytes | None = None) -> int:
    """원본 시트를 **흘려보내며** 마킹하고, 범위 밖 행은 아예 쓰지 않는다.

    ## 왜 이렇게 바뀌었나

    예전에는 「전체 로드 -> 마킹 -> `delete_rows`로 범위 축소」였다. 둘 다 비쌌다:

        전체 로드   행 수에 비례 — 38만 행이면 10.2GB (먹통)
        delete_rows 남길 행 수가 아니라 **흩어진 정도**에 비례
                    실측 Q520(4,430행 유지, 연속구간 79개): 39초

    스트리밍은 둘을 **한 번의 순회로 합친다.** 범위 밖 행은 쓰지 않으면 그만이라
    삭제 비용이 아예 사라지고, 메모리는 행 수와 무관해진다.

    ## 행 번호는 «원본 기준»이다

    플래그의 `row`는 원본 행 번호다. 범위를 좁히면 결과 파일에서의 위치가 앞으로
    당겨지지만, 마킹은 **읽고 있는 원본 행 번호로** 찾는다. 여기를 출력 위치로
    바꾸면 엉뚱한 행이 칠해진다 — 색이 «칠해지긴 해서» 알아보기 어렵다.
    """
    def note(msg: str) -> None:
        if progress:
            progress(msg)

    best = _best_marks(flags, priority)
    layout = _source_layout(qmg_path, raw)

    # 값과 **서식**을 함께 읽는다. `data_only=True`면 수식 자리에 계산값이 오는데,
    # 예전 전체 로드는 `data_only` 없이 열어 수식을 그대로 옮겼다. 원본 시트는
    # 「현장이 익숙한 양식 그대로」가 목적이라 그 동작을 유지한다.
    rb = _open_source(qmg_path, raw, read_only=True)
    rs = rb[rb.sheetnames[0]]
    ws = _original_open(wb, rs.title, layout)
    port_style = _style_porter(rb, wb)

    kept = 0
    note(f"원본 시트 쓰는 중 (마킹 {len(flags)}건)")
    for i, row in enumerate(rs.iter_rows(values_only=False), start=1):
        if i > HEADER_ROWS:
            vals = [c.value for c in row]
            def at(col: int) -> Any:
                return vals[col - 1] if col <= len(vals) else None
            if not scope.matches(at(COL_DEPARTMENT), at(COL_TEAM), at(COL_DRAWING_NO)):
                continue
            kept += 1

        marks = best.get(i)
        out: list[Any] = []
        # **열 번호는 세어서 쓴다.** 값이 없는 자리는 `EmptyCell`로 오는데 그건
        # `.column`이 없다 — `c.column`을 쓰면 빈 칸을 만나는 순간 터진다.
        # 그리고 마킹 대상은 빈 칸일 수도 있다(값이 없어서 지적된 검사가 있다).
        for col, c in enumerate(row, start=1):
            wc = WriteOnlyCell(ws, value=c.value)
            # 서식은 **머리말만이 아니라 본문도** 옮긴다. 본문에 채움은 없지만
            # 글꼴(Arial 9pt)·표시형식·테두리가 있어서, 빼면 엑셀 기본값
            # (Calibri 11pt)으로 조용히 바뀐다.
            #
            # `EmptyCell`에는 `style_array`가 없다 — `getattr`로 받는다.
            sa = getattr(c, "style_array", None)
            if sa is not None:
                wc._style = port_style(sa)
            if marks and col in marks:
                # **색인은 여러 셀이 나눠 쓴다.** 그대로 두고 `cell.fill = …`을
                # 하면 그 `StyleArray`를 «고쳐» 버려서, 같은 서식을 쓰던 셀이
                # 전부 함께 칠해진다. 실측으로 결함 4,321건이 8만 6천 셀을
                # 물들였다 — 색이 «칠해지긴 해서» 파일만 보면 그럴듯하다.
                wc._style = copy(wc._style) if wc._style is not None else StyleArray()
                _apply_mark(wc, marks[col])
            out.append(wc)
        ws.append(out)
    rb.close()

    _original_close(ws, layout)
    # 옛 `_shrink_to_scope`는 «머리말을 포함한» 총 행수를 돌려줬다. 소비처
    # (`info["original_rows"]`)가 그 뜻으로 읽으므로 같은 값을 낸다.
    return kept + HEADER_ROWS


def _shrink_to_scope(ws: Worksheet, scope: Scope,
                     progress: Callable[[str], None] | None = None) -> int:
    """범위 밖 행을 지운다. 남은 데이터 행 수를 돌려준다.

    연속 구간으로 묶어 **아래에서 위로** 지운다 — 위에서 지우면 그 아래 전부가
    매번 밀려 훨씬 느리다. 실측상 서식/주석/열너비/병합은 모두 보존된다.
    """
    # 임시부재 제외만 켜도 행을 지워야 한다 — 조직 범위가 «전체»인 것과 다르다
    if scope.keeps_every_row:
        return ws.max_row

    keep: set[int] = set(range(1, HEADER_ROWS + 1))
    for row in range(HEADER_ROWS + 1, ws.max_row + 1):
        dept = ws.cell(row=row, column=COL_DEPARTMENT).value
        team = ws.cell(row=row, column=COL_TEAM).value
        drawing = ws.cell(row=row, column=COL_DRAWING_NO).value
        if scope.matches(dept, team, drawing):
            keep.add(row)

    drop = [r for r in range(1, ws.max_row + 1) if r not in keep]
    blocks: list[list[int]] = []
    for r in drop:
        if blocks and blocks[-1][0] + blocks[-1][1] == r:
            blocks[-1][1] += 1
        else:
            blocks.append([r, 1])

    if progress:
        progress(f"원본 시트 축소 중 ({len(drop)}행 제거, {len(blocks)}구간)")
    for start, cnt in reversed(blocks):
        ws.delete_rows(start, cnt)
    return ws.max_row


# ─── 진입점 ───────────────────────────────────────────────────────────────────
def _flags_for(result: dict, scope: Scope) -> list[dict]:
    """이 범위의 플래그. `result`에 없으면 **저장소에서 직접 가져온다.**

    호출부가 두 종류다:

    - `verify.py` — 판정 직후, 플래그가 실린 원본 dict를 넘긴다
    - `exports.py` — 화면에 공개된 결과(`get_last_result()`)를 넘기는데, 이건
      **플래그를 싣지 않는다**(응답의 84%라 뺐다)

    후자를 그냥 훑으면 '결함 목록' 시트가 헤더만 남고 원본 시트에 색도 안 칠해진다.
    **예외가 아니라 «0건짜리 정상 파일»이 나가므로** 받는 사람이 «우리 부서는
    결함이 없구나»로 읽는다. 그래서 호출부가 아니라 여기서 막는다.
    """
    flags = result.get("flags") or []
    if flags:
        return scope.filter_flags(flags)
    from . import result_store
    return result_store.query_flags(dept=scope.dept, team=scope.team,
                                    exclude_temp=scope.exclude_temp)["items"]


def build_report(
    qmg_path: str | Path,
    result: dict,
    out_path: str | Path,
    *,
    dept: str | None = None,
    team: str | None = None,
    exclude_temp: bool = False,
    feedback: dict | None = None,
    priority: dict[str, int] | None = None,
    progress: Callable[[str], None] | None = None,
) -> dict[str, Any]:
    """범위별 결과 Excel을 만든다. 반환값은 무엇이 담겼는지에 대한 요약."""
    scope = Scope(dept, team, exclude_temp)
    flags = _flags_for(result, scope)
    priority = priority or {}

    def note(msg: str) -> None:
        if progress:
            progress(msg)

    # **write_only는 만든 순서가 곧 파일 안의 순서다.** 열었을 때 요약부터
    # 보이도록 요약 -> 결함목록 -> 원본 -> 미작업 -> 검토기록으로 만든다.
    # (예전에는 원본을 먼저 열고 `create_sheet(…, 0)`으로 앞에 끼워 넣었다.)
    # **DRM 원본은 여기서 딱 한 번 변환한다.** 아래에서 원본을 네 번 여는데
    # (기본 글꼴·열너비/병합·반복 머리말·본문), 열 때마다 변환하면 Excel COM
    # subprocess가 네 번 뜬다. DRM이 아니면 `None`이라 경로로 그냥 연다.
    note("원본 여는 중")
    raw = _source_handle(qmg_path)

    wb = Workbook(write_only=True)
    # **시트를 만들기 전에** 해야 한다 — 서식을 지정하지 않은 셀 전부에 걸린다.
    _adopt_default_font(wb, qmg_path, raw)

    note("요약/목록 시트 만드는 중")
    _sheet_summary(wb, result, scope, flags)
    _sheet_flags(wb, result, scope, flags)

    kept_rows = _sheet_original(wb, qmg_path, flags, priority, scope, progress, raw)

    n_unworked = _sheet_unworked(wb, result, scope)
    n_feedback = _sheet_feedback(wb, result, scope, feedback or {})

    # 열었을 때 요약부터 보이게
    wb.active = 0

    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    note("저장 중")
    _save_atomically(wb, out)

    info = {
        "scope": scope.label,
        "path": str(out),
        "size": out.stat().st_size,
        "flags": len(flags),
        "defect_rows": len({f["row"] for f in flags}),
        "original_rows": kept_rows,
        "unworked": n_unworked,
        "feedback": n_feedback,
        "built_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    logger.info("Excel 생성: %s (%s, %.0f KB, 플래그 %d건)",
                out.name, scope.label, info["size"] / 1024, len(flags))
    return info


# ─── 여러 범위를 한 번에 ──────────────────────────────────────────────────────
#
# ## 왜 필요한가 — 비용이 «범위 수»에 곱해지고 있었다
#
# `build_report()`는 범위마다 원본을 통째로 다시 읽는다. 그 읽기는 **범위가
# 작아도 줄지 않는다** — 어느 행이 이 범위에 속하는지 알려면 전부 봐야 한다.
# 실측(10,034행, 범위 31개):
#
#     5행짜리 팀 하나            3.89초   <- 출력은 5행인데 원본 1만 행을 다 읽는다
#     31개 순차 합계           124.9초   그중 약 118초가 되풀이된 읽기
#
# 38만 행이면 읽기 한 번이 2분을 넘으므로 31개면 **한 시간**이 읽기로만 나간다.
# 화면에서는 팀마다 「생성」을 누르고 1분씩 기다리는 모습으로 보인다.
#
# ## 어떻게 바꿨나
#
# 원본을 **한 번** 읽고, 각 행을 그 행이 속하는 파일들에만 흘려보낸다. 한 행이
# 가는 곳은 언제나 최대 셋이다 — 전체 · 그 부서 · 그 팀. 범위가 몇 개든 쓰기
# 총량은 «행 수 x 3»으로 고정된다.
#
#     지금  범위마다 (읽기 + 자기 몫 쓰기)
#     이후  읽기 1회 + 전체 쓰기 x 3
#
# ## 열어 두는 워크북 수를 제한한다
#
# 범위 전부를 한 번에 열면 `_best_marks()`가 만드는 마킹 색인이 동시에 살아
# 있는다. 38만 행에서는 그것만으로 수백 MB다. 그래서 `_FANOUT_BATCH`개씩
# 나눠서 돈다 — 묶음 수만큼만 원본을 읽으므로 31개를 8개씩이면 읽기가 4회다
# (31회에서 줄었다).
#
# **묶음을 나눠도 결과는 같아야 한다.** 각 파일은 자기 범위 안에서만 판단하고
# 다른 범위를 참조하지 않으므로, 어떻게 나누든 같은 파일이 나온다.

_FANOUT_BATCH = 8


class _Target:
    """팬아웃 한 칸 — 범위 하나와 그 출력 파일."""

    __slots__ = ("scope", "out", "wb", "ws", "flags", "best", "port", "kept")

    def __init__(self, scope: "Scope", out: Path):
        self.scope = scope
        self.out = out
        self.wb: Any = None
        self.ws: Any = None
        self.flags: list[dict] = []
        self.best: dict[int, dict[int, dict]] = {}
        self.port: Callable[[Any], Any] | None = None
        self.kept = 0


def _route(batch: "list[_Target]"):
    """(부서, 팀) -> 그 행을 받을 칸들. 행마다 `Scope.matches`를 N번 부르지 않는다.

    **`Scope.matches`와 같은 판단이어야 한다.** 거기도 부서/팀을 `strip()` 후
    정확일치로 보므로 사전 조회로 바꿔도 결과가 같다. 부서명이 빈 행은 어느
    부서 칸에도 안 들어가는 것까지 그대로다(그런 행은 «전체»에만 실린다).
    """
    all_, by_dept, by_team = [], defaultdict(list), defaultdict(list)
    for t in batch:
        if t.scope.is_all:
            all_.append(t)
        elif t.scope.team:
            by_team[(t.scope.dept, t.scope.team)].append(t)
        else:
            by_dept[t.scope.dept].append(t)
    return all_, by_dept, by_team


def build_reports(
    qmg_path: str | Path,
    result: dict,
    scopes: "list[Scope]",
    out_dir_for: Callable[["Scope"], Path],
    *,
    feedback: dict | None = None,
    priority: dict[str, int] | None = None,
    progress: Callable[[str], None] | None = None,
    on_ready: Callable[["Scope", dict], None] | None = None,
    on_error: Callable[["Scope", Exception], None] | None = None,
) -> list[dict[str, Any]]:
    """여러 범위의 결과 Excel을 **원본 한 번 읽기**로 만든다.

    `out_dir_for(scope)`가 그 범위의 출력 경로를 준다. 한 범위가 끝날 때마다
    `on_ready(scope, info)`를 부른다 — 화면이 전부 끝나기를 기다리지 않고
    하나씩 «생성됨»으로 바꿀 수 있어야 하기 때문이다.

    한 범위가 실패해도 **나머지는 계속 만든다.** 하나 때문에 전부 못 받는 것이
    더 나쁘다. 실패한 범위는 `on_error`로 알리고 반환 목록에서 빠진다.
    """
    priority = priority or {}
    feedback = feedback or {}
    infos: list[dict[str, Any]] = []

    def note(msg: str) -> None:
        if progress:
            progress(msg)

    # **DRM 원본은 여기서 딱 한 번 변환한다.** 예전에는 범위마다 `build_report`가
    # 변환했으므로 Excel COM subprocess가 «범위 수 x 4»번 떴다.
    note("원본 여는 중")
    raw = _source_handle(qmg_path)
    layout = _source_layout(qmg_path, raw)

    todo = list(scopes)
    done = 0
    for start in range(0, len(todo), _FANOUT_BATCH):
        batch_scopes = todo[start:start + _FANOUT_BATCH]
        batch: list[_Target] = []

        # ① 각 칸의 앞 시트(요약·결함 목록)를 만들고 원본 시트를 연다.
        #    **write_only는 만든 순서가 곧 파일 안의 순서다.**
        rb = _open_source(qmg_path, raw, read_only=True)
        rs = rb[rb.sheetnames[0]]
        for sc in batch_scopes:
            t = _Target(sc, Path(out_dir_for(sc)))
            try:
                t.flags = _flags_for(result, sc)
                t.best = _best_marks(t.flags, priority)
                t.wb = Workbook(write_only=True)
                _adopt_default_font(t.wb, qmg_path, raw)
                _sheet_summary(t.wb, result, sc, t.flags)
                _sheet_flags(t.wb, result, sc, t.flags)
                t.ws = _original_open(t.wb, rs.title, layout)
                t.port = _style_porter(rb, t.wb)
                batch.append(t)
            except Exception as exc:
                logger.exception("범위 준비 실패: %s", sc.label)
                if on_error:
                    on_error(sc, exc)

        if not batch:
            rb.close()
            continue

        all_, by_dept, by_team = _route(batch)
        note(f"원본 읽는 중 ({done + 1}~{done + len(batch)}/{len(todo)}번째 범위)")

        # ② 원본을 한 번 훑으며 해당하는 칸들에만 쓴다.
        for i, row in enumerate(rs.iter_rows(values_only=False), start=1):
            if i > HEADER_ROWS:
                vals = [c.value for c in row]

                def at(col: int) -> Any:
                    return vals[col - 1] if col <= len(vals) else None

                dept = (at(COL_DEPARTMENT) or "")
                dept = dept.strip() if isinstance(dept, str) else str(dept).strip()
                team = (at(COL_TEAM) or "")
                team = team.strip() if isinstance(team, str) else str(team).strip()
                hit = all_ + by_dept.get(dept, []) + by_team.get((dept, team), [])
                if not hit:
                    continue
                if wps_rules.is_temp_member(at(COL_DRAWING_NO)):
                    hit = [t for t in hit if not t.scope.exclude_temp]
                    if not hit:
                        continue
                for t in hit:
                    t.kept += 1
            else:
                hit = batch          # 머리말은 모든 파일에 들어간다

            # 셀 값·서식은 한 번만 읽고 칸마다 새 셀을 만든다. `WriteOnlyCell`은
            # 시트에 매여 있어 **공유할 수 없다** — 돌려쓰면 마지막 시트의 것만
            # 남는다.
            cells = [(c.value, getattr(c, "style_array", None)) for c in row]
            for t in hit:
                marks = t.best.get(i)
                out: list[Any] = []
                # **열 번호는 세어서 쓴다.** 빈 칸은 `EmptyCell`로 오는데 그건
                # `.column`이 없고, 마킹 대상이 빈 칸일 수도 있다.
                for col, (value, sa) in enumerate(cells, start=1):
                    wc = WriteOnlyCell(t.ws, value=value)
                    if sa is not None:
                        wc._style = t.port(sa)
                    if marks and col in marks:
                        # **색인은 여러 셀이 나눠 쓴다.** 그대로 두고 고치면
                        # 같은 서식을 쓰던 셀이 전부 함께 칠해진다.
                        wc._style = copy(wc._style) if wc._style is not None else StyleArray()
                        _apply_mark(wc, marks[col])
                    out.append(wc)
                t.ws.append(out)
        rb.close()

        # ③ 뒤 시트(미작업·검토 기록)를 붙이고 저장한다.
        for t in batch:
            done += 1
            try:
                _original_close(t.ws, layout)
                n_unworked = _sheet_unworked(t.wb, result, t.scope)
                n_feedback = _sheet_feedback(t.wb, result, t.scope, feedback)
                t.wb.active = 0
                t.out.parent.mkdir(parents=True, exist_ok=True)
                note(f"저장 중 ({done}/{len(todo)}) {t.scope.label}")
                _save_atomically(t.wb, t.out)
                info = {
                    "scope": t.scope.label,
                    "path": str(t.out),
                    "size": t.out.stat().st_size,
                    "flags": len(t.flags),
                    "defect_rows": len({f["row"] for f in t.flags}),
                    "original_rows": t.kept + HEADER_ROWS,
                    "unworked": n_unworked,
                    "feedback": n_feedback,
                    "built_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }
                infos.append(info)
                if on_ready:
                    on_ready(t.scope, info)
            except Exception as exc:
                logger.exception("범위 Excel 생성 실패: %s", t.scope.label)
                if on_error:
                    on_error(t.scope, exc)
            finally:
                # 다음 묶음으로 넘어가기 전에 마킹 색인을 놓아준다
                t.best = {}
                t.flags = []
                t.wb = None
                t.ws = None

    logger.info("Excel 팬아웃 생성: 범위 %d개 중 %d개 완료", len(todo), len(infos))
    return infos
