"""이 PC에서 도는 프로젝트 서버들의 목록과 생사.

## 고르는 자리는 로그인 화면 «안»이다

예전에는 앞에 별도 선택 페이지(포트 8000)를 뒀는데, 그러면 배경 영상과 로고가
있는 로그인 화면이 뒤로 밀리고 **아무 꾸밈 없는 흰 화면이 이 시스템의 첫인상**이
된다. 그래서 선택을 로그인 화면 안으로 들여왔다. 자리는 둘이다 —
**로그인 화면의 목록**(처음 들어오는 사람)과 **상단 배지 드롭다운**(이미
로그인해 둔 사람은 로그인 화면을 아예 지나가지 않는다). 둘이 같은 답을 내야
해서 여기 한 곳에 둔다.

## 확인은 서버 사이드다

브라우저에서 8001/8002를 직접 부르면 CORS에 걸린다(다른 포트 = 다른 origin).
`fetch` 실패로는 «서버가 꺼졌다»와 «CORS로 막혔다»를 구분할 수 없어서, 멀쩡히
도는 서버가 «중지됨»으로 보인다.

## 목록 파일은 공용이다

`data/projects.json`(저장소 쪽). 프로젝트별 폴더에 두면 **서버마다 다른 목록**을
보게 되어, 어느 창에서 보느냐에 따라 있는 프로젝트가 없어 보인다.
"""
from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request
from pathlib import Path

logger = logging.getLogger(__name__)

# `config.EMPLOYEES_FILE`과 같은 자리(공용 data/). config를 거치지 않고 직접 잡는
# 이유는 이 목록이 **프로젝트 데이터 폴더와 무관**하기 때문이다 — 프로젝트별로
# 두면 서버마다 다른 목록을 보게 되어, 어느 창에서 보느냐에 따라 있는 프로젝트가
# 없어 보인다.
PROJECTS_FILE = Path(__file__).resolve().parent.parent.parent / "data" / "projects.json"

# 목록 파일이 없을 때. 폴더를 나누지 않은 설치가 이 모습이다 — 8001 하나.
FALLBACK = [{"name": "QC 자동검증", "port": 8001, "note": "기본 서버"}]


def load_projects() -> list[dict]:
    """매 요청 다시 읽는다 — 프로젝트를 추가하고 서버를 재시작하게 만들면,
    그 재시작을 잊는 쪽이 훨씬 흔하다."""
    try:
        raw = json.loads(PROJECTS_FILE.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return list(FALLBACK)
    except (OSError, json.JSONDecodeError) as e:
        logger.warning("projects.json을 읽지 못했다: %s", e)
        return list(FALLBACK)

    items = raw.get("projects") if isinstance(raw, dict) else raw
    out: list[dict] = []
    for it in items or []:
        try:
            port = int(it["port"])
        except (KeyError, TypeError, ValueError):
            continue
        out.append({"name": str(it.get("name") or f"포트 {port}"),
                    "port": port,
                    "note": str(it.get("note") or "")})
    return out or list(FALLBACK)


def probe(port: int, timeout: float = 1.5) -> dict:
    """그 포트의 서버가 살아 있는가.

    **여기서 예외가 새면 목록 전체가 죽는다** — 한 프로젝트 서버가 꺼져 있다는
    이유로 다른 프로젝트로도 못 들어가게 된다.
    """
    try:
        with urllib.request.urlopen(
                f"http://127.0.0.1:{port}/api/server-info", timeout=timeout) as r:
            info = json.loads(r.read() or b"{}")
        return {"up": True,
                "project": info.get("project") or "",
                "data_root": info.get("data_root") or "",
                "wps_ref_found": bool(info.get("wps_ref_found"))}
    except urllib.error.HTTPError as e:
        # 응답은 했으니 서버는 살아 있다. 옛 버전이라 이 엔드포인트가 없을 뿐이다.
        return {"up": True, "project": "", "data_root": "",
                "wps_ref_found": True, "note": f"HTTP {e.code}"}
    except Exception:
        return {"up": False, "project": "", "data_root": "", "wps_ref_found": False}


def listing() -> list[dict]:
    """목록 + 생사. 순서는 파일 그대로다 — 생사로 정렬하면 서버 하나를 껐다 켤
    때마다 카드 자리가 바뀌어, 늘 같은 자리를 누르던 사람이 다른 데로 들어간다."""
    return [dict(p, **probe(p["port"])) for p in load_projects()]

def raw_projects() -> list[dict]:
    """편집 화면용 원문 — `load_projects()`가 떨어뜨리는 `data_dir`까지 준다.

    `load_projects()`는 «로그인 화면이 쓰는 것»이라 이름·포트·설명만 남긴다.
    편집할 때는 데이터 폴더가 있어야 한다 — 그게 프로젝트를 가르는 축이다.
    """
    try:
        raw = json.loads(PROJECTS_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return [dict(p, data_dir="") for p in FALLBACK]
    items = raw.get("projects") if isinstance(raw, dict) else raw
    out: list[dict] = []
    for it in items or []:
        try:
            port = int(it["port"])
        except (KeyError, TypeError, ValueError):
            continue
        out.append({"name": str(it.get("name") or f"포트 {port}"),
                    "port": port,
                    "data_dir": str(it.get("data_dir") or ""),
                    "note": str(it.get("note") or "")})
    return out


def validate(items: list[dict]) -> list[str]:
    """저장 전에 막아야 하는 것들. 통과하면 빈 목록.

    이름·포트가 겹치면 **어느 서버를 가리키는지 알 수 없게 된다.** 화면은
    `location.port`로 «지금 여기»를 판단하므로 포트가 겹치면 두 줄이 동시에
    «현재»로 표시되고, 이름이 겹치면 고르는 사람이 구분할 방법이 없다.
    """
    errs: list[str] = []
    if not items:
        errs.append("프로젝트가 하나도 없습니다 — 최소 한 개는 있어야 합니다")
    names, ports = set(), set()
    for i, it in enumerate(items, start=1):
        name = (it.get("name") or "").strip()
        if not name:
            errs.append(f"{i}번째 줄: 이름이 비었습니다")
        elif len(name) > 40:
            errs.append(f"'{name[:20]}…': 이름이 너무 깁니다 (40자 이내)")
        elif name in names:
            errs.append(f"'{name}': 이름이 겹칩니다")
        names.add(name)
        try:
            port = int(it.get("port"))
        except (TypeError, ValueError):
            errs.append(f"'{name}': 포트가 숫자가 아닙니다")
            continue
        if not (1024 <= port <= 65535):
            errs.append(f"'{name}': 포트는 1024~65535 사이여야 합니다")
        elif port in ports:
            errs.append(f"'{name}': 포트 {port}가 겹칩니다")
        ports.add(port)
    return errs


def warnings(items: list[dict]) -> list[str]:
    """막지는 않지만 알아야 하는 것들."""
    out: list[str] = []
    for it in items:
        name = (it.get("name") or "").strip()
        try:
            port = int(it.get("port"))
        except (TypeError, ValueError):
            continue
        # 8011부터는 `tools.sandbox_server`가 쓴다. 겹치면 에이전트가 띄운
        # 샌드박스가 사용자 서버처럼 목록에 뜬다.
        if port >= 8011:
            out.append(f"'{name}': 포트 {port}는 샌드박스 대역(8011~)입니다 — "
                       f"8001~8010을 쓰시는 편이 좋습니다")
        if not (it.get("data_dir") or "").strip():
            out.append(f"'{name}': 데이터 폴더가 비어 있어 **저장소 안의 data 폴더**를 "
                       f"씁니다. 다른 프로젝트와 같은 자리를 쓰면 나중에 돌린 쪽이 "
                       f"앞의 결과를 덮어씁니다")
        elif not Path(it["data_dir"]).is_dir():
            out.append(f"'{name}': 데이터 폴더가 아직 없습니다 ({it['data_dir']}) — "
                       f"서버를 띄울 때 만들어집니다")
    return out


def save_projects(items: list[dict]) -> list[dict]:
    """목록을 갈아 끼운다. **설명 블록(`_설명`)은 남긴다.**

    통째로 덮으면 파일을 손으로 열어 본 사람이 «이 파일이 무엇인지» 알 방법이
    없어진다. 그 설명은 이 파일의 유일한 안내문이다.

    임시 파일 + `os.replace`로 원자적으로 바꾼다 — 쓰다 끊겨 반쪽이 남으면
    `load_projects()`가 FALLBACK으로 떨어져 **프로젝트가 하나만 보인다.**
    """
    errs = validate(items)
    if errs:
        raise ValueError(" / ".join(errs))

    try:
        raw = json.loads(PROJECTS_FILE.read_text(encoding="utf-8"))
        head = {k: v for k, v in raw.items() if k != "projects"} \
            if isinstance(raw, dict) else {}
    except (OSError, json.JSONDecodeError):
        head = {}

    clean = [{"name": (it.get("name") or "").strip(),
              "port": int(it["port"]),
              "data_dir": (it.get("data_dir") or "").strip()}
             for it in items]
    data = dict(head)
    data["projects"] = clean

    PROJECTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = PROJECTS_FILE.with_suffix(PROJECTS_FILE.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, PROJECTS_FILE)
    logger.info("프로젝트 목록 저장: %d개", len(clean))
    return clean
