import logging

# 로깅 설정은 **라우터 import보다 먼저** 해야 한다.
# verify.py는 import 시점에 _load_app_state()를 실행하며 "이전 검증 결과 복원 완료" 로그를
# 남기는데, basicConfig가 뒤에 있으면 그 로그가 통째로 버려진다. 하필 그 로그가
# "낡은 서버 프로세스" 진단에 쓰라고 CLAUDE.md가 지목한 로그다.
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%H:%M:%S",
)

from fastapi import FastAPI, Header, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, Response

from backend import config
from pydantic import BaseModel

from backend.services import project_servers
from backend.routers.settings import _require_admin
from backend.routers.verify   import router as verify_router
from backend.routers.auth     import router as auth_router
from backend.routers.settings import router as settings_router
from backend.routers.feedback import router as feedback_router
from backend.routers.agents   import router as agents_router
from backend.routers.review   import router as review_router
from backend.routers.exports  import router as exports_router
from backend.routers.diagrams import router as diagrams_router
from backend.routers.rules    import router as rules_router

app = FastAPI(title="HD현대중공업 QC Summary 자동검증 시스템", version="1.0", docs_url="/docs")
app.include_router(verify_router,   prefix="/api")
app.include_router(auth_router,     prefix="/api")
app.include_router(settings_router, prefix="/api")
app.include_router(feedback_router, prefix="/api")
app.include_router(agents_router,   prefix="/api")
app.include_router(review_router,   prefix="/api")
app.include_router(exports_router,  prefix="/api")
app.include_router(diagrams_router, prefix="/api")
app.include_router(rules_router,    prefix="/api")
class _NoCacheStaticFiles(StaticFiles):
    """
    정적 파일(app.js/style.css 등)에 항상 재검증을 요구한다.

    기본 StaticFiles는 ETag/Last-Modified만 보내고 Cache-Control은 보내지 않는다.
    그러면 브라우저가 휴리스틱 캐싱으로 재검증 없이 예전 파일을 그대로 쓸 수 있어,
    코드를 고치고 서버를 재시작해도 사용자 화면에는 반영되지 않는 일이 생긴다
    (이 앱은 빌드 단계가 없어 파일명에 해시가 붙지 않으므로 특히 그렇다).

    'no-cache'는 "캐시하지 말라"가 아니라 "쓰기 전에 반드시 재검증하라"는 뜻이라,
    내용이 그대로면 304로 끝나 사내망에서 비용이 사실상 없다.
    """

    def file_response(self, *args, **kwargs) -> Response:
        resp = super().file_response(*args, **kwargs)
        resp.headers["Cache-Control"] = "no-cache, must-revalidate"
        return resp


app.mount("/static", _NoCacheStaticFiles(directory=str(config.STATIC_DIR)), name="static")


# 어느 데이터 폴더를 물고 있는지 **기동 로그 첫 줄에** 남긴다.
# 두 서버를 동시에 띄우는 구조에서는 «지금 보고 있는 창이 어느 프로젝트인가»가
# 곧바로 안 보이고, 틀린 창에 파일을 올리면 남의 프로젝트 결과를 덮어쓴다.
logging.getLogger(__name__).info(
    "데이터 폴더: %s%s", config.DATA_ROOT,
    f"  (프로젝트: {config.PROJECT_NAME})" if config.PROJECT_NAME else "  (기본 위치)",
)

# **사번 목록이 없으면 아무도 로그인하지 못한다.** 새 PC에 복사하면 `data/`가
# `.gitignore` 대상이라 이 파일이 없고, 등록하려면 관리자 로그인이 필요해서
# 교착이다. 기동 로그 첫머리에서 알린다 — 로그인 화면에서야 알면 늦다.
if not config.EMPLOYEES_FILE.exists():
    logging.getLogger(__name__).error(
        "사번 목록이 없습니다: %s — 같은 폴더의 employees.example.json을 "
        "복사해 실제 사번으로 고치세요. 없으면 아무도 로그인할 수 없습니다.",
        config.EMPLOYEES_FILE)


@app.get("/api/projects", include_in_schema=False)
def projects() -> dict:
    """이 PC에서 도는 프로젝트 서버 목록 — **로그인 화면과 상단 배지가 쓴다.**

    예전에는 앞에 «프로젝트를 고르는» 페이지(포트 8000)를 따로 뒀는데, 그러면
    배경 영상과 로고가 있는 로그인 화면이 뒤로 밀리고 **아무 꾸밈 없는 흰 화면이
    이 시스템의 첫인상**이 된다. 선택을 로그인 화면 안으로 들여오면서 그 페이지는
    없앴다.

    **로그인 전에 답한다** — 서버를 고르기 전에 로그인해야 하면 순환이다.
    나가는 것은 이름·포트·생사뿐이고 데이터는 없다.
    """
    # «지금 어느 것인가»는 서버가 아니라 화면이 안다(`location.port`). 서버는
    # 자기가 몇 번 포트로 떴는지 확실히 알 수 없다 — uvicorn 인자로 들어온다.
    return {"projects": project_servers.listing()}


class _ProjectsIn(BaseModel):
    projects: list[dict]


@app.get("/api/projects/edit", include_in_schema=False)
def projects_edit(x_employee_id: str | None = Header(None)) -> dict:
    """편집용 원문 — 데이터 폴더까지 준다. **관리자만.**

    `/api/projects`는 로그인 전에도 답해야 해서 이름·포트·생사만 낸다.
    편집은 그 반대라 자리를 나눈다.
    """
    _require_admin(x_employee_id)
    items = project_servers.raw_projects()
    return {"projects": items,
            "warnings": project_servers.warnings(items),
            "path": str(project_servers.PROJECTS_FILE)}


@app.post("/api/projects/edit", include_in_schema=False)
def projects_save(body: _ProjectsIn,
                  x_employee_id: str | None = Header(None)) -> dict:
    """목록을 갈아 끼운다.

    **여기서 서버가 떠지지는 않는다.** 사내망에 열린 페이지가 이 PC에서
    프로세스를 만들 수 있게 되는 것은 '에이전트' 탭에서 실행 기능을 뺀 것과 같은
    이유로 안 된다. 새로 추가한 프로젝트는 이 PC에서 `start_all.bat`을 다시
    돌려야 뜬다 — 화면이 그 사실을 말해 준다. 안 말하면 「추가했는데 중지됨으로
    나온다」가 된다.

    목록은 **매 요청 다시 읽히므로** 저장 즉시 로그인 화면과 배지에 반영된다.
    """
    _require_admin(x_employee_id)
    try:
        items = project_servers.save_projects(body.projects or [])
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    return {"ok": True, "projects": items,
            "warnings": project_servers.warnings(items),
            # 목록에 넣었다고 서버가 뜨지는 않는다
            "needs_restart": True}


@app.get("/api/server-info", include_in_schema=False)
def server_info() -> dict:
    """이 서버가 무엇을 물고 있는가. 화면 상단 배지와 랜딩 앱이 함께 쓴다.

    **로그인 전에도 답한다** — 랜딩 앱이 «어느 포트가 살아 있는가»를 묻는 자리이고,
    여기서 사번을 요구하면 서버를 고르기 전에 로그인을 해야 하는 순환이 된다.
    프로젝트 이름과 파일 존재 여부만 나가고 데이터는 나가지 않는다.
    """
    return {
        "project": config.PROJECT_NAME,
        "data_root": str(config.DATA_ROOT),
        "wps_ref": config.WPS_REF.name,
        "wps_ref_found": config.WPS_REF.exists(),
    }

@app.get("/", include_in_schema=False)
def root() -> FileResponse:
    # index.html도 같은 이유로 항상 재검증시킨다 — 여기서 script/link 태그를 참조하므로
    # 이 파일이 캐시되면 새 정적 파일 참조 자체가 반영되지 않는다.
    return FileResponse(
        str(config.FRONTEND_DIR / "index.html"),
        headers={"Cache-Control": "no-cache, must-revalidate"},
    )
