"""
'프로젝트 세팅' 탭 API — 판정 항목 취사선택 + 신규 규칙 요청 접수.

## 왜 «판정» 설정인가 (대시보드 토글과 다르다)

    프로젝트 세팅   무엇을 판정할 것인가        -> 재검증 필요
    대시보드 토글   판정된 것 중 무엇을 볼 것인가 -> 즉시 반영

끈 항목은 플래그가 **애초에 생기지 않는다.** 그래서 결함 행수·클린 행수·부서
실적이 전부 그 기준으로 다시 계산된다. 이걸 화면 필터로 처리하면 분모는 그대로인데
분자만 줄어드는 상태가 되어, 결함률이 조용히 틀린다.

그래서 저장하면 «재검증 필요»를 응답에 실어 화면이 배지를 띄운다.

## 신규 규칙은 «접수»만 한다

현업이 낸 판정로직 요청을 서버가 코드로 바꾸지는 않는다. 자연어를 판정 코드로
옮기려면 이 PC의 Claude Code 자격증명이 사내망에 열려야 하는데, '에이전트' 탭에서
이미 같은 이유로 실행 기능을 뺐다(0.0.0.0으로 열려 있고 로그인이 사번 하나뿐이다).

    현업 입력 -> 서버가 data/project_rules.json에 기록
              -> 관리자가 Claude Code로 반영
              -> 상태를 '반영됨'으로

접수할 때 **«이 조건에 지금 몇 행이 걸리는가»를 즉시 세어 돌려준다.** 0건이면
그 자리에서 표기 문제를 알 수 있다 — 실제로 「S355KL -40」이 실데이터 표기와
맞지 않아 한 번 막혔다.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

from backend.routers.auth import require_login
from backend.routers.settings import _require_admin
from backend.routers.verify import get_last_result
from backend.services import project_checks, rule_catalog, result_store
from backend.services.verifier import CHECK_UNWORKED
from backend.services.verifier import check_color as verifier_check_color
from backend.services.verifier import check_name as verifier_check_name

logger = logging.getLogger(__name__)
router = APIRouter()


def _items() -> list[dict]:
    """항목 목록. 지금 회차의 건수를 함께 실어 «껐을 때 무엇이 사라지는지»를 보인다."""
    enabled = rule_catalog.enabled_map()
    result = get_last_result() or {}
    stats = result.get("stats") or {}
    # 「대조 대상이 0건」 — «위반이 없다»와 다르다. 결과에 박힌 값을 그대로 쓴다.
    scope = result.get("scope") or {}
    # **잠정 표식** — 「이 항목은 다른 프로젝트 값을 빌려 쓰는 중이라 재확인이
    # 필요하다」. 활성 프로파일의 `params.provisional`(Check 번호 -> 사유)에서 온다.
    #
    # 표식이 없으면 빌려 온 값으로 나온 숫자를 «확정된 판정»으로 읽게 된다.
    # 오류가 나지 않는 종류라, 화면에 남겨 두지 않으면 잊는다.
    prov = {str(k): str(v) for k, v in
            (rule_catalog.active_params().get("provisional") or {}).items()}
    out: list[dict] = []
    cat = rule_catalog.catalog()
    # `sorted()`만 쓰면 **사전순**이다 — 키가 문자열이라 1·10·11·…·2·20 순으로
    # 나온다. 오류는 나지 않고 화면의 목록 순서만 뒤엉킨다.
    for no in sorted(cat, key=project_checks.sort_key):
        if no == CHECK_UNWORKED:
            continue
        spec = cat[no]
        d = {"check_no": no,
             "category": spec.get("category", rule_catalog.COMMON),
             "cols": spec.get("cols", ""),
             "summary": spec.get("summary", ""),
             "logic": spec.get("logic", ""),
             "name": spec.get("name") or verifier_check_name(no),
             "color": spec.get("color") or verifier_check_color(no),
             "enabled": enabled.get(no, True),
             "count": stats.get(str(no), 0),
             "retired": no in rule_catalog.RETIRED,
             "provisional": prov.get(str(no), ""),
             # None = 판정 대상 전체를 보는 검사(표식 없음) / 0 = 대상이 없었다
             "scope": scope.get(str(no))}
        # 프로젝트 규칙은 «편집 가능»하다. 폼을 채우려면 정의가 필요하다.
        if not project_checks.is_common(no):
            d["editable"] = True
            d["key"] = spec.get("key", "")
            d["kind"] = spec.get("kind", "")
            d["when"] = spec.get("when") or {}
            d["param"] = spec.get("param") or {}
            d["overrides"] = spec.get("overrides") or []
        out.append(d)
    return out


def _basis_gap() -> dict:
    """«지금 결과가 판정된 기준»과 «지금 설정»이 다른가.

    이름만 보면 부족하다 — 같은 프로젝트 안에서 항목을 켜고 껐으면 이름은 같고
    내용만 다르다. 그래서 이름과 항목 목록을 모두 대조한다.

    저장 직후의 «changed»와 다르다: 그건 그 순간만 알려주고 새로고침하면
    사라진다. 이건 결과에 박힌 기준을 보므로 언제 열어도 판단할 수 있다.
    """
    result = get_last_result() or {}
    if not result:
        return {"has_result": False, "stale": False, "result_project": "",
                "changed": []}
    now = rule_catalog.enabled_map()
    was = {str(k): bool(v) for k, v in (result.get("rules") or {}).items()}
    changed = sorted(n for n in now if was.get(n, True) != now[n]) if was else []
    return {"has_result": True,
            "result_project": result.get("project", ""),
            "result_run_at": result.get("run_at", ""),
            # 옛 회차는 기준이 없다(`rules`가 비어 있다). 그때는 «다르다»고
            # 단정하지 않는다 — 모르는 것과 틀린 것은 다르다.
            "basis_known": bool(was),
            "stale": bool(changed)
                     or (bool(result.get("project"))
                         and result["project"] != rule_catalog.active_profile_name()),
            "changed": changed}


@router.get("/rules")
def list_rules(x_employee_id: str | None = Header(None)) -> dict:
    require_login(x_employee_id)
    s = rule_catalog.settings()
    return {"project": s["active"],
            "projects": rule_catalog.profile_names(),
            "items": _items(),
            "requests": s.get("requests") or [],
            "basis": _basis_gap(),
            "run_at": (get_last_result() or {}).get("run_at", "")}


class ProjectIn(BaseModel):
    name: str


@router.post("/rules/project")
def switch_project(body: ProjectIn, x_employee_id: str | None = Header(None)) -> dict:
    """프로젝트(프로파일)를 바꾸거나 새로 만든다.

    **판정 기준이 통째로 달라지므로 재검증이 필요하다.** 이 시스템은 한 프로젝트
    전용이 아니라, 이름으로 설정을 불러와 바꾼 뒤 파일을 올려 돌리는 방식으로 쓴다.
    """
    _require_admin(x_employee_id)
    name = body.name.strip()
    if not name:
        raise HTTPException(400, "프로젝트 이름을 입력하세요")
    if len(name) > 60:
        raise HTTPException(400, "프로젝트 이름이 너무 깁니다 (60자 이내)")

    before = rule_catalog.active_profile_name()
    rule_catalog.switch_profile(name)
    logger.info("프로젝트 전환: %s -> %s", before, name)
    return {"ok": True, "project": name,
            "projects": rule_catalog.profile_names(),
            "items": _items(),
            # 이름만 바뀐 게 아니라 «무엇을 판정할지»가 바뀐다
            "needs_reverify": name != before}


@router.delete("/rules/project")
def delete_project(name: str, x_employee_id: str | None = Header(None)) -> dict:
    """활성 프로젝트는 지울 수 없다 — 지우면 «무엇을 기준으로 판정 중인지»가 사라진다."""
    _require_admin(x_employee_id)
    if not rule_catalog.delete_profile(name):
        raise HTTPException(400, f"'{name}'을 지울 수 없습니다 "
                                 f"(활성 프로젝트이거나 존재하지 않습니다)")
    logger.info("프로젝트 삭제: %s", name)
    return {"ok": True, "projects": rule_catalog.profile_names()}


class RulesIn(BaseModel):
    enabled: dict[str, bool]
    project: str | None = None


@router.post("/rules")
def save_rules(body: RulesIn, x_employee_id: str | None = Header(None)) -> dict:
    """취사선택 저장. **판정 설정이므로 재검증이 필요하다.**"""
    _require_admin(x_employee_id)
    # **프로젝트 규칙도 켜고 끌 수 있어야 한다.** 공통 표만 보면 `RUYA1`을
    # 토글할 때 400이 나고, 사용자에게는 «저장이 안 된다»로만 보인다.
    known = {str(n) for n in rule_catalog.catalog() if str(n) != str(CHECK_UNWORKED)}
    unknown = sorted(set(body.enabled) - known)
    if unknown:
        raise HTTPException(400, f"없는 Check 번호: {', '.join(unknown)}")

    before = rule_catalog.enabled_map()
    before_project = rule_catalog.active_profile_name()
    rule_catalog.save_enabled({str(k): v for k, v in body.enabled.items()}, body.project)
    after = rule_catalog.enabled_map()
    changed = sorted(n for n in after if before.get(n, True) != after.get(n, True))
    moved = rule_catalog.active_profile_name() != before_project

    logger.info("프로젝트 '%s' 판정 항목 저장: 바뀐 항목 %s",
                rule_catalog.active_profile_name(), changed or "없음")
    return {"ok": True, "changed": changed,
            "project": rule_catalog.active_profile_name(),
            "projects": rule_catalog.profile_names(),
            # 화면이 «재검증 필요» 배지를 띄우는 근거. 바뀐 게 없으면 띄우지 않는다.
            "needs_reverify": bool(changed) or moved,
            "items": _items()}


class RuleRequestIn(BaseModel):
    title: str
    category: str = rule_catalog.COMMON
    target_cols: str = ""       # 어느 열을 보는가 (예: "M · R · AK")
    condition: str = ""         # 어떤 조건일 때
    verdict: str = ""           # 무엇을 결함으로 볼 것인가
    note: str = ""
    author: str = ""


@router.post("/rules/requests")
def add_rule_request(body: RuleRequestIn,
                     x_employee_id: str | None = Header(None)) -> dict:
    """신규 판정로직 요청 접수 — 코드로 바꾸지는 않는다(모듈 독스트링 참조)."""
    emp = require_login(x_employee_id)
    if not body.title.strip():
        raise HTTPException(400, "규칙 제목을 입력하세요")
    if not body.condition.strip() or not body.verdict.strip():
        raise HTTPException(400, "«어떤 조건일 때»와 «무엇을 결함으로 볼 것인가»를 모두 적어야 "
                                 "코드로 옮길 수 있습니다")
    req = rule_catalog.add_request({
        "title": body.title.strip(),
        "category": body.category if body.category in (rule_catalog.COMMON,
                                                       rule_catalog.PROJECT)
                    else rule_catalog.COMMON,
        "target_cols": body.target_cols.strip(),
        "condition": body.condition.strip(),
        "verdict": body.verdict.strip(),
        "note": body.note.strip(),
        "author": (body.author or emp or "").strip(),
    })
    logger.info("신규 판정로직 요청 접수 #%s: %s", req["id"], req["title"])
    return {"ok": True, "request": req}


class RequestStatusIn(BaseModel):
    status: str


@router.post("/rules/requests/{req_id}/status")
def set_request_status(req_id: int, body: RequestStatusIn,
                       x_employee_id: str | None = Header(None)) -> dict:
    """관리자가 Claude Code로 반영한 뒤 상태를 바꾼다."""
    _require_admin(x_employee_id)
    allowed = ("접수", "검토중", "반영됨", "보류")
    if body.status not in allowed:
        raise HTTPException(400, f"상태는 {' / '.join(allowed)} 중 하나여야 합니다")
    if not rule_catalog.set_request_status(req_id, body.status):
        raise HTTPException(404, f"요청 #{req_id}을 찾을 수 없습니다")
    return {"ok": True, "requests": rule_catalog.settings().get("requests") or []}


# ─── 프로젝트 판정규칙 편집 ───────────────────────────────────────────────────
#
# **정해진 틀로만 받는다.** 자유 서술이 아니라 «대상 조건 · 허용 범위»를 나눠
# 받고, 판정 논리 자체는 코드(`project_checks.KINDS`)에 있다. 자유 서술로 두면
# 반영률이 떨어진다 — 실제로 「S355KL -40」이 실데이터 표기(`S355KT-40`)와 맞지
# 않아 한 번 막혔다.
class CheckRuleIn(BaseModel):
    key: str = ""                      # 비면 서버가 만든다
    name: str
    kind: str = "thickness_range"
    color: str = "Blue"
    material_contains: list[str] = []
    wps_contains: list[str] = []
    range: str = ""
    overrides: list[int] = [3]
    summary: str = ""
    logic: str = ""


def _slugify(name: str) -> str:
    """이름에서 안정 식별자를 만든다.

    **이름 전체의 해시를 붙인다.** 한글은 ASCII 슬러그에서 통째로 사라져서
    「시험 규칙 A36」과 「다른 규칙 A36」이 둘 다 `a36`이 된다 — key가 겹치면
    **번호가 겹치고, 검토 기록이 서로 섞인다.** 실제로 첫 시험에서 그랬다.

    해시는 이름에서 결정적으로 나오므로 같은 이름은 늘 같은 key를 받는다
    (= 같은 번호). 이름을 바꾸면 새 key가 되는데, 그건 «뜻이 바뀌었다»는 뜻이라
    새 번호를 받는 것이 맞다.
    """
    import hashlib
    import re as _re

    base = _re.sub(r"[^0-9a-z]+", "-", name.lower()).strip("-")[:36]
    tag = hashlib.sha1(name.strip().encode("utf-8")).hexdigest()[:6]
    return f"{base}-{tag}" if base else f"rule-{tag}"


def _to_rule_dict(body: CheckRuleIn, no: int) -> dict:
    return {
        "key": body.key, "no": no, "name": body.name.strip(),
        "color": body.color, "kind": body.kind,
        "when": {"material_contains": [t.strip() for t in body.material_contains if t.strip()],
                 "wps_contains": [t.strip() for t in body.wps_contains if t.strip()]},
        "param": {"range": body.range.strip()},
        "overrides": body.overrides or ["3"],
        "scope": "side", "cols": "J · K",
        "summary": body.summary.strip() or f"허용 두께 {body.range.strip()}mm",
        "logic": body.logic.strip() or (
            f"대상 조건에 맞는 side는 이 규칙이 판정한다. 허용 두께는 "
            f"{body.range.strip()}mm이고 WPS List G열보다 우선한다 — 이 프로젝트에서 "
            f"합의된 값이기 때문이다. 이 규칙을 끄면 그 side는 다시 공통 Check 3이 "
            f"판정한다."),
    }


@router.post("/rules/checks")
def save_check_rule(body: CheckRuleIn,
                    x_employee_id: str | None = Header(None)) -> dict:
    """프로젝트 판정규칙을 추가하거나 고친다. **판정 설정이라 재검증이 필요하다.**"""
    _require_admin(x_employee_id)
    if not body.name.strip():
        raise HTTPException(400, "규칙 이름을 입력하세요")
    if not body.range.strip():
        raise HTTPException(400, "허용 두께 범위를 입력하세요 (예: 12~50)")
    if not body.material_contains and not body.wps_contains:
        raise HTTPException(400, "대상 조건이 없습니다 — 재질 또는 WPS 중 하나는 "
                                 "적어야 이 규칙이 어떤 행에 걸립니다")

    data = rule_catalog.settings()
    prof = data["profiles"].setdefault(data["active"], {})
    checks = list(prof.get("checks") or [])
    ledger = dict(data.get("check_ids") or {})

    key = (body.key or "").strip() or _slugify(body.name)
    body.key = key
    no, _ = project_checks.assign_id(ledger, key, body.name.strip(), data["active"])
    entry = _to_rule_dict(body, no)

    # 스키마 검증을 **저장 전에** 한다. 깨진 규칙이 파일에 들어가면 다음 검증에서야
    # 거부되고, 그때는 «왜 안 걸리지»로만 보인다.
    ok, problems = project_checks.parse([entry])
    if problems:
        raise HTTPException(400, problems[0])

    checks = [c for c in checks if c.get("key") != key] + [entry]
    # 좁은 조건이 앞이어야 한다 — `S355KT-40`이 'KT'가 아니라 'KT-40'에 걸린다.
    # 토큰이 긴 것을 앞에 둔다(사람이 순서를 신경 쓰지 않아도 되게).
    checks.sort(key=lambda c: -max(
        (len(t) for t in (c.get("when", {}).get("material_contains") or [])
         + (c.get("when", {}).get("wps_contains") or [])), default=0))
    prof["checks"] = checks
    data["check_ids"] = ledger
    project_checks.retire_missing(ledger, {c["key"] for c in checks})
    rule_catalog._write(data)

    logger.info("프로젝트 판정규칙 저장: Check %s (%s) — %s", no, key, body.name)
    return {"ok": True, "check_no": no, "key": key,
            "needs_reverify": True, "items": _items()}


@router.delete("/rules/checks")
def delete_check_rule(key: str, x_employee_id: str | None = Header(None)) -> dict:
    """규칙을 뺀다. **번호는 대장에 `retired`로 남고 재발급되지 않는다** —
    검토 기록이 그 번호로 남아 있기 때문이다."""
    _require_admin(x_employee_id)
    data = rule_catalog.settings()
    prof = data["profiles"].setdefault(data["active"], {})
    checks = [c for c in prof.get("checks") or [] if c.get("key") != key]
    if len(checks) == len(prof.get("checks") or []):
        raise HTTPException(404, f"'{key}' 규칙을 찾을 수 없습니다")
    prof["checks"] = checks
    ledger = dict(data.get("check_ids") or {})
    project_checks.retire_missing(ledger, {c["key"] for c in checks})
    data["check_ids"] = ledger
    rule_catalog._write(data)
    logger.info("프로젝트 판정규칙 삭제: %s", key)
    return {"ok": True, "needs_reverify": True, "items": _items()}


class PreviewIn(BaseModel):
    material_contains: list[str] = []
    wps_contains: list[str] = []


@router.post("/rules/checks/preview")
def preview_check_rule(body: PreviewIn,
                       x_employee_id: str | None = Header(None)) -> dict:
    """이 조건이 **지금 데이터에 몇 행 걸리는가.**

    0행이면 그 자리에서 표기 문제를 알 수 있다 — 실제로 「S355KL -40」이 실데이터
    표기(`S355KT-40`)와 맞지 않아 한 번 막혔다. 규칙을 저장하고 재검증을 돌린
    뒤에야 «0건»을 보는 것과, 입력하는 자리에서 아는 것은 아주 다르다.

    판정 대상의 «재질 × WPS» 분포로 센다(행수가 아니라 조합 수에 비례한다).
    """
    require_login(x_employee_id)
    result = get_last_result() or {}
    combos = result.get("material_wps") or []
    if not combos:
        return {"has_result": False, "rows": 0, "samples": []}

    probe = project_checks.Rule({
        "key": "preview", "no": "PREVIEW1", "name": "미리보기",
        "color": "Blue", "kind": "thickness_range",
        "when": {"material_contains": body.material_contains,
                 "wps_contains": body.wps_contains},
        "param": {"range": "0~9999"},
    })
    hits = [c for c in combos if probe.matches(c["material"], c["wps"])]
    return {"has_result": True,
            "rows": sum(c["rows"] for c in hits),
            "combos": len(hits),
            # 무엇에 걸렸는지 보여야 «의도한 것과 다른 데 걸렸다»를 알 수 있다
            "samples": [{"material": c["material"], "wps": c["wps"], "rows": c["rows"]}
                        for c in hits[:8]]}

# ─── 프로젝트 값(params) ──────────────────────────────────────────────────────
#
# `checks`(별도 검증항목)와 나누는 기준은 `rule_catalog.active_params()`에 있다:
#
#     params  공통 Check가 그대로 쓰는 값     repair_prefix · wps_corrections · temp_member
#     checks  자기 번호를 갖는 별도 판정항목   재질별·WPS별 두께 허용범위
#
# 예전에는 이 값을 **화면에서 고칠 수 없었다.** `data/project_rules.json`을 직접
# 열어야 했고, 그래서 새 프로젝트를 올릴 때 값을 안 정하고 지나가기 쉬웠다.
# 비어 있으면 규칙이 조용히 죽는다 — 「검사를 돌렸는데 아무것도 안 나왔다」를
# 「문제가 없다」로 읽게 된다.


class ParamsIn(BaseModel):
    params: dict[str, Any]
    project: str | None = None


@router.get("/rules/params")
def get_params(x_employee_id: str | None = Header(None)) -> dict:
    """활성 프로파일의 프로젝트 값 + 기본값 + 지금 상태의 경고."""
    require_login(x_employee_id)
    from backend.services import wps_rules
    return {
        "project": rule_catalog.active_profile_name(),
        "params": rule_catalog.active_params(),
        # 화면이 «무엇을 정할 수 있는지» 알아야 한다. 키가 늘었는데 화면이
        # 모르면 새 프로젝트가 그 값을 안 정하고 지나간다.
        "defaults": {k: v for k, v in wps_rules.DEFAULTS.items()
                     if k not in ("project", "provisional")},
        "effective": wps_rules.load(),
        "warnings": wps_rules.check_params(),
    }


@router.post("/rules/params")
def save_params(body: ParamsIn, x_employee_id: str | None = Header(None)) -> dict:
    """프로젝트 값을 저장한다. **판정 기준이 달라지므로 재검증이 필요하다.**

    비어 있는 값을 **막지는 않는다** — 프로젝트에 따라 정말 없을 수도 있다.
    대신 무엇이 죽는지 함께 돌려준다. 막아 버리면 정당한 경우에 저장을 못 하고,
    조용히 넘어가면 «검사가 안 도는 줄 모르는» 상태가 된다.
    """
    _require_admin(x_employee_id)
    from backend.services import wps_rules

    p = body.params or {}
    if not isinstance(p, dict):
        raise HTTPException(400, "params는 객체여야 합니다")
    # 모르는 키는 받지 않는다 — 오타로 넣은 키는 **아무 데서도 안 읽히고**
    # 사용자는 값을 정했다고 믿는다.
    known = set(wps_rules.DEFAULTS) - {"project"}
    unknown = sorted(set(p) - known)
    if unknown:
        raise HTTPException(400,
            f"모르는 값입니다: {', '.join(unknown)} — 쓸 수 있는 값은 "
            f"{', '.join(sorted(known))}입니다")

    days = p.get("inspection_grace_days")
    if days is not None and (not isinstance(days, int) or isinstance(days, bool)
                             or days < 0):
        raise HTTPException(400, "검사 유예일은 0 이상의 정수여야 합니다")
    for key in ("check8", "check9"):
        if key in p and not isinstance(p[key], dict):
            raise HTTPException(400, f"{key}는 객체여야 합니다")
    if "wps_corrections" in p and not isinstance(p["wps_corrections"], dict):
        raise HTTPException(400, "wps_corrections는 객체여야 합니다")
    if "temp_member" in p:
        tm = p["temp_member"]
        if not isinstance(tm, dict) or not isinstance(
                tm.get("drawing_prefixes", []), list):
            raise HTTPException(400,
                "temp_member.drawing_prefixes는 목록이어야 합니다")

    rule_catalog.save_params(p, body.project)
    logger.info("프로젝트 값 저장: %s (%d개 키)",
                rule_catalog.active_profile_name(), len(p))
    return {"ok": True,
            "project": rule_catalog.active_profile_name(),
            "params": rule_catalog.active_params(),
            "effective": wps_rules.load(),
            "warnings": wps_rules.check_params(),
            # 세팅 토글과 같은 이유 — 저장만으로는 지금 결과가 안 바뀐다
            "needs_reverify": True}
