"""
검증 결과 저장소 — `data/app_state.json`을 SQLite로 대체한다 (개선계획 1번).

## 왜 바꾸나

JSON 한 덩어리로 들고 있는 구조가 30만 행에서 성립하지 않는다. 실측(1만 행)에서
역산한 값이다:

| | 1만 행 | 30만 행 |
|---|---|---|
| `app_state.json` | 19.9 MB | ~600 MB |
| `/api/result` 응답 | 18 MB | ~540 MB |

느린 게 아니라 **브라우저가 응답을 받지 못한다.**

그리고 지금 `_save_app_state()`는 **파일명만 바뀌는 업로드에도 20MB 전체를
재직렬화**한다. 30만 건이면 파일 하나 올릴 때마다 6초를 버린다. 그래서 이 모듈은
«이름 저장»과 «결과 저장»을 아예 다른 함수로 나눈다.

## 지켜야 하는 계약

`verifier`는 지금과 똑같은 dict를 만든다. 이 모듈은 그걸 넣었다 뺐을 때
**같은 것이 나오는 것**을 책임진다.

    save_run(result) -> load_latest() == result

무엇이 «같음»인지는 정확히 정해 두어야 한다:

| | 보장 | 이유 |
|---|---|---|
| 모든 값 | **동일** | 하나라도 다르면 화면 숫자가 틀린다 |
| 리스트 순서 | **동일** | `flags`·`defects`·`unworked_list`·`row_raw` 키 순서는 표에 그대로 보인다 |
| 객체 키 순서 | 보장 안 함 | 소비자가 없다 — 프론트는 `stats["13"]`처럼 키로 조회한다 |

마지막 줄이 중요하다. `check_stats`의 키 순서는 원래 «판정 중 처음 만난 Check
순서»인데, 그건 flag에서 유도할 수 없다(2차 패스 Check 13/14가 언제 붙었는지에
달려 있다). 그걸 재현하려고 버킷마다 순서를 저장하는 것은 **아무도 보지 않는 것을
위해 복잡도를 지불하는 일**이라 하지 않는다. 최상위 키와 `stats`는 이미
`run.key_order_json`으로 되돌리고 있는데, 그건 payload를 눈으로 비교할 때
편하기 때문이지 동작 때문이 아니다.

## 1단계 — 저장 방식만 바꿨다

행에 비례하는 세 가지(`flags` / `row_raw` / `unworked_list`)를 진짜 테이블로
쪼갰다. 나머지는 파이썬이 계산한 결과 그대로 `run.aggregate_json`에 넣었다 —
저장과 집계를 한꺼번에 바꾸면 「저장을 바꿔서 틀린 건지, 집계를 바꿔서 틀린 건지」
구분할 수 없게 되기 때문이다.

## 2단계 — flag에서 파생되는 집계는 저장하지 않는다

`stats`, 부서/팀의 `defect_rows`·`check_stats`·`defects`·`defect_trend_by_date`는
이제 **꺼낼 때 flag / defect_row에서 다시 만든다**(`_rebuild_derived`).

저장하지 않으면 **어긋날 수가 없다.** 이 프로젝트에서 비용을 치른 버그 두 건이
전부 «집계가 flags와 따로 계산돼 어긋난» 종류였다(2차 패스 소급 갱신 누락으로
257행이 용접사 집계에서 빠진 건). 실측으로도 `departments`가 payload의 16.2%였는데
그 내용이 `flags`를 부서별·팀별로 두 번 복제한 것이었다.

무엇을 파생시키지 «않는지»와 그 이유는 아래 `_DERIVED_*` 옆에 적어 두었다.
계획 문서는 "집계는 전부 쿼리로"였지만 실데이터를 재보니 그대로는 틀린다.

## 계획 문서와 다르게 간 두 곳

1. **`thickness1/2`를 REAL이 아니라 TEXT로 둔다.** 실제 payload의 값은 `"20"`
   같은 **문자열**이라, REAL로 넣으면 꺼낼 때 `20.0`이 되어 왕복이 깨진다.
   숫자로 다뤄야 하는 곳은 이미 판정 엔진 안이고, 여기 값은 화면 표시용이다.
2. **`extra_json` 열을 둔다.** 아래 `_FLAG_COLS`에 없는 키가 `flags`에 생겨도
   조용히 사라지지 않게 받아 둔다. Check를 추가하면서 필드가 늘어나는 일이
   실제로 있었고, 그때 왕복이 깨지면 «화면에서 뭔가 빈다»로만 드러난다.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
from pathlib import Path
from typing import Any

from .. import config
from . import wps_rules

logger = logging.getLogger(__name__)

# 보관할 검증 회차 수.
#
# 지금은 1 — `app_state.json`이 결과 하나만 들고 있던 것과 같은 동작이다.
# 개선계획 9번(검증 이력 비교)이 이 값을 올린다. 그때 함께 정해야 하는 것이
# 있다: `row_raw`는 30만 행에서 회차당 ~330MB라, 이력을 쌓더라도 **최신 회차만
# 남기고 과거 회차의 row_raw는 지워야 한다**(비교에는 쓰이지 않는다).
KEEP_RUNS = 1

# 스키마 버전. **열이나 테이블을 바꾸면 반드시 올려라.**
# 올리면 기동 시 저장된 회차를 버리고 다시 만든다(`_ensure_schema` 참조).
# v3: aggregate_json에 `temp_judged_rows`·버킷 `temp_rows`가 생겼다(임시부재 토글).
# 올리지 않으면 옛 회차가 남은 채 재시작했을 때 토글이 **분모를 안 줄여**
# 결함률이 실제보다 낮게 나온다 — 예외가 아니라 조용히 틀린다.
# v4: flag/defect_row에 `ndt_report`(BE열) 열이 생겼다. 이건 «없는 열» 오류로
#     바로 터지는 종류다.
# v5: run에 `project`·`rules_json`이 생겼다 — 이 회차를 «무엇으로» 판정했는지.
#     올리지 않으면 옛 회차가 기준 없이 남아, 화면이 «어느 프로젝트 결과인지»를
#     말할 수 없다(빈칸으로 조용히 나간다).
# v8: 임시부재(1C)가 판정 대상에서 빠졌다(2026-08-20). `temp_judged_rows`가
#     `temp_rows`로 바뀌고 **뜻도 달라졌다** — «판정된 1C»가 아니라 «판정에서
#     뺀 1C»다. 올려서 옛 회차를 버린다. 안 올리면 화면이 옛 뜻으로 읽는다.
SCHEMA_VERSION = 8

# run 테이블에 열로 두는 행 회계 값. 나머지는 aggregate_json에 들어간다.
_RUN_COUNTS = (
    "total_rows", "deleted_rows", "active_rows", "unworked_rows",
    "judged_rows", "flagged_rows", "clean_rows", "total_flags",
)

# flag 테이블에 열로 두는 키. SQL로 집계·필터할 대상이라 열로 꺼내 둔다.
#
# **순서는 `verifier`가 만드는 payload의 키 순서와 같아야 한다.** 꺼낼 때 이 순서로
# dict를 다시 짜기 때문이다. dict 비교는 순서를 보지 않지만 JSON 직렬화는 순서를
# 남기고, 화면이 받는 것은 그쪽이다.
_FLAG_COLS = (
    "row", "check_no", "check_name", "col", "col_letter", "color",
    "msg", "expected", "actual",
    "drawing_no", "joint_no", "block",
    "material1", "material2", "thickness1", "thickness2",
    "wps_no", "wps_process", "ndt_report", "weld_date", "ndt_date",
    "welder1_no", "department", "team",
)

_UNWORKED_COLS = ("row", "drawing_no", "joint_no", "block", "department", "team")

# 결함 행 머리말에서 뽑아 두는 필드 (`defects[]` 항목의 checks[] 제외 부분).
_DEFECT_ROW_COLS = ("row", "joint_no", "block", "wps_no", "ndt_report",
                    "weld_date", "welder1_no")

# ── 2단계: flag에서 «파생되는» 집계 ──────────────────────────────────────────
#
# 아래 키들은 저장하지 않는다. 꺼낼 때 flag / defect_row 테이블에서 다시 만든다.
# 그래야 **집계가 flags와 어긋나는 일이 구조적으로 불가능**해진다 — 이 프로젝트에서
# 비용을 치른 버그 두 건이 전부 그 종류였다(2차 패스 소급 갱신 누락).
#
# 전역
_DERIVED_TOP = ("stats", "total_flags", "flagged_rows", "defect_trend_by_date")
# 부서/팀 버킷
_DERIVED_BUCKET = ("defect_rows", "check_stats", "defects", "defect_trend_by_date")

# ── 파생시키지 «않는» 것과 그 이유 ───────────────────────────────────────────
#
# 계획 문서는 "집계는 저장하지 않고 전부 쿼리로 만든다"였는데, 실데이터를 재보니
# 두 부류는 flag 테이블만으로 만들 수 없다. 억지로 만들면 조용히 틀린다.
#
# 1. **분모(`total_rows`, `unworked_rows`, `welder_totals`)**
#    깨끗한 판정 행은 payload 어디에도 없다 — flag 테이블에는 «결함이 난 행»만
#    들어간다. 부서별 판정 대상 행수를 flag에서 세면 결함 행수와 같아져
#    결함률이 전부 100%가 된다.
#
# 2. **용접사 귀속 집계(`welder_defect_rate`, `welder_defects`)**
#    `flags`에는 `welder1_no`밖에 없는데, 판정 엔진은 그 행의 **용접사 4명 전원**
#    에게 결함을 귀속시킨다. 계획 문서의 예시 쿼리
#        SELECT welder1_no, COUNT(DISTINCT row_no) FROM flag ...
#    를 그대로 썼으면 2~4번 용접사의 결함이 통째로 사라졌을 것이다.
#
# 3. `recurring_patterns`(규칙 기반 탐지), `ml`, `welder_info`, `rule_health`
#    — 애초에 flag의 집계가 아니다.
#
# 이 셋을 SQL로 옮기려면 «판정 행» 테이블(깨끗한 행 포함)과 행별 용접사 목록이
# 필요하고, 그건 `verifier`가 내보내는 payload를 바꿔야 한다. 3단계 이후 과제다.

_SCHEMA = """
PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS meta (
  key   TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS run (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  run_at          TEXT,
  -- 저장된 시각(epoch). 예전에는 app_state.json의 파일 mtime이 이 역할을 했는데,
  -- DB는 파일명만 바뀌어도 mtime이 움직여서 그 대용이 성립하지 않는다.
  -- 결과 Excel과 범위별 Excel이 «이 결과보다 오래된 산출물인가»를 이 값으로 판단한다.
  saved_at        REAL,
  qmg_filename    TEXT,
  welder_filename TEXT,
  -- 이 회차를 «무엇으로» 판정했는가. 이름만으로는 부족하다 — 같은 이름 안에서
  -- 항목을 켜고 끄면 되짚을 수 없어서, 그때의 취사선택도 함께 남긴다.
  project         TEXT,
  rules_json      TEXT,
  total_rows      INTEGER, deleted_rows INTEGER, active_rows   INTEGER,
  unworked_rows   INTEGER, judged_rows  INTEGER, flagged_rows  INTEGER,
  clean_rows      INTEGER, total_flags  INTEGER,
  aggregate_json  TEXT NOT NULL,
  -- 파생 집계를 빼고 저장했다가 되끼울 때 **제자리에** 돌려놓기 위한 키 순서.
  -- {"top": [...], "stats": [...]} 형태다.
  --
  -- 표준 순서를 소스에 박아 두지 않는 이유: payload가 바뀌면 조용히 어긋난다.
  -- 만든 쪽의 순서를 그대로 받아 적는다.
  --
  -- `stats`를 따로 적는 이유: 원래 순서가 «판정 중 처음 만난 Check 순서»인데,
  -- `flags`는 행 번호로 정렬돼 있어 그걸로 유도할 수 없다. 실데이터에서 첫 행이
  -- 2차 패스(Check 13) 전용 행이라 훑는 순서가 13부터 시작한다.
  key_order_json  TEXT
);

CREATE TABLE IF NOT EXISTS flag (
  run_id      INTEGER NOT NULL REFERENCES run(id) ON DELETE CASCADE,
  seq         INTEGER NOT NULL,          -- 원래 순서. 화면이 이 순서에 의존한다
  row         INTEGER,
  -- **문자열이다.** 공통은 `3`, 프로젝트는 `RUYA1`.
  -- INTEGER면 `RUYA1`이 들어갈 때 SQLite가 조용히 TEXT로 저장하고,
  -- `ORDER BY check_no`가 타입 섞인 정렬이 되어 순서가 흔들린다.
  check_no    TEXT,
  check_name  TEXT,
  col         INTEGER,
  col_letter  TEXT,
  color       TEXT,
  drawing_no  TEXT, joint_no TEXT, block TEXT,
  department  TEXT, team     TEXT,
  -- 협력사(개선계획 7번)가 들어올 자리. 지금은 항상 NULL이다.
  subcontractor TEXT,
  welder1_no  TEXT, wps_no  TEXT, wps_process TEXT,
  -- BE열. 산출물의 추적 키다 — 현업은 도면번호가 아니라 이 번호로 원본을 찾는다
  ndt_report  TEXT,
  material1   TEXT, material2 TEXT,
  thickness1  TEXT, thickness2 TEXT,     -- payload가 문자열이라 TEXT (모듈 독스트링 참조)
  weld_date   TEXT, ndt_date  TEXT,
  expected    TEXT, actual    TEXT, msg  TEXT,
  extra_json  TEXT,
  PRIMARY KEY (run_id, seq)
);
CREATE INDEX IF NOT EXISTS ix_flag_run_check ON flag(run_id, check_no);
CREATE INDEX IF NOT EXISTS ix_flag_run_dept  ON flag(run_id, department, team);
CREATE INDEX IF NOT EXISTS ix_flag_run_row   ON flag(run_id, row);

-- 결함 행 머리말. `departments[*]['defects']` 항목에서 checks[]를 뺀 나머지다.
--
-- 왜 따로 두나: 부서/팀 집계를 flag에서 만들려면 «어느 행이 어느 부서의 결함인가»와
-- **그 순서**가 필요하다. 순서를 row 번호로 대신할 수 없다 — 2차 패스(Check 13/14)에서
-- 처음 결함이 된 행은 목록 끝에 붙기 때문이다(실데이터 7개 부서 중 5개가 row 정렬이
-- 아니다). 화면에 보이는 표의 순서라 저장 방식을 바꾸면서 조용히 흔들면 안 된다.
--
-- 팀 목록은 부서 목록을 걸러낸 것이라 순서가 같으므로, seq 하나로 양쪽을 재현한다.
CREATE TABLE IF NOT EXISTS defect_row (
  run_id     INTEGER NOT NULL REFERENCES run(id) ON DELETE CASCADE,
  row_no     INTEGER NOT NULL,
  seq        INTEGER NOT NULL,          -- 부서 목록 안에서의 원래 순서
  department TEXT, team TEXT,
  joint_no   TEXT, block TEXT, wps_no TEXT, weld_date TEXT, welder1_no TEXT,
  ndt_report TEXT,                        -- BE열. 부서/팀 리포트의 추적 키
  PRIMARY KEY (run_id, row_no)
);
CREATE INDEX IF NOT EXISTS ix_defect_row_dept ON defect_row(run_id, department, seq);
CREATE INDEX IF NOT EXISTS ix_defect_row_date ON defect_row(run_id, weld_date);

CREATE TABLE IF NOT EXISTS row_raw (
  run_id       INTEGER NOT NULL REFERENCES run(id) ON DELETE CASCADE,
  row_no       TEXT NOT NULL,            -- payload의 키가 문자열이라 그대로 둔다
  -- 삽입 순서. row_no로 정렬하면 안 된다 - TEXT라 "100"이 "27"보다 앞에 오고,
  -- 숫자로 캐스팅해도 2차 패스(Check 13/14)에서 뒤늦게 추가된 행이 끝에 붙는
  -- 원래 순서가 재현되지 않는다.
  seq          INTEGER NOT NULL,
  payload_json TEXT NOT NULL,
  PRIMARY KEY (run_id, row_no)
);
CREATE INDEX IF NOT EXISTS ix_row_raw_seq ON row_raw(run_id, seq);

CREATE TABLE IF NOT EXISTS unworked (
  run_id     INTEGER NOT NULL REFERENCES run(id) ON DELETE CASCADE,
  seq        INTEGER NOT NULL,
  row        INTEGER,
  drawing_no TEXT, joint_no TEXT, block TEXT,
  department TEXT, team     TEXT,
  extra_json TEXT,
  PRIMARY KEY (run_id, seq)
);
"""


# ─── 연결 ────────────────────────────────────────────────────────────────────
def connect(path: Path | None = None) -> sqlite3.Connection:
    """DB 연결을 열고 스키마를 보장한다.

    호출부가 매번 열고 닫는다. 검증은 백그라운드 스레드에서 돌고 조회는 요청
    스레드에서 오므로, 연결 하나를 공유하면 `sqlite3`의 스레드 제약에 걸린다.
    WAL 모드라 «쓰는 중에도 읽기»가 막히지 않는다.
    """
    p = Path(path or config.RESULT_DB)
    p.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(p, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    _ensure_schema(conn)
    return conn


def _ensure_schema(conn: sqlite3.Connection) -> None:
    """스키마를 보장한다. 버전이 낮으면 **비우고 다시 만든다.**

    마이그레이션을 쓰지 않는 이유: 이 DB에 담긴 것은 전부 **다시 만들 수 있는
    파생물**이다. 검증을 한 번 더 돌리면 그대로 복원된다. 원본(업로드 엑셀)은
    `qc_uploads/`에 따로 있고, 사람이 손으로 남긴 검토 기록은 이 DB가 아니라
    `data/flag_feedback.json`에 있다.

    `CREATE TABLE IF NOT EXISTS`만 두면 열이 늘었을 때 조용히 옛 스키마가 남아
    «없는 열» 오류가 실행 중에 터진다. 그게 더 나쁘다.
    """
    ver = conn.execute("PRAGMA user_version").fetchone()[0]
    names = [r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' "
        "AND name NOT LIKE 'sqlite_%'")]
    # 빈 DB(테이블 없음)는 버전이 0이어도 «옛것»이 아니다 — 그냥 만들면 된다.
    # 버전 도입 «전에» 만들어진 DB도 user_version이 0이므로, 테이블이 있는데
    # 버전이 다르면 전부 옛것으로 본다.
    if names and ver != SCHEMA_VERSION:
        logger.warning("결과 DB 스키마 v%s -> v%s: 저장된 회차를 버리고 다시 만든다 "
                       "(검증을 다시 돌리면 복원된다)", ver, SCHEMA_VERSION)
        conn.execute("PRAGMA foreign_keys = OFF")
        for n in names:
            conn.execute(f'DROP TABLE IF EXISTS "{n}"')
        conn.execute("PRAGMA foreign_keys = ON")
        conn.commit()
    conn.executescript(_SCHEMA)
    conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")


# ─── 이름(업로드 파일명) — 결과와 분리해 두는 것이 요점 ──────────────────────
def save_names(qmg_name: str, welder_name: str, wps_name: str,
               path: Path | None = None) -> None:
    """업로드 파일명만 저장한다.

    **이 함수가 결과를 건드리지 않는 것이 개선의 절반이다.** 예전에는 파일명이
    바뀔 때도 20MB 결과 전체를 다시 썼다.
    """
    with connect(path) as conn:
        conn.executemany(
            "INSERT INTO meta(key, value) VALUES(?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            [("qmg_name", qmg_name or ""),
             ("welder_name", welder_name or ""),
             ("wps_name", wps_name or "")],
        )


def load_names(path: Path | None = None) -> dict[str, str]:
    with connect(path) as conn:
        rows = conn.execute("SELECT key, value FROM meta").fetchall()
    got = {r["key"]: r["value"] for r in rows}
    return {k: got.get(k, "") for k in ("qmg_name", "welder_name", "wps_name")}


# ─── 결과 ────────────────────────────────────────────────────────────────────
def save_run(result: dict, path: Path | None = None) -> int:
    """검증 결과 한 회차를 저장하고 run_id를 돌려준다.

    한 트랜잭션으로 넣는다 — 중간에 죽으면 통째로 없던 일이 되어야 한다.
    예전 JSON 방식이 임시 파일 + `os.replace`로 얻던 원자성을 여기서는
    트랜잭션이 준다.
    """
    aggregate = {k: v for k, v in result.items()
                 if k not in ("flags", "row_raw", "unworked_list")}
    defect_rows = _extract_defect_rows(result)
    aggregate = _strip_derived(aggregate)

    flags = result.get("flags") or []
    row_raw = result.get("row_raw") or {}
    unworked = result.get("unworked_list") or []

    conn = connect(path)
    try:
        with conn:                       # 커밋/롤백을 컨텍스트가 맡는다
            cur = conn.execute(
                "INSERT INTO run(run_at, saved_at, qmg_filename, welder_filename, "
                "project, rules_json, "
                f"{', '.join(_RUN_COUNTS)}, aggregate_json, key_order_json) "
                f"VALUES(?, ?, ?, ?, ?, ?, {', '.join('?' * len(_RUN_COUNTS))}, ?, ?)",
                (result.get("run_at"), time.time(), result.get("qmg_filename"),
                 result.get("welder_filename"),
                 result.get("project") or "",
                 json.dumps(result.get("rules") or {}, ensure_ascii=False),
                 *[result.get(k) for k in _RUN_COUNTS],
                 json.dumps(aggregate, ensure_ascii=False),
                 json.dumps({"top": list(result),
                             "stats": list(result.get("stats") or {})},
                            ensure_ascii=False)),
            )
            run_id = int(cur.lastrowid)

            conn.executemany(
                f"INSERT INTO flag(run_id, seq, {', '.join(_FLAG_COLS)}, extra_json) "
                f"VALUES(?, ?, {', '.join('?' * len(_FLAG_COLS))}, ?)",
                [(run_id, i, *[f.get(c) for c in _FLAG_COLS], _extra(f, _FLAG_COLS))
                 for i, f in enumerate(flags)],
            )
            conn.executemany(
                "INSERT INTO row_raw(run_id, row_no, seq, payload_json) "
                "VALUES(?, ?, ?, ?)",
                [(run_id, str(k), i, json.dumps(v, ensure_ascii=False))
                 for i, (k, v) in enumerate(row_raw.items())],
            )
            conn.executemany(
                f"INSERT INTO unworked(run_id, seq, {', '.join(_UNWORKED_COLS)}, extra_json) "
                f"VALUES(?, ?, {', '.join('?' * len(_UNWORKED_COLS))}, ?)",
                [(run_id, i, *[u.get(c) for c in _UNWORKED_COLS],
                  _extra(u, _UNWORKED_COLS))
                 for i, u in enumerate(unworked)],
            )
            conn.executemany(
                "INSERT INTO defect_row(run_id, row_no, seq, department, team, "
                "joint_no, block, wps_no, weld_date, welder1_no, ndt_report) "
                "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [(run_id, e["row"], e["seq"], e["department"], e["team"],
                  e.get("joint_no"), e.get("block"), e.get("wps_no"),
                  e.get("weld_date"), e.get("welder1_no"), e.get("ndt_report"))
                 for e in defect_rows],
            )
            _prune(conn)
        return run_id
    finally:
        conn.close()


def load_latest(path: Path | None = None,
                include_row_raw: bool = True,
                include_unworked: bool = True,
                include_flags: bool = True) -> dict | None:
    """가장 최근 회차를 **저장하기 전과 같은 dict**로 되살린다. 없으면 None.

    `include_*=False`면 그 자리를 **빈 값으로** 돌려준다(키 자체는 남긴다 — 화면
    코드가 `result.row_raw` / `result.unworked_list` / `result.flags`를 그대로
    훑기 때문이다). 개수는 `unworked_rows` / `total_flags`에 그대로 있다.

    `include_flags=False`가 마지막 조각이다. 실측 2,521KB(응답의 84%)이고 30만
    행이면 ~76MB라 브라우저가 받지 못한다. 화면은 `/api/flags`로 조건에 맞는
    한 페이지만 가져간다.

    실측으로 `row_raw`가 payload의 **64.2%**다. 화면은 사용자가 클릭한 한 행만
    쓰는데 7,901행 전체를 실어 보내고 있었다. 필요할 때 `get_row_raw()`로 한 건씩
    가져간다 (3단계, 개선계획 2번).
    """
    conn = connect(path)
    try:
        run = conn.execute(
            "SELECT * FROM run ORDER BY id DESC LIMIT 1").fetchone()
        if run is None:
            return None
        run_id = run["id"]

        result: dict[str, Any] = json.loads(run["aggregate_json"])

        result["flags"] = [
            _row_to_dict(r, _FLAG_COLS)
            for r in conn.execute(
                "SELECT * FROM flag WHERE run_id=? ORDER BY seq", (run_id,))
        ] if include_flags else []
        result["row_raw"] = {
            r["row_no"]: json.loads(r["payload_json"])
            for r in conn.execute(
                "SELECT row_no, payload_json FROM row_raw WHERE run_id=? "
                "ORDER BY seq", (run_id,))
        } if include_row_raw else {}
        result["unworked_list"] = [
            _row_to_dict(r, _UNWORKED_COLS)
            for r in conn.execute(
                "SELECT * FROM unworked WHERE run_id=? ORDER BY seq", (run_id,))
        ] if include_unworked else []
        # 이 회차를 «무엇으로» 판정했는지. 없으면(옛 회차) 빈 값으로 둔다 —
        # 억지로 지금 설정을 채우면 «이 결과가 그 기준으로 나왔다»고 거짓말이 된다.
        result["project"] = run["project"] or ""
        try:
            result["rules"] = json.loads(run["rules_json"] or "{}")
        except Exception:
            result["rules"] = {}
        _rebuild_derived(conn, run_id, result)
        return _restore_key_order(result, run["key_order_json"])
    finally:
        conn.close()


# 화면의 검색창이 훑는 열. **여기와 화면이 달라지면 «있는데 안 나온다»가 된다.**
#
# `ndt_report`(BE열)가 들어 있는 이유: 현업이 산출물을 되짚을 때 쥐고 있는 것이
# 도면번호가 아니라 NDT 리포트 번호다. 리포트 하나가 여러 조인트를 덮으므로
# 번호로 검색하면 그 리포트에 걸린 결함이 한 번에 나온다.
_FLAG_SEARCH_COLS = ("joint_no", "wps_no", "msg", "block", "ndt_report")


def query_flags(check: int | None = None,
                checks: list[int] | None = None,
                dept: str | None = None,
                team: str | None = None,
                q: str = "",
                rows: list[int] | None = None,
                welder: str | None = None,
                drawing_no: str | None = None,
                joint_no: str | None = None,
                offset: int = 0,
                limit: int | None = None,
                path: Path | None = None) -> dict:
    """플래그를 조건에 맞게 한 페이지씩 꺼낸다.

    `/api/result`가 전량을 싣던 것을 대신한다 — 실측 2,521KB(payload의 84%)이고
    30만 행이면 ~76MB라 브라우저가 받지 못한다. 필드를 줄이는 것으로는 안 된다
    (전부 걷어내도 ~72MB). 애초에 한 화면이 쓰는 것은 한 페이지뿐이다.

    정렬은 `seq` — 저장 당시의 순서, 즉 판정 엔진이 내보낸 순서 그대로다.
    화면의 표가 이 순서에 의존한다.
    """
    where = ["run_id=(SELECT id FROM run ORDER BY id DESC LIMIT 1)"]
    params: list[Any] = []

    if check is not None:
        where.append("check_no=?")
        params.append(str(check))
    if checks is not None:
        if not checks:                      # 하나도 선택 안 함 = 결과 없음
            return {"total": 0, "offset": offset, "items": []}
        where.append("check_no IN (%s)" % ",".join("?" * len(checks)))
        # **문자열로 넘긴다.** `check_no` 열이 TEXT라 정수 파라미터는 한 행도
        # 안 맞고, 화면에서 Check를 고르면 조용히 전부 0건이 된다.
        params += [str(c) for c in checks]
    if dept:
        where.append("department=?")
        params.append(dept)
    if team:
        where.append("team=?")
        params.append(team)
    if welder:
        where.append("welder1_no=?")
        params.append(welder)
    # 정확일치. Check 14 그룹처럼 «이 조인트의 등록행 전부»를 물을 때 쓴다.
    # `q`(부분일치)로 대신하면 다른 조인트가 섞여 화면이 다시 걸러야 하고,
    # 그 후보 수를 예측할 수 없어 상한에 걸릴 수 있다.
    if drawing_no is not None:
        where.append("drawing_no=?")
        params.append(drawing_no)
    if joint_no is not None:
        where.append("joint_no=?")
        params.append(joint_no)
    if rows is not None:
        if not rows:
            return {"total": 0, "offset": offset, "items": []}
        where.append("row IN (%s)" % ",".join("?" * len(rows)))
        params += list(rows)
    if q:
        where.append("(" + " OR ".join(
            f"LOWER({c}) LIKE ?" for c in _FLAG_SEARCH_COLS) + ")")
        params += [f"%{q.lower()}%"] * len(_FLAG_SEARCH_COLS)

    clause = "WHERE " + " AND ".join(where)
    with connect(path) as conn:
        total = conn.execute(
            f"SELECT COUNT(*) FROM flag {clause}", params).fetchone()[0]
        sql = f"SELECT * FROM flag {clause} ORDER BY seq"
        page = list(params)
        if limit is not None:
            sql += " LIMIT ? OFFSET ?"
            page += [limit, offset]
        got = conn.execute(sql, page).fetchall()
    return {"total": total, "offset": offset,
            "items": [_row_to_dict(r, _FLAG_COLS) for r in got]}


def aggregate_flags(checks: list[int] | None = None,
                    dept: str | None = None,
                    team: str | None = None,
                    path: Path | None = None) -> dict:
    """선택된 Check만으로 대시보드 수치를 다시 낸다.

    화면의 «Check 취사선택»이 하던 계산이다. 예전에는 전체 `flags` 배열을 받아
    브라우저에서 매번 다시 돌렸는데, 30만 행이면 배열 자체가 오지 못한다.

    셈법은 화면과 같아야 한다:

    - `flagged_rows`는 **행 단위 중복 제거**다. 한 행에 선택/제외 Check가 섞여
      있어도 선택된 것이 하나라도 있으면 그 행은 여전히 결함이다.
    - `trend`도 행 단위다(플래그 수가 아니다). 같은 행의 플래그는 용접일이 같다.
    - `clean_rows`는 «판정 대상 − 결함 행»이며, 분모는 이 계산과 무관하게 고정이다.

    **임시부재(1C)를 거르지 않는다.** 걸러야 할 것이 애초에 없다 —
    2026-08-20부터 1C는 미작업과 같이 판정 대상에서 빠져 flag 테이블에
    들어오지 않고 `judged_rows`에도 없다.
    """
    where = ["run_id=(SELECT id FROM run ORDER BY id DESC LIMIT 1)"]
    params: list[Any] = []
    if checks is not None:
        if not checks:
            judged = _judged_rows(path)
            return {"flagged_rows": 0, "clean_rows": judged,
                    "total_flags": 0, "stats": {}, "trend": []}
        where.append("check_no IN (%s)" % ",".join("?" * len(checks)))
        # **문자열로 넘긴다.** `check_no` 열이 TEXT라 정수 파라미터는 한 행도
        # 안 맞고, 화면에서 Check를 고르면 조용히 전부 0건이 된다.
        params += [str(c) for c in checks]
    if dept:
        where.append("department=?")
        params.append(dept)
    if team:
        where.append("team=?")
        params.append(team)
    clause = "WHERE " + " AND ".join(where)

    with connect(path) as conn:
        stats = {str(r["check_no"]): r["n"] for r in conn.execute(
            f"SELECT check_no, COUNT(*) AS n FROM flag {clause} "
            "GROUP BY check_no ORDER BY check_no", params)}
        flagged, total = conn.execute(
            f"SELECT COUNT(DISTINCT row), COUNT(*) FROM flag {clause}",
            params).fetchone()
        trend = [{"date": r["weld_date"], "count": r["n"]} for r in conn.execute(
            f"SELECT weld_date, COUNT(DISTINCT row) AS n FROM flag {clause} "
            "AND weld_date <> '' AND weld_date IS NOT NULL "
            "GROUP BY weld_date ORDER BY weld_date", params)]

    # **`exclude_temp` 필터는 없앴다**(2026-08-20). 1C는 판정 자체에서 빠지므로
    # flag 테이블에 아예 들어오지 않고, `judged_rows`에도 없다. 남겨 두면 분모를
    # 두 번 줄여 clean 행이 부풀어 오른다 — 실측으로 5가 9로 나왔다.
    judged = _bucket_judged(dept, team, path) if (dept or team) else _judged_rows(path)
    return {"flagged_rows": flagged, "clean_rows": max(judged - flagged, 0),
            "total_flags": total, "stats": stats, "trend": trend}


def _judged_rows(path: Path | None = None) -> int:
    with connect(path) as conn:
        row = conn.execute(
            "SELECT judged_rows FROM run ORDER BY id DESC LIMIT 1").fetchone()
    return (row["judged_rows"] if row else 0) or 0


# 임시부재(1C)를 거르는 헬퍼(`_add_temp_filter`)는 없앴다 — 2026-08-20부터
# 1C는 판정 대상이 아니라 flag 테이블에 한 행도 들어오지 않는다. 남겨 두면
# «어딘가에서는 아직 판정한다»는 뜻으로 읽혀서, 다음 사람이 토글을 되살린다.


def scope_defect_rows(path: Path | None = None) -> dict[tuple[str, str], int]:
    """(부서, 팀)별 결함 «행» 수를 **한 번의 질의로** 낸다.

    '범위별 내보내기' 표가 31개 범위의 건수를 한꺼번에 보여준다. 범위마다
    `aggregate_flags`를 부르면 31번 왕복하고, 그 사이에 화면이 멈춘다.

    부서 합계는 팀 값을 더해서 내지 **않는다** — 한 행이 결함 행 하나이므로
    팀별 DISTINCT를 더하면 맞지만, 팀이 빈 문자열인 행이 섞이면 어긋난다.
    그래서 부서 단위도 따로 센다.
    """
    where = ["run_id=(SELECT id FROM run ORDER BY id DESC LIMIT 1)"]
    params: list[Any] = []
    clause = "WHERE " + " AND ".join(where)

    out: dict[tuple[str, str], int] = {}
    with connect(path) as conn:
        for r in conn.execute(
            f"SELECT department, team, COUNT(DISTINCT row) AS n FROM flag {clause} "
            "GROUP BY department, team", params
        ):
            out[(r["department"] or "", r["team"] or "")] = r["n"]
        for r in conn.execute(
            f"SELECT department, COUNT(DISTINCT row) AS n FROM flag {clause} "
            "GROUP BY department", params
        ):
            out[(r["department"] or "", "")] = r["n"]
        out[("", "")] = conn.execute(
            f"SELECT COUNT(DISTINCT row) FROM flag {clause}", params).fetchone()[0]
    return out


def _bucket_judged(dept: str | None, team: str | None,
                   path: Path | None = None) -> int:
    """부서/팀의 판정 대상 행수. flag에서 셀 수 없어 저장된 값을 쓴다."""
    with connect(path) as conn:
        row = conn.execute(
            "SELECT aggregate_json FROM run ORDER BY id DESC LIMIT 1").fetchone()
    if not row:
        return 0
    depts = (json.loads(row["aggregate_json"]).get("departments") or {})
    bucket = depts.get(dept or "") or {}
    if team:
        bucket = (bucket.get("teams") or {}).get(team) or {}
    return bucket.get("total_rows", 0)


def flag_facets(dept: str | None = None, path: Path | None = None) -> dict:
    """필터 select에 채울 값 목록 — 부서, 그리고 (부서를 고르면) 그 부서의 팀.

    화면이 전체 `flags`를 훑어 `Set`으로 모으던 것이다. 30만 행이면 그 배열이
    오지 못하고, 애초에 이건 `SELECT DISTINCT` 한 줄이다.

    정렬은 한국어 기준(`localeCompare(_, 'ko')`)이라 SQL로 재현할 수 없으므로
    **정렬하지 않고 보낸다** — 화면이 지금처럼 정렬한다.
    """
    base = "FROM flag WHERE run_id=(SELECT id FROM run ORDER BY id DESC LIMIT 1)"
    with connect(path) as conn:
        depts = [r[0] for r in conn.execute(
            f"SELECT DISTINCT department {base} AND department IS NOT NULL")]
        if dept:
            teams = [r[0] for r in conn.execute(
                f"SELECT DISTINCT team {base} AND department=? "
                "AND team IS NOT NULL", (dept,))]
        else:
            teams = [r[0] for r in conn.execute(
                f"SELECT DISTINCT team {base} AND team IS NOT NULL")]
    return {"departments": depts, "teams": teams}


def pattern_teams(path: Path | None = None) -> list[dict]:
    """(용접사, Check, 부서) -> 팀 목록.

    반복 결함 패턴 표의 '팀' 열이 쓰던 역산이다. 패턴은 부서 단위로 계산되므로
    팀은 플래그에서 되찾아야 하는데, 화면이 표를 그리는 **도중에** 동기로 훑고
    있어서 패턴마다 요청을 보낼 수 없다. 조합 전체를 한 번에 준다.

    대부분 팀 하나로 특정되지만 한 용접사가 같은 Check를 두 팀에서 낸 경우가
    있어(실데이터 2건) 목록으로 돌려준다.
    """
    with connect(path) as conn:
        rows = conn.execute(
            "SELECT DISTINCT welder1_no, check_no, department, team FROM flag "
            "WHERE run_id=(SELECT id FROM run ORDER BY id DESC LIMIT 1) "
            "AND team IS NOT NULL AND team <> '' "
            "AND welder1_no IS NOT NULL AND welder1_no <> ''").fetchall()
    out: dict[tuple, list[str]] = {}
    for r in rows:
        out.setdefault((r["welder1_no"], r["check_no"], r["department"]),
                       []).append(r["team"])
    return [{"welder_no": w, "check_no": c, "department": d, "teams": t}
            for (w, c, d), t in out.items()]


def dept_defects(dept: str, team: str | None = None, q: str = "",
                 offset: int = 0, limit: int | None = None,
                 path: Path | None = None) -> dict:
    """부서/팀 결함 목록을 한 페이지씩 — `expand_defects`의 페이지 버전.

    4단계에서 화면이 `flags`로 직접 만들게 했는데(`_bucketDefects`), 그건 전체
    배열이 있다는 전제였다. 그 전제가 없어지므로 서버가 낸다.

    `q`는 화면의 부서 결함 표 검색과 같은 범위(Joint No · 용접사 번호)다.
    """
    where = ["run_id=(SELECT id FROM run ORDER BY id DESC LIMIT 1)", "department=?"]
    params: list[Any] = [dept]
    if team:
        where.append("team=?")
        params.append(team)
    if q:
        where.append("(LOWER(joint_no) LIKE ? OR LOWER(welder1_no) LIKE ?)")
        params += [f"%{q.lower()}%"] * 2
    clause = "WHERE " + " AND ".join(where)

    with connect(path) as conn:
        total = conn.execute(
            f"SELECT COUNT(*) FROM defect_row {clause}", params).fetchone()[0]
        sql = f"SELECT * FROM defect_row {clause} ORDER BY seq"
        page = list(params)
        if limit is not None:
            sql += " LIMIT ? OFFSET ?"
            page += [limit, offset]
        heads = conn.execute(sql, page).fetchall()

        rows = [h["row_no"] for h in heads]
        checks: dict[int, list[dict]] = {}
        if rows:
            for f in conn.execute(
                "SELECT row, check_no, check_name, color, msg, expected, actual "
                "FROM flag WHERE run_id=(SELECT id FROM run ORDER BY id DESC LIMIT 1) "
                f"AND row IN ({','.join('?' * len(rows))}) ORDER BY seq", rows
            ):
                checks.setdefault(f["row"], []).append(
                    {k: f[k] for k in ("check_no", "check_name", "color",
                                       "msg", "expected", "actual")})

    return {"total": total, "offset": offset, "items": [
        {"row": h["row_no"],
         **{c: h[c] for c in _DEFECT_ROW_COLS if c != "row"},
         "checks": checks.get(h["row_no"], [])}
        for h in heads]}


def review_counts_by_welder(feedback: dict, path: Path | None = None) -> dict:
    """용접사별 미검토 건수를 **한 번에** 낸다.

    용접사 목록의 '미검토' 열이 146명분을 동시에 필요로 한다. 한 명씩 물으면
    146번을 왕복해야 한다.

    Check 6은 뺀다 — 목록의 결함 열이 C6를 뺀 기준이고, 플래그에 welder1_no만
    실려 있어 C6를 포함하면 2~4번 용접사의 자격 문제가 1번에게 잘못 붙는다.
    """
    out: dict[str, dict[str, int]] = {}
    with connect(path) as conn:
        for f in conn.execute(
            "SELECT welder1_no, drawing_no, joint_no, wps_no, check_no FROM flag "
            "WHERE run_id=(SELECT id FROM run ORDER BY id DESC LIMIT 1) "
            "AND check_no<>'6' AND welder1_no IS NOT NULL AND welder1_no <> ''"
        ):
            w = f["welder1_no"]
            rec = out.setdefault(w, {"total": 0, "reviewed": 0, "unreviewed": 0})
            rec["total"] += 1
            key = (f"{(f['drawing_no'] or '').strip()}|{(f['joint_no'] or '').strip()}"
                   f"|{(f['wps_no'] or '').strip()}|{f['check_no']}")
            if key in feedback:
                rec["reviewed"] += 1
    for rec in out.values():
        rec["unreviewed"] = rec["total"] - rec["reviewed"]
    return out


def review_counts(feedback: dict, welder: str | None = None,
                  path: Path | None = None) -> dict:
    """검토 기록이 없는 플래그 건수.

    화면이 전체 `flags`를 훑어 `S.feedback[_fbKey(f)]`가 없는 것을 세던 것이다.
    키는 `도면번호|Joint No|WPS No|Check No` — 화면과 같은 형식이어야 한다.

    `welder`를 주면 그 용접사(1번)의 플래그만 세고 **Check 6을 뺀다** — 결함 열이
    C6를 뺀 기준이고, 플래그에는 welder1_no만 실려 있어 C6를 포함하면 2~4번
    용접사의 자격 문제가 1번 용접사에게 잘못 붙는다.

    **임시부재(1C)는 두 열 모두에서 빠진다 — 선택이 아니다.**
    `by_result`는 DB를 세는데 1C가 판정 대상이 아니라 애초에 없고,
    `by_result_all`은 기록 «파일» 전체를 세므로 예전에 남긴 1C 검토 기록이
    아직 들어 있다. 여기서 안 거르면 나란히 놓인 두 열이 서로 다른 기준이
    되어 **차이가 «규칙 변경 때문»인지 «1C 때문»인지 구분할 수 없다** —
    두 열을 나란히 두는 이유 자체가 무너진다. (임시 용접은 작업도 결과 처리도
    불완전해서 라벨이 되어서는 안 된다.)
    """
    where = ["run_id=(SELECT id FROM run ORDER BY id DESC LIMIT 1)"]
    params: list[Any] = []
    if welder is not None:
        where += ["welder1_no=?", "check_no<>'6'"]
        params.append(welder)
    clause = "WHERE " + " AND ".join(where)

    # 판정별 내역도 함께 낸다. '지도학습' 탭이 «학습 가능한 라벨이 모였는가»를
    # 이 값으로 판단한다 — 분류기는 두 클래스가 다 있어야 배우므로, 총 건수보다
    # «결함확정이 몇 건인가»가 중요하다. 화면에 숫자를 박아 두면 곧 낡는다.
    total = reviewed = 0
    by_result: dict[str, int] = {}
    with connect(path) as conn:
        for f in conn.execute(
            f"SELECT drawing_no, joint_no, wps_no, check_no FROM flag {clause}",
            params
        ):
            total += 1
            key = (f"{(f['drawing_no'] or '').strip()}|{(f['joint_no'] or '').strip()}"
                   f"|{(f['wps_no'] or '').strip()}|{f['check_no']}")
            rec = feedback.get(key)
            if rec is not None:
                reviewed += 1
                r = (rec.get("result") or "미기재") if isinstance(rec, dict) else "미기재"
                by_result[r] = by_result.get(r, 0) + 1
    # 기록 «파일 전체»의 내역도 함께 낸다. 둘은 다를 수 있고, 그 차이가 중요하다:
    # 규칙이 바뀌면 그 규칙으로 오탐 판정을 받은 플래그는 **더 이상 생기지 않는다.**
    # 라벨은 파일에 남지만 대조할 행이 이번 회차에 없다 — 지금 회차만 놓고 보면
    # 학습에 쓸 수 있는 클래스가 한쪽뿐일 수 있다. 회차를 하나만 보관하므로
    # (`KEEP_RUNS = 1`) 사라진 행의 피처를 되살릴 방법도 없다.
    all_by_result: dict[str, int] = {}
    pres = tuple(wps_rules.temp_member_prefixes())
    for key, rec in feedback.items():
        # 키는 `도면번호|Joint No|WPS No|Check No`라 앞머리가 곧 도면번호다
        if pres and str(key).split("|", 1)[0].strip().upper().startswith(pres):
            continue
        r = (rec.get("result") or "미기재") if isinstance(rec, dict) else "미기재"
        all_by_result[r] = all_by_result.get(r, 0) + 1
    return {"total": total, "reviewed": reviewed, "unreviewed": total - reviewed,
            "by_result": by_result, "by_result_all": all_by_result}


def get_unworked(offset: int = 0, limit: int | None = None,
                 q: str = "", path: Path | None = None) -> dict:
    """미작업(Check 0) 목록을 필요한 만큼만 꺼낸다.

    `/api/result`에 통째로 싣지 않는 이유: 실측 590KB(payload의 17%)인데 화면은
    모달을 열었을 때만, 그것도 한 페이지(50건)만 쓴다. 30만 행이면 ~18MB다.

    `q`는 도면번호·Joint No·블록·부서·팀을 훑는다 — 화면의 검색창과 같은 범위다.
    """
    where = "WHERE run_id=(SELECT id FROM run ORDER BY id DESC LIMIT 1)"
    params: list[Any] = []
    if q:
        cols = ("drawing_no", "joint_no", "block", "department", "team")
        where += " AND (" + " OR ".join(f"LOWER({c}) LIKE ?" for c in cols) + ")"
        params += [f"%{q.lower()}%"] * len(cols)

    with connect(path) as conn:
        total = conn.execute(
            f"SELECT COUNT(*) FROM unworked {where}", params).fetchone()[0]
        sql = f"SELECT * FROM unworked {where} ORDER BY seq"
        page = list(params)
        if limit is not None:
            sql += " LIMIT ? OFFSET ?"
            page += [limit, offset]
        rows = conn.execute(sql, page).fetchall()
    return {"total": total, "offset": offset,
            "items": [_row_to_dict(r, _UNWORKED_COLS) for r in rows]}


def get_row_raw(row_no: int | str, path: Path | None = None) -> list | None:
    """한 행의 엑셀 원문 스냅샷. 없으면 None.

    상세 모달을 열 때 그 행만 가져간다. 전체를 응답에 싣지 않기 위한 것이다.
    """
    with connect(path) as conn:
        row = conn.execute(
            "SELECT payload_json FROM row_raw WHERE run_id="
            "(SELECT id FROM run ORDER BY id DESC LIMIT 1) AND row_no=?",
            (str(row_no),)).fetchone()
    return json.loads(row["payload_json"]) if row else None


def has_result(path: Path | None = None) -> bool:
    """결과 전체를 읽지 않고 존재만 확인한다."""
    with connect(path) as conn:
        return conn.execute("SELECT 1 FROM run LIMIT 1").fetchone() is not None


def latest_saved_at(path: Path | None = None) -> float | None:
    """최신 회차가 저장된 시각(epoch). 없으면 None.

    «이 Excel이 지금 결과의 산출물인가»를 판단하는 기준이다. 파일이 존재한다는
    이유로 옛 Excel을 내려주면 조용히 틀린 산출물이 나간다 — 재시작이 그 경계를
    우회하던 문제라 서버 기동 경로에서 반드시 확인해야 한다.
    """
    with connect(path) as conn:
        row = conn.execute(
            "SELECT saved_at FROM run ORDER BY id DESC LIMIT 1").fetchone()
    return row["saved_at"] if row else None


def clear(path: Path | None = None) -> None:
    """저장된 회차를 전부 지운다."""
    with connect(path) as conn:
        conn.execute("DELETE FROM run")


# ─── app_state.json에서 옮겨 담기 (1회) ──────────────────────────────────────
def migrate_from_json(json_path: Path | None = None,
                      path: Path | None = None) -> bool:
    """`app_state.json`이 있고 DB가 비어 있으면 1회 옮겨 담는다.

    옮긴 뒤에도 **JSON을 지우지 않는다.** 되돌릴 자리를 남겨 두는 것이 목적이다
    — 옮기다 뭔가 어긋나도 원본이 그대로 있으면 원인을 대조할 수 있다.
    """
    src = Path(json_path or config.APP_STATE_FILE)
    if not src.is_file() or has_result(path):
        return False
    try:
        saved = json.loads(src.read_text(encoding="utf-8"))
    except Exception:
        logger.exception("app_state.json을 읽지 못해 이관을 건너뛴다: %s", src)
        return False

    save_names(saved.get("qmg_name", ""), saved.get("welder_name", ""),
               saved.get("wps_name", ""), path=path)
    result = saved.get("result")
    if result is None:
        logger.info("app_state.json에 결과가 없어 파일명만 이관했다")
        return True
    save_run(result, path=path)
    logger.info("app_state.json -> SQLite 이관 완료 (플래그 %d건, 원본은 남겨 둔다)",
                len(result.get("flags") or []))
    return True


# ─── 2단계: 파생 집계 ────────────────────────────────────────────────────────
def _extract_defect_rows(result: dict) -> list[dict]:
    """부서 결함 목록을 «결함 행 머리말» 목록으로 편다.

    **두 가지 모양을 모두 받는다:**

    - `defects`(항목 전체) — `verifier`가 갓 만든 결과
    - `defect_row_order`(행 번호만) — 이 저장소가 꺼내 준 결과

    후자를 받아야 하는 이유: `load_latest()`로 꺼낸 결과를 다시 저장하는 경로가
    실제로 있다(테스트, 그리고 앞으로 이력 비교가 회차를 옮길 때). 한 모양만
    받으면 그때 결함 목록이 통째로 비고, **예외가 아니라 «0건»으로 조용히 틀린다.**
    """
    flags_by_row: dict[int, dict] = {}
    for f in result.get("flags") or []:
        flags_by_row.setdefault(f["row"], f)   # 머리말은 그 행의 첫 flag에서

    out: list[dict] = []
    for dept, d in (result.get("departments") or {}).items():
        team_of: dict[int, str] = {}
        for team, t in (d.get("teams") or {}).items():
            for row in _bucket_rows(t):
                team_of[row] = team

        entries = {e["row"]: e for e in (d.get("defects") or [])}
        for seq, row in enumerate(_bucket_rows(d)):
            src = entries.get(row) or flags_by_row.get(row) or {}
            out.append({"row": row, "seq": seq, "department": dept,
                        "team": team_of.get(row, ""),
                        **{c: src.get(c) for c in _DEFECT_ROW_COLS if c != "row"}})
    return out


def _bucket_rows(bucket: dict) -> list[int]:
    """부서/팀 버킷의 결함 행 번호를 순서대로. 두 모양을 모두 읽는다."""
    order = bucket.get("defect_row_order")
    if order is not None:
        return list(order)
    return [e["row"] for e in (bucket.get("defects") or [])]


def _strip_derived(aggregate: dict) -> dict:
    """flag에서 다시 만들 수 있는 값을 저장 대상에서 뺀다.

    이게 2단계의 요점이다. 저장하지 않으면 **어긋날 수가 없다.**
    (실측: `departments`가 payload의 16.2%였는데 그 내용이 `flags`를 부서별·팀별로
    두 번 복제한 것이었다.)
    """
    agg = {k: v for k, v in aggregate.items() if k not in _DERIVED_TOP}
    depts = {}
    for dept, d in (agg.get("departments") or {}).items():
        nd = {k: v for k, v in d.items() if k not in _DERIVED_BUCKET}
        nd["teams"] = {
            team: {k: v for k, v in t.items() if k not in _DERIVED_BUCKET}
            for team, t in (d.get("teams") or {}).items()
        }
        depts[dept] = nd
    if "departments" in agg:
        agg["departments"] = depts
    return agg


def _rebuild_derived(conn: sqlite3.Connection, run_id: int, result: dict) -> None:
    """`_strip_derived()`가 뺀 값을 flag / defect_row에서 다시 만든다.

    **키 순서까지 원래대로 되돌린다.** dict 비교는 순서를 보지 않지만 JSON 직렬화는
    순서를 남기고, 화면이 받는 것은 그쪽이다.
    """
    # **DB에서 낸다.** `result["flags"]`를 훑으면 안 된다 — 응답에서 플래그를 뺀
    # 뒤로는 그 배열이 비어 있고, 그러면 `stats`가 `{}`가 되어 «결함 0건»으로
    # 조용히 틀린다(예외가 나지 않는다).
    checks_by_row: dict[int, list[dict]] = {}
    for f in conn.execute(
        "SELECT row, check_no, check_name, color, msg, expected, actual "
        "FROM flag WHERE run_id=? ORDER BY seq", (run_id,)
    ):
        checks_by_row.setdefault(f["row"], []).append(
            {k: f[k] for k in ("check_no", "check_name", "color",
                               "msg", "expected", "actual")})

    heads = conn.execute(
        "SELECT * FROM defect_row WHERE run_id=? ORDER BY department, seq",
        (run_id,)).fetchall()

    dept_defects: dict[str, list[dict]] = {}
    team_defects: dict[tuple[str, str], list[dict]] = {}
    dept_dates: dict[str, dict[str, int]] = {}
    team_dates: dict[tuple[str, str], dict[str, int]] = {}
    all_dates: dict[str, int] = {}

    for h in heads:
        entry = {"row": h["row_no"],
                 **{c: h[c] for c in _DEFECT_ROW_COLS if c != "row"},
                 "checks": checks_by_row.get(h["row_no"], [])}
        dept, team, wd = h["department"], h["team"], h["weld_date"]
        dept_defects.setdefault(dept, []).append(entry)
        team_defects.setdefault((dept, team), []).append(entry)
        if wd:
            all_dates[wd] = all_dates.get(wd, 0) + 1
            dept_dates.setdefault(dept, {})[wd] = dept_dates.setdefault(dept, {}).get(wd, 0) + 1
            k = (dept, team)
            team_dates.setdefault(k, {})[wd] = team_dates.setdefault(k, {}).get(wd, 0) + 1

    def check_stats(rows: list[dict]) -> dict[str, int]:
        out: dict[str, int] = {}
        for e in rows:
            for c in e["checks"]:
                key = str(c["check_no"])
                out[key] = out.get(key, 0) + 1
        return out

    def trend(dates: dict[str, int]) -> list[dict]:
        return [{"date": d, "count": c} for d, c in sorted(dates.items())]

    for dept, d in (result.get("departments") or {}).items():
        rows = dept_defects.get(dept, [])
        _insert_bucket(d, rows, check_stats(rows), trend(dept_dates.get(dept, {})))
        for team, t in (d.get("teams") or {}).items():
            trows = team_defects.get((dept, team), [])
            _insert_bucket(t, trows, check_stats(trows),
                           trend(team_dates.get((dept, team), {})))

    # 정렬하지 않는다 — 원래 `stats`는 «처음 만난 Check 순서»이고, flag를 seq 순으로
    # 훑으면 같은 순서가 나온다. 2차 패스(Check 13/14)가 뒤에 붙는 것까지 재현된다.
    stats: dict[str, int] = {}
    total_flags = 0
    for f in conn.execute(
        "SELECT check_no FROM flag WHERE run_id=? ORDER BY seq", (run_id,)
    ):
        key = str(f["check_no"])
        stats[key] = stats.get(key, 0) + 1
        total_flags += 1
    result["stats"] = stats
    result["total_flags"] = total_flags
    result["flagged_rows"] = len(heads)
    result["defect_trend_by_date"] = trend(all_dates)


def expand_defects(result: dict, dept: str, team: str | None = None,
                   path: Path | None = None) -> list[dict]:
    """부서(또는 팀)의 결함 목록을 `flags`에서 되살린다.

    **파생 규칙은 여기 하나뿐이다.** 화면(app.js의 `_deptDefects`)과 부서 메일
    본문이 같은 규칙을 쓴다. 규칙이 갈라지면 «메일에 적힌 건수»와 «화면에서 본
    건수»가 달라지고, 그건 현업이 가장 못 믿는 종류의 어긋남이다.

    머리말 필드(joint_no·block·wps_no·weld_date·welder1_no)는 그 행의 첫 flag에서
    가져온다 — 실데이터 3,426건 전수 대조로 원본과 같음을 확인했다.
    """
    bucket = (result.get("departments") or {}).get(dept) or {}
    if team:
        bucket = (bucket.get("teams") or {}).get(team) or {}
    order = bucket.get("defect_row_order")
    if order is None:
        return bucket.get("defects") or []   # 옛 모양(항목이 실려 온 경우)

    # 응답에서 플래그를 뺀 뒤로는 `result["flags"]`가 비어 있다. 그때 그대로
    # 훑으면 checks[]가 전부 빈 목록이 되어 «지적 내용 없는 결함»이 나간다
    # (부서 리포트 메일이 이걸 쓴다). 비어 있으면 저장소에서 직접 낸다.
    if not (result.get("flags") or []):
        return dept_defects(dept, team=team, path=path)["items"]

    by_row: dict[int, list[dict]] = {}
    for f in result.get("flags") or []:
        by_row.setdefault(f["row"], []).append(f)

    out: list[dict] = []
    for row in order:
        fl = by_row.get(row)
        if not fl:
            continue
        h = fl[0]
        out.append({
            "row": row,
            "joint_no": h.get("joint_no", ""),
            "block": h.get("block", ""),
            "wps_no": h.get("wps_no", ""),
            "ndt_report": h.get("ndt_report", ""),
            "weld_date": h.get("weld_date", ""),
            "welder1_no": h.get("welder1_no", ""),
            "checks": [{"check_no": f.get("check_no"),
                        "check_name": f.get("check_name"),
                        "color": f.get("color"),
                        "msg": f.get("msg"),
                        "expected": f.get("expected"),
                        "actual": f.get("actual")} for f in fl],
        })
    return out


def expand_result(result: dict) -> dict:
    """결과 전체를 **판정 엔진이 만든 것과 같은 모양**으로 되돌린다.

    `defect_row_order`를 `defects`(항목 전체)로 바꿔 원래 자리에 끼운다.
    화면에는 이걸 보내지 않는다 — 그러려고 뺀 것이다. 쓰는 곳은 둘이다:

    - 불변식 검사(`tests/conftest.py`의 `real_result`) — «화면에 실려 가는 형태»가
      아니라 «판정 결과 전체»를 봐야 한다.
    - 부서 리포트 메일처럼 서버에서 목록 전체가 필요한 경로.

    펴는 규칙이 여기 하나뿐이어야 «메일에 적힌 건수»와 «화면에서 본 건수»가
    갈라지지 않는다.
    """
    out = json.loads(json.dumps(result, ensure_ascii=False))   # 깊은 복사
    for dept, d in (out.get("departments") or {}).items():
        _swap_order_for_defects(d, expand_defects(result, dept))
        for team, t in (d.get("teams") or {}).items():
            _swap_order_for_defects(t, expand_defects(result, dept, team))
    return out


def _swap_order_for_defects(bucket: dict, defects: list[dict]) -> None:
    """버킷의 `defect_row_order`를 `defects`로 갈아끼운다(같은 자리에)."""
    if "defect_row_order" not in bucket:
        return
    rebuilt: dict[str, Any] = {}
    for k, v in bucket.items():
        if k == "defect_row_order":
            rebuilt["defects"] = defects
        else:
            rebuilt[k] = v
    bucket.clear()
    bucket.update(rebuilt)


def _reorder(d: dict, order: list) -> dict:
    """`order`에 적힌 키를 앞세우고, 목록에 없던 키는 뒤에 원래 순서대로 남긴다."""
    out = {k: d[k] for k in order if k in d}
    out.update({k: v for k, v in d.items() if k not in out})
    return out


def _restore_key_order(result: dict, key_order_json: str | None) -> dict:
    """키 순서를 저장 당시대로 되돌린다.

    dict 비교는 순서를 보지 않지만 **JSON 직렬화는 순서를 남기고, 화면이 받는 것은
    그쪽이다.** 파생 집계를 빼서 저장했다가 다시 끼우면 그것들이 전부 뒤로 밀린다.
    """
    if not key_order_json:
        return result
    try:
        orders = json.loads(key_order_json)
    except Exception:
        return result
    if not isinstance(orders, dict):
        return result
    if isinstance(result.get("stats"), dict) and orders.get("stats"):
        result["stats"] = _reorder(result["stats"], orders["stats"])
    return _reorder(result, orders.get("top") or [])


def _insert_bucket(bucket: dict, defects: list[dict],
                   stats: dict[str, int], trend: list[dict]) -> None:
    """부서/팀 버킷에 파생값을 **원래 키 순서 자리에** 끼워 넣는다.

    `defects` 자리에는 **행 번호 목록(`defect_row_order`)만** 넣는다. 항목 전체는
    `flags`에서 만들 수 있으므로(`expand_defects`), 응답에 세 번 실을 이유가 없다 —
    실측으로 부서·팀 사본 합이 payload의 44%였다(2,737KB -> 40.5KB).

    행 번호를 «순서»로 보내는 이유: 화면에서 `flags`를 행 번호로 정렬해 만들면
    순서가 바뀐다. 2차 패스(Check 13/14)에서 처음 결함이 된 행이 목록 끝에 붙기
    때문이다(실데이터 7개 부서 중 5개).
    """
    rebuilt = {"defect_rows": len(defects), "check_stats": stats,
               "defect_row_order": [e["row"] for e in defects],
               "defect_trend_by_date": trend}
    order = ("total_rows", "unworked_rows", "defect_rows", "check_stats",
             "welder_defect_rate", "defect_row_order", "defect_trend_by_date",
             "teams", "recurring_patterns")
    merged = {**bucket, **rebuilt}
    bucket.clear()
    for k in order:
        if k in merged:
            bucket[k] = merged.pop(k)
    bucket.update(merged)          # 목록에 없던 키가 생겨도 잃지 않는다


# ─── 내부 ────────────────────────────────────────────────────────────────────
def _extra(d: dict, known: tuple[str, ...]) -> str | None:
    """열로 두지 않은 키를 모아 둔다. 없으면 None(공간 낭비를 피한다)."""
    rest = {k: v for k, v in d.items() if k not in known}
    return json.dumps(rest, ensure_ascii=False) if rest else None


def _row_to_dict(row: sqlite3.Row, cols: tuple[str, ...]) -> dict:
    """열 + extra_json을 합쳐 원래 dict를 되돌린다.

    **없던 키를 만들어내지 않는다.** 원래 dict에 없던 키가 None으로 생기면
    화면이 «값이 비어 있음»으로 그리게 되므로, NULL인 열은 빼고 extra로 채운다.
    """
    out = {c: row[c] for c in cols if row[c] is not None}
    extra = row["extra_json"]
    if extra:
        out.update(json.loads(extra))
    # 원래 순서(=_FLAG_COLS 순서 + extra)를 유지해 돌려준다
    return {**{c: out[c] for c in cols if c in out},
            **{k: v for k, v in out.items() if k not in cols}}


def _prune(conn: sqlite3.Connection) -> None:
    """KEEP_RUNS를 넘는 오래된 회차를 지운다 (ON DELETE CASCADE가 딸린 행을 정리)."""
    conn.execute(
        "DELETE FROM run WHERE id NOT IN "
        "(SELECT id FROM run ORDER BY id DESC LIMIT ?)", (KEEP_RUNS,))
