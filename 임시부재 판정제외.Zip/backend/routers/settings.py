"""
관리자 설정 라우터 — 사번(관리자) 관리 + Outlook 자동 발송 설정 + 부서별 결함 리포트 발송
모든 엔드포인트는 요청자가 관리자(admin=true)인 사번이어야 접근 가능.
요청자 사번은 X-Employee-Id 헤더로 전달받는다 (localStorage에 저장된 로그인 사번).
"""
import json
import logging
import threading
from email.message import EmailMessage
from pathlib import Path
from typing import Any

import urllib.parse

from fastapi import APIRouter, Header, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel

from backend import config
from backend.services import result_store
from backend.routers.auth import load_employees, is_admin, update_employees
from backend.routers.verify import get_last_result
from backend.services import project_checks
from backend.services.verifier import check_name as verifier_check_name

logger = logging.getLogger(__name__)
router = APIRouter()
_lock = threading.Lock()

try:
    import win32com.client
    import pythoncom
    _OUTLOOK_AVAILABLE = True
except ImportError:
    _OUTLOOK_AVAILABLE = False
    logger.warning("pywin32 미설치 — Outlook 발송 기능 비활성화")


def _require_admin(x_employee_id: str | None) -> str:
    emp_id = (x_employee_id or "").strip().upper()
    if not emp_id:
        raise HTTPException(401, "로그인이 필요합니다")
    if not is_admin(emp_id):
        raise HTTPException(403, "관리자 권한이 필요합니다")
    return emp_id


# ─── 사번(관리자) 관리 ────────────────────────────────────────────────────────
@router.get("/settings/employees")
def list_employees(x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    return {"employees": load_employees()}


class EmployeeIn(BaseModel):
    id: str
    admin: bool = False


@router.post("/settings/employees")
def add_employee(body: EmployeeIn, x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    new_id = body.id.strip().upper()
    if not new_id:
        raise HTTPException(400, "사번을 입력하세요")

    error: dict | None = None
    def _mutate(employees: list[dict]) -> list[dict]:
        nonlocal error
        if any(e["id"] == new_id for e in employees):
            error = {"status": 409, "detail": f"사번 '{new_id}'는 이미 등록되어 있습니다"}
            return employees
        employees.append({"id": new_id, "admin": body.admin})
        return employees

    # 읽기→수정→저장을 하나의 락으로 묶어 두 관리자의 동시 요청이 서로
    # 덮어쓰지 않도록 한다(update_employees, backend/routers/auth.py).
    employees = update_employees(_mutate)
    if error:
        raise HTTPException(error["status"], error["detail"])
    logger.info("사번 등록: %s (admin=%s)", new_id, body.admin)
    return {"ok": True, "employees": employees}


@router.delete("/settings/employees/{emp_id}")
def delete_employee(emp_id: str, x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    target = emp_id.strip().upper()

    error: dict | None = None
    def _mutate(employees: list[dict]) -> list[dict]:
        nonlocal error
        match = next((e for e in employees if e["id"] == target), None)
        if match is None:
            error = {"status": 404, "detail": f"사번 '{target}'를 찾을 수 없습니다"}
            return employees
        remaining_admins = [e for e in employees if e["admin"] and e["id"] != target]
        if match["admin"] and not remaining_admins:
            error = {"status": 400, "detail": "마지막 관리자는 삭제할 수 없습니다"}
            return employees
        return [e for e in employees if e["id"] != target]

    employees = update_employees(_mutate)
    if error:
        raise HTTPException(error["status"], error["detail"])
    logger.info("사번 삭제: %s", target)
    return {"ok": True, "employees": employees}


# ─── Outlook 자동 발송 설정 (설정값 저장만 — 실제 발송 로직은 추후 별도 구현) ──────
class OutlookSettingsIn(BaseModel):
    enabled: bool = False
    recipients: list[str] = []


def _load_outlook_settings() -> dict:
    if config.OUTLOOK_SETTINGS.exists():
        try:
            return json.loads(config.OUTLOOK_SETTINGS.read_text(encoding="utf-8"))
        except Exception:
            return {"enabled": False, "recipients": []}
    return {"enabled": False, "recipients": []}


@router.get("/settings/outlook")
def get_outlook_settings(x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    return _load_outlook_settings()


@router.post("/settings/outlook")
def save_outlook_settings(body: OutlookSettingsIn,
                          x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    recipients = [r.strip() for r in body.recipients if r.strip()]
    data = {"enabled": body.enabled, "recipients": recipients}
    with _lock:
        config.OUTLOOK_SETTINGS.parent.mkdir(parents=True, exist_ok=True)
        config.OUTLOOK_SETTINGS.write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    logger.info("Outlook 설정 저장: enabled=%s, 수신인 %d명", body.enabled, len(recipients))
    return {"ok": True, **data}


# ─── 부서별 결함 리포트 — 수신인 관리 + Outlook 발송 ────────────────────────────
def _load_dept_recipients() -> dict[str, list[str]]:
    if config.DEPT_RECIPIENTS_FILE.exists():
        try:
            return json.loads(config.DEPT_RECIPIENTS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _update_dept_recipients(dept: str, recipients: list[str]) -> None:
    """읽기→수정→저장을 락 하나로 묶어 두 관리자의 동시 저장이 서로
    덮어쓰지 않도록 한다(기존에는 _load_dept_recipients()/_save_dept_recipients()를
    따로 호출해서 lost-update가 가능했다)."""
    with _lock:
        data: dict[str, list[str]] = {}
        if config.DEPT_RECIPIENTS_FILE.exists():
            try:
                data = json.loads(config.DEPT_RECIPIENTS_FILE.read_text(encoding="utf-8"))
            except Exception:
                data = {}
        data[dept] = recipients
        config.DEPT_RECIPIENTS_FILE.parent.mkdir(parents=True, exist_ok=True)
        config.DEPT_RECIPIENTS_FILE.write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )


@router.get("/settings/dept-recipients")
def get_dept_recipients(x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    return _load_dept_recipients()


class DeptRecipientsIn(BaseModel):
    department: str
    recipients: list[str] = []


@router.post("/settings/dept-recipients")
def save_dept_recipients_endpoint(body: DeptRecipientsIn,
                                  x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    dept = body.department.strip()
    if not dept:
        raise HTTPException(400, "부서명이 필요합니다")
    recipients = [r.strip() for r in body.recipients if r.strip()]
    _update_dept_recipients(dept, recipients)
    logger.info("부서 수신인 저장: %s (%d명)", dept, len(recipients))
    return {"ok": True, "department": dept, "recipients": recipients}


# ─── 팀별 수신인 ──────────────────────────────────────────────────────────────
#
# 부서 아래에 중첩해 둔다: `{부서: {팀: [메일주소]}}`.
# 팀 이름만으로 키를 잡지 않는 이유는 `config.TEAM_RECIPIENTS_FILE` 주석에 있다.
def _load_team_recipients() -> dict[str, dict[str, list[str]]]:
    if config.TEAM_RECIPIENTS_FILE.exists():
        try:
            data = json.loads(config.TEAM_RECIPIENTS_FILE.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception:
            logger.exception("팀 수신인 파일을 읽지 못했다")
            return {}
    return {}


def _update_team_recipients(dept: str, team: str, recipients: list[str]) -> None:
    """읽기→수정→저장을 락 하나로 묶는다 (부서 쪽과 같은 이유 — lost update 방지)."""
    with _lock:
        data: dict[str, dict[str, list[str]]] = {}
        if config.TEAM_RECIPIENTS_FILE.exists():
            try:
                loaded = json.loads(config.TEAM_RECIPIENTS_FILE.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    data = loaded
            except Exception:
                data = {}
        bucket = data.setdefault(dept, {})
        if recipients:
            bucket[team] = recipients
        else:
            # 빈 목록은 «삭제»로 본다. 남겨 두면 화면이 «설정됨»으로 읽는다.
            bucket.pop(team, None)
            if not bucket:
                data.pop(dept, None)
        config.TEAM_RECIPIENTS_FILE.parent.mkdir(parents=True, exist_ok=True)
        config.TEAM_RECIPIENTS_FILE.write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )


def _team_recipients_of(dept: str, team: str) -> list[str]:
    return (_load_team_recipients().get(dept) or {}).get(team) or []


@router.get("/settings/team-recipients")
def get_team_recipients(x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    return _load_team_recipients()


class TeamRecipientsIn(BaseModel):
    department: str
    team: str
    recipients: list[str] = []


@router.post("/settings/team-recipients")
def save_team_recipients_endpoint(body: TeamRecipientsIn,
                                  x_employee_id: str | None = Header(None)) -> dict:
    _require_admin(x_employee_id)
    dept = body.department.strip()
    team = body.team.strip()
    if not dept or not team:
        raise HTTPException(400, "부서명과 팀명이 모두 필요합니다")
    recipients = [r.strip() for r in body.recipients if r.strip()]
    _update_team_recipients(dept, team, recipients)
    logger.info("팀 수신인 저장: %s > %s (%d명)", dept, team, len(recipients))
    return {"ok": True, "department": dept, "team": team, "recipients": recipients}


def _td(v) -> str:
    style = "border:1px solid #ccc;padding:4px 8px;text-align:left;font-size:12px"
    return f'<td style="{style}">{v}</td>'


def _build_dept_report_html(department: str, dept_data: dict, run_at: str,
                            team: str | None = None,
                            attached: bool = True) -> str:
    """부서(또는 팀) 리포트 메일 본문 — **요약만** 싣는다.

    팀 범위도 **같은 함수**로 만든다. 팀 버킷은 부서 버킷과 키 모양이 같고,
    본문이 갈라지면 «부서 메일에 적힌 합»과 «팀 메일들의 합»이 어긋났을 때
    어느 쪽이 틀렸는지 알 수 없게 된다.

    ## 왜 상세 표를 뺐나 — Outlook이 멈췄다

    예전에는 결함 리스트를 **지적 1건 = 1행**으로 본문에 다 실었다. 용접사별
    발생률과 반복 패턴 표도 함께였다. 셋 다 **상한이 없다** — 큰 팀 하나가 수천
    행짜리 HTML 표가 되고, Outlook이 그걸 그리다 멈춘다.

    작은 데이터에서는 멀쩡하다. 그래서 «검사 항목이 많은 팀»에서만 드러난다.

    지금 본문에 남는 것은 **행 수에 비례하지 않는 것**뿐이다:

        판정 대상 · 결함 발생 · 결함률 · 총 지적 건수 · 미작업
        검사 항목별 건수          <- Check 종류만큼이라 상한이 있다

    상세는 전부 첨부 Excel에 있다. '결함 목록' 시트는 지적 1건이 1행이라
    필터·정렬·피벗이 그대로 되고, 본문 표로는 할 수 없던 일이다.

    `tests/test_mail_body.py`가 **본문 크기가 결함 건수에 따라 자라지 않는지**
    본다. 표를 하나만 되살려도 같은 증상이 조용히 돌아온다.
    """
    scope    = f"{department} > {team}" if team else department
    kind     = "팀 실적" if team else "부서 실적"
    # 임시부재(1C)는 판정 대상이 아니라 `total_rows`·`defect_rows` 양쪽에서
    # 이미 빠져 있다 — 여기서 또 빼면 분모가 두 번 줄어든다.
    total    = dept_data.get('total_rows', 0)
    unworked = dept_data.get('unworked_rows', 0)   # 미작업 (결함률 분모 아님)
    temp     = dept_data.get('temp_rows', 0) or 0  # 임시부재 (판정 대상 아님)
    defect   = dept_data.get('defect_rows', 0)
    rate     = round(defect / total * 100, 1) if total else 0.0
    check_stats = dept_data.get('check_stats', {}) or {}
    # 한 행에 여러 Check가 걸릴 수 있어 «지적 건수»는 «결함 행수»보다 많다
    flags    = sum(check_stats.values())
    th_style = "border:1px solid #ccc;padding:4px 8px;text-align:left;font-size:12px;background:#f2f2f2"

    check_rows = "".join(
        "<tr>" + _td(f"Check {project_checks.label(no)}") + _td(verifier_check_name(no)) + _td(cnt) + "</tr>"
        for no, cnt in sorted(check_stats.items(), key=lambda x: -x[1])
    ) or f'<tr><td colspan="3" style="{th_style}">해당 없음</td></tr>'

    # 첨부가 없으면 이 메일에는 상세가 **어디에도 없다.** 조용히 넘어가면
    # 받는 사람은 요약만 보고 «이게 전부»라고 읽는다.
    if attached:
        attach_note = """
      <p style="margin-top:16px;padding:10px 12px;background:#f2f7ff;border:1px solid #cfe0ff">
        <b>상세 내용은 첨부한 Excel 파일에 있습니다.</b><br>
        <span style="font-size:12px;color:#444">
          <b>결함 목록</b> 시트 — 지적 1건이 1행입니다. NDT REPORT 번호 · 도면번호 ·
          Joint No · WPS No · 용접일 · 용접사 · 기준값 · 실제값이 실제 셀 값으로
          들어 있어 엑셀에서 필터 · 정렬 · 피벗이 그대로 됩니다.<br>
          <b>QMG4520</b> 시트 — 원본 그대로에 색상 마킹과 주석이 붙어 있습니다.<br>
          <b>요약</b> 시트 — 이 메일의 수치와 같은 집계입니다.
        </span>
      </p>"""
    else:
        attach_note = f"""
      <p style="margin-top:16px;padding:10px 12px;background:#fff4f4;border:1px solid #f0c0c0">
        <b>첨부 파일을 만들지 못했습니다.</b>
        <span style="font-size:12px;color:#444">이 메일에는 위 요약만 들어 있습니다 —
          결함 상세 · 용접사별 발생률 · 반복 패턴은 담기지 않았습니다.
          QC Summary 화면의 '범위별 내보내기' 탭에서 <b>{scope}</b> 파일을 직접
          만들어 받으십시오.</span>
      </p>"""

    return f"""
    <div style="font-family:'Malgun Gothic',sans-serif">
      <h3>{scope} 결함 리포트 ({kind})</h3>
      <p>검증 실행: {run_at}</p>
      <p style="color:#7030A0">도면번호가 <b>1C</b>로 시작하는 임시부재는 판정 대상이 아니며
         이 리포트에 들어 있지 않습니다{f' — 이 범위에서 {temp:,}건'  if temp else ''}.</p>
      <p>판정 대상: {total:,}건 · 결함 발생: {defect:,}건 ({rate}%)
         · 총 지적 건수: {flags:,}건
         {f' · 미작업(판정 제외): {unworked:,}건' if unworked else ''}</p>
      <h4>검사 항목별 건수</h4>
      <table style="border-collapse:collapse;width:100%">
        <tr><th style="{th_style}">Check</th><th style="{th_style}">항목</th><th style="{th_style}">건수</th></tr>
        {check_rows}
      </table>
      {attach_note}
    </div>
    """


def _dept_excel_path(department: str, team: str | None = None) -> str | None:
    """그 부서(또는 팀) 범위의 결과 Excel을 만들어 경로를 돌려준다. 실패하면 None.

    본문 HTML만 보내면 수신자가 원본 대조를 할 수 없어서 첨부한다.
    생성이 오래 걸릴 수 있으므로(큰 부서 약 1분) 완료까지 기다린다 - 메일 초안이
    첨부 없이 먼저 열리면 사용자가 그대로 보내버리기 때문이다.
    첨부에 실패해도 메일 자체는 보낼 수 있어야 하므로 예외를 밖으로 던지지 않는다.
    """
    try:
        from backend.routers import exports
        st = exports.ensure_built(department, team, wait=True)
        if st.get("status") == "ready" and st.get("info"):
            return st["info"]["path"]
        logger.warning("범위 Excel 생성 실패로 첨부 없이 발송: %s (%s)",
                       st.get("scope") or department, st.get("error"))
    except Exception:
        logger.exception("범위 Excel 첨부 준비 실패: %s / %s", department, team)
    return None


# ─── 메일: «무엇을 보낼까»와 «어떻게 보낼까»를 가른다 ────────────────────────
#
# 발송 방법이 바뀌어 왔고 앞으로 한 번 더 바뀐다:
#
#     ① win32com  — 서버 PC의 Outlook에 초안을 연다        (레거시)
#     ② .eml      — 받는 사람이 **자기 PC** Outlook에서 연다 (지금)
#     ③ 서버 직접 발송 — 누르면 저장된 수신처로 바로 나간다  (최종 목표)
#
# ②가 필요해진 이유: 사내망 다른 PC에서 쓰기 시작하니 ①은 **원격 접속자가
# 눌러도 서버 PC에 초안이 쌓이고 누른 사람은 그걸 볼 수 없었다.** 오류도 나지
# 않는다 — 누른 쪽에서는 아무 일도 안 일어난 것처럼 보인다.
#
# ②는 ③으로 가기 전 **안정성을 확보하는 임시조치**다. 사람이 한 번 보고
# 보내므로 잘못된 수신처·첨부가 그대로 나가지 않는다.
#
# 그래서 조립(`compose_report`)과 발송을 갈라 둔다. ③으로 갈 때 발송부만
# 갈아 끼우면 되고, 본문·첨부·수신인 규칙은 손대지 않는다.


def compose_report(department: str, dept_data: dict, run_at: str,
                   recipients: list[str], team: str | None = None) -> dict[str, Any]:
    """보낼 «내용»을 만든다 — 보내는 방법과 무관하다.

    본문과 첨부는 **같은 기준**이어야 한다. 임시부재(1C)가 판정 대상에서 빠진
    뒤로는 양쪽 모두 그 기준이라 맞출 것이 없다. 예전에는 이것이 토글이어서
    한쪽만 빼면 「본문 26건, 첨부 3,245건」처럼 어긋났다.

    **첨부를 먼저 만들고 그 성공 여부를 본문에 알린다.** 첨부가 없으면 이 메일에
    상세가 어디에도 없는데, 본문이 「첨부를 보십시오」라고 적혀 있으면 받는
    사람은 첨부를 잃어버린 줄 알고 되묻는다.
    """
    scope = f"{department} > {team}" if team else department
    attach = _dept_excel_path(department, team)
    return {
        "scope": scope,
        "recipients": recipients,
        "subject": f"[QC Summary] {scope} 결함 리포트 - {run_at}",
        "html": _build_dept_report_html(department, dept_data, run_at, team,
                                        attached=attach is not None),
        "attach": attach,
    }


def build_eml(mail: dict[str, Any]) -> bytes:
    """받는 사람의 Outlook에서 «초안»으로 열리는 파일을 만든다.

    **`X-Unsent: 1`이 핵심이다.** 이게 없으면 Outlook이 «받은 편지»처럼 읽기
    모드로 열어서 보내기 단추가 없다 — 사용자는 「열리긴 하는데 못 보낸다」가
    된다.

    `mailto:`로는 안 된다. **첨부를 실을 수 없고**, 본문 길이 제한(~2,000자)에
    지금 요약본(약 2,400자)이 이미 걸린다.

    첨부는 base64로 실려 약 1.35배가 된다. 사내 메일 서버의 첨부 상한을 넘길
    수 있으므로, 그건 받는 사람이 보내기를 누를 때 드러난다.

    pywin32가 필요 없다 — 표준 `email` 모듈만 쓴다. 그래서 **서버 PC에 Outlook이
    없어도** 이 경로는 동작한다.
    """
    m = EmailMessage()
    # **쉼표로 잇는다.** `.eml`은 RFC 5322라 주소 구분자가 쉼표다. Outlook UI의
    # 관례인 세미콜론으로 이으면 파서가 첫 주소만 읽고 **나머지가 조용히
    # 사라진다** — 실제로 그렇게 만들었다가 테스트가 잡았다. 오류가 나지 않고,
    # 빠진 사람이 말해 주기 전에는 알 수 없다.
    m["To"] = ", ".join(mail["recipients"])
    m["Subject"] = mail["subject"]
    m["X-Unsent"] = "1"
    # HTML을 못 읽는 클라이언트를 위한 대체 본문. 없으면 그런 클라이언트에서
    # 태그가 그대로 보인다.
    m.set_content(f"{mail['scope']} 결함 리포트입니다. "
                  "HTML을 지원하는 메일 클라이언트에서 열어 주십시오.")
    m.add_alternative(mail["html"], subtype="html")
    if mail["attach"]:
        p = Path(mail["attach"])
        m.add_attachment(
            p.read_bytes(),
            maintype="application",
            subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            filename=p.name)
    return m.as_bytes()


# 루프백 주소. 여기서 온 요청만 «서버 PC에서 누른 것»이다.
_LOOPBACK = {"127.0.0.1", "::1", "localhost"}


def _require_server_pc(request: Request) -> None:
    """서버 PC에서 온 요청인가.

    `win32com` 경로는 **서버 PC의 Outlook에 창을 띄운다.** 원격 접속자가 부르면
    초안은 서버 PC에 열리고 누른 사람은 그걸 볼 수 없다 — 응답은 `{"ok": true}`라
    성공한 것처럼 보인다. 오류가 나지 않아 알아채기 어렵고, 서버 PC에는 아무도
    안 보는 초안이 쌓인다.

    그래서 **막고 대신 길을 알려준다.** 조용히 엉뚱하게 도는 것보다 낫다.

    서버 PC에서 LAN 주소로 접속한 경우도 막히는데, 그때 안내받는 `.eml` 경로가
    그 자리에서도 그대로 동작하므로 손해가 없다.
    """
    host = (request.client.host if request.client else "") or ""
    if host not in _LOOPBACK:
        raise HTTPException(
            400,
            "이 발송 방식은 서버 PC의 Outlook에 초안을 엽니다 — 지금 접속하신 "
            "PC에서는 그 창을 볼 수 없습니다. '범위별 내보내기' 탭의 "
            "[메일 발송]을 쓰시면 메일 파일(.eml)이 내려오고, 더블클릭하면 "
            "이 PC의 Outlook에서 초안으로 열립니다.")


def _dispatch_dept_mail(department: str, dept_data: dict,
                        recipients: list[str], run_at: str,
                        team: str | None = None) -> None:
    """**레거시** — 서버 PC의 Outlook에 초안을 연다. 실패 시 예외 발생.

    원격 접속자에게는 쓸 수 없다(초안이 서버 PC에 열린다). 화면의 「메일 발송」은
    `.eml` 경로를 쓴다. 서버 PC에서 직접 쓰는 경우를 위해 남겨 둔다.
    """
    mail = compose_report(department, dept_data, run_at, recipients, team)
    pythoncom.CoInitialize()
    try:
        outlook = win32com.client.Dispatch("Outlook.Application")
        item = outlook.CreateItem(0)  # olMailItem
        item.To = "; ".join(mail["recipients"])
        item.Subject = mail["subject"]
        item.HTMLBody = mail["html"]
        if mail["attach"]:
            item.Attachments.Add(mail["attach"])
        item.Display()
    finally:
        pythoncom.CoUninitialize()


def _mail_scope_or_404(department: str, team: str | None) -> tuple[dict, list[str], str]:
    """그 범위의 집계·수신인·검증 시각. 없으면 이유를 말하고 404/400."""
    result = get_last_result()
    if result is None:
        raise HTTPException(404, "검증 결과가 없습니다. 먼저 검증을 실행하세요")
    dept_data = (result.get('departments') or {}).get(department)
    if dept_data is None:
        raise HTTPException(404, f"'{department}' 부서 데이터를 찾을 수 없습니다")
    if team:
        dept_data = (dept_data.get('teams') or {}).get(team)
        if dept_data is None:
            raise HTTPException(404, f"'{department} > {team}' 팀 데이터를 찾을 수 없습니다")
        recipients = _team_recipients_of(department, team)
    else:
        recipients = _load_dept_recipients().get(department, [])
    if not recipients:
        what = f"'{team}'" if team else f"'{department}'"
        raise HTTPException(400, f"{what}의 수신인이 설정되지 않았습니다. 먼저 수신인을 추가하세요")
    return dept_data, recipients, result.get('run_at', '')


@router.get("/mail/draft")
def download_mail_draft(
    department: str,
    team: str | None = None,
    t: str | None = None,
    x_employee_id: str | None = Header(None),
):
    """리포트 메일을 **받는 사람의 Outlook에서** 열리는 `.eml`로 내려준다.

    예전에는 서버가 `win32com`으로 자기 PC의 Outlook에 초안을 열었다. 사내망
    다른 PC에서 쓰기 시작하니 **원격 접속자가 눌러도 초안은 서버 PC에 열렸다** —
    누른 사람에게는 아무 일도 안 일어난 것처럼 보이고, 서버 PC에는 아무도 안 보는
    초안이 쌓인다. 오류가 나지 않아서 알아채기 어렵다.

    부서명·팀명은 **질의 파라미터로 받는다** — 이름에 `/`가 든 부서가 실제로
    있어서(`Q530-SMR/ITER생산부`) 경로에 두면 그 부서만 404가 된다.

    인증은 결과 Excel 내려받기와 **같은 표**를 쓴다. `<a download>`는 커스텀
    헤더를 실을 수 없기 때문이다. 표에는 사번이 들어 있어 관리자 여부까지 본다.
    """
    from backend.routers.verify import check_download_ticket
    emp = x_employee_id or check_download_ticket(t)
    if not emp:
        raise HTTPException(401, "다운로드 표가 없거나 만료되었습니다. 다시 시도하세요")
    _require_admin(emp)

    dept_data, recipients, run_at = _mail_scope_or_404(department, team)
    mail = compose_report(department, dept_data, run_at, recipients, team)
    body = build_eml(mail)

    # 파일 이름이 곧 Outlook 창의 제목처럼 읽힌다 — 어느 범위인지 보이게 한다.
    name = "QC리포트_" + "".join(
        ch for ch in (mail["scope"].replace(" > ", "_"))
        if ch.isalnum() or ch in "-_" or ord(ch) > 127) + ".eml"
    logger.info("메일 초안 파일 생성: %s -> %s (%.0f KB%s)",
                mail["scope"], recipients, len(body) / 1024,
                "" if mail["attach"] else ", 첨부 없음")
    return Response(
        content=body,
        media_type="message/rfc822",
        headers={
            "Content-Disposition":
                f"attachment; filename*=UTF-8''{urllib.parse.quote(name)}",
            "Cache-Control": "no-store, no-cache, must-revalidate",
        },
    )


@router.post("/departments/send")
def send_department_report(request: Request,
                           department: str,
                           x_employee_id: str | None = Header(None)) -> dict:
    """
    부서별 결함 리포트를 Outlook 초안으로 연다 (mail.Display()).
    사용자가 Outlook에서 직접 확인 후 '보내기'를 눌러야 실제 발송된다.
    (추후 검증 완료 시 mail.Send()로 자동 발송하도록 전환 예정)

    부서명은 **질의 파라미터로 받는다.** 경로에 두면 `Q530-SMR/ITER생산부`처럼
    이름에 `/`가 든 부서가 404가 된다 — `encodeURIComponent`로 `%2F`를 보내도
    ASGI 서버가 라우팅 전에 경로를 풀어 버려서 세그먼트가 갈라진다.
    결함 목록 쪽에서 같은 이유로 표가 통째로 비었던 적이 있다.
    """
    _require_admin(x_employee_id)
    _require_server_pc(request)
    if not _OUTLOOK_AVAILABLE:
        raise HTTPException(501, "Outlook 연동을 사용할 수 없습니다 (pywin32 미설치)")

    result = get_last_result()
    if result is None:
        raise HTTPException(404, "검증 결과가 없습니다. 먼저 검증을 실행하세요")
    dept_data = (result.get('departments') or {}).get(department)
    if dept_data is None:
        raise HTTPException(404, f"'{department}' 부서 데이터를 찾을 수 없습니다")

    recipients = _load_dept_recipients().get(department, [])
    if not recipients:
        raise HTTPException(400, f"'{department}'의 수신인이 설정되지 않았습니다. 먼저 수신인을 추가하세요")

    try:
        # 상세 목록을 본문에 싣지 않으므로 `expand_defects()`를 부르지 않는다 —
        # 큰 팀에서 그 자체가 무거웠다. 상세는 첨부 Excel이 갖고 있다.
        _dispatch_dept_mail(department, dept_data,
                            recipients, result.get('run_at', ''))
    except Exception as exc:
        logger.exception("Outlook 초안 생성 실패")
        raise HTTPException(500, f"Outlook 초안 생성 실패: {exc}")

    logger.info("부서 리포트 초안 생성: %s -> %s", department, recipients)
    return {"ok": True, "department": department, "recipients": recipients,
            "mode": "draft"}


@router.post("/teams/send")
def send_team_report(request: Request,
                     department: str, team: str,
                     x_employee_id: str | None = Header(None)) -> dict:
    """팀별 결함 리포트를 Outlook 초안으로 연다.

    부서 발송과 **같은 본문·같은 첨부 구조**를 쓴다. 다른 것은 범위뿐이다:
    수신인은 그 팀에 설정된 주소이고, 첨부는 그 팀 범위의 결과 Excel이다.

    부서명·팀명 모두 질의 파라미터로 받는다 — 이름에 `/`가 들어간 부서가
    실제로 있어서(`Q530-SMR/ITER생산부`) 경로에 두면 그 부서만 404가 된다.
    """
    _require_admin(x_employee_id)
    _require_server_pc(request)
    if not _OUTLOOK_AVAILABLE:
        raise HTTPException(501, "Outlook 연동을 사용할 수 없습니다 (pywin32 미설치)")

    result = get_last_result()
    if result is None:
        raise HTTPException(404, "검증 결과가 없습니다. 먼저 검증을 실행하세요")
    dept_data = (result.get('departments') or {}).get(department)
    if dept_data is None:
        raise HTTPException(404, f"'{department}' 부서 데이터를 찾을 수 없습니다")
    team_data = (dept_data.get('teams') or {}).get(team)
    if team_data is None:
        raise HTTPException(404, f"'{department} > {team}' 팀 데이터를 찾을 수 없습니다")

    recipients = _team_recipients_of(department, team)
    if not recipients:
        raise HTTPException(400, f"'{team}'의 수신인이 설정되지 않았습니다. 먼저 수신인을 추가하세요")

    try:
        _dispatch_dept_mail(department, team_data,
                            recipients, result.get('run_at', ''), team=team)
    except Exception as exc:
        logger.exception("Outlook 초안 생성 실패")
        raise HTTPException(500, f"Outlook 초안 생성 실패: {exc}")

    logger.info("팀 리포트 초안 생성: %s > %s -> %s", department, team, recipients)
    return {"ok": True, "department": department, "team": team,
            "recipients": recipients, "mode": "draft"}


class SendBatchIn(BaseModel):
    departments: list[str]


@router.post("/departments/send-batch")
def send_department_reports_batch(request: Request, body: SendBatchIn,
                                  x_employee_id: str | None = Header(None)) -> dict:
    """
    선택된 여러 부서 각각에 대해 개별 Outlook 초안을 연다.
    부서마다 별도 메일로, 그 부서의 개별 수신인에게만 발송(초안)된다 — 하나로 합쳐 보내지 않음.
    """
    _require_admin(x_employee_id)
    _require_server_pc(request)
    if not _OUTLOOK_AVAILABLE:
        raise HTTPException(501, "Outlook 연동을 사용할 수 없습니다 (pywin32 미설치)")
    if not body.departments:
        raise HTTPException(400, "발송할 부서를 선택하세요")

    result = get_last_result()
    if result is None:
        raise HTTPException(404, "검증 결과가 없습니다. 먼저 검증을 실행하세요")
    departments_data = result.get('departments') or {}
    recipients_map    = _load_dept_recipients()
    run_at            = result.get('run_at', '')

    sent:    list[dict] = []
    skipped: list[dict] = []
    for dept in body.departments:
        dept_data = departments_data.get(dept)
        if dept_data is None:
            skipped.append({"department": dept, "reason": "부서 데이터를 찾을 수 없음"})
            continue
        recipients = recipients_map.get(dept, [])
        if not recipients:
            skipped.append({"department": dept, "reason": "수신인이 설정되지 않음"})
            continue
        try:
            _dispatch_dept_mail(dept, dept_data, recipients, run_at)
            sent.append({"department": dept, "recipients": recipients})
        except Exception as exc:
            logger.exception("Outlook 초안 생성 실패: %s", dept)
            skipped.append({"department": dept, "reason": str(exc)})

    logger.info("부서 일괄 발송: 성공 %d건, 건너뜀 %d건", len(sent), len(skipped))
    return {"ok": True, "sent": sent, "skipped": skipped}
