'use strict';

/* ── 서버 조회 계층 ────────────────────────────────────────────────────────────
   플래그는 더 이상 /api/result에 통째로 실려 오지 않는다. 실측 2,521KB(응답의 84%)
   이고 30만 행이면 ~76MB라 브라우저가 받지 못한다. 한 화면이 쓰는 것은 한 페이지뿐.

   여기 있는 함수들은 전부 **서버가 하는 필터와 같은 조건**을 보낸다. 조건이
   갈라지면 «전에는 나오던 게 안 나온다»가 되고, 현업은 그걸 판정이 바뀐 것으로
   읽는다. 서버쪽 규칙은 result_store._FLAG_SEARCH_COLS 참조. */
function _qs(params) {
  const p = new URLSearchParams();
  Object.keys(params).forEach(k => {
    const v = params[k];
    if (v === undefined || v === null || v === '') return;
    p.set(k, Array.isArray(v) ? v.join(',') : String(v));
  });
  return p.toString();
}

/* 플래그 한 페이지. {total, offset, items} */
function fetchFlags(params) {
  return apiFetch(`/api/flags?${_qs(params)}`);
}

/* 선택된 Check만으로 다시 낸 대시보드 수치 */
function fetchAggregate(params) {
  return apiFetch(`/api/flags/aggregate?${_qs(params)}`);
}

/* checks 파라미터는 «전부 해제»와 «필터 없음»을 반드시 구분해야 한다.
   뭉개면 화면에서 Check를 전부 해제했는데 전체가 나오는 상태가 된다.

   전부 해제일 때 -1을 보내는 이유: 빈 값은 _qs()가 생략해 버려 «필터 없음»과
   구분되지 않는다. 존재하지 않는 check_no라 서버에서 자연히 0건이 된다. */
/* 이번 회차에서 «판정한» 항목만.

   '프로젝트 세팅'에서 끈 항목은 판정 자체를 하지 않으므로 영영 0건이다. 카드를
   그대로 두면 «껐는데 왜 보이냐»가 되고, 0건이 «문제가 없다»인지 «판정을 안
   했다»인지도 구분되지 않는다.

   기준은 **현재 설정이 아니라 결과에 박힌 스냅샷**(`result.rules`)이다. 화면이
   보여주는 것은 «이 회차의 결과»이므로, 검증 뒤에 설정을 바꿔도 그 회차가
   무엇으로 판정됐는지는 변하지 않아야 한다.

   스냅샷이 없으면(옛 회차) 전부 보여준다 — 모르는 것과 꺼진 것은 다르다. */
function _ruleOn(no) {
  const r = (S.result && S.result.rules) || null;
  if (!r || !Object.keys(r).length) return true;
  return r[String(no)] !== false;
}

/* 이 회차가 실제로 판정한 항목 전부 — **공통(고정 표) + 프로젝트 규칙(결과 스냅샷).**

   `CHECK_META`는 1~20 고정이라 프로젝트 규칙(101~199)이 들어올 자리가 없었다.
   결과 표의 배지는 서버가 준 색 이름(`COLOR_TO_CLS`)을 쓰므로 멀쩡하지만, 여기를
   거치는 세 곳이 조용히 틀어진다:

     · 대시보드 Check 카드 — 101번 결함이 카드로 안 보인다
     · 도넛 범례 — 같은 이유
     · `_checksParam()` — 선택 집합에 101이 없으니 «전부 선택»으로 판정되지 않고,
       101을 뺀 목록을 필터로 보내 **그 결함이 집계에서 사라진다**

   지금 물량은 프로젝트 규칙이 0행이라 화면 영향이 없다. 그래서 더 위험하다 —
   규칙이 처음 걸리는 날에야 드러나고, 그날은 «새 규칙이 안 먹는다»로 보인다. */
/* 「이 Check는 다른 프로젝트 값을 빌려 쓰는 중이라 재확인이 필요하다」.

   **결과에 박힌 것**을 읽는다(`result.provisional`) — 켬/끔과 같은 이유다.
   나중에 설정을 고쳐도 «이 회차가 무슨 상태에서 나온 숫자인가»는 변하지 않아야 한다.

   표식이 없으면 빌려 온 값으로 나온 건수를 «확정된 판정»으로 읽게 된다. 오류가
   나지 않는 종류라, 화면에 남겨 두지 않으면 잊는다. */
function _provReason(no) {
  return ((S.result && S.result.provisional) || {})[String(no)] || '';
}

function _provMark(no) {
  const why = _provReason(no);
  return why ? `<span class="ck-prov" title="${_esc(why)}">확인 필요</span>` : '';
}

/* 「대조할 대상이 0건이었다」 — «검사했고 위반이 없다»와 다르다.

   화면에서는 둘 다 그냥 «0건»으로 보인다. 실제로 Check 25는 `Q01`로 끝나는 WPS가
   한 행도 없어 한 번도 안 돌았는데 «통과»로 읽혔다. Check 15가 결번이 된 것도
   「위반 0건」을 뒤늦게 「대조 조합 0건」으로 정정한 결과다.

   `result.scope`에 없는 번호는 **판정 대상 전체**를 보는 검사다(Check 1·2·3 등) —
   그건 «대상이 없다»가 아니라 «전부가 대상»이라 표식을 달지 않는다. */
function _noScope(no) {
  const sc = (S.result && S.result.scope) || null;
  if (!sc) return false;
  const v = sc[String(no)];
  return v !== undefined && Number(v) === 0;
}

function _scopeMark(no) {
  return _noScope(no)
    ? '<span class="ck-noscope" title="이 검사가 대조한 대상이 0건입니다.'
      + ' «위반이 없다»가 아니라 «한 번도 판정하지 않았다»는 뜻입니다.">대상 없음</span>'
    : '';
}

function _activeMeta() {
  const common = CHECK_META.filter(c => _ruleOn(c.no));
  const rules = (S.result && S.result.project_checks) || [];
  const extra = rules
    .filter(r => r && r.no && !CHECK_META.some(c => c.no === r.no) && _ruleOn(r.no))
    .map(r => {
      const cls = COLOR_TO_CLS[r.color] || 'p-blue';
      return {no: r.no, name: r.name || `프로젝트 규칙 ${r.no}`,
              col: r.cols || 'J · K', cls,
              // `p-blue` -> `var(--ck-blue)`. 색 정의는 CSS 한 곳뿐이라 여기서 만든다.
              ckC: `var(--ck-${cls.replace(/^p-/, '')})`};
    });
  return common.concat(extra.sort((a, b) => _ckSort(a.no, b.no)));
}

function _checksParam(sel) {
  const all = _activeMeta().map(c => c.no);
  const picked = all.filter(no => sel.has(no));
  if (picked.length === all.length) return undefined;   // 전부 선택 = 필터 없음
  return picked.length ? picked.join(',') : '-1';
}

/* ── 상수 ──────────────────────────────────────────────────────────────────── */
/* **`no`는 문자열이다.** 서버가 주는 `check_no`가 문자열(`'14'`·`'RUYA1'`)이라,
   여기만 숫자로 두면 한 화면 안에 두 표현이 공존한다. 그러면
   `sel.has('14')`처럼 숫자와 문자열이 맞부딪히는 자리가 **조용히 «없는 것»**이
   된다 — `===`는 타입까지 보는데 예외는 나지 않는다. 실제로 Check 14 그룹 뷰가
   통째로 안 나오고, 프로젝트 세팅 체크박스가 상태를 안 바꾸는 사고가 났다. */
const CHECK_META = [
  {no:'1',  name:'일정 오류',           col:'AO', cls:'p-red',    ckC:'var(--ck-red)'},
  {no:'2',  name:'WPS/Process 불일치',  col:'AJ', cls:'p-green',  ckC:'var(--ck-green)'},
  {no:'3',  name:'두께 허용범위 초과',  col:'J',  cls:'p-blue',   ckC:'var(--ck-blue)'},
  {no:'4',  name:'Groove 불일치',       col:'R',  cls:'p-amber',  ckC:'var(--ck-amber)'},
  {no:'5',  name:'특수규칙 P+G01',      col:'AJ', cls:'p-blue',   ckC:'var(--ck-blue)'},
  {no:'6',  name:'용접사 자격 미등록',  col:'AP', cls:'p-orange', ckC:'var(--ck-orange)'},
  {no:'7',  name:'용접사 승인기간 이후 작업', col:'AP', cls:'p-amber',  ckC:'var(--ck-amber)'},
  {no:'8',  name:'TR-FC-G03 특수',      col:'J',  cls:'p-blue',   ckC:'var(--ck-blue)'},
  {no:'9',  name:'TR-SMFC-G01 특수',    col:'J',  cls:'p-green',  ckC:'var(--ck-green)'},
  {no:'10', name:'복합 오류 (3+8)',     col:'J',  cls:'p-dark',   ckC:'var(--ck-dark)'},
  {no:'11', name:'재질-WPS 부적합',     col:'M',  cls:'p-purple', ckC:'var(--ck-purple)'},
  {no:'12', name:'관재 DIA 확인 필요',  col:'I',  cls:'p-teal',   ckC:'var(--ck-teal)'},
  {no:'13', name:'이상치(특이 조합) 확인 필요', col:'A', cls:'p-cyan', ckC:'var(--ck-cyan)'},
  {no:'14', name:'Joint 중복 등록 (값 불일치)', col:'D', cls:'p-brown', ckC:'var(--ck-brown)'},
  // Check 15는 결번 — 용접사 두께/직경 상한 대조를 넣으려다 위반 0건(자격 DB 766명 중
  // 두께 상한 기재가 5명뿐)이라 착수하지 않았다. 검토 기록 키가 '…|Check No'라서
  // 번호를 재사용하면 과거 검토 의견이 무관한 항목에 붙는다.
  {no:'16', name:'NDT 요구 대비 미수행', col:'BP', cls:'p-olive', ckC:'var(--ck-olive)'},
  {no:'17', name:'육안검사(VT) 미수행',  col:'BI', cls:'p-navy',  ckC:'var(--ck-navy)'},
  {no:'18', name:'용접봉 Lot 미기재·미승인', col:'AL', cls:'p-orange', ckC:'var(--ck-orange)'},
  {no:'19', name:'WPS Process 자격자 미투입', col:'AK', cls:'p-maroon', ckC:'var(--ck-maroon)'},
  {no:'20', name:'API 재질 Groove별 프로세스 부적합', col:'AK', cls:'p-indigo', ckC:'var(--ck-indigo)'},
  // 2026-08-13 추가. 색은 기존 16색에서 고른다 — 없는 색을 쓰면 배지가 무색이 된다.
  {no:'21', name:'혼합 프로세스 용접재료 누락',   col:'AL', cls:'p-rose',   ckC:'var(--ck-rose)'},
  {no:'22', name:'NDT 리포트 번호 미확정',        col:'BQ', cls:'p-olive',  ckC:'var(--ck-olive)'},
  {no:'23', name:'수리 시공 · 수리 WPS 미적용',   col:'AJ', cls:'p-gray',   ckC:'var(--ck-gray)'},
  {no:'24', name:'TKY 이음 전용 WPS 미적용',      col:'AJ', cls:'p-cyan',   ckC:'var(--ck-cyan)'},
  {no:'25', name:'Q01 WPS · 이음 Type 부적합',    col:'Q',  cls:'p-teal',   ckC:'var(--ck-teal)'},
  {no:'26', name:'NDE 적용 요율 미달',            col:'BQ', cls:'p-navy',   ckC:'var(--ck-navy)'},
  {no:'27', name:'이종재 상위 그레이드 WPS 부적합', col:'M', cls:'p-purple', ckC:'var(--ck-purple)'},
];
/* 판정 항목의 «구분». 서버 `rule_catalog.CATALOG`와 같아야 한다 —
   갈라지면 결함 카드의 배지와 '프로젝트 세팅' 탭이 서로 다른 말을 한다.
   `tests/test_rule_catalog.py`가 두 곳을 대조한다. */
const CHECK_CATEGORY = {
  8: '프로젝트', 9: '프로젝트',
};
/* 101~199는 «프로젝트» 대역이다(`project_checks.ID_MIN`). 표에 적어 두면 규칙을
   추가할 때마다 여기도 고쳐야 하고, 빠뜨리면 프로젝트 규칙이 «공통» 배지를 단다. */
/* 식별자 정렬 — 공통을 숫자순으로 먼저, 그다음 프로젝트를 이름으로 묶어 순번순.
   `Number(a) - Number(b)`로 정렬하던 자리가 여럿이었다. 프로젝트 식별자가
   문자열이 되면 `Number("RUYA1")`이 NaN이라 **순서가 통째로 무너진다** —
   오류는 나지 않고 카드 순서만 뒤죽박죽이 된다. */
function _ckSort(a, b) {
  const key = v => {
    const s = String(v).trim();
    if (/^\d+$/.test(s)) return [0, '', parseInt(s, 10)];
    const m = /^(.*?)(\d+)$/.exec(s);
    return [1, (m ? m[1] : s).toUpperCase(), m ? parseInt(m[2], 10) : 0];
  };
  const x = key(a), y = key(b);
  return x[0] - y[0] || (x[1] < y[1] ? -1 : x[1] > y[1] ? 1 : 0) || x[2] - y[2];
}

/* 화면 표기 — `RUYA1` -> `RUYA 1`, `3` -> `3`. */
function _ckLabel(no) {
  const s = String(no).trim();
  if (/^\d+$/.test(s)) return s;
  const m = /^(.*?)(\d+)$/.exec(s);
  return m ? `${m[1]} ${m[2]}` : s;
}

function _ckCategory(no) {
  // **모양으로 가른다** — 숫자면 공통, 아니면 프로젝트(`RUYA1`).
  // 번호 대역으로 가르던 때는 규칙을 추가할 때마다 여기도 고쳐야 했다.
  //
  // 다만 **옛 번호(101~199)는 숫자인데 프로젝트다.** 모양만 보면 «공통»으로
  // 답해서, 대시보드는 「공통」·프로젝트 세팅 탭은 「프로젝트」가 되어 **같은
  // 서버의 두 화면이 다른 말을 한다.** 서버 `project_checks.is_common()`과
  // 같은 예외를 둔다.
  const s = String(no).trim();
  if (!/^\d+$/.test(s)) return '프로젝트';
  if (+s >= 101 && +s <= 199) return '프로젝트';
  return CHECK_CATEGORY[no] || '공통';
}

const COLOR_TO_CLS = {
  Red:'p-red', Green:'p-green', Blue:'p-blue',
  Yellow:'p-amber', Orange:'p-orange', Black:'p-dark',
  Purple:'p-purple', Teal:'p-teal', Gray:'p-gray', Cyan:'p-cyan', Brown:'p-brown',
  Olive:'p-olive', Navy:'p-navy', Rose:'p-rose',
  Maroon:'p-maroon', Indigo:'p-indigo',
};
const CRUMBS = {
  upload:'파일 업로드', dashboard:'대시보드', results:'상세 결과',
  welders:'용접사 관리', departments:'부서별 결함', 'dept-dashboard':'부서별 대시보드',
  logic:'검사 로직',
  review:'현업 검증사항', agents:'에이전트',
  'ml-unsup':'비지도학습', 'ml-sup':'지도학습',
  exports:'범위별 내보내기', rules:'프로젝트 세팅', settings:'설정',
};
const PAGE_SIZE = 50;

/* 용접사 상세가 한 번에 받는 플래그 상한. 서버의 config.MAX_FLAG_PAGE와 짝이며,
   실측(1만 행) 최다 용접사가 382건이라 30만 행이면 ~11,000건이 된다. */
const WELDER_FLAG_MAX = 20000;

/* ── 앱 상태 ────────────────────────────────────────────────────────────────── */
const S = {
  view:           'dashboard',
  pollTimer:      null,
  result:         null,
  filteredFlags:  [],
  welderRows:     [],   // 통합 용접사 목록(welder_info 기반)
  page:           1,
  recipients:     [],
  currentDept:    null,
  deptRecipients: {},
  deptRecipientDraft: [],
  deptSubtab:      'defects',
  welderPage:      1,
  welderFilter:    '',   // '' | 'unregistered' | 'recurring' | 'lowsample' | 'clean'
  welderRecurPage: 1,
  deptWelderPage:  1,
  deptDefectPage:  1,
  deptRecurringPage: 1,
  deptDashDept:    null,
  deptDashTeam:    null,
  feedback:        {},   // Human-in-the-loop 검토 기록: "drawing_no|joint_no|wps_no|check_no" -> record
                         // 도면번호가 키에 반드시 들어가야 한다 — Joint No는 도면 안에서만
                         // 유일해서, 빼면 무관한 조인트끼리 검토 기록을 공유한다(_fbKey 참고).
  mck:             null, // Check 목록 팝업 상태
  rcp:             null, // 반복 결함 패턴 상세 팝업 상태
  wd:              null, // 용접사 상세 팝업 상태
  dashCheckSel:    null, // 대시보드 Check 취사선택 — null이면 "전부 선택"으로 간주
                        // (개수를 적지 않는다 — Check가 늘 때마다 주석이 낡는다)
  deptDashCheckSel: null, // 부서별 대시보드 Check 취사선택 — 부서/팀을 옮겨도 유지된다(공용 1개)
  // 검사 항목 카드의 정렬. **기본이 «수량 순»이다** — 이 화면에서 가장 먼저
  // 알고 싶은 것이 «어떤 검사가 가장 많이 걸렸는가»다. 번호 순은 특정 Check를
  // 찾을 때 쓴다. 메인/부서가 따로 갖는다 — 한쪽이 다른 쪽을 조용히 따라가면
  // «내가 무엇을 보고 있는지»를 놓친다.
  dashCheckSort:     'count',   // count | no
  deptDashCheckSort: 'count',
};

/* ── 공용 페이지네이션 유틸 ────────────────────────────────────────────────────── */
function _paginate(arr, page, size) {
  const pages = Math.ceil(arr.length / size) || 1;
  const p     = Math.min(Math.max(1, page), pages);
  const start = (p - 1) * size;
  return { slice: arr.slice(start, start + size), page: p, pages, total: arr.length, start };
}

function _buildPagerHtml(page, pages, fnName) {
  const arr = buildPageArr(page, pages);
  return `<button class="pbtn" onclick="${fnName}(${page - 1})" ${page<=1?'disabled':''}>‹</button>` +
    arr.map(p => p === '…'
      ? `<span style="padding:3px 6px;color:var(--text-3)">…</span>`
      : `<button class="pbtn ${p===page?'curr':''}" onclick="${fnName}(${p})">${p}</button>`
    ).join('') +
    `<button class="pbtn" onclick="${fnName}(${page + 1})" ${page>=pages?'disabled':''}>›</button>`;
}

function _setPageInfo(id, start, end, total) {
  const el = document.getElementById(id);
  if (el) el.textContent = total ? `${_n(start)}–${_n(end)} / ${_n(total)}행` : '0행';
}

/* ── 뷰 전환 ────────────────────────────────────────────────────────────────── */
function setView(v) {
  ['upload','dashboard','results','welders','departments','dept-dashboard','logic','review','agents','ml-unsup','ml-sup','exports','rules','settings'].forEach(id => {
    const el = document.getElementById('view-' + id);
    if (el) el.style.display = (id === v) ? 'block' : 'none';
  });
  document.querySelectorAll('.nav-item').forEach(el =>
    el.classList.toggle('active', el.id === 'nav-' + v)
  );
  const crumb = document.getElementById('view-crumb');
  if (crumb) crumb.textContent = CRUMBS[v] || v;
  S.view = v;
  setStatusContext(CRUMBS[v] || v);
  if (v === 'dashboard' && S.result) renderDashboard(S.result);
  if (v === 'results'   && S.result) renderResults();
  if (v === 'welders')               renderWelderManagement(S.result);
  if (v === 'departments')           renderDepartments(S.result);
  if (v === 'dept-dashboard')        renderDeptDashboard(S.result);
  if (v === 'logic')                 loadLogicDiagrams();
  if (v === 'review')                loadReviewItems();
  if (v === 'ml-unsup')              renderMlUnsup();
  if (v === 'ml-sup')                loadMlSupLabels();
  if (v === 'exports')               loadExports();
  if (v === 'rules')               { loadRuleSettings(); loadProjectParams();
                                     aiShow('rules', 'rules', {}, 'ai-rules'); }
  if (v === 'upload')              { loadRunProjects();
                                     aiShow('upload', 'quality', {}, 'ai-upload'); }
  if (v === 'agents')                loadAgents();
  if (v === 'settings')            { loadSettings(); loadRecipientSettings();
                                     loadTeamRecipientSettings(); loadProjectList(); }
}

/* ── 검사 로직 도식 ───────────────────────────
   서버가 `verifier.py`에서 Mermaid 소스를 «생성»해 내려주고, 여기서는 렌더만 한다.
   화면에 도식을 박아 두지 않는 이유: 판정 코드를 고쳤을 때 그림이 조용히 낡는다.
   그림은 틀려도 오류가 나지 않고, 보는 사람은 그림을 믿는다.

   Mermaid는 렌더 시점의 색을 SVG에 구워 넣으므로 테마가 바뀌면 다시 그려야 한다.
   그래서 «받아온 소스»(LG.items)와 «그린 결과»를 분리해 둔다 — 다시 그릴 때
   서버에 또 묻지 않는다. */
const LG = { items: null, loading: false, seq: 0 };

async function loadLogicDiagrams() {
  if (LG.loading || LG.items) { _lgRender(); return; }
  LG.loading = true;
  const body = document.getElementById('lg-body');
  if (body) body.innerHTML = '<div class="rv-form-hint" style="padding:18px">도식을 만드는 중…</div>';
  try {
    const r = await apiFetch('/api/diagrams');
    LG.items = r.items || [];
    const at = document.getElementById('lg-runat');
    if (at) {
      at.textContent = r.has_result
        ? ' · 행 수치는 ' + (r.run_at || '') + ' 검증 결과입니다'
        : ' · 검증 결과가 없어 구조만 표시합니다';
    }
    _lgRender();
  } catch (e) {
    if (body) {
      body.innerHTML = '<div class="rv-note" style="color:var(--ck-orange)">' +
        '도식을 불러오지 못했습니다 — ' + _esc(String(e.message || e)) + '</div>';
    }
  } finally {
    LG.loading = false;
  }
}

/* Mermaid 테마 변수. 앱의 CSS 변수에서 가져와 «화면과 같은 바탕»으로 그린다.
   노드 색은 서버가 도식 안에 직접 넣는다 — 판정 색상이라 테마와 무관해야 한다.

   **토큰 이름을 지어내지 마라.** 처음에 `--bg-1`·`--line-1`처럼 없는 이름을 썼고,
   `v()`의 기본값(라이트 색)이 항상 대신 들어가 **다크 모드에서 도식만 흰 바탕**
   으로 남았다. 값이 없으면 빈 문자열이라 조용히 기본값으로 떨어진다. */
function _lgTheme() {
  const cs = getComputedStyle(document.documentElement);
  const v = (n, fb) => (cs.getPropertyValue(n) || '').trim() || fb;
  return {
    startOnLoad: false,
    securityLevel: 'strict',
    theme: 'base',
    fontFamily: "'Malgun Gothic','Segoe UI',sans-serif",
    themeVariables: {
      background:         v('--bg', '#ffffff'),
      primaryColor:       v('--surface', '#f4f5f7'),
      primaryTextColor:   v('--text', '#111111'),
      primaryBorderColor: v('--border', '#cccccc'),
      lineColor:          v('--text-3', '#888888'),
      textColor:          v('--text', '#111111'),
      clusterBkg:         v('--surface', '#fafafa'),
      clusterBorder:      v('--border', '#dddddd'),
    },
  };
}

/* Mermaid가 내주는 SVG는 **그린 것보다 훨씬 큰 캔버스**를 들고 온다.
   실측(같은 페이지):

       판정 흐름   viewBox 2146 x 2111   실제 내용  612 x 1729
       검사 지도   viewBox 2146 x 2746   실제 내용  736 x 2710
       색 우선순위 viewBox 3109 x 2055   실제 내용 3127 x   78   ← 높이 25배

   그대로 두면 카드 옆과 아래에 빈 공간이 잔뜩 남고, 폭에 맞춰 줄이면 «내용»이
   아니라 «빈 캔버스»를 기준으로 줄어들어 글자만 작아진다.

   그래서 그린 내용의 실제 경계(getBBox)로 viewBox를 다시 잡는다. 그 뒤에 폭을
   맞추되 **75%까지만** 줄인다 — 그 아래로 가면 한글 라벨이 읽히지 않는다.
   더 필요하면 카드 안에서 가로로 스크롤한다. */
const LG_PAD = 12;          // 잘려 보이지 않도록 두는 여백
const LG_MIN_SCALE = 0.75;  // 이 아래로는 줄이지 않는다

function _lgFitSvg(slot) {
  const svg = slot.querySelector('svg');
  if (!svg) return;

  // ① 그린 내용에 맞춰 viewBox를 다시 잡는다
  const root = svg.querySelector('g');
  if (root && root.getBBox) {
    try {
      const b = root.getBBox();
      if (b.width > 0 && b.height > 0) {
        svg.setAttribute('viewBox',
          (b.x - LG_PAD) + ' ' + (b.y - LG_PAD) + ' ' +
          (b.width + LG_PAD * 2) + ' ' + (b.height + LG_PAD * 2));
      }
    } catch (e) {
      /* 숨겨진 상태 등에서 getBBox가 실패하면 원래 viewBox로 둔다 */
    }
  }

  // ② 폭 맞추기
  const vb = (svg.getAttribute('viewBox') || '').split(/[ ,]+/).map(Number);
  const natural = vb.length === 4 ? vb[2] : 0;
  if (!natural) return;
  const avail = slot.clientWidth || natural;
  const w = Math.min(natural, Math.max(avail, natural * LG_MIN_SCALE, 320));
  svg.setAttribute('width', w);
  svg.removeAttribute('height');
  svg.style.maxWidth = 'none';
  svg.style.width = w + 'px';
  svg.style.height = 'auto';
}

/* 설명 본문의 아주 좁은 마크다운만 푼다 - `**굵게**`와 `코드`.
   **반드시 이스케이프를 먼저 하고 그 위에 태그를 얹는다.** 순서가 뒤바뀌면
   본문에 들어온 `<`가 태그로 살아난다. 서버가 만든 문장이라 지금은 안전하지만,
   나중에 현업 답변 같은 외부 문자열을 여기 넣게 되면 그때 사고가 난다. */
function _mdInline(text) {
  return _esc(String(text || ''))
    .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
    .replace(/`([^`]+)`/g, '<code>$1</code>');
}

function _lgRender() {
  const body = document.getElementById('lg-body');
  if (!body || !LG.items) return;
  if (typeof mermaid === 'undefined') {
    body.innerHTML = '<div class="rv-note" style="color:var(--ck-orange)">' +
      'Mermaid를 불러오지 못했습니다 (static/js/vendor/mermaid.min.js).</div>';
    return;
  }
  const seq = ++LG.seq;

  body.innerHTML = LG.items.map((d, i) =>
    '<div class="sec-hd" style="margin-top:18px">' +
      '<div class="sec-title">' + _esc(d.title) + '</div>' +
      '<span class="sec-hint">' + _esc(d.hint) + '</span>' +
    '</div>' +
    '<div class="lg-card">' +
      '<div class="lg-split">' +
        '<div class="lg-canvas" id="lg-svg-' + i + '"></div>' +
        '<aside class="lg-notes">' +
          (d.notes || []).map(n =>
            '<div class="lg-note">' +
              '<div class="lg-note-hd">' + _esc(n.heading) + '</div>' +
              '<div class="lg-note-bd">' + _mdInline(n.body) + '</div>' +
            '</div>').join('') +
        '</aside>' +
      '</div>' +
      '<details class="lg-src"><summary>Mermaid 소스 보기 ' +
        '<span class="rv-form-hint">— 문서·Obsidian에 그대로 붙일 수 있습니다</span>' +
      '</summary><pre>' + _esc(d.mermaid) + '</pre></details>' +
    '</div>'
  ).join('');

  mermaid.initialize(_lgTheme());
  _lgDraw(seq);
}

async function _lgDraw(seq) {
  for (let i = 0; i < LG.items.length; i++) {
    if (seq !== LG.seq) return;       // 테마를 연달아 바꾸면 앞선 그리기는 버린다
    try {
      // id는 매 렌더 달라야 한다 — 같은 id면 Mermaid가 옛 정의를 재사용한다
      const res = await mermaid.render('lg-m-' + i + '-' + seq, LG.items[i].mermaid);
      if (seq !== LG.seq) return;
      const slot = document.getElementById('lg-svg-' + i);
      if (!slot) continue;
      slot.innerHTML = res.svg;
      _lgFitSvg(slot);
    } catch (err) {
      const slot = document.getElementById('lg-svg-' + i);
      if (slot) {
        slot.innerHTML = '<div class="rv-form-hint" style="color:var(--ck-orange)">' +
          '이 도식을 그리지 못했습니다 — ' + _esc(String((err && err.message) || err)) + '</div>';
      }
    }
  }
}

/* 지도학습 탭 — «학습 가능한 라벨이 모였는가»를 서버에서 받아 채운다.

   분류기는 두 클래스가 다 있어야 배운다. 총 검토 건수가 아무리 많아도 전부
   한쪽(오탐)이면 «전부 오탐»이라고 답하는 모델이 정확도 100%가 되고, 그건
   아무것도 아니다. 그래서 «결함확정이 몇 건인가»를 따로 보여준다. */
const MLS_MIN_PER_CLASS = 300;   // 경험칙 - 큰 Check에서 쓸 만한 순위가 나오는 선

/* 1C 토글은 없앴다(2026-08-20). 임시부재는 판정 대상이 아니라 플래그가 없고,
   기록 파일에 남은 옛 1C 검토 기록도 서버가 항상 거른다 — 기준이 하나뿐이다. */
async function loadMlSupLabels() {
  const box = document.getElementById('mls-label-body');
  if (!box) return;
  try {
    const d = await apiFetch('/api/flags/review-counts');
    const now = d.by_result || {};        // 이번 회차 플래그와 대조되는 것
    const all = d.by_result_all || {};    // 검토 기록 파일 전체
    const pos = now['결함확정'] || 0;
    const neg = now['오탐'] || 0;
    const ready = pos >= MLS_MIN_PER_CLASS && neg >= MLS_MIN_PER_CLASS;
    const gapNeg = (all['오탐'] || 0) - neg;

    const row = (lbl, a, b, note) =>
      '<tr><td>' + lbl + '</td>' +
      '<td style="text-align:right"><b>' + _n(a) + '</b></td>' +
      '<td style="text-align:right;color:var(--text-3)">' + _n(b) + '</td>' +
      '<td class="rv-form-hint">' + note + '</td></tr>';

    box.innerHTML =
      '<table class="dtbl mls-tbl"><thead><tr><th>판정</th>' +
      '<th style="width:110px;text-align:right">이번 회차</th>' +
      '<th style="width:110px;text-align:right">기록 전체</th>' +
      '<th>비고</th></tr></thead><tbody>' +
      row('결함확정 (양성)', pos, all['결함확정'] || 0,
          pos ? '기준이 확정된 Check에 부여됨' : '없으면 학습 자체가 불가') +
      row('오탐 (음성)', neg, all['오탐'] || 0,
          gapNeg > 0 ? '<b>' + _n(gapNeg) + '건은 이번 회차에 대조할 행이 없다</b>'
                     : '규칙이 틀렸던 건') +
      row('확인중', now['확인중'] || 0, all['확인중'] || 0, '판단 보류 - 학습에서 제외') +
      '</tbody></table>' +
      '<div class="rv-form-hint" style="margin-top:6px">미검토 ' + _n(d.unreviewed) +
      '건 / 대조 대상 플래그 ' + _n(d.total) + '건 <b>(임시부재 1C 제외 기준)</b></div>' +
      '<div class="mls-note" style="margin-top:10px">' +
      (ready
        ? '두 클래스가 모두 <b>' + MLS_MIN_PER_CLASS + '건 이상</b> 대조됩니다 - ' +
          '<b>오탐 예측 착수 가능</b>합니다.'
        // **«0건»의 원인이 둘이다.** 지금까지의 검토는 대부분 1C 행에 붙어
        // 있었고, 1C가 판정 대상에서 빠지면서 그 라벨이 통째로 대조 밖으로
        // 나갔다. 여기서 「규칙이 바뀌어서」라고만 말하면 **틀린 이유를 자신
        // 있게** 말하는 화면이 된다 — 그걸 보고 「검증 이력 보관」부터 하러 간다.
        : (pos + neg < MLS_MIN_PER_CLASS && gapNeg <= 0
            ? '<b>대조되는 라벨이 거의 없습니다.</b> 지금까지의 검토는 대부분 ' +
              '1C(임시부재) 행에 대해 이뤄졌는데, <b>1C는 판정 대상에서 빠졌습니다</b> — ' +
              '임시 용접이라 작업도 결과 처리도 불완전해서 라벨이 될 수 없습니다. ' +
              '본 작업(비1C) 행의 검토가 쌓이는 것이 먼저입니다.'
        : (gapNeg > 0
            ? '<b>「이번 회차」 열을 보십시오.</b> 오탐 라벨은 기록에 ' + _n(all['오탐'] || 0) +
              '건 있지만, 그 판정을 낳은 규칙을 이미 고쳐서 <b>이번 회차에는 대조할 행이 ' +
              '없습니다</b>. 회차를 하나만 보관하므로(KEEP_RUNS = 1) 사라진 행의 피처도 ' +
              '되살릴 수 없습니다. 학습에 쓰려면 <b>검증 이력 보관</b>이 먼저입니다.'
            : '한쪽 클래스가 <b>' + MLS_MIN_PER_CLASS + '건</b>에 못 미칩니다. 분류기는 두 ' +
              '클래스가 다 있어야 배웁니다 - 한쪽뿐이면 «전부 그쪽»이라고 답하는 모델이 ' +
              '정확도 100%가 됩니다.'))) +
      '</div>';

    const t = document.getElementById('mls-title');
    if (t) t.textContent = ready ? '오탐 예측은 착수할 수 있습니다' : '아직 시작할 수 없습니다';
  } catch (e) {
    box.innerHTML = '<span style="color:var(--ck-orange)">검토 기록을 불러오지 못했습니다 - ' +
      _esc(String(e.message || e)) + '</span>';
  }
}

/* ── 검사 로직: 상세 분석 문서 ────────────────────────────────────────────
   `QC_검사로직_상세분석.md`가 검사 로직의 정본인데, 지금까지 저장소에 접근할 수
   있는 서버 관리자만 볼 수 있었다. 정작 판정 결과를 받아 검토하는 현업이
   «이 검사가 무엇을 보는가»를 확인할 방법이 없었다.

   HTML은 **서버가 만든다.** 이 문서에는 현업이 화면에서 입력한 글이 들어오므로
   (`review_items`가 §11에 답변을 되쓴다) 이스케이프를 먼저 하고 그 위에 태그를
   얹어야 한다. 브라우저에서 범용 마크다운 라이브러리를 쓰면 기본값이 HTML을
   그대로 통과시켜 그 보호가 사라진다. */
const LGDOC = { loaded: false, loading: false };

function setLogicTab(which) {
  const on = which === 'doc';
  const d = document.getElementById('lg-pane-diagram');
  const c = document.getElementById('lg-pane-doc');
  if (d) d.style.display = on ? 'none' : '';
  if (c) c.style.display = on ? '' : 'none';
  const td = document.getElementById('lg-tab-diagram');
  const tc = document.getElementById('lg-tab-doc');
  if (td) td.classList.toggle('on', !on);
  if (tc) tc.classList.toggle('on', on);
  const sub = document.getElementById('lg-bar-sub');
  if (sub) sub.textContent = '';
  if (on) loadLogicDoc();
}

async function loadLogicDoc(force) {
  if (LGDOC.loading || (LGDOC.loaded && !force)) return;
  LGDOC.loading = true;
  const body = document.getElementById('doc-body');
  try {
    const d = await apiFetch('/api/logic-doc');
    if (!d.ok) throw new Error(d.error || '문서를 읽지 못했습니다');
    body.innerHTML = d.html;
    _docBuildOutline(d.outline || []);
    _docDrawMermaid();
    LGDOC.loaded = true;
  } catch (e) {
    body.innerHTML = '<div class="rv-note" style="color:var(--ck-orange)">' +
      '문서를 불러오지 못했습니다 — ' + _esc(String(e.message || e)) + '</div>';
  } finally {
    LGDOC.loading = false;
  }
}

function _docBuildOutline(items) {
  const nav = document.getElementById('doc-outline');
  if (!nav) return;
  nav.innerHTML = '<div class="doc-outline-hd">목차</div>' + items.map(o =>
    '<a class="doc-link doc-l' + o.level + '" href="#' + _esc(o.id) + '" ' +
    'onclick="return _docJump(event, \'' + _jsq(o.id) + '\')">' +
    _esc(o.text) + '</a>').join('');
}

/* 문서 패널만 스크롤한다. `href="#id"`를 그대로 두면 페이지 전체가 튀어
   사이드바·상태바가 화면 밖으로 나간다. */
function _docJump(ev, id) {
  ev.preventDefault();
  const el = document.getElementById(id);
  const box = document.getElementById('doc-body');
  if (el && box) box.scrollTop = el.offsetTop - 8;
  return false;
}

/* 문서 안의 mermaid 블록도 그린다. **한 장씩 순차로** — 동시에 그리면 Mermaid가
   글자 크기를 잘못 재서 한글 라벨이 잘린다(오류는 나지 않는다). */
async function _docDrawMermaid() {
  const nodes = [...document.querySelectorAll('#doc-body .doc-mermaid')];
  if (!nodes.length || typeof mermaid === 'undefined') return;
  _lgTheme();
  for (let i = 0; i < nodes.length; i++) {
    const el = nodes[i];
    const src = el.textContent;
    try {
      const out = await mermaid.render('docmmd' + i + '_' + Date.now(), src);
      el.innerHTML = out.svg;
      _lgFitSvg(el);
    } catch (e) {
      el.innerHTML = '<pre><code>' + _esc(src) + '</code></pre>';
    }
  }
}

/* ── 프로젝트 두께 규칙 편집 ──────────────────────────────────────────────
   **값만 정해진 틀로 받는다.** 판정 논리 자체는 코드에 있고(`project_checks.KINDS`),
   화면은 «대상 조건 · 허용 범위»만 정한다. 자유 서술로 두면 반영률이 떨어진다 —
   실제로 「S355KL -40」이 실데이터 표기(`S355KT-40`)와 맞지 않아 한 번 막혔다.

   그래서 입력하는 자리에서 «지금 데이터에 몇 행 걸리는가»를 즉시 센다. 저장하고
   재검증을 돌린 뒤에야 «0건»을 보는 것과는 아주 다르다. */
let _ckPreviewTimer = null;

function _ckTokens(id) {
  return ((document.getElementById(id) || {}).value || '')
    .split(',').map(t => t.trim()).filter(Boolean);
}

function previewCheckRule() {
  clearTimeout(_ckPreviewTimer);
  _ckPreviewTimer = setTimeout(_ckDoPreview, 350);
}

async function _ckDoPreview() {
  const box = document.getElementById('ck-preview');
  if (!box) return;
  const mat = _ckTokens('ck-mat'), wps = _ckTokens('ck-wps');
  if (!mat.length && !wps.length) {
    box.className = 'ck-preview';
    box.textContent = '대상 조건을 적으면 지금 데이터에 몇 행 걸리는지 세어 봅니다';
    return;
  }
  try {
    const r = await apiFetch('/api/rules/checks/preview', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ material_contains: mat, wps_contains: wps }),
    });
    if (!r.has_result) {
      box.className = 'ck-preview';
      box.textContent = '검증 결과가 없어 셀 수 없습니다 — 먼저 파일을 한 번 돌리세요';
      return;
    }
    if (!r.rows) {
      // 0행은 «문제 없음»이 아니라 «표기가 안 맞을 수 있다»이다
      box.className = 'ck-preview ck-preview-zero';
      box.textContent = '지금 데이터에 0행 — 재질/WPS 표기가 실데이터와 다를 수 있습니다. '
        + '이대로 저장하면 이 규칙은 아무 행에도 걸리지 않습니다.';
      return;
    }
    box.className = 'ck-preview ck-preview-hit';
    box.innerHTML = '지금 데이터에 <b>' + _n(r.rows) + '행</b> (' + r.combos + '개 조합) — '
      + r.samples.map(c => _esc(c.material) + ' / ' + _esc(c.wps)
                           + ' <span class="rv-form-hint">' + _n(c.rows) + '</span>').join(' · ');
  } catch (e) {
    box.className = 'ck-preview';
    box.textContent = '세지 못했습니다 — ' + (e.message || e);
  }
}

function clearCheckRuleForm() {
  ['ck-key', 'ck-name', 'ck-range', 'ck-mat', 'ck-wps']
    .forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
  const msg = document.getElementById('ck-msg');
  if (msg) msg.textContent = '';
  _ckDoPreview();
}

function editCheckRule(no) {
  const it = RL.items.find(x => String(x.check_no) === String(no));
  if (!it || !it.editable) return;
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v || ''; };
  set('ck-key', it.key);
  set('ck-name', it.name);
  set('ck-range', (it.param || {}).range);
  set('ck-mat', ((it.when || {}).material_contains || []).join(', '));
  set('ck-wps', ((it.when || {}).wps_contains || []).join(', '));
  const msg = document.getElementById('ck-msg');
  if (msg) msg.textContent = 'Check ' + no + '을 고치는 중입니다';
  _ckDoPreview();
  const el = document.getElementById('ck-name');
  if (el) el.scrollIntoView({ block: 'center' });
}

async function saveCheckRule() {
  const g = id => ((document.getElementById(id) || {}).value || '').trim();
  const msg = document.getElementById('ck-msg');
  try {
    const r = await apiFetch('/api/rules/checks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        key: g('ck-key'), name: g('ck-name'), range: g('ck-range'),
        material_contains: _ckTokens('ck-mat'), wps_contains: _ckTokens('ck-wps'),
      }),
    });
    RL.items = r.items || RL.items;
    _rlRender();
    _rlShowReverify('Check ' + r.check_no + ' 저장됨 — 검증을 다시 돌려야 반영됩니다');
    clearCheckRuleForm();
    if (msg) msg.textContent = 'Check ' + r.check_no + ' 저장됐습니다';
  } catch (e) {
    if (msg) msg.textContent = '저장 실패: ' + (e.message || e);
  }
}

async function deleteCheckRule(key, no) {
  if (!confirm('Check ' + no + ' 규칙을 뺍니다.\n\n번호는 대장에 남고 재발급되지 '
             + '않습니다(검토 기록이 그 번호로 남아 있습니다).\n\n계속할까요?')) return;
  const msg = document.getElementById('ck-msg');
  try {
    const r = await apiFetch('/api/rules/checks?key=' + encodeURIComponent(key),
                             { method: 'DELETE' });
    RL.items = r.items || RL.items;
    _rlRender();
    _rlShowReverify('Check ' + no + ' 제거됨 — 검증을 다시 돌려야 반영됩니다');
    if (msg) msg.textContent = 'Check ' + no + ' 규칙을 뺐습니다';
  } catch (e) {
    if (msg) msg.textContent = '삭제 실패: ' + (e.message || e);
  }
}

function _rlShowReverify(text) {
  const warn = document.getElementById('rl-reverify');
  if (warn) warn.style.display = '';
  const m = document.getElementById('rl-msg');
  if (m) m.textContent = text;
}

/* ── 프로젝트 세팅 ───────────────────────────────────────────────────────────
   대시보드의 Check 토글과 **성격이 다르다.**

       프로젝트 세팅   무엇을 판정할 것인가          -> 재검증 필요
       대시보드 토글   판정된 것 중 무엇을 볼 것인가  -> 즉시 반영

   여기서 끈 항목은 플래그가 애초에 생기지 않으므로 결함 행수·클린 행수·부서
   실적이 전부 그 기준으로 다시 계산된다. 그래서 저장한 뒤 «재검증 필요» 배지를
   띄운다 — 안 띄우면 «껐는데 왜 그대로냐»가 반드시 나온다. */
const RL = { items: [], requests: [], dirty: false, project: '', projects: [] };

async function loadRuleSettings() {
  try {
    const d = await apiFetch('/api/rules');
    RL.items = d.items || [];
    RL.requests = d.requests || [];
    RL.project = d.project || '';
    RL.projects = d.projects || [];
    RL.dirty = false;
    _rlRender();
  } catch (e) {
    document.getElementById('rl-list').innerHTML =
      '<div class="rv-note" style="color:var(--ck-orange)">불러오지 못했습니다 — ' +
      _esc(String(e.message || e)) + '</div>';
  }
}

function _rlRender() {
  const box = document.getElementById('rl-list');
  if (!box) return;
  const groups = [['공통', '어느 프로젝트에서나 성립하는 규칙 — 표준·자격·기록 품질'],
                  ['프로젝트', '이 프로젝트에서 합의된 값 — 프로젝트가 바뀌면 다시 정해야 한다']];
  box.innerHTML = groups.map(function (g) {
    const cat = g[0], desc = g[1];
    const items = RL.items.filter(i => i.category === cat);
    if (!items.length) return '';
    return '<div class="rl-group">' +
      '<div class="rl-group-hd"><span class="rl-cat rl-cat-' +
        (cat === '공통' ? 'common' : 'project') + '">' + cat + '</span>' +
        '<span class="rl-group-desc">' + _esc(desc) + '</span></div>' +
      items.map(_rlCardHtml).join('') +
    '</div>';
  }).join('');
  _rlSyncButtons();
  _rlRenderRequests();
}

function _rlCardHtml(i) {
  const cls = (COLOR_TO_CLS[i.color] || 'p-gray').replace('p-', '');
  return '<div class="rl-card' + (i.enabled ? '' : ' rl-off') +
      (i.retired ? ' rl-retired' : '') + '" style="--ck-c:var(--ck-' + cls + ')">' +
    '<label class="rl-toggle"><input type="checkbox"' +
      (i.enabled ? ' checked' : '') + (i.retired ? ' disabled' : '') +
      ' onchange="toggleRule(\'' + _jsq(i.check_no) + '\', this.checked)"></label>' +
    '<div class="rl-body">' +
      '<div class="rl-title"><b>Check ' + _ckLabel(i.check_no) + '</b> ' + _esc(i.name) +
        '<span class="rl-cols">' + _esc(i.cols || '—') + '</span>' +
        (i.retired ? '<span class="rl-dead">폐지</span>' : '') +
        // **잠정 표식** — 다른 프로젝트 값을 빌려 쓰는 중이라 재확인이 필요하다.
        // 없으면 빌려 온 값으로 나온 건수를 «확정된 판정»으로 읽게 된다.
        (i.provisional
          ? '<span class="rl-prov" title="' + _esc(i.provisional) + '">확인 필요</span>'
          : '') +
        (i.scope === 0
          ? '<span class="rl-noscope" title="이 검사가 대조한 대상이 0건입니다. '
            + '«위반이 없다»가 아니라 «한 번도 판정하지 않았다»는 뜻입니다.">대상 없음</span>'
          : '') +
        '<span class="rl-count">' + _n(i.count) + '건</span></div>' +
      '<div class="rl-summary">' + _esc(i.summary) + '</div>' +
      (i.provisional
        ? '<div class="rl-prov-note">⚑ ' + _esc(i.provisional) + '</div>'
        : '') +
      '<details class="rl-logic"><summary>판정 로직</summary><div>' +
        _mdInline(i.logic) + '</div></details>' +
      (i.editable
        ? '<div class="rl-edit">' +
            '<button class="btn btn-sm" onclick="editCheckRule(\'' + _jsq(i.check_no) + '\')">고치기</button> ' +
            '<button class="btn btn-sm" onclick="deleteCheckRule(\'' + _jsq(i.key || '') +
              '\',\'' + _jsq(i.check_no) + '\')">빼기</button>' +
          '</div>'
        : '') +
    '</div></div>';
}

function toggleRule(no, on) {
  // **문자열로 못 박는다.** 인라인 핸들러가 숫자를 넘기면 `'14' === 14`이
  // false가 되어 항목을 못 찾고 **조용히 아무 일도 안 일어난다** — 체크박스는
  // 시각적으로 꺼지는데 `RL.items[].enabled`도 `RL.dirty`도 그대로라
  // 사용자는 «껐다»고 믿고 저장까지 누른다. 예외도 경고도 없다.
  const it = RL.items.find(x => String(x.check_no) === String(no));
  if (!it) return;
  it.enabled = !!on;
  RL.dirty = true;
  _rlRender();
}

/* 프로젝트(프로파일) 선택. **이름만 바뀌는 게 아니라 판정 기준이 바뀐다** —
   그래서 전환도 «재검증 필요»다. 저장하지 않은 변경이 있으면 먼저 묻는다:
   전환하면 그 변경은 사라지는데, 조용히 사라지면 «저장했는데 왜 안 되냐»가 된다. */
function _rlFillProjects() {
  const sel = document.getElementById('rl-project');
  if (!sel) return;
  sel.innerHTML = (RL.projects || []).map(n =>
    '<option value="' + _esc(n) + '"' + (n === RL.project ? ' selected' : '') + '>' +
    _esc(n) + '</option>').join('');
}

async function _rlApplyProject(name) {
  const msg = document.getElementById('rl-project-msg');
  try {
    const r = await apiFetch('/api/rules/project', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: name }),
    });
    RL.project = r.project;
    RL.projects = r.projects || [];
    RL.items = r.items || [];
    RL.dirty = false;
    _rlRender();
    const warn = document.getElementById('rl-reverify');
    if (warn) warn.style.display = r.needs_reverify ? '' : 'none';
    if (msg) msg.textContent = r.needs_reverify
      ? "'" + r.project + "' 기준으로 바꿨습니다 — 파일을 다시 돌려야 반영됩니다"
      : '';
  } catch (e) {
    if (msg) msg.textContent = '전환 실패: ' + (e.message || e);
    _rlFillProjects();          // select를 원래 값으로 되돌린다
  }
}

async function switchProject(name) {
  if (!name || name === RL.project) return;
  if (RL.dirty && !confirm('저장하지 않은 변경이 있습니다.\n프로젝트를 바꾸면 그 변경은 사라집니다.\n\n계속할까요?')) {
    _rlFillProjects();
    return;
  }
  await _rlApplyProject(name);
}

async function createProject() {
  const input = document.getElementById('rl-new-project');
  const name = ((input || {}).value || '').trim();
  if (!name) return;
  await _rlApplyProject(name);
  if (input) input.value = '';
}

async function deleteProject() {
  const name = RL.project;
  const msg = document.getElementById('rl-project-msg');
  if (msg) msg.textContent = '';
  if ((RL.projects || []).length < 2) {
    if (msg) msg.textContent = '프로젝트가 하나뿐이라 지울 수 없습니다';
    return;
  }
  // 활성 프로젝트는 서버가 막는다 — 지우려면 다른 것으로 옮긴 뒤에 지운다
  const other = RL.projects.find(n => n !== name);
  if (!confirm("'" + name + "' 설정을 지웁니다.\n'" + other + "' 기준으로 바뀝니다.\n\n계속할까요?")) return;
  try {
    await _rlApplyProject(other);
    const r = await apiFetch('/api/rules/project?name=' + encodeURIComponent(name),
                             { method: 'DELETE' });
    RL.projects = r.projects || [];
    _rlFillProjects();
    if (msg) msg.textContent = "'" + name + "' 설정을 지웠습니다";
  } catch (e) {
    if (msg) msg.textContent = '삭제 실패: ' + (e.message || e);
  }
}

function _rlSyncButtons() {
  _rlFillProjects();
  const msg = document.getElementById('rl-msg');
  if (msg && RL.dirty) msg.textContent = '저장하지 않은 변경이 있습니다';
  const off = RL.items.filter(i => !i.enabled && !i.retired).length;
  const sub = document.getElementById('rl-bar-sub');
  if (sub) sub.textContent = (RL.project ? RL.project + ' · ' : '') + (off
    ? (RL.items.length - off) + '개 적용 · ' + off + '개 제외'
    : RL.items.length + '개 전부 적용');
}

async function saveRuleSettings() {
  const enabled = {};
  RL.items.forEach(i => { enabled[String(i.check_no)] = !!i.enabled; });
  const msg = document.getElementById('rl-msg');
  try {
    const r = await apiFetch('/api/rules', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ enabled: enabled }),
    });
    RL.items = r.items || RL.items;
    RL.project = r.project || RL.project;
    RL.projects = r.projects || RL.projects;
    RL.dirty = false;
    _rlRender();
    const warn = document.getElementById('rl-reverify');
    if (warn) warn.style.display = r.needs_reverify ? '' : 'none';
    if (msg) msg.textContent = r.needs_reverify
      ? '저장됐습니다 — 바뀐 항목 ' + (r.changed || []).map(n => 'Check ' + n).join(', ') +
        '. 검증을 다시 돌려야 결과에 반영됩니다.'
      : '저장됐습니다 (바뀐 항목 없음)';
  } catch (e) {
    if (msg) msg.textContent = '저장 실패: ' + (e.message || e);
  }
}

function _rlRenderRequests() {
  const tb = document.getElementById('rq-tbody');
  if (!tb) return;
  tb.innerHTML = RL.requests.length
    ? RL.requests.map(r =>
        '<tr><td>' + r.id + '</td>' +
        '<td><span class="rl-cat rl-cat-' + (r.category === '공통' ? 'common' : 'project') +
          '">' + _esc(r.category) + '</span></td>' +
        '<td>' + _esc(r.title) + (r.target_cols
          ? '<span class="rl-cols">' + _esc(r.target_cols) + '</span>' : '') + '</td>' +
        '<td class="rv-form-hint">' + _esc(r.condition) + ' → ' + _esc(r.verdict) + '</td>' +
        '<td>' + _esc(r.status || '접수') + '</td></tr>').join('')
    : '<tr><td colspan="5" style="text-align:center;color:var(--text-3);padding:14px">' +
      '등록된 요청이 없습니다</td></tr>';
}

async function submitRuleRequest() {
  const g = id => (document.getElementById(id) || {}).value || '';
  const msg = document.getElementById('rq-msg');
  try {
    const r = await apiFetch('/api/rules/requests', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: g('rq-title'), category: g('rq-category'), target_cols: g('rq-cols'),
        condition: g('rq-condition'), verdict: g('rq-verdict'), note: g('rq-note'),
      }),
    });
    RL.requests.push(r.request);
    ['rq-title', 'rq-cols', 'rq-condition', 'rq-verdict', 'rq-note']
      .forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
    _rlRenderRequests();
    if (msg) msg.textContent = '요청 #' + r.request.id + ' 등록됐습니다 — 서버 관리자가 반영합니다';
  } catch (e) {
    if (msg) msg.textContent = '등록 실패: ' + (e.message || e);
  }
}

/* ── 테마 ───────────────────────────────────────────────────────────────────── */
function toggleTheme() {
  const r   = document.documentElement;
  const cur = r.getAttribute('data-theme');
  r.setAttribute('data-theme', cur === 'dark' ? 'light' : 'dark');
  _redrawVisibleCharts();
  // Mermaid는 렌더 시점의 색을 SVG에 구워 넣는다 — 테마가 바뀌면 다시 그려야 한다
  if (S.view === 'logic') _lgRender();
}

/* 현재 보이는 뷰(메인 대시보드 또는 부서별 대시보드)의 캔버스 차트를 다시 그린다
   — 테마 전환·창 크기 변경 시 공용으로 사용. */
/* `_dashAggregate`는 서버에 묻는 **비동기** 함수다. await 없이 쓰면 Promise가
   들어와 `agg.stats`가 undefined가 되고, 테마 전환·창 크기 변경 때 차트가
   **빈 채로 다시 그려진다.** 오류는 나지 않는다 — 그래서 이 함수는 async다. */
async function _redrawVisibleCharts() {
  if (!S.result) return;
  if (S.view === 'dashboard') {
    const agg = await _dashAggregate(S.result);
    drawBarChart('bar-chart', agg.stats, S.dashCheckSort);
    drawDonutChart('donut-chart', 'donut-legend', agg.stats,
                   agg.flaggedRows, agg.cleanRows, agg.flaggedRows + agg.cleanRows);
    drawTrendChart('trend-chart', 'trend-tooltip', agg.trend);
  } else if (S.view === 'dept-dashboard') {
    const scope = _currentDeptDashScope();
    if (scope) _drawDeptDashCharts(scope);
  } else if (S.view === 'ml-unsup') {
    _mluDrawScatter();
    _mluDrawHist();
  }
}

/* ── API 헬퍼 ───────────────────────────────────────────────────────────────── */
/* 로그인 사번을 헤더로 싣는다. 이 앱은 0.0.0.0으로 사내망에 열려 있어서, 검증 결과처럼
   사번·도면번호·용접사 이름이 들어간 응답은 등록된 사번에만 내려준다(백엔드 require_login). */
function _authHeaders(extra) {
  return Object.assign({}, extra || {},
    {'X-Employee-Id': localStorage.getItem('qc_employee_id') || ''});
}

async function apiFetch(url, opts = {}) {
  const res = await fetch(url, Object.assign({}, opts, {headers: _authHeaders(opts.headers)}));
  if (!res.ok) {
    let msg = `HTTP ${res.status}`;
    try { const j = await res.json(); msg = j.detail || msg; } catch {}
    const e = new Error(msg);
    e.status = res.status;      // 화면이 «404인가»를 문구로 추측하지 않게
    throw e;
  }
  return res.json();
}

/* ── 상태 폴링 ──────────────────────────────────────────────────────────────── */
async function pollStatus() {
  try {
    const s = await apiFetch('/api/status');
    updateUploadUI(s);
    updateExcelStatus(s);
    updateStatusBar(s);

    // 검증 중 상태바 표시
    const statusBar = document.getElementById('verify-status-bar');
    if (statusBar) statusBar.style.display = s.status === 'running' ? '' : 'none';

    if (s.status === 'running') {
      document.getElementById('prog-bar').style.width   = s.progress + '%';
      document.getElementById('prog-label').textContent = s.message;
    }
    if (s.status === 'done' && !S.result) {
      // 결과 JSON은 Excel 생성과 무관하게 즉시 확정되어 있으므로 바로 렌더링
      const result = await apiFetch('/api/result');
      _setResult(result);
      await _loadPatternTeams();
      showResult(result);
    }
    if (s.status === 'error') {
      document.getElementById('prog-label').textContent = '오류: ' + (s.error || '알 수 없음');
      document.getElementById('prog-bar').style.background = 'var(--ck-red)';
      document.getElementById('btn-verify').disabled = false;
    }
    // 진행 중이면 폴링을 **시작**하고, 끝나면 중단한다.
    //
    // 예전에는 중단만 했다. 그래서 페이지를 열었을 때 마침 Excel이 생성 중이면
    // "⏳ Excel 결과 파일 생성 중…" 배지가 뜬 채로, 그것을 지워줄 타이머가 없어
    // 생성이 끝나도 배지가 영원히 남았다(다른 조작으로 폴링이 다시 돌기 전까지).
    // 검증 실행 화면에서만 타이머를 걸었기 때문인데, 재접속 경로에는 그 지점이 없다.
    const busy = s.status === 'running' || s.excel_status === 'generating';
    if (busy && !S.pollTimer) {
      // 검증 중에는 진행률을 부드럽게 보여줘야 하므로 촘촘히, Excel 생성만 남았으면 느슨하게
      S.pollTimer = setInterval(pollStatus, s.status === 'running' ? 600 : 2000);
    } else if (!busy && S.pollTimer) {
      clearInterval(S.pollTimer);
      S.pollTimer = null;
    }
  } catch (e) {
    console.warn('poll error:', e.message);
  }
}

/* ── 상태바 ─────────────────────────────────────────────────────────────────
   어느 화면에 있든 같은 자리에서 "지금 무슨 상태인지"를 보여준다.
   pollStatus()와 showResult() 양쪽에서 호출된다. */
/* 결과가 «무엇으로 판정됐는지»를 상태바에 남긴다.

   업로드 화면에서 기준을 고르게 하면 «잘못 골라서 틀림»이라는 위험이 새로
   생긴다. 그래서 돌아간 뒤 어느 기준이었는지가 보여야 한다 — 안 보이면 위험만
   옮겨간 셈이 된다. */
function _syncBasis(r) {
  const el = document.getElementById('sb-basis');
  const wrap = document.getElementById('sb-basis-wrap');
  if (!el || !wrap) return;
  const p = (r || {}).project || '';
  wrap.style.display = p ? '' : 'none';
  el.textContent = p;
}

function updateStatusBar(s) {
  const led = document.getElementById('sb-led');
  const st  = document.getElementById('sb-state');
  if (!led || !st) return;

  if (s && s.status === 'running') {
    led.className = 'sb-led running';
    st.textContent = `검증 중 ${s.progress || 0}% · ${s.message || ''}`.trim();
  } else if (s && s.status === 'error') {
    led.className = 'sb-led error';
    st.textContent = '검증 실패: ' + (s.error || '알 수 없음');
  } else if (S.result) {
    led.className = 'sb-led';
    st.textContent = '검증 완료';
  } else {
    led.className = 'sb-led idle';
    st.textContent = '대기 중';
  }

  const r = S.result;
  const runEl = document.getElementById('sb-run');
  const cntEl = document.getElementById('sb-counts');
  if (r) {
    runEl.style.display = '';
    cntEl.style.display = '';
    document.getElementById('sb-run-at').textContent = r.run_at || '—';
    document.getElementById('sb-judged').textContent = _n(_judged(r));
    document.getElementById('sb-defect').textContent = _n(r.flagged_rows || 0);
    // 미검토 = 전체 플래그 중 검토 기록이 없는 건수.
    // 플래그 전량을 훑던 계산이라 서버가 센다. 도착 전까지는 직전 값을 그대로 둔다
    // — 0을 잠깐 보여주면 «검토가 끝났다»로 잘못 읽힌다.
    _refreshUnreviewedCount();
  } else {
    runEl.style.display = 'none';
    cntEl.style.display = 'none';
  }
}

/* 상태바 우측 — 현재 보고 있는 화면/범위 */
function setStatusContext(text) {
  const el = document.getElementById('sb-context');
  if (el) el.textContent = text || '—';
}

function updateExcelStatus(s) {
  const chip   = document.getElementById('excel-status-chip');
  const dlBtns = document.querySelectorAll('.excel-dl-btn');
  if (!chip) return;
  if (s.excel_status === 'generating') {
    chip.style.display = '';
    chip.textContent   = '⏳ Excel 결과 파일 생성 중…';
    chip.className     = 'excel-status-chip generating';
    dlBtns.forEach(b => b.classList.add('excel-disabled'));
  } else if (s.excel_status === 'error') {
    chip.style.display = '';
    chip.textContent   = '⚠ Excel 생성 실패';
    chip.className     = 'excel-status-chip error';
    dlBtns.forEach(b => b.classList.remove('excel-disabled'));
  } else {
    chip.style.display = 'none';
    dlBtns.forEach(b => b.classList.remove('excel-disabled'));
  }
}

function updateUploadUI(s) {
  // QMG 파일 상태
  const zqmg = document.getElementById('zone-qmg');
  const fqmg = document.getElementById('file-qmg');
  if (s.has_qmg && s.qmg_name) {
    zqmg.classList.add('has-file');
    fqmg.style.display = 'inline-block';
    fqmg.textContent   = '✓ ' + s.qmg_name;
  }
  // Welder 파일 상태
  const zwelder = document.getElementById('zone-welder');
  const fwelder = document.getElementById('file-welder');
  if (s.has_welder && s.welder_name) {
    zwelder.classList.add('has-file');
    fwelder.style.display = 'inline-block';
    fwelder.textContent   = '✓ ' + s.welder_name;
  }
  // WPS ref / 캐시 상태
  const wpsPath  = document.getElementById('wps-path');
  const wpsStat  = document.getElementById('wps-status');
  const wpsCacheEl = document.getElementById('wps-cache-status');
  const wpsDel   = document.getElementById('btn-wps-del');
  if (s.has_wps_cache) {
    const cacheLabel = s.wps_cache_name
      ? `✓ ${s.wps_cache_name} (${s.wps_cache_count}개)`
      : `✓ WPS 캐시 적용 중 (${s.wps_cache_count}개)`;
    if (wpsPath) wpsPath.textContent = cacheLabel;
    if (wpsStat) wpsStat.innerHTML = '<span class="dot-ok"></span><span style="color:var(--ck-green)">업로드 캐시 사용</span>';
    if (wpsCacheEl) {
      wpsCacheEl.textContent = '⚑ 업로드된 WPS List가 우선 적용됩니다 (xlsm 고정 파일보다 우선)';
      wpsCacheEl.style.color = 'var(--ck-green)';
    }
    if (wpsDel) wpsDel.style.display = '';
    const zone = document.getElementById('zone-wps');
    if (zone) zone.classList.add('has-file');
  } else if (s.has_wps_ref) {
    if (wpsPath) wpsPath.textContent = 'Raw data / QMG4520 ... (테스트R5).xlsm  ·  Hull & Topside WPS List';
    if (wpsStat) wpsStat.innerHTML = '<span class="dot-ok"></span><span style="color:var(--ck-green)">서버 고정 파일 확인됨</span>';
    if (wpsCacheEl) { wpsCacheEl.textContent = ''; }
    if (wpsDel) wpsDel.style.display = 'none';
  } else {
    // **원격 접속자는 서버의 Raw data 폴더에 손댈 수 없다.** 그 사실만 적어 두면
    // 「내가 할 수 있는 게 없다」로 읽힌다 — 바로 아래 업로드 칸을 가리킨다.
    if (wpsPath) wpsPath.textContent =
      '서버의 Raw data 폴더에 WPS 참조 파일이 없습니다 — 아래에서 직접 올리셔도 됩니다';
    if (wpsStat) wpsStat.innerHTML = '<span style="color:var(--ck-red)">⚠ 파일 없음</span>';
    if (wpsCacheEl) { wpsCacheEl.textContent = ''; }
  }
  // 승인 용접봉 리스트. **검증을 막지 않는다** — 없으면 Check 18의 «미승인» 쪽만
  // 돌지 않는다(기재 누락은 그대로 본다). 「없음」만 적으면 «문제 없음»으로
  // 읽히므로 무슨 뜻인지 함께 적는다.
  const cEl = document.getElementById('consumable-status');
  const cDel = document.getElementById('btn-consumable-del');
  const cZone = document.getElementById('zone-consumable');
  const cFile = document.getElementById('file-consumable');
  const cList = document.getElementById('consumable-list');
  const cFiles = s.consumable_files || [];
  if (s.has_consumables) {
    // 여러 리스트를 합치면 **같은 Lot이 겹칠 수 있다.** 안 알려 주면
    // 「300+200을 올렸는데 총 450」이 오류로 보인다.
    const dup = s.consumable_overlap > 0
      ? ' · 리스트끼리 겹친 Lot <b>' + _n(s.consumable_overlap) + '개</b>는 한 번만 셉니다'
      : '';
    if (cEl) cEl.innerHTML = '<span class="dot-ok"></span>' +
      '<span style="color:var(--ck-green)">리스트 ' + _n(cFiles.length) +
      '개 · 승인 Lot ' + _n(s.consumable_count) + '개 등록됨</span>' + dup +
      ' · Check 18이 AL열 Lot No.를 이 목록과 대조합니다';
    if (cDel) cDel.style.display = '';
    if (cZone) cZone.classList.add('has-file');
    if (cFile) cFile.innerHTML = cFiles.length === 1
      ? '✓ ' + _esc(cFiles[0].filename) + ' (Lot ' + _n(cFiles[0].count) + '개)'
      : '✓ 리스트 ' + _n(cFiles.length) + '개 · 더 올리려면 클릭 또는 드래그';
    if (cList) cList.innerHTML = cFiles.map(f =>
      `<div class="cons-row">
         <span class="cons-name" title="${_esc(f.filename)}">${_esc(f.filename)}</span>
         <span class="cons-cnt">Lot ${_n(f.count)}</span>
         <button class="cons-x" title="이 리스트만 지웁니다"
                 onclick="deleteConsumableOne('${_jsq(f.filename)}')">✕</button>
       </div>`).join('');
  } else {
    if (cList) cList.innerHTML = '';
    if (cEl) cEl.innerHTML = '<span style="color:var(--ck-orange)">미등록</span> — ' +
      'Check 18의 <b>«미승인 용접봉» 판정이 돌지 않습니다</b>(기재 누락만 봅니다). ' +
      '결과의 0건은 «문제 없음»이 아니라 «대상 없음»입니다';
    if (cDel) cDel.style.display = 'none';
    if (cZone) cZone.classList.remove('has-file');
    if (cFile) cFile.innerHTML = '클릭 또는 드래그 · <b>여러 개 한꺼번에</b> (*.xlsx / *.xlsm)';
  }

  // 검증 버튼 활성화
  const btn = document.getElementById('btn-verify');
  const canVerify = s.has_qmg && s.has_welder && (s.has_wps_ref || s.has_wps_cache);
  if (btn) btn.disabled = !(canVerify && s.status !== 'running');
  // 이미 결과 있으면 배지 표시
  if (s.has_result) {
    document.getElementById('badge-dashboard').style.display = '';
  }
}

/* ── 파일 업로드 ─────────────────────────────────────────────────────────────── */
async function uploadFile(type, file) {
  if (!file) return;
  const fd = new FormData();
  fd.append('file', file);
  try {
    const r = await fetch(`/api/files/${type}`,
                          { method: 'POST', body: fd, headers: _authHeaders() });
    if (!r.ok) throw new Error((await r.json()).detail || 'upload failed');
    const j = await r.json();
    if (type === 'wps') {
      const zone = document.getElementById('zone-wps');
      const fEl  = document.getElementById('file-wps');
      if (zone) zone.classList.add('has-file');
      if (fEl)  fEl.textContent = `✓ ${j.filename} (WPS ${j.wps_count}개)`;
    } else if (type === 'consumable') {
      // 서버가 «걷은 개수»를 돌려준다. 0이면 서버가 이미 거절하므로
      // 여기에 0이 올 일은 없다 — 온다면 그건 서버 쪽 회귀다.
      const zone = document.getElementById('zone-consumable');
      const fEl  = document.getElementById('file-consumable');
      if (zone) zone.classList.add('has-file');
      if (fEl)  fEl.textContent = `✓ ${j.filename} (Lot ${_n(j.count)}개)`;
    } else if (type === 'welder') {
      // **어느 형식으로 읽혔는지 보여준다.** 옛 파일을 올리면 만료일이 없어
      // Check 7이 «대상 없음»이 되는데, 그 사실을 여기서 말하지 않으면
      // 「왜 만료일 검사가 안 도나」를 되짚을 방법이 없다.
      const zone = document.getElementById('zone-welder');
      const fEl  = document.getElementById('file-welder');
      zone.classList.add('has-file');
      fEl.style.display = 'inline-block';
      fEl.textContent = '✓ ' + j.filename + ' (' + _n(j.welders) + '명 · ' + j.layout +
        (j.has_expiry
          ? ' · 만료일 ' + _n(j.expiry_dated) + '명' +
            (j.expiry_missing ? ' · 누락 ' + _n(j.expiry_missing) + '명' : '')
          : '') + ')';
      const note = document.getElementById('welder-layout-note');
      if (note) note.innerHTML = j.has_expiry
        ? '<span class="dot-ok"></span><span style="color:var(--ck-green)">만료일 포함</span>' +
          ' · Check 7이 자격 만료·박탈 이후 작업을 잡습니다'
        : '<span style="color:var(--ck-orange)">만료일 없는 형식</span> — ' +
          'Check 7(용접사 승인기간)이 <b>한 행도 대조하지 않습니다</b>. ' +
          '만료일이 든 파일로 올리시면 함께 판정합니다';
    } else {
      const zone = document.getElementById('zone-' + type);
      const fEl  = document.getElementById('file-' + type);
      zone.classList.add('has-file');
      fEl.style.display = 'inline-block';
      fEl.textContent   = '✓ ' + j.filename + ' (' + _kb(j.size) + ')';
    }
    await pollStatus();
  } catch (e) {
    alert('업로드 실패: ' + e.message);
  }
}

async function deleteWpsCache() {
  if (!confirm('업로드된 WPS 캐시를 삭제하고\n서버 고정 xlsm 파일로 되돌리겠습니까?')) return;
  try {
    const r = await fetch('/api/files/wps', { method: 'DELETE', headers: _authHeaders() });
    if (!r.ok) throw new Error((await r.json()).detail || 'delete failed');
    const zone = document.getElementById('zone-wps');
    const fEl  = document.getElementById('file-wps');
    if (zone) zone.classList.remove('has-file');
    if (fEl)  fEl.textContent = '클릭 또는 드래그 (*.xlsx / *.xlsm)';
    await pollStatus();
  } catch (e) {
    alert('삭제 실패: ' + e.message);
  }
}

/* 목록을 지우면 **Check 18의 «미승인» 판정이 멈춘다.** 그때의 0건은 «승인된 것만
   썼다»가 아니라 «대조하지 않았다»다 — 확인 문구가 그걸 말해야 한다. */
async function deleteConsumableCache() {
  if (!confirm('승인 용접봉 리스트를 삭제합니다.\n\n' +
               '다음 검증부터 Check 18이 «미승인 용접봉»을 대조하지 않습니다 — ' +
               '용접봉을 대조하지 않게 됩니다.\n\n계속할까요?')) return;
  try {
    const r = await fetch('/api/files/consumable',
                          { method: 'DELETE', headers: _authHeaders() });
    if (!r.ok) throw new Error((await r.json()).detail || 'delete failed');
    const zone = document.getElementById('zone-consumable');
    const fEl  = document.getElementById('file-consumable');
    if (zone) zone.classList.remove('has-file');
    if (fEl)  fEl.textContent = '클릭 또는 드래그 (*.xlsx / *.xlsm)';
    await pollStatus();
  } catch (e) {
    alert('삭제 실패: ' + e.message);
  }
}

function dragOver(e, id) {
  e.preventDefault();
  document.getElementById(id).classList.add('dragover');
}
function dragLeave(id) {
  document.getElementById(id).classList.remove('dragover');
}
function dropFile(e, type) {
  e.preventDefault();
  dragLeave('zone-' + type);
  const files = e.dataTransfer.files;
  if (!files || !files.length) return;
  // 승인 용접봉 목록만 여러 벌이다 — 나머지는 «한 벌»이라 첫 파일만 받는다.
  if (type === 'consumable') uploadConsumables(files);
  else uploadFile(type, files[0]);
}

/* 승인 용접봉 리스트 — **여러 개를 한꺼번에.**

   현업 요청(2026-08-24): 목록이 여러 파일로 나뉘어 있어 다 같이 올려야 한다.

   **한 건씩 순서대로 올린다.** 한 번에 묶어 보내면 그중 하나가 양식이 틀렸을 때
   무엇이 문제인지 말하기 어렵고, 성공한 것까지 함께 버려진다. 하나가 실패해도
   나머지는 그대로 등록되고, 실패한 파일 이름만 따로 알린다. */
async function uploadConsumables(fileList) {
  const files = [...(fileList || [])];
  if (!files.length) return;
  const st = document.getElementById('consumable-status');
  const bad = [];
  for (let i = 0; i < files.length; i++) {
    if (st) st.innerHTML = `<span class="ai-spin">●</span> ${_esc(files[i].name)} 읽는 중… (${i + 1}/${files.length})`;
    try {
      const fd = new FormData();
      fd.append('file', files[i]);
      const r = await fetch('/api/files/consumable',
                            { method: 'POST', body: fd, headers: _authHeaders() });
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail || `HTTP ${r.status}`);
    } catch (e) {
      bad.push(files[i].name + ' — ' + e.message);
    }
  }
  await pollStatus();                 // 목록·합계를 서버에서 다시 받는다
  if (bad.length) {
    alert('다음 리스트는 등록하지 못했습니다:\n\n' + bad.join('\n\n') +
          '\n\n나머지는 그대로 등록되었습니다.');
  }
}

async function deleteConsumableOne(name) {
  if (!confirm(`«${name}» 리스트를 목록에서 지웁니다.\n이 파일의 Lot만 빠집니다.`)) return;
  try {
    await apiFetch('/api/files/consumable?name=' + encodeURIComponent(name),
                   { method: 'DELETE' });
  } catch (e) {
    alert('지우지 못했습니다: ' + e.message);
  }
  await pollStatus();
}

/* ── 검증 실행 ─────────────────────────────────────────────────────────────── */
/* 업로드 화면의 «판정 기준» 목록. 검증을 돌리기 전에 채워 둔다 —
   비어 있으면 사용자가 무엇으로 돌아가는지 모르는 채 실행하게 된다. */
async function loadRunProjects() {
  const sel = document.getElementById('run-project');
  if (!sel) return;
  try {
    const d = await apiFetch('/api/rules');
    const cur = d.project || '';
    sel.innerHTML = (d.projects || [cur]).map(n =>
      '<option value="' + _esc(n) + '"' + (n === cur ? ' selected' : '') + '>' +
      _esc(n) + '</option>').join('');
  } catch (e) {
    sel.innerHTML = '<option value="">(설정을 불러오지 못했습니다)</option>';
  }
}

async function startVerify() {
  document.getElementById('btn-verify').disabled  = true;
  document.getElementById('prog-bar').style.width = '0%';
  document.getElementById('prog-bar').style.background = 'var(--accent)';
  document.getElementById('prog-label').textContent    = '시작 중…';
  _setResult(null);
  try {
    // 고른 기준을 함께 보낸다. 서버가 이 값으로 판정하고 결과에 박아 둔다.
    const proj = (document.getElementById('run-project') || {}).value || '';
    const res = await fetch('/api/verify' + (proj ? '?project=' + encodeURIComponent(proj) : ''),
                            { method: 'POST', headers: _authHeaders() });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      if (res.status === 409) {
        alert('⚠ 다른 사용자가 현재 검증을 진행 중입니다.\n\n잠시 후 다시 시도해 주세요.');
      } else {
        alert('검증 시작 실패: ' + (err.detail || `HTTP ${res.status}`));
      }
      document.getElementById('btn-verify').disabled = false;
      return;
    }
    S.pollTimer = setInterval(pollStatus, 600);
  } catch (e) {
    alert('검증 시작 실패: ' + e.message);
    document.getElementById('btn-verify').disabled = false;
  }
}

/* ── 결과 표시 ─────────────────────────────────────────────────────────────── */
function showResult(result) {
  document.getElementById('prog-bar').style.width   = '100%';
  document.getElementById('prog-label').textContent = '검증 완료 ✓';

  const stamp = document.getElementById('run-stamp');
  if (stamp) stamp.innerHTML = `<span class="dot-ok"></span>${result.run_at} 검증 완료`;

  const bd = document.getElementById('badge-dashboard');
  const br = document.getElementById('badge-results');
  const bw = document.getElementById('badge-welders');
  if (bd) { bd.style.display = ''; bd.textContent = '최신'; }
  if (br) { br.style.display = ''; br.textContent = result.flagged_rows.toLocaleString() + '행'; }
  if (bw) {
    const missCnt = Object.keys(result.welder_missing || {}).length;
    bw.style.display = missCnt ? '' : 'none';
    bw.textContent = missCnt + '명';
  }

  S.dashCheckSel = null;       // 새 검증 결과에서는 항상 전부 선택된 상태로 시작
  S.deptDashCheckSel = null;
  _loadPatternTeams();         // 반복 패턴 표의 '팀' 열이 동기로 조회한다
  renderDashboard(result);
  setView('dashboard');
  updateStatusBar(null);
}

/* ── 대시보드 Check 취사선택 ────────────────────────────────────────────────
   "검사 항목별 상세" 카드를 클릭해 특정 Check를 대시보드 집계에서 제외할 수 있다.
   제외된 Check의 플래그는 정상 판정으로 간주되어 결함/클린 행수·차트가 실시간으로
   재구성된다. 서버가 내려준 result.stats/flagged_rows 등 원본은 건드리지 않고,
   매 렌더마다 result.flags(개별 플래그 목록)에서 선택된 Check만 다시 집계한다 —
   이 화면(메인 대시보드)에만 적용되며, 부서별 대시보드·용접사 관리의 Check 카드는
   기존대로 클릭 시 상세 목록으로 이동하는 별개 동작을 유지한다. */
function _dashSelectedChecks() {
  if (!S.dashCheckSel) S.dashCheckSel = new Set(_activeMeta().map(c => c.no));
  return S.dashCheckSel;
}

function toggleDashCheck(checkNo) {
  const sel = _dashSelectedChecks();
  if (sel.has(checkNo)) sel.delete(checkNo); else sel.add(checkNo);
  renderDashboard(S.result);
}

function resetDashCheckSel() {
  S.dashCheckSel = new Set(_activeMeta().map(c => c.no));
  renderDashboard(S.result);
}

/* 선택된 Check만으로 결함/클린 행수·Check별 건수·날짜별 추이를 다시 계산한다.
   '결함 행'은 선택된 Check 중 하나라도 걸린 행의 수(중복 제거) — 한 행에 선택/제외
   Check가 섞여 있어도 선택된 것이 하나라도 있으면 그 행은 여전히 결함이다. */
let _dashSeq = 0;

async function _dashAggregate(r) {
  // 두 번 묻는다. 축이 다르기 때문이다:
  //   d      = 선택된 Check + 행 범위(1C 제외)  -> KPI·차트
  //   cards  = 행 범위만                        -> Check 카드 건수
  // 카드에 `d.stats`를 쓰면 «해제한 Check»가 0으로 보여서 다시 켤 수가 없다.
  // 반대로 `r.stats`(원본)를 쓰면 1C를 뺐는데 카드만 전체 건수라, 바로 옆
  // 막대그래프와 숫자가 어긋난다 — 실제로 그렇게 나갔다.
  const [d, cards] = await Promise.all([
    fetchAggregate({ checks: _checksParam(_dashSelectedChecks()) }),
    fetchAggregate({}),
  ]);
  return {
    flaggedRows: d.flagged_rows,
    cleanRows:   d.clean_rows,
    totalFlags:  d.total_flags,
    stats:       d.stats,   // check_no(문자열) -> 건수. drawBarChart 등이 String(no)로 조회
    cardStats:   cards.stats,
    trend:       d.trend,
  };
}

/* ── 임시부재(1C 도면)는 판정 대상이 아니다 ────────────────────────────────
   현업 확인(2026-08-10): 「도면번호가 1C로 시작하면 임시부재」.
   현업 결정(2026-08-20): **판정에서 아예 뺀다.**

   예전에는 토글이었다 — 판정은 하고 «보는 방식»만 바꿨다. 그러면 대시보드와
   결함 목록이 다른 기준으로 보인다: 화면에는 1C를 뺀 숫자가, 항목을 눌러
   들어가면 1C가 섞인 목록이 나왔다. 같은 화면 안에서 어느 쪽이 맞는지 보는
   사람이 알 방법이 없었다.

   **토글이 사라졌으니 대신 말해야 한다.** 「원본은 1만 행인데 판정이 374행」이
   설명되지 않으면 그건 «숫자가 이상한 화면»이다. */
function _tempNote(id, temp) {
  const el = document.getElementById(id);
  if (!el) return;
  temp = temp || 0;
  el.style.display = temp > 0 ? '' : 'none';
  el.innerHTML = temp > 0
    ? '임시부재(1C 도면) <b>' + _n(temp) + '행</b>은 판정 대상이 아닙니다 — ' +
      '미작업과 같이 결함률 분모에도 들어가지 않습니다'
    : '';
}

/* 미검토 건수는 검토 기록을 저장할 때마다 달라지므로 서버에 다시 묻는다.
   실패하면 화면을 건드리지 않는다 — 틀린 숫자보다 옛 숫자가 낫다. */
async function _refreshUnreviewedCount() {
  const el = document.getElementById('sb-unrev');
  if (!el) return;
  try {
    const d = await apiFetch('/api/flags/review-counts');
    el.textContent = _n(d.unreviewed);
  } catch (e) {
    console.warn('미검토 건수 조회 실패:', e.message);
  }
}

/* ── 대시보드 렌더링 ─────────────────────────────────────────────────────────── */
async function renderDashboard(r) {
  document.getElementById('dash-empty').style.display   = 'none';
  document.getElementById('dash-content').style.display = '';

  // Check 카드를 빠르게 연달아 누르면 늦게 온 집계가 최신 선택을 덮어쓸 수 있다.
  // 실제 클릭 간격에서는 재현되지 않았지만(클릭마다 별도 tick) 목록 쪽과 같은
  // 형태의 공백이라 같은 방식으로 막는다.
  const seq = ++_dashSeq;
  let agg;
  try {
    agg = await _dashAggregate(r);
  } catch (e) {
    if (seq !== _dashSeq) return;
    console.warn('대시보드 집계 조회 실패:', e.message);
    const lbl = document.getElementById('dash-agg-error');
    if (lbl) lbl.textContent = '집계를 불러오지 못했습니다: ' + e.message;
    return;
  }
  if (seq !== _dashSeq) return;   // 더 새로운 선택이 이미 나갔다
  _tempNote('dash-temp-note', r.temp_rows);
  // **저장된 글을 다시 보여줄 뿐이다**(`GET /api/ai/saved`). 여기서 분석이
  // 시작되지는 않는다 — 「누르지 않으면 나가지 않는다」.
  aiShow('dash', 'overall', {}, 'ai-dash');
  aiShow('dashtrend', 'trend', {}, 'ai-dashtrend');
  renderKpiCards(r, agg);
  renderCheckGrid(agg.cardStats);
  renderKpiRec(r, agg);
  setTimeout(() => {
    drawBarChart('bar-chart', agg.stats, S.dashCheckSort);
    drawDonutChart('donut-chart', 'donut-legend', agg.stats,
                   agg.flaggedRows, agg.cleanRows, agg.flaggedRows + agg.cleanRows);
    drawTrendChart('trend-chart', 'trend-tooltip', agg.trend);
  }, 30);
}

function renderKpiCards(r, agg) {
  // 결함률 분모는 '판정 대상(judged_rows)' — 미작업(Check 0)은 결함이 아니므로 제외한다.
  //
  // **분모는 «지금 보고 있는 기준»이어야 한다.** Check를 취사선택해도
  // `flaggedRows + cleanRows`가 곧 그 기준의 판정 대상이다 — 카드도 도넛도
  // 같은 수를 봐야 한다.
  const judged    = agg.flaggedRows + agg.cleanRows;
  const flagRate  = judged > 0 ? (agg.flaggedRows / judged * 100).toFixed(1) : '0.0';
  const cleanRate = judged > 0 ? (agg.cleanRows   / judged * 100).toFixed(1) : '0.0';
  const unworked  = r.unworked_rows || 0;
  const temp      = r.temp_rows || 0;
  const sub0 = `삭제 ${_n(r.deleted_rows)}건 · 미작업 ${_n(unworked)}건 제외`
             + (temp > 0 ? ` · 임시부재 ${_n(temp)}행 제외` : '');
  const cards = [
    { lbl:'판정 대상', val: _n(judged), sub: sub0, c:'var(--text)' },
    { lbl:'미작업 수량 (CHECK 0)', val: _n(unworked), sub:'용접 미수행 (결함 아님·판정 제외) · 클릭 시 목록', c:'var(--text-2)', click: unworked > 0 ? 'openUnworkedList()' : '' },
    { lbl:'결함 행',   val: _n(agg.flaggedRows), sub:`판정 대상의 ${flagRate}% · 총 플래그 ${_n(agg.totalFlags)}건`,
      c:'var(--ck-orange)', sev: _sevByRate(flagRate) },
    { lbl:'이상 없음 (클린)', val: _n(agg.cleanRows), sub:`판정 대상의 ${cleanRate}%`, c:'var(--ck-green)' },
  ];
  document.getElementById('kpi-grid').innerHTML = cards.map(_kpiCardHtml).join('');
}

/* 결함률(%) -> 심각도. 임계값은 현장 감각에 맞춰 조정 가능하다.
   정상 수치는 발광시키지 않아야 문제 수치가 눈에 들어온다 — 전부 빛나면 아무것도 안 보인다. */
function _sevByRate(ratePct) {
  const v = parseFloat(ratePct) || 0;
  if (v >= 50) return 'bad';
  if (v >= 20) return 'warn';
  return '';
}

/* KPI 카드 1장. sev가 'warn'/'bad'면 수치가 계기처럼 발광한다(CSS에서 처리). */
function _kpiCardHtml(c) {
  return `<div class="kpi-card ${c.click ? 'clickable' : ''}"
        style="--kpi-c:${c.c}" ${c.sev ? `data-sev="${c.sev}"` : ''}
        ${c.click ? `role="button" tabindex="0" onclick="${c.click}"` : ''}>
      <div class="kpi-lbl">${c.lbl}</div>
      <div class="kpi-val">${c.val}</div>
      <div class="kpi-sub">${c.sub}</div>
    </div>`;
}

/* ── 검사 항목 카드의 정렬 ────────────────────────────────────────────────
   «어떤 검사가 가장 많이 걸렸는가»가 이 화면에서 가장 먼저 알고 싶은 것이라
   **기본이 수량 순**이다. 번호 순은 «특정 Check를 찾을 때» 쓴다.

   메인과 부서 대시보드가 상태를 **따로** 갖는다 — 한쪽에서 바꾼 것이 다른 쪽에
   조용히 따라가면 «내가 무엇을 보고 있는지»를 놓친다. 임시부재 토글이 그랬다.

   정렬 함수는 하나다. 갈라지면 같은 데이터가 두 화면에서 다른 순서로 보이고,
   그건 «어느 쪽이 맞는지» 알 수 없는 종류의 어긋남이다.

   **동점은 번호 순으로 깬다.** 안 그러면 건수가 같은 카드들의 자리가 렌더할
   때마다 달라져, 바뀐 것이 없는데도 화면이 흔들린 것처럼 보인다. */
const CK_SORTS = [['count', '수량 순'], ['no', '번호 순']];

function _sortedCheckMeta(statsObj, mode) {
  const meta = _activeMeta();
  if (mode !== 'count') return meta;              // 번호 순 = _activeMeta() 그대로
  const n = c => (statsObj || {})[String(c.no)] || 0;
  return meta.slice().sort((a, b) => n(b) - n(a) || _ckSort(a.no, b.no));
}

/* 정렬 칩 두 개. 화면 두 곳이 같은 모양이어야 하므로 여기서 그린다. */
function _ckSortChipsHtml(mode, fnName) {
  return CK_SORTS.map(([v, label]) =>
    `<button class="chip ${mode === v ? 'on' : ''}" role="button"
             aria-pressed="${mode === v}"
             onclick="${fnName}('${_jsq(v)}')">${label}</button>`).join('');
}

function setDashCheckSort(mode) {
  S.dashCheckSort = mode;
  renderDashboard(S.result);
}

function setDeptDashCheckSort(mode) {
  S.deptDashCheckSort = mode;
  _renderDeptDashScope();
}

/* statsObj: {"1": 0, "3": 782, ...} 형태의 check_no->건수 맵.
   clickable=true면 카드 클릭 시 상세 결과 탭으로 이동. onclickFn으로 어떤 스코프로
   이동할지 지정한다 — 전역(goToCheckDetail) 또는 부서/팀 범위(goToCheckDetailScoped). */
function _buildCheckGridHtml(statsObj, clickable, onclickFn) {
  statsObj = statsObj || {};
  onclickFn = onclickFn || 'goToCheckDetail';
  return _activeMeta().map(c => {
    const cnt = statsObj[String(c.no)] || 0;
    const canClick = clickable && cnt > 0;
    return `<div class="ck-card ${canClick ? 'clickable' : ''}" style="--ck-c:${c.ckC}"
                 ${canClick ? `role="button" tabindex="0" title="클릭하면 상세 목록으로 이동" onclick="${onclickFn}('${_jsq(c.no)}')"` : ''}>
      <div class="ck-num">CHECK ${_ckLabel(c.no)}<span class="ck-cat ck-cat-${_ckCategory(c.no) === '공통' ? 'common' : 'project'}">${_ckCategory(c.no)}</span>${_provMark(c.no)}${_scopeMark(c.no)}</div>
      <div class="ck-name">${c.name}</div>
      <div class="ck-count ${cnt === 0 ? 'zero' : ''}">${_n(cnt)}</div>
      <div class="ck-col">${c.col}열</div>
    </div>`;
  }).join('');
}

/* 대시보드/용접사 탭의 Check 카드 클릭 -> 상세 결과 "탭"으로 이동하는 대신 팝업으로 띄운다.
   팝업을 닫으면 지금 보고 있던 화면(대시보드/용접사 관리)이 그대로 유지된다. */
/* `CHECK_META[].no`는 **문자열**('12')인데 부르는 쪽이 숫자를 넘기는 자리가
   있다 — 필터를 바꾸면 `_mckFilter`가 `parseInt`로 숫자를 넣는다. `===`로 비교하면
   그때부터 못 찾아서, **모달 제목이 「전체 Check」로 바뀌고** 내려받는 파일 이름에서
   검사 이름이 사라진다. 오류는 나지 않는다. */
function _ckMeta(no) {
  if (no == null || no === '') return null;
  return CHECK_META.find(c => String(c.no) === String(no)) || null;
}

function goToCheckDetail(checkNo) {
  openCheckListModal(checkNo, '', '');
}

/* 부서별 대시보드의 Check 카드 클릭 -> 현재 선택된 부서/팀(+ Check)으로 필터링된 목록을 팝업으로 띄운다. */
function goToCheckDetailScoped(checkNo) {
  openCheckListModal(checkNo, S.deptDashDept || '', S.deptDashTeam || '');
}

/* statsObj는 «행 범위만 반영된» 건수다(1C 제외·부서/팀). Check 취사선택은
   반영하지 않는다 — 해제한 Check가 0으로 보이면 다시 켤 근거가 사라진다. */
function renderCheckGrid(statsObj) {
  document.getElementById('check-grid').innerHTML = _buildDashCheckGridHtml(statsObj);

  const sel = _dashSelectedChecks();
  const allSelected = sel.size === _activeMeta().length;
  const resetBtn = document.getElementById('check-grid-reset');
  const hint = document.getElementById('check-grid-hint');
  if (resetBtn) resetBtn.style.display = allSelected ? 'none' : '';
  if (hint) hint.textContent = allSelected
    // 개수를 박아 두면 검사가 늘거나 «프로젝트 세팅»에서 꺼도 옛말이 남는다
    ? `${_activeMeta().length}가지 검사 · 정렬은 위 «검사 항목별 플래그 현황»의 단추를 따릅니다 · 카드는 클릭 시 상세 목록, 우상단 체크박스로 집계에서 제외`
    : `${sel.size}/${_activeMeta().length}개 선택됨 · 제외된 항목은 정상 판정으로 처리되어 대시보드가 재구성됩니다`;
}

/* 대시보드 전용 Check 카드 — 두 영역이 서로 다른 동작을 한다:
   - 우상단 체크박스(.ck-toggle-box): 대시보드 집계 포함/제외 토글 (신규)
   - 카드 본문(나머지 전체): 기존과 동일하게 클릭 시 상세 목록 팝업으로 이동
   체크박스 클릭은 stopPropagation으로 카드 본문의 클릭을 막아, 토글과 드릴다운이
   서로를 건드리지 않는다. 카드 자체 건수는 해당 Check의 실제 발생 건수를 그대로
   보여준다(제외해도 0으로 바뀌지 않음) — 바뀌는 건 그 Check가 전체 집계에
   반영되는지 여부이지, Check 자체의 발생 건수가 아니기 때문이다. */
function _buildDashCheckGridHtml(statsObj) {
  const sel = _dashSelectedChecks();
  statsObj = statsObj || {};
  // **카드 건수는 취사선택에 흔들리지 않는다**(위 주석 참조). 그래서 체크박스를
  // 눌러도 순서가 다시 섞이지 않는다 — 섞이면 방금 누른 카드가 커서 밑에서
  // 사라져 «어디를 눌렀는지» 잃어버린다.
  return _sortedCheckMeta(statsObj, S.dashCheckSort).map(c => {
    const cnt = statsObj[String(c.no)] || 0;
    const selected = sel.has(c.no);
    const canDrill = cnt > 0;
    return `<div class="ck-card ${canDrill ? 'clickable' : ''} ${selected ? '' : 'ck-off'}" style="--ck-c:${c.ckC}"
                 ${canDrill ? `role="button" tabindex="0" title="클릭하면 상세 목록으로 이동" onclick="goToCheckDetail('${_jsq(c.no)}')"` : ''}>
      <span class="ck-toggle-box" role="button" tabindex="0" aria-pressed="${selected}"
            title="${selected ? '클릭하면 대시보드 집계에서 제외(정상 판정으로 처리)' : '클릭하면 다시 포함'}"
            onclick="event.stopPropagation(); toggleDashCheck('${_jsq(c.no)}')"></span>
      <div class="ck-num">CHECK ${_ckLabel(c.no)}<span class="ck-cat ck-cat-${_ckCategory(c.no) === '공통' ? 'common' : 'project'}">${_ckCategory(c.no)}</span>${_provMark(c.no)}${_scopeMark(c.no)}</div>
      <div class="ck-name">${c.name}</div>
      <div class="ck-count ${cnt === 0 ? 'zero' : ''}">${_n(cnt)}</div>
      <div class="ck-col">${c.col}열</div>
    </div>`;
  }).join('');
}

/* 주요 지표 카드. **항목마다 Check 번호를 달고 `_ruleOn()`으로 거른다.**

   예전에는 여섯 항목이 번호 없이 하드코딩돼 있어서, 프로젝트 세팅에서 Check 5를 꺼도
   「특수규칙 대상율 0.0%」가 그대로 남았다. 판정을 아예 안 하는 항목이 0.0%로 보이면
   «검사했는데 한 건도 없다»로 읽힌다 — 아래 Check 카드에서는 그 항목이 사라진
   상태라서, 같은 화면 안에서 두 곳이 서로 다른 말을 한다. */
function renderKpiRec(r, agg) {
  // **분모도 건수도 «지금 보고 있는 기준»이어야 한다.**
  //
  // 예전에는 이 블록만 `r.stats`(전체 결과)와 `_judged(r)`(5,516)을 썼다. 바로
  // 위 KPI 카드와 Check 카드는 집계(`agg`)를 쓰는데 여기만 안 써서, 임시부재를
  // 제외한 같은 화면에 이렇게 나왔다:
  //
  //     KPI 카드      판정 대상 374 · 결함 153 (40.9%)
  //     Check 카드    CHECK 3 = 0
  //     주요 KPI 지표  두께 허용범위 초과율 14.1% (Check 3 · 778건)   <- 그대로
  //
  // 같은 화면 안에서 숫자가 어긋나면 **어느 쪽이 맞는지 보는 사람이 알 방법이
  // 없다.** 오류는 나지 않는다. ui-regression-checker가 실측으로 잡았다.
  //
  // 건수는 `cardStats`를 쓴다 — Check 카드와 같은 값이다. 대시보드에서 Check를
  // 해제해도 «그 검사의 발생 건수»는 변하지 않는다는 것이 카드의 규칙이고,
  // 여기만 다르면 또 어긋난다.
  const stats = (agg && agg.cardStats) || r.stats || {};
  const total = (agg ? agg.flaggedRows + agg.cleanRows : _judged(r)) || 1;
  const cnt = no => stats[String(no)] || 0;
  const items = [
    { no:6,  lbl:'용접사 미등록 비율',  val: _pct(cnt(6), total), sub: `Check 6 · ${_n(cnt(6))}건`,  c:'var(--ck-orange)' },
    { no:4,  lbl:'Groove 불일치율',      val: _pct(cnt(4), total), sub: `Check 4 · ${_n(cnt(4))}건`,  c:'var(--ck-amber)' },
    { no:5,  lbl:'특수규칙 대상율',      val: _pct(cnt(5), total), sub: `Check 5 · ${_n(cnt(5))}건`,  c:'var(--ck-blue)' },
    { no:3,  lbl:'두께 허용범위 초과율', val: _pct(cnt(3), total), sub: `Check 3 · ${_n(cnt(3))}건`,  c:'var(--ck-blue)' },
    { no:11, lbl:'재질-WPS 부적합',      val: _n(cnt(11)),         sub: `Check 11 · 허용 재질 아님`, c:'var(--ck-purple)' },
    { no:12, lbl:'관재 DIA 확인 필요',   val: _n(cnt(12)),         sub: `Check 12 · 수동 확인 대상`, c:'var(--ck-teal)' },
  ].filter(i => _ruleOn(i.no));
  document.getElementById('kpi-rec-grid').innerHTML = items.map(i =>
    `<div class="rec-item">
      <div class="rec-label">${i.lbl}</div>
      <div class="rec-val" style="color:${i.c}">${i.val}</div>
      <div class="rec-sub">${i.sub}</div>
    </div>`
  ).join('');
}

function _formatCheckBreakdown(breakdown, exclude = []) {
  if (!breakdown) return '—';
  const entries = Object.keys(breakdown)
    .filter(no => breakdown[no] > 0 && !exclude.includes(no))
    .sort(_ckSort);
  if (!entries.length) return '결함 없음';
  return entries.map(no => `C${no}: ${breakdown[no]}`).join(', ');
}

function _formatCheckBreakdownHtml(breakdown, exclude = []) {
  if (!breakdown) return '—';
  const entries = Object.keys(breakdown)
    .filter(no => breakdown[no] > 0 && !exclude.includes(no))
    .sort(_ckSort);
  if (!entries.length) return '<span style="color:var(--text-3)">결함 없음</span>';
  return entries
    .map(no => `<span style="color:var(--ck-red);font-weight:700">C${no}: ${breakdown[no]}</span>`)
    .join(', ');
}

/* 반복 결함 패턴을 전 부서에 걸쳐 용접사 단위로 모은다.
   백엔드는 부서/팀 스코프별로만 패턴을 내려주므로(부서 리포트 메일이 그 단위라서),
   "사람 관점"으로 보려면 여기서 합쳐야 한다. 같은 (용접사, Check)가 여러 부서에
   나올 수 있으므로 부서명을 함께 보관한다. */
function _allRecurringPatterns() {
  const out = [];
  const depts = (S.result && S.result.departments) || {};
  Object.keys(depts).forEach(dname => {
    (depts[dname].recurring_patterns || []).forEach(p => {
      out.push(Object.assign({ department: dname }, p));
    });
  });
  out.sort((a, b) => b.count - a.count);
  return out;
}

/* 반복 패턴 한 건이 어느 팀(BG열)에서 나온 것인지 — 패턴은 부서 단위로 계산되므로
   팀은 플래그에서 역산한다. 대부분 팀 하나로 특정되지만, 한 용접사가 같은 Check를
   두 팀에서 낸 경우(실데이터 2건)가 있어 복수 표기를 지원한다. */
/* 표를 그리는 «도중에» 동기로 불리므로 패턴마다 요청할 수 없다.
   조합 전체(실측 289개 / 26KB)를 한 번 받아 두고 조회한다. */
function _patternTeams(welderNo, checkNo, dept) {
  const m = S._patternTeams;
  if (!m) return [];
  return m.get(`${welderNo}|${checkNo}|${dept || ''}`) || [];
}

async function _loadPatternTeams() {
  if (S._patternTeams) return;
  try {
    const d = await apiFetch('/api/flags/pattern-teams');
    const m = new Map();
    (d.items || []).forEach(it => {
      m.set(`${it.welder_no}|${it.check_no}|${it.department || ''}`, it.teams);
      // dept를 지정하지 않고 부르는 자리가 있어 «부서 무관» 키도 함께 만든다
      const k = `${it.welder_no}|${it.check_no}|`;
      m.set(k, [...new Set([...(m.get(k) || []), ...it.teams])]);
    });
    S._patternTeams = m;
  } catch (e) {
    console.warn('반복 패턴 팀 조회 실패:', e.message);
    S._patternTeams = new Map();
  }
}

function _patternTeamHtml(p) {
  const teams = _patternTeams(p.welder_no, p.check_no, p.department);
  if (!teams.length) return '<span style="color:var(--text-3)">—</span>';
  if (teams.length === 1) return _esc(teams[0]);
  return `${_esc(teams[0])} <span class="w-lowsample" title="${_esc(teams.join(' / '))}">외 ${teams.length - 1}팀</span>`;
}

/* 용접사별 반복 패턴 개수 — 통합 목록의 '반복' 열과 정렬에 쓴다. */
function _recurCountByWelder() {
  const m = {};
  _allRecurringPatterns().forEach(p => {
    m[p.welder_no] = (m[p.welder_no] || 0) + 1;
  });
  return m;
}

/* ── Canvas: 결함 발생 추이 (꺾은선) ──────────────────────────────────────────── */
function drawTrendChart(canvasId, tooltipId, trend) {
  const cvs = document.getElementById(canvasId);
  if (!cvs) return;
  trend = trend || [];
  const dpr = window.devicePixelRatio || 1;
  const W = cvs.parentElement.clientWidth - 32;
  // 숨겨진 화면(display:none)에서는 clientWidth가 0이라 W가 음수가 되고,
  // ctx.arc가 음수 반경을 받아 IndexSizeError로 죽는다. 그릴 것도 없으므로 나간다
  // (화면이 보이게 되면 해당 render 함수가 다시 호출해 그린다).
  if (W < 40) return;
  const H = 200;
  cvs.width = W * dpr; cvs.height = H * dpr;
  cvs.style.width = W + 'px'; cvs.style.height = H + 'px';
  const ctx = cvs.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, W, H);

  const st = getComputedStyle(document.documentElement);
  const textC  = st.getPropertyValue('--text').trim();
  const text2C = st.getPropertyValue('--text-2').trim();
  const borderC = st.getPropertyValue('--border-sub').trim();
  const lineC  = st.getPropertyValue('--ck-red').trim();

  if (!trend.length) {
    ctx.font = '13px -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif';
    ctx.fillStyle = text2C;
    ctx.textAlign = 'center';
    ctx.fillText('용접일 데이터가 있는 결함이 없습니다', W / 2, H / 2);
    return;
  }

  const padL = 40, padR = 16, padT = 16, padB = 26;
  const plotW = W - padL - padR;
  const plotH = H - padT - padB;
  const maxV = Math.max(...trend.map(t => t.count), 1);

  // y축 그리드 (0, max)
  ctx.strokeStyle = borderC; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(padL, padT); ctx.lineTo(padL, padT + plotH); ctx.lineTo(padL + plotW, padT + plotH); ctx.stroke();
  ctx.font = '10px -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif';
  ctx.fillStyle = text2C; ctx.textAlign = 'right';
  ctx.fillText(String(maxV), padL - 6, padT + 4);
  ctx.fillText('0', padL - 6, padT + plotH + 4);

  const stepX = trend.length > 1 ? plotW / (trend.length - 1) : 0;
  const pts = trend.map((t, i) => ({
    x: padL + stepX * i,
    y: padT + plotH - (t.count / maxV) * plotH,
    ...t,
  }));

  // 라인
  ctx.strokeStyle = lineC; ctx.lineWidth = 2;
  ctx.beginPath();
  pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
  ctx.stroke();

  // 포인트
  ctx.fillStyle = lineC;
  pts.forEach(p => { ctx.beginPath(); ctx.arc(p.x, p.y, 3, 0, Math.PI * 2); ctx.fill(); });

  // x축 라벨 (처음/마지막/중간 정도만 표시해 겹침 방지)
  ctx.fillStyle = text2C; ctx.textAlign = 'center';
  const labelEvery = Math.max(1, Math.ceil(pts.length / 6));
  pts.forEach((p, i) => {
    if (i % labelEvery === 0 || i === pts.length - 1) {
      ctx.fillText(p.date.slice(5), p.x, padT + plotH + 16);
    }
  });

  // 호버 시 건수 표시를 위해 포인트 좌표 저장 + 이벤트 1회만 바인딩
  cvs._trendPts   = pts;
  cvs._tooltipId  = tooltipId;
  if (!cvs._hoverBound) {
    cvs.addEventListener('mousemove', e => _onTrendHover(e, cvs));
    cvs.addEventListener('mouseleave', () => _hideTrendTooltip(cvs._tooltipId));
    cvs._hoverBound = true;
  }
}

function _onTrendHover(e, cvs) {
  const pts = cvs._trendPts || [];
  const tip = document.getElementById(cvs._tooltipId);
  if (!pts.length || !tip) return;
  const rect = cvs.getBoundingClientRect();
  const mx = e.clientX - rect.left;
  let nearest = null, minDist = Infinity;
  for (const p of pts) {
    const dist = Math.abs(p.x - mx);
    if (dist < minDist) { minDist = dist; nearest = p; }
  }
  if (!nearest || minDist > 18) { _hideTrendTooltip(cvs._tooltipId); return; }
  tip.style.display = 'block';
  tip.textContent   = `${nearest.date} · ${_n(nearest.count)}건`;
  tip.style.left = (rect.left + nearest.x + 10) + 'px';
  tip.style.top  = (rect.top  + nearest.y - 32) + 'px';
}

function _hideTrendTooltip(tooltipId) {
  const tip = document.getElementById(tooltipId || 'trend-tooltip');
  if (tip) tip.style.display = 'none';
}

/* ── Canvas: 바 차트 ─────────────────────────────────────────────────────────── */
/* statsObj: {"1":0, "3":782, ...} check_no->건수 맵 (전역 result.stats 또는 부서/팀 check_stats 재사용) */
/* 막대그래프 우상단의 정렬 칩. 차트를 그릴 때마다 함께 갱신한다 —
   따로 두면 «단추는 바뀌었는데 차트는 그대로»가 생긴다. */
function _drawBarSortChips(canvasId, mode, fnName) {
  const el = document.getElementById(canvasId + '-sort');
  if (el) el.innerHTML = _ckSortChipsHtml(mode, fnName);
}

/* 이름이 칸을 넘치면 **뒤를 줄이고 말줄임표**를 붙인다.

   그냥 두면 캔버스가 잘라 내는데, 이름을 오른쪽 정렬로 그리므로 잘리는 쪽이
   **앞**이다 — 즉 `C26 · ` 하는 Check 코드가 사라진다. 어떤 검사인지 알 수
   없는 막대가 되고, 그게 이 화면에서 가장 쓸모없는 상태다.

   `measure`를 인자로 받는다(캔버스의 `measureText`). 그래야 이 규칙만 떼어
   시험할 수 있다 — 캔버스를 띄우지 않고.

   말줄임표 자리도 안 나오면 그때는 그대로 돌려준다. 여기서 빈 문자열을 주면
   막대만 남아 더 나쁘다. */
function _fitBarLabel(measure, text, maxW) {
  if (maxW <= 0 || measure(text) <= maxW) return text;
  for (let i = text.length - 1; i > 0; i--) {
    const t = text.slice(0, i) + '…';
    if (measure(t) <= maxW) return t;
  }
  return text;
}

function drawBarChart(canvasId, statsObj, mode) {
  _drawBarSortChips(canvasId, mode,
                    canvasId === 'bar-chart' ? 'setDashCheckSort'
                                             : 'setDeptDashCheckSort');
  const cvs = document.getElementById(canvasId);
  if (!cvs) return;
  statsObj = statsObj || {};
  const dpr  = window.devicePixelRatio || 1;
  const W    = cvs.parentElement.clientWidth - 32;
  // 숨겨진 화면(display:none)에서는 clientWidth가 0이라 W가 음수가 되고,
  // ctx.arc가 음수 반경을 받아 IndexSizeError로 죽는다. 그릴 것도 없으므로 나간다
  // (화면이 보이게 되면 해당 render 함수가 다시 호출해 그린다).
  if (W < 40) return;
  // **카드 그리드와 같은 정렬 함수를 쓴다.** 바로 위아래에 붙어 있는 두 표가
  // 다른 순서면 같은 화면 안에서 어느 쪽이 맞는지 보는 사람이 알 수 없다.
  // 여기 건수(`stats`)는 Check 취사선택이 반영된 값이라 카드(`cardStats`)와
  // 항목 «구성»은 다를 수 있다 — 순서 규칙이 같으면 그건 어긋남이 아니다.
  const items= _sortedCheckMeta(statsObj, mode)
    .filter(c => (statsObj[String(c.no)] || 0) > 0);
  const H    = Math.max(items.length * 36 + 8, 60);
  cvs.width  = W * dpr; cvs.height = H * dpr;
  cvs.style.width = W + 'px'; cvs.style.height = H + 'px';
  const ctx  = cvs.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, W, H);
  const st   = getComputedStyle(document.documentElement);
  const textC  = st.getPropertyValue('--text').trim();
  const text2C = st.getPropertyValue('--text-2').trim();
  const borderC= st.getPropertyValue('--border-sub').trim();

  if (!items.length) {
    ctx.font = '13px -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif';
    ctx.fillStyle = text2C;
    ctx.textAlign = 'center';
    ctx.fillText('결함이 없습니다', W / 2, H / 2);
    return;
  }

  const maxV = Math.max(...items.map(c => statsObj[String(c.no)] || 0), 1);

  // **이름 칸을 넓힌다.** 140px였을 때 긴 이름이 캔버스 밖으로 밀려 앞부분
  // (Check 코드)이 잘렸다 — 어떤 검사인지 알 수 없는 막대가 됐다.
  // 좁은 창에서 이름 칸이 카드를 다 먹지 않도록 폭에도 상한을 건다.
  const lblW = Math.max(80, Math.min(182, Math.round(W * 0.45)));

  // **숫자 칸은 «가장 큰 수»를 재서 잡는다.** 55px 고정이었는데, 실측으로
  // 건수가 78,000까지 올라갔다. 38만 행이면 여섯 자리를 넘어 오른쪽이 잘린다.
  ctx.font = '600 11px -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif';
  const padR = Math.max(55, Math.ceil(ctx.measureText(_n(maxV)).width) + 18);
  ctx.fillStyle = borderC; ctx.fillRect(lblW, 0, 1, H);
  items.forEach((c, i) => {
    const cnt = statsObj[String(c.no)] || 0;
    const y   = i * 36 + 24;
    ctx.font      = '600 11px -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif';
    ctx.fillStyle = text2C;
    ctx.textAlign = 'right';
    // 칸을 넘치면 뒤를 줄인다 — 앞(Check 코드)은 반드시 남아야 한다
    const lbl = _fitBarLabel(t => ctx.measureText(t).width,
                             `C${c.no} · ${c.name}`, lblW - 12);
    ctx.fillText(lbl, lblW - 8, y + 4);
    // 칸을 넓힌 만큼 막대가 짧아진다. 카드가 아주 좁으면 음수가 될 수 있는데,
    // `roundRect`에 음수 폭을 주면 예외로 죽는다.
    const bw    = Math.max(0, (cnt / maxV) * (W - lblW - padR));
    const bH    = 18;
    const color = st.getPropertyValue(c.ckC.slice(4, -1)).trim();
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.roundRect(lblW + 6, y - bH / 2, bw, bH, 2);
    ctx.fill();
    ctx.font      = '600 11px -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif';
    ctx.fillStyle = textC; ctx.textAlign = 'left';
    ctx.fillText(_n(cnt), lblW + bw + 10, y + 4);
  });
}

/* ── Canvas: 도넛 차트 ───────────────────────────────────────────────────────── */
/* statsObj: check_stats 맵. flaggedRows/cleanRows/judgedRows: 전역 result 또는 부서/팀 스코프에서 계산한 값 */
function drawDonutChart(canvasId, legendId, statsObj, flaggedRows, cleanRows, judgedRows) {
  const cvs = document.getElementById(canvasId);
  if (!cvs) return;
  statsObj = statsObj || {};
  const dpr = window.devicePixelRatio || 1;
  const W   = cvs.parentElement.clientWidth - 32;
  // 숨겨진 화면(display:none)에서는 clientWidth가 0이라 W가 음수가 되고,
  // ctx.arc가 음수 반경을 받아 IndexSizeError로 죽는다. 그릴 것도 없으므로 나간다
  // (화면이 보이게 되면 해당 render 함수가 다시 호출해 그린다).
  if (W < 40) return;
  const H   = 160;
  cvs.width = W * dpr; cvs.height = H * dpr;
  cvs.style.width = W + 'px'; cvs.style.height = H + 'px';
  const ctx = cvs.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, W, H);
  const st = getComputedStyle(document.documentElement);
  const surfC = st.getPropertyValue('--surface').trim();
  const textC = st.getPropertyValue('--text').trim();
  const text2C= st.getPropertyValue('--text-2').trim();
  const cleanC = st.getPropertyValue('--ck-green').trim();

  /* 결함 부분을 Check별로 쪼갠다.
     예전에는 Check 4·5만 이름을 달고 나머지를 «기타»로 뭉쳤는데, 실제로 걸린
     Check가 9종인데 범례에 4줄만 나와 화면이 실제와 달라 보였다.

     쪼개는 기준은 **플래그 건수 비중**이다. 한 행에 Check가 여럿 걸릴 수 있어
     (실측 결함 3,426행 / 플래그 4,508건) Check별 «행 수»는 더해도 결함 행수가
     되지 않는다. 그래서 결함 호(弧)의 크기는 행 기준으로 두고, 그 안을 플래그
     비중으로 나눈다 — 고리 전체 합은 판정 대상과 정확히 같게 유지된다. */
  const clnV = cleanRows || 0;
  const flg  = Math.max(flaggedRows || 0, 0);
  const parts = _activeMeta()
    .map(m => ({ no: m.no, name: m.name, n: statsObj[String(m.no)] || 0,
                 c: _ckColor(m, st) }))
    .filter(p => p.n > 0);
  const totalFlags = parts.reduce((a, p) => a + p.n, 0);
  const segs = [{ v: clnV, c: cleanC }].concat(
    totalFlags > 0 ? parts.map(p => ({ v: flg * (p.n / totalFlags), c: p.c })) : []
  ).filter(s => s.v > 0);
  const total = segs.reduce((s, x) => s + x.v, 0) || 1;
  const cx = W / 2; const cy = H / 2;
  const R = Math.min(W, H) / 2 - 10;
  const thick = 28;
  let angle = -Math.PI / 2;
  segs.forEach(s => {
    const sweep = (s.v / total) * Math.PI * 2;
    ctx.beginPath();
    ctx.arc(cx, cy, R, angle, angle + sweep);
    ctx.arc(cx, cy, R - thick, angle + sweep, angle, true);
    ctx.closePath();
    ctx.fillStyle = s.c; ctx.fill();
    angle += sweep;
  });
  ctx.fillStyle = surfC;
  ctx.beginPath(); ctx.arc(cx, cy, R - thick - 2, 0, Math.PI * 2); ctx.fill();
  const cleanPct = judgedRows > 0 ? (cleanRows / judgedRows * 100).toFixed(1) : '0.0';
  ctx.font      = `700 20px -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif`;
  ctx.fillStyle = textC; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(cleanPct + '%', cx, cy - 7);
  ctx.font      = `11px -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif`;
  ctx.fillStyle = text2C;
  ctx.fillText('클린 비율', cx, cy + 12);
  /* 범례는 걸린 Check를 **전부** 적는다. 대시보드에서 Check를 취사선택하면
     구성이 바뀌므로 목록을 고정하지 않고 매번 statsObj에서 만든다. */
  const leg = document.getElementById(legendId);
  if (leg) {
    const items = [{ c: cleanC, l: `클린 ${cleanPct}%`, t: `이상 없음 ${_n(clnV)}행` }]
      .concat(parts.map(p => ({
        c: p.c,
        l: `C${p.no} · ${p.name} ${_n(p.n)}`,
        t: `${p.name} — 플래그 ${_n(p.n)}건 (결함 중 ${(p.n / totalFlags * 100).toFixed(1)}%)`,
      })));
    leg.innerHTML = items.map(x =>
      `<div class="legend-item" title="${_esc(x.t)}">` +
      `<span class="legend-dot" style="background:${x.c}"></span>` +
      `<span class="legend-lbl">${_esc(x.l)}</span></div>`
    ).join('') +
    `<div class="legend-note">결함 조각은 플래그 건수 비중으로 나눴습니다 ` +
    `— 한 행에 Check가 여럿 걸릴 수 있어 Check별 행수는 합해도 결함 행수가 되지 않습니다.</div>`;
  }
}

/* CHECK_META의 `ckC`(예: `var(--ck-navy)`)에서 실제 색을 읽는다.
   캔버스에는 CSS 변수를 그대로 못 넘기므로 계산된 값이 필요하다. */
function _ckColor(meta, st) {
  const m = /var\((--[\w-]+)\)/.exec(meta.ckC || '');
  const v = m ? st.getPropertyValue(m[1]).trim() : '';
  return v || st.getPropertyValue('--ck-blue').trim();
}

/* ── 결과 테이블 ─────────────────────────────────────────────────────────────── */
function buildResultFilters(r) {
  const sel      = document.getElementById('ck-filter');
  const deptSel  = document.getElementById('dept-filter');
  const chips    = document.getElementById('chip-bar');
  // Check select
  const active = _activeMeta().filter(c => (r.stats[String(c.no)] || 0) > 0);
  sel.innerHTML = `<option value="">전체 Check</option>` +
    active.map(c => `<option value="${c.no}">Check ${c.no} · ${c.name}</option>`).join('');
  // 부서 select — r.departments 키 순서(결함 많은 순 정렬은 부서 탭 몫이므로 여기선 이름순)
  const deptNames = Object.keys(r.departments || {}).sort((a, b) => a.localeCompare(b, 'ko'));
  const deptCur = deptSel.value;
  deptSel.innerHTML = `<option value="">전체 부서</option>` +
    deptNames.map(name => `<option value="${_esc(name)}">${_esc(name)}</option>`).join('');
  if (deptNames.includes(deptCur)) deptSel.value = deptCur;
  _populateTeamFilter();
  // chips
  chips.innerHTML = [
    { v:'', l:'전체', c:'var(--accent)' },
    ...active.slice(0,3).map(c => ({ v: String(c.no), l: `C${c.no} ${c.name.split(' ')[0]}`, c: c.ckC }))
  ].map(x =>
    `<div class="chip ${x.v===''?'on':''}" style="--chip-c:${x.c}" role="button" tabindex="0"
          onclick="chipClick(this,'${_jsq(x.v)}')">${x.l}</div>`
  ).join('');
}

/* 팀 select 옵션은 현재 선택된 부서(dept-filter)에 속한 팀만 보여준다.
   부서가 "전체"면 모든 플래그에서 등장하는 팀을 통째로 모아 보여준다.

   **정렬은 화면이 한다** — 한국어 정렬(localeCompare(_, 'ko'))은 SQL로 재현할 수
   없어 서버는 정렬하지 않고 보낸다. */
const _teamFacetCache = new Map();

async function _fetchTeams(dept) {
  const key = dept || '';
  if (_teamFacetCache.has(key)) return _teamFacetCache.get(key);
  try {
    const d = await apiFetch(`/api/flags/facets?${_qs({ dept: key })}`);
    const teams = d.teams || [];
    _teamFacetCache.set(key, teams);
    return teams;
  } catch (e) {
    console.warn('팀 목록 조회 실패:', e.message);
    return [];
  }
}


async function _populateTeamFilter() {
  const teamSel = document.getElementById('team-filter');
  if (!teamSel || !S.result) return;
  const deptVal = (document.getElementById('dept-filter') || {}).value || '';
  const teams = await _fetchTeams(deptVal);
  const cur = teamSel.value;
  const sorted = [...teams].sort((a, b) => a.localeCompare(b, 'ko'));
  teamSel.innerHTML = `<option value="">전체 팀</option>` +
    sorted.map(t => `<option value="${_esc(t)}">${_esc(t)}</option>`).join('');
  if (sorted.includes(cur)) teamSel.value = cur;
}

function onDeptFilterChange() {
  document.getElementById('team-filter').value = '';
  _populateTeamFilter();
  S.page = 1;
  filterResults();
}

function chipClick(el, val) {
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('on'));
  el.classList.add('on');
  document.getElementById('ck-filter').value = val;
  S.page = 1;
  filterResults();
}

/* 필터 조건만 들고 있다가 페이지를 옮길 때마다 그 페이지만 가져온다.
   검색 열(joint_no · wps_no · msg · block · ndt_report)은 서버가 고른다 —
   조건이 갈라지면 «전에는 나오던 게 안 나온다»가 되므로 여기서 따로 거르지 않는다. */
function _resultFilterParams() {
  return {
    check: document.getElementById('ck-filter').value,
    dept:  document.getElementById('dept-filter').value,
    team:  document.getElementById('team-filter').value,
    q:     document.getElementById('txt-filter').value,
  };
}

function filterResults() {
  if (!S.result) return;
  S.page = 1;
  // promise를 돌려준다 — 인라인 핸들러는 반환값을 무시하므로 화면 동작은 그대로고,
  // 테스트는 «반영될 때까지» 기다릴 수 있다.
  return loadResultPage();
}

function renderResults() {
  if (!S.result) return;
  document.getElementById('results-empty').style.display   = 'none';
  document.getElementById('results-content').style.display = '';
  buildResultFilters(S.result);
  aiShow('res', 'falsepos', {}, 'ai-res');
  S.page = 1;
  return loadResultPage();
}

/* 응답이 늦게 도착했을 때 «지금 화면이 보고 있는 것»과 다르면 버린다.
   빠르게 필터를 바꾸면 옛 응답이 뒤늦게 도착해 표를 덮어쓸 수 있다. */
let _resultSeq = 0;

async function loadResultPage() {
  const seq = ++_resultSeq;
  const params = _resultFilterParams();
  params.offset = (S.page - 1) * PAGE_SIZE;
  params.limit  = PAGE_SIZE;
  try {
    const d = await fetchFlags(params);
    if (seq !== _resultSeq) return;      // 더 새로운 요청이 이미 나갔다
    S.resultPage = d;
  } catch (e) {
    if (seq !== _resultSeq) return;
    console.warn('결과 목록 조회 실패:', e.message);
    S.resultPage = { total: 0, offset: 0, items: [] };
  }
  renderResultPage();
}

function renderResultPage() {
  const d       = S.resultPage || { total: 0, items: [] };
  const total   = d.total;
  const pages   = Math.ceil(total / PAGE_SIZE) || 1;
  const start   = (S.page - 1) * PAGE_SIZE;
  const slice   = d.items;

  document.getElementById('result-count').textContent =
    `표시 중: ${_n(slice.length)}건 / 전체 ${_n(total)}건`;
  document.getElementById('result-tbody').innerHTML = slice.map(f =>
    `<tr class="row-clickable" role="button" tabindex="0" title="클릭하면 원본 데이터 및 비교 상세를 볼 수 있습니다"
         onclick="openFlagDetail(${f.row})">
      <td class="mono" style="color:var(--text-3)">${f.row}</td>
      <td class="mono" style="color:var(--text-2)">${_esc(f.drawing_no || '—')}</td>
      <td class="mono" style="font-weight:600">${_esc(f.joint_no || '—')}</td>
      <td>${_esc(f.block || '—')}</td>
      <td class="mono">${_esc(_fmtPair(f.material1, f.material2))}</td>
      <td class="mono">${_fmtPair(f.thickness1, f.thickness2)}</td>
      <td class="mono">${_esc(f.wps_no || '—')}</td>
      <td class="mono">${_esc(f.wps_process || '—')}</td>
      <td class="mono">${_esc(f.weld_date || '—')}</td>
      <td class="mono">${_esc(f.ndt_date || '—')}</td>
      <td>${_esc(f.department || '—')}</td>
      <td>${_esc(f.team || '—')}</td>
      <td><span class="pill ${COLOR_TO_CLS[f.color] || 'p-blue'}">C${f.check_no}</span></td>
      <td>${_reviewBadgeHtml(f)}</td>
      <td class="mono" style="color:var(--text-2)">${_esc(f.col_letter)}열</td>
      <td class="cmp-cell"><span class="cmp-expected" title="${_esc(f.expected || f.msg)}">${_esc(f.expected || f.msg)}</span></td>
      <td class="cmp-cell"><span class="cmp-actual" title="${_esc(f.actual || '')}">${_esc(f.actual || '—')}</span></td>
    </tr>`
  ).join('');

  document.getElementById('page-info').textContent =
    `${_n(start + 1)}–${_n(Math.min(start + PAGE_SIZE, total))} / ${_n(total)}행`;

  const btns = document.getElementById('page-btns');
  const pArr = buildPageArr(S.page, pages);
  btns.innerHTML = `<button class="pbtn" onclick="goPage(${S.page - 1})" ${S.page<=1?'disabled':''}>‹</button>` +
    pArr.map(p => p === '…'
      ? `<span style="padding:3px 6px;color:var(--text-3)">…</span>`
      : `<button class="pbtn ${p===S.page?'curr':''}" onclick="goPage(${p})">${p}</button>`
    ).join('') +
    `<button class="pbtn" onclick="goPage(${S.page + 1})" ${S.page>=pages?'disabled':''}>›</button>`;
}

function buildPageArr(cur, total) {
  if (total <= 7) return Array.from({length:total}, (_,i)=>i+1);
  const arr = [1];
  if (cur > 3)  arr.push('…');
  for (let p = Math.max(2, cur-1); p <= Math.min(total-1, cur+1); p++) arr.push(p);
  if (cur < total - 2) arr.push('…');
  arr.push(total);
  return arr;
}

function goPage(p) {
  const total = (S.resultPage || {}).total || 0;
  const pages = Math.ceil(total / PAGE_SIZE) || 1;
  if (p < 1 || p > pages) return;
  S.page = p;
  return loadResultPage();   // 페이지가 바뀌면 그 페이지를 새로 가져온다
}

/* ── 행 상세 모달 (원본 데이터 + 기준값/실측값 비교) ──────────────────────────────── */

/* 엑셀 원문 스냅샷은 /api/result에 실려 오지 않는다.
   payload의 64.2%였는데 화면은 사용자가 클릭한 한 행만 쓴다. 모달을 열 때
   그 행만 가져와 슬롯에 채운다. 같은 행을 다시 열면 캐시에서 꺼낸다. */
const _rawCache = new Map();

/* 슬롯에 «어느 행의 것인가»를 반드시 박아 둔다.
   모달 body를 다시 그릴 때마다 같은 id의 슬롯이 새로 생기므로, id만 보고 채우면
   늦게 도착한 응답이 «없어진 슬롯»이 아니라 **새 행의 슬롯**을 덮어쓴다.
   실제로 그렇게 만들어진 검토 기록이 «키는 행 A, 첨부 원문은 행 B»가 됐다. */
function _rawSlotHtml(rowNum) {
  return `<div id="raw-grid-slot" data-row="${_esc(String(rowNum))}">`
       + `<div style="color:var(--text-3);font-size:12px">원본 데이터를 불러오는 중…</div>`
       + `</div>`;
}

async function _fillRawSlot(rowNum) {
  let raw = _rawCache.get(rowNum);
  if (!raw) {
    try {
      const d = await apiFetch(`/api/result/row/${rowNum}`);
      raw = (d && d.raw) || [];
      _rawCache.set(rowNum, raw);
    } catch (e) {
      raw = [];
    }
  }
  // 기다리는 동안 사용자가 다른 행을 열었을 수 있다. 지금 화면에 있는 슬롯이
  // «이 행»의 것일 때만 반영한다 — 아니면 이 응답은 이미 버려진 것이다.
  const slot = document.getElementById('raw-grid-slot');
  if (!slot || slot.dataset.row !== String(rowNum)) return;

  S._modalRaw = raw;   // saveFlagFeedback()이 이 값을 함께 보낸다
  slot.innerHTML = _buildRawGridHtml(raw);
}

function _buildRawGridHtml(rawList) {
  if (!rawList || !rawList.length) {
    return `<div style="color:var(--text-3);font-size:12px">원본 데이터를 불러올 수 없습니다.</div>`;
  }
  return `<div class="raw-grid">` + rawList.map(f => `
    <div class="raw-cell">
      <div class="raw-cell-lbl">${_esc(f.label)} <span class="raw-cell-col">${f.col}열</span></div>
      <div class="raw-cell-val ${!f.value ? 'empty' : ''}">${_esc(f.value || '—')}</div>
    </div>`).join('') + `</div>`;
}

/* focusCheckNo: 특정 Check를 보려고 들어온 경우(반복 결함 패턴 팝업, Check별 목록 팝업)
   그 Check 행을 강조한다. 한 행에 Check가 여러 개 걸려 있으면(예: C3+C4+C14) 어느 것을
   검토하러 왔는지 찾기 어렵기 때문. 나머지 Check도 그대로 보여준다 — 판단에 필요한
   전체 맥락은 유지해야 하므로 숨기지는 않는다. */
/* Check 14 행을 열었을 때, 같은 (도면번호, Joint No)로 등록된 다른 행들을 나란히
   보여준다. Check14는 "이 행 하나가 틀렸다"가 아니라 "이 조인트의 등록값들이 서로
   어긋난다"는 판정이라, 형제 행과 대조하지 않으면 어느 값이 맞는지 판단할 수 없다.
   값이 갈리는 칸은 강조 표시하고, 형제 행을 클릭하면 그 행 상세로 이동한다. */
/* 형제 행은 서버에서 가져온다. 모달을 그리는 시점에는 슬롯만 두고, 도착하면
   채운다 — 원본 데이터 패널(_fillRawSlot)과 같은 방식이다.

   **어느 행의 것인지 반드시 대조한다.** 늦게 도착한 응답이 새로 연 행의 슬롯을
   덮어쓴 사고가 실제로 있었다(검토 기록에 다른 행의 원문이 섞였다). */
function _c14SlotHtml(rowNum) {
  return `<div id="c14-group-slot" data-row="${_esc(String(rowNum))}"></div>`;
}

async function _fillC14Slot(rowFlags, rowNum, backTo) {
  const slot = document.getElementById('c14-group-slot');
  if (!slot || slot.dataset.row !== String(rowNum)) return;
  const f14 = (rowFlags || []).find(f => String(f.check_no) === '14');
  if (!f14) return;
  let items = [];
  try {
    // 그룹 키(도면번호 + Joint No)를 **정확일치**로 묻는다. 부분일치(q)로 받아
    // 화면에서 다시 거르면 후보 수를 예측할 수 없어 상한에 걸릴 수 있다 —
    // 정확일치면 결과가 그룹 크기(실측 2~41행)로 자연히 묶인다.
    const d = await fetchFlags({
      check: 14,
      drawing_no: f14.drawing_no || '',
      joint_no:   f14.joint_no || '',
      limit: 200,
    });
    items = d.items || [];
  } catch (e) {
    console.warn('Check 14 형제 행 조회 실패:', e.message);
    return;
  }
  const after = document.getElementById('c14-group-slot');
  if (!after || after.dataset.row !== String(rowNum)) return;
  after.innerHTML = _buildC14GroupSectionHtml(rowFlags, rowNum, backTo, items);
}

function _buildC14GroupSectionHtml(rowFlags, rowNum, backTo, candidates) {
  const f14 = (rowFlags || []).find(f => String(f.check_no) === '14');
  if (!f14) return '';
  const key  = _c14GroupKey(f14);
  const rows = (candidates || [])
    .filter(f => String(f.check_no) === '14' && _c14GroupKey(f) === key)
    .sort((a, b) => a.row - b.row);
  if (rows.length < 2) return '';

  const diffSet = new Set(_c14GroupDiff(rows).map(d => d.label));
  const cell = (label, val) =>
    `<td class="mono${diffSet.has(label) ? ' c14-cell-diff' : ''}">${_esc(val) || '—'}</td>`;
  const backArg = backTo ? `, '${backTo}'` : '';

  return `
    <div class="detail-sec">
      <div class="detail-sec-title">중복 등록 그룹 비교
        <span class="sec-hint">같은 도면·Joint No로 등록된 행들입니다 — 값이 어긋난 칸을 표시했습니다</span>
      </div>
      <div class="c14-gmeta">
        <span class="c14-gtitle">${_esc(f14.drawing_no) || '(도면번호 없음)'}</span>
        <span class="c14-gjoint">Joint ${_esc(f14.joint_no || '—')}</span>
        <span class="c14-gcount">${rows.length}행 중복</span>
        ${_c14DiffHtml(rows)}
      </div>
      <table class="cmp-tbl c14-gtbl">
        <thead><tr>
          <th>행</th><th>재질</th><th>두께</th><th>WPS</th>
          <th>Process</th><th>용접일</th><th>블록</th><th>용접사</th><th>검토</th>
        </tr></thead>
        <tbody>
          ${rows.map(r => `
            <tr class="row-clickable${r.row === rowNum ? ' c14-current' : ''}"
                role="button" tabindex="0" onclick="openFlagDetail(${r.row}${backArg})">
              <td class="mono">${r.row}${r.row === rowNum ? ' <span class="c14-here">현재</span>' : ''}</td>
              ${cell('재질', r.material1)}
              ${cell('두께', r.thickness1)}
              ${cell('WPS', r.wps_no)}
              <td class="mono">${_esc(r.wps_process || '—')}</td>
              <td class="mono">${_esc(r.weld_date || '—')}</td>
              <td>${_esc(r.block || '—')}</td>
              <td class="mono">${_esc(r.welder1_no || '—')}</td>
              <td>${_reviewBadgeHtml(r)}</td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
}

function _buildComparisonTableHtml(rowFlags, focusCheckNo) {
  if (!rowFlags.length) return '';
  return `
    <table class="cmp-tbl">
      <thead><tr>
        <th>Check</th><th>마킹 열</th><th>기준값 (정상)</th><th>실측값 (원인)</th>
      </tr></thead>
      <tbody>
        ${rowFlags.map((f, idx) => {
          const focus = (focusCheckNo != null &&
                         String(f.check_no) === String(focusCheckNo)) ? ' cmp-focus' : '';
          return `
          <tr class="cmp-row${focus}">
            <td><span class="pill ${COLOR_TO_CLS[f.color] || 'p-blue'}">C${f.check_no}</span> ${_esc(f.check_name)}${
              focus ? ` <span class="cmp-focus-tag">← 검토 대상</span>` : ''}</td>
            <td class="mono" style="color:var(--text-2)">${_esc(f.col_letter)}열</td>
            <td class="cmp-expected">${_esc(f.expected || f.msg)}</td>
            <td class="cmp-actual">${_esc(f.actual || '—')}</td>
          </tr>
          <tr class="fb-row${focus}"><td colspan="4">${_buildFeedbackBoxHtml(f, idx)}</td></tr>`;
        }).join('')}
      </tbody>
    </table>`;
}

/* 플래그 1건에 대한 검토(결함확정/오탐/확인중 + remark) 입력 박스.
   idx는 이 모달을 여는 동안 S._modalRowFlags 배열의 인덱스로, 저장 시 그 배열에서
   joint_no/wps_no/check_no 등 컨텍스트를 그대로 다시 읽어온다. */
function _buildFeedbackBoxHtml(f, idx) {
  const key = _fbKey(f);
  const rec = S.feedback[key];
  return `
    <div class="fb-box">
      <div class="fb-choices">
        ${FEEDBACK_RESULTS.map(v => `
          <label class="fb-opt fb-opt-${v === '결함확정' ? 'confirm' : v === '오탐' ? 'false' : 'review'}">
            <input type="radio" name="fbr-${idx}" value="${v}" ${rec && rec.result === v ? 'checked' : ''}> ${v}
          </label>`).join('')}
      </div>
      <textarea class="fb-remark" id="fb-remark-${idx}"
                placeholder="검토 의견을 남기세요 (왜 오탐인지, 추가 확인이 필요한 이유 등 — Claude/향후 분석이 이해할 수 있도록 구체적으로)">${_esc(rec ? rec.remark : '')}</textarea>
      <div class="fb-foot">
        <span class="fb-meta" id="fb-meta-${idx}">${_fbMetaText(rec)}</span>
        <button class="btn btn-sm" onclick="saveFlagFeedback(${idx})">저장</button>
      </div>
    </div>`;
}

function _fbMetaText(rec) {
  if (!rec) return '아직 검토되지 않았습니다';
  return `마지막 검토: ${_esc(rec.reviewer_id)} · ${_esc(rec.updated_at || '').replace('T', ' ').slice(0, 16)}`;
}

async function saveFlagFeedback(idx) {
  const f = (S._modalRowFlags || [])[idx];
  if (!f) return;
  const form = document.querySelector(`input[name="fbr-${idx}"]:checked`);
  if (!form) { alert('결함확정 / 오탐 / 확인중 중 하나를 선택하세요'); return; }
  const remark = (document.getElementById(`fb-remark-${idx}`) || {}).value || '';
  const metaEl = document.getElementById(`fb-meta-${idx}`);
  if (metaEl) metaEl.textContent = '저장 중…';
  try {
    const res = await _adminFetch('/api/feedback', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        drawing_no: f.drawing_no,
        joint_no: f.joint_no,
        wps_no: f.wps_no,
        check_no: f.check_no,
        result: form.value,
        remark,
        flag_snapshot: {
          check_no: f.check_no, check_name: f.check_name, color: f.color,
          col_letter: f.col_letter, msg: f.msg, expected: f.expected, actual: f.actual,
          material1: f.material1, material2: f.material2,
          thickness1: f.thickness1, thickness2: f.thickness2,
          weld_date: f.weld_date, ndt_date: f.ndt_date,
          department: f.department, team: f.team, block: f.block,
          drawing_no: f.drawing_no, row: f.row,
        },
        row_raw: S._modalRaw || [],
      }),
    });
    S.feedback[_fbKey(f)] = res.record;
    if (metaEl) metaEl.textContent = _fbMetaText(res.record);
    _refreshReviewBadges();
    // 사이드바 '미검토'는 서버가 세므로 저장 후 다시 물어야 한다.
    // 배지만 갱신하면 표는 바뀌는데 사이드바만 옛 숫자로 남는다.
    _refreshUnreviewedCount();
  } catch (e) {
    if (metaEl) metaEl.textContent = '저장 실패: ' + e.message;
  }
}

/* 표가 그려진 «뒤에» 스크롤을 되돌린다.
   브라우저는 스크롤 높이가 없으면 값을 0으로 클램프하므로, 한 프레임 뒤에
   다시 한 번 시도한다 — 차트/이미지가 늦게 자리를 잡는 경우가 있다. */
function _restoreModalScroll(top) {
  if (!top) return;
  const apply = () => {
    const body = document.getElementById('detail-modal-body');
    if (body) body.scrollTop = top;
  };
  apply();
  setTimeout(apply, 40);
}

/* 피드백 저장 직후, 지금 배경에 떠 있는 목록(상세 결과 탭 또는 Check 목록 팝업)의
   "검토" 배지를 최신 상태로 다시 그린다. */
function _refreshReviewBadges() {
  // 데이터는 그대로고 배지만 바뀌므로 다시 «그리기»만 한다(재조회 아님).
  if (document.getElementById('result-tbody') && S.result) renderResultPage();
  if (S.mck && document.getElementById('mck-tbody')) _mckRenderPage();
  if (S.rcp && document.getElementById('rcp-tbody')) _rcpRender();
  if (S.wd  && document.getElementById('wd-tbody'))  _wdRenderPage();
}

/* 모달 패널 너비 전환 — Check 목록 팝업(mck)만 표를 넓게 써야 해서 wide, 나머지(행 상세/
   미작업 목록)는 원래 폭(780px)을 쓴다. 여는 함수가 매번 명시적으로 켜고/끄므로 상태가 남지 않는다. */
function _setModalWide(wide) {
  const panel = document.querySelector('#detail-modal .detail-modal-panel');
  if (panel) panel.classList.toggle('wide', !!wide);
}

/* backTo: 'mck'(Check 목록 팝업) | 'rcp'(반복 결함 패턴 팝업) | falsy(돌아갈 목록 없음).
   목록 팝업에서 넘어온 경우 지금 보고 있던 스크롤 위치를 기억해뒀다가
   "‹ 목록으로 돌아가기"에서 페이지/스크롤을 그대로 복원한다. */
async function openFlagDetail(rowNum, backTo) {
  if (!S.result) return;
  let rowFlags;
  try {
    rowFlags = (await fetchFlags({ rows: rowNum, limit: 200 })).items || [];
  } catch (e) {
    console.warn('행 상세 조회 실패:', e.message);
    return;
  }
  if (!rowFlags.length) return;
  const backState = backTo === 'mck' ? S.mck : backTo === 'rcp' ? S.rcp
                  : backTo === 'wd' ? S.wd : null;
  if (backState) {
    const curBody = document.getElementById('detail-modal-body');
    if (curBody) backState.scrollTop = curBody.scrollTop;
  }
  const backFn = backTo === 'mck' ? '_mckReopen()' : backTo === 'rcp' ? '_rcpReopen()'
               : backTo === 'wd' ? '_wdReopen()' : '';
  // 어떤 Check를 보려고 들어왔는지 알면(반복 패턴 팝업, Check 필터가 걸린 목록 팝업)
  // 그 Check를 강조해 여러 Check 중에서 바로 찾을 수 있게 한다.
  const focusCheckNo = backState ? backState.checkNo : null;
  const head = rowFlags[0];
  S._modalRowFlags = rowFlags;   // saveFlagFeedback()이 인덱스로 이 배열을 다시 참조한다
  S._modalRaw      = [];         // _fillRawSlot()이 도착하면 채운다

  _setModalWide(false);
  document.getElementById('detail-modal-title').textContent =
    // textContent는 엔티티를 해석하지 않으므로 _esc()를 쓰면 &#39; 같은 것이 그대로 보인다.
    // 여기는 escape하지 않는 것이 맞다 (textContent 자체가 이미 안전하다).
    `행 ${rowNum} · Joint ${head.joint_no || '—'} · 결함 상세`;
  document.getElementById('detail-modal-sub').textContent =
    `${head.block || '블록 미기재'} · WPS ${head.wps_no || '미기재'} · Check ${rowFlags.length}건 감지`;

  document.getElementById('detail-modal-body').innerHTML = `
    ${backFn ? `<div style="margin-bottom:14px">
      <button class="btn btn-sm" onclick="${backFn}">‹ 목록으로 돌아가기</button>
    </div>` : ''}
    <div class="detail-sec">
      <div class="detail-sec-title">원본 데이터 (엑셀 원문)</div>
      ${_rawSlotHtml(rowNum)}
    </div>
    ${_c14SlotHtml(rowNum)}
    <div class="detail-sec">
      <div class="detail-sec-title">기준값 / 실측값 비교 및 검토</div>
      ${_buildComparisonTableHtml(rowFlags, focusCheckNo)}
    </div>
    <div id="ai-row"></div>`;

  aiShow('row', 'row', { row: String(rowNum) }, 'ai-row');
  document.getElementById('detail-modal').style.display = 'flex';
  _fillRawSlot(rowNum);
  _fillC14Slot(rowFlags, rowNum, backTo);
}

/* 미작업 목록은 응답에 실려 오지 않는다 — 실측 590KB(payload의 17%)인데 화면은
   모달을 열었을 때만, 그것도 한 페이지(50건)만 쓴다. 30만 행이면 ~18MB다.
   개수는 result.unworked_rows에 그대로 있으므로 제목 줄은 요청 없이 그린다. */
function openUnworkedList(preservePage) {
  if (!S.result) return;
  _setModalWide(false);
  if (!preservePage) S.unworkedPage = 1;
  document.getElementById('detail-modal-title').textContent = 'CHECK 0 · 미작업 수량 목록';
  document.getElementById('detail-modal-sub').textContent =
    `총 ${_n(S.result.unworked_rows || 0)}건 · 용접 미수행 — 결함이 아니므로 기준값/실측값 비교 대상이 아닙니다`;
  document.getElementById('detail-modal-body').innerHTML = `
    <div class="detail-sec">
      <div id="unworked-list-area">
        <div style="color:var(--text-3);font-size:12px">불러오는 중…</div>
      </div>
    </div>`;
  document.getElementById('detail-modal').style.display = 'flex';
  _renderUnworkedPage();
}

async function _renderUnworkedPage() {
  const page  = Math.max(1, S.unworkedPage || 1);
  const start = (page - 1) * PAGE_SIZE;

  let data;
  try {
    data = await apiFetch(`/api/result/unworked?offset=${start}&limit=${PAGE_SIZE}`);
  } catch (e) {
    const err = document.getElementById('unworked-list-area');
    if (err) err.innerHTML =
      `<div style="color:var(--text-3);font-size:12px">목록을 불러오지 못했습니다: ${_esc(e.message)}</div>`;
    return;
  }
  const slice = data.items || [];
  const total = data.total || 0;
  S._unworkedPageItems = slice;   // openUnworkedRawDetail()이 제목에 쓴다
  const pages = Math.ceil(total / PAGE_SIZE) || 1;
  S.unworkedPage = page;

  // 응답을 기다리는 동안 모달이 닫혔거나 다른 화면으로 갔을 수 있다
  const area = document.getElementById('unworked-list-area');
  if (!area) return;
  area.innerHTML = `
    <table class="cmp-tbl">
      <thead><tr><th>행</th><th>도면번호</th><th>Joint No</th><th>블록</th><th>부서</th></tr></thead>
      <tbody>
        ${slice.map(u => `
          <tr class="row-clickable" role="button" tabindex="0" onclick="openUnworkedRawDetail(${u.row})">
            <td class="mono" style="color:var(--text-3)">${u.row}</td>
            <td class="mono">${_esc(u.drawing_no || '—')}</td>
            <td class="mono" style="font-weight:600">${_esc(u.joint_no || '—')}</td>
            <td>${_esc(u.block || '—')}</td>
            <td>${_esc(u.department)}</td>
          </tr>`).join('')}
      </tbody>
    </table>
    <div class="page-row">
      <span>${_n(total ? start + 1 : 0)}–${_n(Math.min(start + PAGE_SIZE, total))} / ${_n(total)}행</span>
      <div class="page-btns">
        <button class="pbtn" onclick="_goUnworkedPage(${page - 1})" ${page<=1?'disabled':''}>‹</button>
        <span style="padding:3px 8px">${page} / ${pages}</span>
        <button class="pbtn" onclick="_goUnworkedPage(${page + 1})" ${page>=pages?'disabled':''}>›</button>
      </div>
    </div>`;
}

function _goUnworkedPage(p) {
  S.unworkedPage = p;
  _renderUnworkedPage();
}

function openUnworkedRawDetail(rowNum) {
  _setModalWide(false);
  const item = (S._unworkedPageItems || []).find(u => u.row === rowNum);
  document.getElementById('detail-modal-title').textContent =
    `행 ${rowNum} · Joint ${item ? item.joint_no || '—' : '—'} · 미작업 원본 데이터`;
  document.getElementById('detail-modal-sub').textContent =
    '용접 미수행 물량 — 결함 판정 대상이 아닙니다';
  document.getElementById('detail-modal-body').innerHTML = `
    <div class="detail-sec">
      <div class="detail-sec-title">원본 데이터 (엑셀 원문)</div>
      ${_rawSlotHtml(rowNum)}
    </div>
    <div style="margin-top:12px">
      <button class="btn btn-sm" onclick="openUnworkedList(true)">‹ 목록으로 돌아가기</button>
    </div>`;
  document.getElementById('detail-modal').style.display = 'flex';
  _fillRawSlot(rowNum);
}

function closeDetailModal() {
  document.getElementById('detail-modal').style.display = 'none';
  _setModalWide(false);
}

/* ── Check 목록 팝업 (mck = modal check-list) ────────────────────────────────────
   Check 카드를 클릭했을 때 상세 결과 "탭"으로 이동시키지 않고 팝업으로 띄운다 —
   팝업을 닫으면 원래 보고 있던 대시보드/부서별 대시보드 화면이 그대로 유지된다. */
/* 표가 채워진 «뒤에» 스크롤을 되돌리기 위해, 목록을 여는 함수들은 로딩
   promise를 돌려준다. 인라인 핸들러는 반환값을 무시하므로 화면 동작은 그대로다. */
async function openCheckListModal(checkNo, dept, team, page) {
  if (!S.result) return;
  S.mck = { checkNo: checkNo, dept: dept || '', team: team || '', page: page || 1, filtered: [] };

  _setModalWide(true);
  const meta = _ckMeta(checkNo);
  const scopeLabel = dept ? (team ? ` · ${dept} › ${team}` : ` · ${dept} (부서 전체)`) : '';
  const ckLabel = meta ? `Check ${checkNo} · ${meta.name}` : '전체 Check';
  document.getElementById('detail-modal-title').textContent = `${ckLabel}${scopeLabel}`;
  document.getElementById('detail-modal-sub').textContent = dept
    ? (team ? '해당 팀으로 필터링된 결과입니다 — 필터를 바꿔 다른 조건으로도 조회할 수 있습니다'
            : '해당 부서 전체(하위 팀 포함)로 필터링된 결과입니다 — 필터를 바꿔 다른 조건으로도 조회할 수 있습니다')
    : '전체 결과 중 이 Check 항목만 필터링되었습니다 — 필터를 바꿔 다른 조건으로도 조회할 수 있습니다';

  document.getElementById('detail-modal-body').innerHTML = `
    <div class="filter-bar">
      <select class="f-sel" id="mck-ck-filter" onchange="_mckFilter()"></select>
      <select class="f-sel" id="mck-dept-filter" onchange="_mckOnDeptChange()"></select>
      <select class="f-sel" id="mck-team-filter" onchange="_mckFilter()"></select>
      <input class="f-inp" type="text" id="mck-txt-filter"
             placeholder="Joint No / 용접사 번호 / WPS 검색…" oninput="_mckFilter()">
      <div class="chips" id="mck-chip-bar"></div>
      <div style="margin-left:auto">
        <button class="btn excel-dl-btn" onclick="downloadMckExcel(this)"
                title="지금 걸린 조건의 지적만 받습니다 (결과 Excel의 '결함 목록' 시트와 같은 열)">⬇ 이 조건 Excel</button>
      </div>
    </div>
    <div class="tbl-card">
      <div class="tbl-hd">
        <span class="tbl-hd-title">플래그 목록</span>
        <span class="tbl-hd-cnt" id="mck-result-count"></span>
      </div>
      <div class="tbl-wrap">
        <table class="dtbl">
          <thead><tr>
            <th>행</th><th>도면번호</th><th>Joint No</th><th>블록</th><th>재질</th><th>두께</th>
            <th>WPS No</th><th>WPS Process</th><th>용접일</th><th>NDE일자</th>
            <th>부서</th><th>팀</th>
            <th>Check</th><th>검토</th><th>마킹 열</th><th>기준값</th><th>실제값</th>
          </tr></thead>
          <tbody id="mck-tbody"></tbody>
        </table>
      </div>
      <div class="page-row">
        <span id="mck-page-info"></span>
        <div class="page-btns" id="mck-page-btns"></div>
      </div>
    </div>`;

  _mckBuildFilters();
  document.getElementById('mck-ck-filter').value = (checkNo == null) ? '' : String(checkNo);
  document.getElementById('mck-dept-filter').value = dept || '';
  // **반드시 기다린다.** 옵션이 채워지기 전에는 값을 넣어도 무시된다.
  await _mckPopulateTeamFilter(team || '');
  // resetPage=false: 필터 값 자체는 위에서 이미 원하는 상태(재오픈이면 기존 값)로
  // 맞춰뒀으므로, 여기서는 그 필터로 목록만 다시 계산하고 페이지 번호(S.mck.page,
  // 위에서 이미 세팅됨)는 건드리지 않는다. 사용자가 직접 필터를 바꾸는 change/input
  // 핸들러들은 인자 없이 _mckFilter()를 호출해 기본값(resetPage=true)으로 1페이지로 간다.
  //
  // **띄우는 것이 먼저다.** 예전에는 이 줄이 `return` 뒤에 있어서 영영 실행되지
  // 않았다 — 목록은 정상적으로 만들어지고 제목까지 채워지는데 팝업만 안 열려서,
  // 콘솔에는 아무 오류가 없고 «카드를 눌러도 아무 일이 없다»로만 보였다.
  document.getElementById('detail-modal').style.display = 'flex';

  // promise를 돌려준다 — `_mckReopen()`이 표가 «채워진 뒤에» 스크롤을 되돌려야
  // 하기 때문이다. 인라인 핸들러는 반환값을 무시하므로 화면 동작은 그대로다.
  return _mckFilter(false);
}

function _mckBuildFilters() {
  const r = S.result;
  const sel = document.getElementById('mck-ck-filter');
  const active = _activeMeta().filter(c => (r.stats[String(c.no)] || 0) > 0);
  sel.innerHTML = `<option value="">전체 Check</option>` +
    active.map(c => `<option value="${c.no}">Check ${c.no} · ${c.name}</option>`).join('');

  const deptSel = document.getElementById('mck-dept-filter');
  const deptNames = Object.keys(r.departments || {}).sort((a, b) => a.localeCompare(b, 'ko'));
  deptSel.innerHTML = `<option value="">전체 부서</option>` +
    deptNames.map(name => `<option value="${_esc(name)}">${_esc(name)}</option>`).join('');

  const chips = document.getElementById('mck-chip-bar');
  chips.innerHTML = [
    { v:'', l:'전체', c:'var(--accent)' },
    ...active.slice(0,3).map(c => ({ v: String(c.no), l: `C${c.no} ${c.name.split(' ')[0]}`, c: c.ckC }))
  ].map(x =>
    `<div class="chip ${x.v===''?'on':''}" style="--chip-c:${x.c}" role="button" tabindex="0"
          onclick="_mckChipClick(this,'${_jsq(x.v)}')">${x.l}</div>`
  ).join('');
}

function _mckChipClick(el, val) {
  document.querySelectorAll('#mck-chip-bar .chip').forEach(c => c.classList.remove('on'));
  el.classList.add('on');
  document.getElementById('mck-ck-filter').value = val;
  _mckFilter();
}

/* 팀 목록은 서버에 물어야 채워진다. 그래서 «고르고 싶은 팀»을 인자로 받아
   **옵션을 채운 뒤에** 값을 넣는다.

   예전에는 호출부가 이 함수를 await 없이 부르고 바로 다음 줄에서
   `mck-team-filter.value = team`을 대입했다. 그 시점의 select는 아직 비어 있어서
   대입이 조용히 무시되고, 곧이어 도는 `_mckFilter()`가 «전체 팀»으로 조회했다.

   화면에는 제목이 「… › 5C1-해양서일」이고 부제가 「해당 팀으로 필터링된
   결과입니다」인데 목록은 부서 전체 649건(참값 166건)이 나왔다. **오류가 나지
   않고 숫자만 틀린다** — 현업이 가장 못 믿는 종류다.

   상세 결과 탭의 `_populateTeamFilter()`는 처음부터 이 순서를 지키고 있었다. */
async function _mckPopulateTeamFilter(preferred) {
  const teamSel = document.getElementById('mck-team-filter');
  const deptVal = document.getElementById('mck-dept-filter').value;
  const want = preferred !== undefined ? preferred : teamSel.value;
  const teams = await _fetchTeams(deptVal);
  const sorted = [...teams].sort((a, b) => a.localeCompare(b, 'ko'));
  teamSel.innerHTML = `<option value="">전체 팀</option>` +
    sorted.map(t => `<option value="${_esc(t)}">${_esc(t)}</option>`).join('');
  if (want && sorted.includes(want)) teamSel.value = want;
}

function _mckOnDeptChange() {
  document.getElementById('mck-team-filter').value = '';
  _mckPopulateTeamFilter();
  _mckFilter();
}

function _mckFilter(resetPage) {
  if (resetPage === undefined) resetPage = true;
  const ck   = document.getElementById('mck-ck-filter').value;
  const dept = document.getElementById('mck-dept-filter').value;
  const team = document.getElementById('mck-team-filter').value;
  const txt  = document.getElementById('mck-txt-filter').value.toLowerCase();
  S.mck.checkNo = ck ? parseInt(ck, 10) : null;
  S.mck.dept = dept;
  S.mck.team = team;
  S.mck.q = txt;
  if (resetPage) S.mck.page = 1;
  return _mckLoadPage();
}

/* Check 14는 그룹 단위로 보여주므로 페이지가 아니라 «그 조건의 C14 전량»이
   필요하다. 서버 상한(2,000건)을 넘으면 잘린 것을 화면에 알린다 — 조용히
   일부만 보여주면 그룹이 통째로 빠진 것을 알 수 없다. */
const MCK_GROUP_MAX = 2000;
let _mckSeq = 0;

async function _mckLoadPage() {
  const seq = ++_mckSeq;
  const grouped = S.mck.checkNo === 14;
  const params = {
    check: S.mck.checkNo === null ? '' : S.mck.checkNo,
    dept:  S.mck.dept, team: S.mck.team, q: S.mck.q,
    offset: grouped ? 0 : (S.mck.page - 1) * PAGE_SIZE,
    limit:  grouped ? MCK_GROUP_MAX : PAGE_SIZE,
  };
  try {
    const d = await fetchFlags(params);
    if (seq !== _mckSeq) return;
    S.mck.pageData = d;
    S.mck.filtered = d.items;            // C14 그룹 렌더가 이 배열을 훑는다
    S.mck.truncated = grouped && d.total > d.items.length;
  } catch (e) {
    if (seq !== _mckSeq) return;
    console.warn('Check 목록 조회 실패:', e.message);
    S.mck.pageData = { total: 0, offset: 0, items: [] };
    S.mck.filtered = [];
    S.mck.truncated = false;
  }
  _mckRenderPage();
}

/* ── Check 14 중복 그룹 유틸 ─────────────────────────────────────────────────
   Check 14는 "같은 도면의 같은 Joint No가 서로 다른 값으로 등록됨"이라, 행 하나만
   봐서는 무엇이 어긋났는지 판단할 수 없다. 반드시 같은 조인트의 다른 등록행과
   나란히 놓고 비교해야 하므로 (도면번호, Joint No) 단위로 묶어서 보여준다. */
function _c14GroupKey(f) {
  return `${f.drawing_no || ''}|${f.joint_no || ''}`;
}

function _c14BuildGroups(flags) {
  const map = new Map();
  flags.forEach(f => {
    const k = _c14GroupKey(f);
    if (!map.has(k)) map.set(k, []);
    map.get(k).push(f);
  });
  // 행 번호 순으로 정렬해 원본 대장과 같은 순서로 대조할 수 있게 한다
  map.forEach(list => list.sort((a, b) => a.row - b.row));
  return [...map.values()];
}

/* 그룹 안에서 실제로 값이 갈리는 항목만 뽑아낸다 (재질/두께/WPS). */
function _c14GroupDiff(rows) {
  const uniq = fn => [...new Set(rows.map(fn).filter(v => v !== undefined && v !== null && v !== ''))];
  const out = [];
  const m = uniq(f => f.material1), t = uniq(f => f.thickness1), w = uniq(f => f.wps_no);
  if (m.length > 1) out.push({ label: '재질', values: m });
  if (t.length > 1) out.push({ label: '두께', values: t });
  if (w.length > 1) out.push({ label: 'WPS',  values: w });
  return out;
}

function _c14DiffHtml(rows) {
  const diffs = _c14GroupDiff(rows);
  if (!diffs.length) return '';
  return diffs.map(d =>
    `<span class="c14-diff"><b>${d.label}</b> ${d.values.map(v => `<code>${_esc(v)}</code>`).join(' vs ')}</span>`
  ).join('');
}

/* 그룹 헤더 행 — 도면번호/Joint No/구성 행수/어긋난 값. colspan은 mck 테이블 열 수(17). */
function _c14GroupHeaderHtml(rows, colspan) {
  const f = rows[0];
  return `<tr class="c14-ghead"><td colspan="${colspan}">
    <span class="c14-gtitle">${_esc(f.drawing_no) || '(도면번호 없음)'}</span>
    <span class="c14-gjoint">Joint ${_esc(f.joint_no || '—')}</span>
    <span class="c14-gcount">${rows.length}행 중복</span>
    ${_c14DiffHtml(rows)}
  </td></tr>`;
}

function _mckRenderPage() {
  // Check 14만 그룹 단위로 페이지네이션/렌더링한다
  if (S.mck.checkNo === 14) { _mckRenderGrouped(); return; }

  const d     = S.mck.pageData || { total: 0, items: [] };
  const total = d.total;
  const pages = Math.ceil(total / PAGE_SIZE) || 1;
  const page  = Math.min(Math.max(1, S.mck.page || 1), pages);
  S.mck.page  = page;
  const start = (page - 1) * PAGE_SIZE;
  const slice = d.items;

  const cntEl = document.getElementById('mck-result-count');
  if (cntEl) cntEl.textContent = `표시 중: ${_n(slice.length)}건 / 전체 ${_n(total)}건`;

  const tbody = document.getElementById('mck-tbody');
  if (!tbody) return;
  tbody.innerHTML = slice.map(f => `
    <tr class="row-clickable" role="button" tabindex="0" onclick="openFlagDetail(${f.row}, 'mck')">
      <td class="mono" style="color:var(--text-3)">${f.row}</td>
      <td class="mono" style="color:var(--text-2)">${_esc(f.drawing_no || '—')}</td>
      <td class="mono" style="font-weight:600">${_esc(f.joint_no || '—')}</td>
      <td>${_esc(f.block || '—')}</td>
      <td class="mono">${_esc(_fmtPair(f.material1, f.material2))}</td>
      <td class="mono">${_fmtPair(f.thickness1, f.thickness2)}</td>
      <td class="mono">${_esc(f.wps_no || '—')}</td>
      <td class="mono">${_esc(f.wps_process || '—')}</td>
      <td class="mono">${_esc(f.weld_date || '—')}</td>
      <td class="mono">${_esc(f.ndt_date || '—')}</td>
      <td>${_esc(f.department || '—')}</td>
      <td>${_esc(f.team || '—')}</td>
      <td><span class="pill ${COLOR_TO_CLS[f.color] || 'p-blue'}">C${f.check_no}</span></td>
      <td>${_reviewBadgeHtml(f)}</td>
      <td class="mono" style="color:var(--text-2)">${_esc(f.col_letter)}열</td>
      <td class="cmp-cell"><span class="cmp-expected" title="${_esc(f.expected || f.msg)}">${_esc(f.expected || f.msg)}</span></td>
      <td class="cmp-cell"><span class="cmp-actual" title="${_esc(f.actual || '')}">${_esc(f.actual || '—')}</span></td>
    </tr>`).join('');

  document.getElementById('mck-page-info').textContent =
    total ? `${_n(start + 1)}–${_n(Math.min(start + PAGE_SIZE, total))} / ${_n(total)}행` : '0행';

  const btns = document.getElementById('mck-page-btns');
  const pArr = buildPageArr(page, pages);
  btns.innerHTML = `<button class="pbtn" onclick="_mckGoPage(${page - 1})" ${page<=1?'disabled':''}>‹</button>` +
    pArr.map(p => p === '…'
      ? `<span style="padding:3px 6px;color:var(--text-3)">…</span>`
      : `<button class="pbtn ${p===page?'curr':''}" onclick="_mckGoPage(${p})">${p}</button>`
    ).join('') +
    `<button class="pbtn" onclick="_mckGoPage(${page + 1})" ${page>=pages?'disabled':''}>›</button>`;
}

/* Check 14 전용 렌더링 — 개별 행이 아니라 중복 그룹 단위로 페이지를 나누고,
   그룹 헤더(도면번호/Joint No/어긋난 값) 아래에 구성 행들을 붙여 바로 대조할 수 있게 한다.
   페이지당 행 수가 아니라 "그룹 수"를 기준으로 나눈다 — 그룹이 페이지 경계에서
   잘리면 비교 자체가 불가능해지기 때문. */
const C14_GROUPS_PER_PAGE = 20;
const _MCK_COLSPAN = 17;

function _mckRenderGrouped() {
  const groups = _c14BuildGroups(S.mck.filtered || []);
  const total  = groups.length;
  const pages  = Math.ceil(total / C14_GROUPS_PER_PAGE) || 1;
  const page   = Math.min(Math.max(1, S.mck.page || 1), pages);
  S.mck.page   = page;
  const start  = (page - 1) * C14_GROUPS_PER_PAGE;
  const slice  = groups.slice(start, start + C14_GROUPS_PER_PAGE);
  const rowsShown = slice.reduce((n, g) => n + g.length, 0);
  const rowsTotal = (S.mck.filtered || []).length;

  const cntEl = document.getElementById('mck-result-count');
  if (cntEl) cntEl.textContent =
    `표시 중: ${_n(slice.length)}개 그룹 (${_n(rowsShown)}행) / 전체 ${_n(total)}개 그룹 (${_n(rowsTotal)}행)`;

  const tbody = document.getElementById('mck-tbody');
  if (!tbody) return;
  tbody.innerHTML = slice.map(rows =>
    _c14GroupHeaderHtml(rows, _MCK_COLSPAN) +
    rows.map(f => `
      <tr class="row-clickable c14-grow" role="button" tabindex="0" onclick="openFlagDetail(${f.row}, 'mck')">
        <td class="mono" style="color:var(--text-3)">${f.row}</td>
        <td class="mono" style="color:var(--text-2)">${_esc(f.drawing_no || '—')}</td>
        <td class="mono" style="font-weight:600">${_esc(f.joint_no || '—')}</td>
        <td>${_esc(f.block || '—')}</td>
        <td class="mono">${_esc(_fmtPair(f.material1, f.material2))}</td>
        <td class="mono">${_fmtPair(f.thickness1, f.thickness2)}</td>
        <td class="mono">${_esc(f.wps_no || '—')}</td>
        <td class="mono">${_esc(f.wps_process || '—')}</td>
        <td class="mono">${_esc(f.weld_date || '—')}</td>
        <td class="mono">${_esc(f.ndt_date || '—')}</td>
        <td>${_esc(f.department || '—')}</td>
        <td>${_esc(f.team || '—')}</td>
        <td><span class="pill ${COLOR_TO_CLS[f.color] || 'p-blue'}">C${f.check_no}</span></td>
        <td>${_reviewBadgeHtml(f)}</td>
        <td class="mono" style="color:var(--text-2)">${_esc(f.col_letter)}열</td>
        <td class="cmp-cell"><span class="cmp-expected" title="${_esc(f.expected || f.msg)}">${_esc(f.expected || f.msg)}</span></td>
        <td class="cmp-cell"><span class="cmp-actual" title="${_esc(f.actual || '')}">${_esc(f.actual || '—')}</span></td>
      </tr>`).join('')
  ).join('') ||
    `<tr><td colspan="${_MCK_COLSPAN}" style="text-align:center;color:var(--text-3);padding:16px">해당 조건의 중복 그룹이 없습니다</td></tr>`;

  document.getElementById('mck-page-info').textContent =
    total ? `${_n(start + 1)}–${_n(Math.min(start + C14_GROUPS_PER_PAGE, total))} / ${_n(total)}개 그룹` : '0개 그룹';
  const btns = document.getElementById('mck-page-btns');
  if (btns) btns.innerHTML = _buildPagerHtml(page, pages, '_mckGoPage');
}

function _mckGoPage(p) {
  S.mck.page = p;
  // Check 14 그룹 보기는 이미 전량을 들고 있어 다시 받을 필요가 없다
  if (S.mck.checkNo === 14) { _mckRenderPage(); return; }
  return _mckLoadPage();
}

/* 목록 팝업에서 행을 클릭해 상세로 들어갔다가 "‹ 목록으로 돌아가기"를 누르면
   같은 필터/페이지 상태로 목록 팝업을 다시 연다. */
async function _mckReopen() {
  if (!S.mck) return;
  const savedScroll = S.mck.scrollTop || 0;
  // 표가 서버에서 오므로 **채워진 뒤에** 되돌려야 한다. 먼저 대입하면 그 시점엔
  // tbody가 비어 스크롤 높이가 없고 값이 0으로 클램프된다.
  await openCheckListModal(S.mck.checkNo, S.mck.dept, S.mck.team, S.mck.page);
  _restoreModalScroll(savedScroll);
}

/* ── 반복 결함 패턴 상세 팝업 (rcp = recurring pattern) ──────────────────────────
   "부서별 결함 > 반복 결함 패턴"에서 (용접사, Check) 조합 한 줄을 클릭했을 때 연다.
   일반 Check 목록과 달리 이 화면의 핵심 정보는 "언제 반복됐나"이므로 날짜 축(타임라인
   차트 + 날짜 칩)을 전면에 두고, 검토 현황 집계를 함께 보여준다 — 반복인데 대부분
   '오탐'이면 판정 룰 문제, 대부분 '결함확정'이면 실제 재발이라 판단이 갈리기 때문. */
async function openRecurringModal(welderNo, checkNo, page, dateFilter) {
  if (!S.result) return;
  const dept = (S.result.departments || {})[S.currentDept];
  if (!dept) return;
  const pat = (dept.recurring_patterns || [])
    .find(p => p.welder_no === welderNo && String(p.check_no) === String(checkNo));
  if (!pat) return;

  // pat.rows는 이미 (용접사, Check)로 걸러진 행 번호 목록이므로, 그 행들의 해당
  // Check 플래그만 뽑으면 이 패턴의 실제 발생 내역이 된다.
  // 행 목록이 그대로 서버 조건이 된다 — 화면에서 거를 필요가 없다.
  let all = [];
  try {
    const d = await fetchFlags({ check: checkNo, rows: pat.rows || [], limit: 2000 });
    all = d.items || [];
  } catch (e) {
    console.warn('반복 패턴 상세 조회 실패:', e.message);
    return;
  }

  S.rcp = {
    welderNo, checkNo,
    checkName:  pat.check_name,
    dept:       S.currentDept,
    all,
    dateFilter: dateFilter || '',
    page:       page || 1,
    scrollTop:  0,
  };

  _setModalWide(true);
  const wName = _welderShortName(welderNo);
  const wInfo = _welderInfo(welderNo);
  document.getElementById('detail-modal-title').textContent =
    `용접사 ${welderNo}${wName ? ` (${wName})` : ''} · C${checkNo} ${pat.check_name}`;
  document.getElementById('detail-modal-sub').textContent =
    // textContent 대입이므로 escape하지 않는다 (엔티티가 그대로 보인다).
    `${_n(pat.count)}건 · ${_n(pat.distinct_dates)}개 날짜 · ${pat.first_date} ~ ${pat.last_date}` +
    (wInfo && wInfo.registered && wInfo.processes.length
      ? ` · 보유자격 ${wInfo.processes.join(', ')}` : '') +
    ' — 서로 다른 날짜에 반복 발생한 동일 항목입니다';

  document.getElementById('detail-modal-body').innerHTML = `
    ${pat.summary ? `<div class="rcp-headline">${_esc(pat.summary)}</div>` : ''}
    <div id="rcp-review-summary" class="rcp-summary"></div>

    <div class="detail-sec">
      <div class="detail-sec-title">날짜별 발생 추이 <span class="sec-hint">막대 또는 아래 칩을 클릭하면 해당 날짜만 표시됩니다</span></div>
      <div class="rcp-chart-wrap">
        <canvas id="rcp-timeline"></canvas>
      </div>
      <div class="chips" id="rcp-date-chips" style="margin-top:10px"></div>
    </div>

    <div class="tbl-card" style="margin-top:14px">
      <div class="tbl-hd">
        <span class="tbl-hd-title">발생 내역</span>
        <span class="tbl-hd-cnt" id="rcp-result-count"></span>
      </div>
      <div class="tbl-wrap">
        <table class="dtbl">
          <thead><tr>
            <th>행</th><th>도면번호</th><th>Joint No</th><th>블록</th><th>재질</th><th>두께</th>
            <th>WPS No</th><th>용접일</th><th>검토</th><th>기준값</th><th>실제값</th>
          </tr></thead>
          <tbody id="rcp-tbody"></tbody>
        </table>
      </div>
      <div class="page-row">
        <span id="rcp-page-info"></span>
        <div class="page-btns" id="rcp-page-btns"></div>
      </div>
    </div>`;

  _rcpRender();
  document.getElementById('detail-modal').style.display = 'flex';
  // 캔버스는 부모 요소 크기를 읽어 그리므로 모달이 표시되어 레이아웃이 확정된
  // 다음 틱에 그린다 (대시보드 차트와 동일한 패턴).
  setTimeout(_rcpDrawTimeline, 30);
}

/* 날짜별 발생 건수 [{date, count}, ...] — 항상 전체(all) 기준으로 계산해
   날짜 필터를 걸어도 차트/칩의 분포는 그대로 유지된다. */
function _rcpDateCounts() {
  const map = {};
  (S.rcp.all || []).forEach(f => {
    const d = f.weld_date || '(용접일 미기재)';
    map[d] = (map[d] || 0) + 1;
  });
  return Object.keys(map).sort().map(d => ({ date: d, count: map[d] }));
}

function _rcpRender() {
  if (!S.rcp) return;
  const filtered = S.rcp.dateFilter
    ? S.rcp.all.filter(f => (f.weld_date || '(용접일 미기재)') === S.rcp.dateFilter)
    : S.rcp.all;

  // ── 검토 현황 집계 (전체 기준) ──
  const tally = { '결함확정': 0, '오탐': 0, '확인중': 0 };
  let unreviewed = 0;
  S.rcp.all.forEach(f => {
    const rec = S.feedback[_fbKey(f)];
    if (rec && tally[rec.result] !== undefined) tally[rec.result] += 1;
    else unreviewed += 1;
  });
  const sumEl = document.getElementById('rcp-review-summary');
  if (sumEl) {
    sumEl.innerHTML = `
      <span class="rcp-summary-lbl">검토 현황</span>
      <span class="fb-badge fb-badge-confirm">결함확정 ${_n(tally['결함확정'])}</span>
      <span class="fb-badge fb-badge-false">오탐 ${_n(tally['오탐'])}</span>
      <span class="fb-badge fb-badge-review">확인중 ${_n(tally['확인중'])}</span>
      <span class="fb-badge fb-badge-none">미검토 ${_n(unreviewed)}</span>`;
  }

  // ── 날짜 칩 ──
  const counts = _rcpDateCounts();
  const chips = document.getElementById('rcp-date-chips');
  if (chips) {
    chips.innerHTML = [
      { v: '', l: `전체 ${_n(S.rcp.all.length)}` },
      ...counts.map(c => ({ v: c.date, l: `${c.date.slice(5)} ${_n(c.count)}` })),
    ].map(x =>
      `<div class="chip ${x.v === S.rcp.dateFilter ? 'on' : ''}" style="--chip-c:var(--ck-brown)"
            role="button" tabindex="0" onclick="_rcpSetDate('${_jsq(x.v)}')">${x.l}</div>`
    ).join('');
  }

  // ── 행 목록 ──
  const { slice, page, pages, total, start } = _paginate(filtered, S.rcp.page, PAGE_SIZE);
  S.rcp.page = page;

  const cntEl = document.getElementById('rcp-result-count');
  if (cntEl) cntEl.textContent = `표시 중: ${_n(slice.length)}건 / ${
    S.rcp.dateFilter ? `${S.rcp.dateFilter} ${_n(total)}건` : `전체 ${_n(total)}건`}`;

  const tbody = document.getElementById('rcp-tbody');
  if (!tbody) return;
  tbody.innerHTML = slice.map(f => `
    <tr class="row-clickable" role="button" tabindex="0" onclick="openFlagDetail(${f.row}, 'rcp')">
      <td class="mono" style="color:var(--text-3)">${f.row}</td>
      <td class="mono" style="color:var(--text-2)">${_esc(f.drawing_no || '—')}</td>
      <td class="mono" style="font-weight:600">${_esc(f.joint_no || '—')}</td>
      <td>${_esc(f.block || '—')}</td>
      <td class="mono">${_esc(_fmtPair(f.material1, f.material2))}</td>
      <td class="mono">${_fmtPair(f.thickness1, f.thickness2)}</td>
      <td class="mono">${_esc(f.wps_no || '—')}</td>
      <td class="mono">${_esc(f.weld_date || '—')}</td>
      <td>${_reviewBadgeHtml(f)}</td>
      <td class="cmp-cell"><span class="cmp-expected" title="${_esc(f.expected || f.msg)}">${_esc(f.expected || f.msg)}</span></td>
      <td class="cmp-cell"><span class="cmp-actual" title="${_esc(f.actual || '')}">${_esc(f.actual || '—')}</span></td>
    </tr>`).join('') ||
    `<tr><td colspan="11" style="text-align:center;color:var(--text-3);padding:16px">해당 날짜의 발생 내역이 없습니다</td></tr>`;

  _setPageInfo('rcp-page-info', total ? start + 1 : 0, Math.min(start + PAGE_SIZE, total), total);
  const btns = document.getElementById('rcp-page-btns');
  if (btns) btns.innerHTML = _buildPagerHtml(page, pages, '_rcpGoPage');
}

function _rcpSetDate(date) {
  if (!S.rcp) return;
  // 같은 칩을 다시 누르면 필터 해제
  S.rcp.dateFilter = (S.rcp.dateFilter === date) ? '' : date;
  S.rcp.page = 1;
  _rcpRender();
  _rcpDrawTimeline();
}

function _rcpGoPage(p) {
  S.rcp.page = p;
  _rcpRender();
}

/* 날짜별 발생 건수 세로 막대 차트. 선택된 날짜는 강조하고 나머지는 흐리게 그린다.
   막대를 클릭하면 그 날짜로 필터링된다(캔버스 좌표 -> 날짜 역산). */
function _rcpDrawTimeline() {
  const cvs = document.getElementById('rcp-timeline');
  if (!cvs || !S.rcp) return;
  const counts = _rcpDateCounts();
  const dpr = window.devicePixelRatio || 1;
  const W = Math.max(cvs.parentElement.clientWidth - 2, 240);
  const H = 170;
  cvs.width = W * dpr; cvs.height = H * dpr;
  cvs.style.width = W + 'px'; cvs.style.height = H + 'px';
  const ctx = cvs.getContext('2d');
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, W, H);

  const st = getComputedStyle(document.documentElement);
  const textC   = st.getPropertyValue('--text').trim();
  const text2C  = st.getPropertyValue('--text-2').trim();
  const borderC = st.getPropertyValue('--border-sub').trim();
  const barC    = st.getPropertyValue('--ck-brown').trim();
  const font    = '-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif';

  if (!counts.length) {
    ctx.font = `13px ${font}`;
    ctx.fillStyle = text2C; ctx.textAlign = 'center';
    ctx.fillText('표시할 발생 내역이 없습니다', W / 2, H / 2);
    return;
  }

  const padL = 34, padR = 12, padT = 18, padB = 30;
  const plotW = W - padL - padR;
  const plotH = H - padT - padB;
  const maxV = Math.max(...counts.map(c => c.count), 1);

  ctx.strokeStyle = borderC; ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(padL, padT); ctx.lineTo(padL, padT + plotH); ctx.lineTo(padL + plotW, padT + plotH);
  ctx.stroke();
  ctx.font = `10px ${font}`;
  ctx.fillStyle = text2C; ctx.textAlign = 'right';
  ctx.fillText(String(maxV), padL - 6, padT + 4);
  ctx.fillText('0', padL - 6, padT + plotH + 4);

  const slotW = plotW / counts.length;
  const barW  = Math.max(Math.min(slotW * 0.6, 46), 4);
  const bars  = [];
  counts.forEach((c, i) => {
    const bh = (c.count / maxV) * plotH;
    const x  = padL + slotW * i + (slotW - barW) / 2;
    const y  = padT + plotH - bh;
    const active = !S.rcp.dateFilter || S.rcp.dateFilter === c.date;
    ctx.globalAlpha = active ? 1 : 0.28;
    ctx.fillStyle = barC;
    ctx.beginPath();
    ctx.roundRect(x, y, barW, Math.max(bh, 1), 2);
    ctx.fill();
    ctx.globalAlpha = 1;

    ctx.font = `600 10px ${font}`;
    ctx.fillStyle = active ? textC : text2C;
    ctx.textAlign = 'center';
    ctx.fillText(_n(c.count), x + barW / 2, y - 4);

    ctx.font = `10px ${font}`;
    ctx.fillStyle = text2C;
    ctx.fillText(c.date.slice(5), padL + slotW * i + slotW / 2, padT + plotH + 15);

    bars.push({ x0: padL + slotW * i, x1: padL + slotW * (i + 1), date: c.date });
  });

  cvs.style.cursor = 'pointer';
  cvs._bars = bars;
  if (!cvs._clickBound) {
    cvs.addEventListener('click', e => {
      const rect = cvs.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const hit = (cvs._bars || []).find(b => mx >= b.x0 && mx < b.x1);
      if (hit) _rcpSetDate(hit.date);
    });
    cvs._clickBound = true;
  }
}

/* 반복 패턴 팝업에서 행을 클릭해 상세로 들어갔다가 "‹ 목록으로 돌아가기"를 누르면
   같은 날짜 필터/페이지/스크롤 상태로 팝업을 다시 연다. */
async function _rcpReopen() {
  if (!S.rcp) return;
  const saved = S.rcp;
  await openRecurringModal(saved.welderNo, saved.checkNo, saved.page, saved.dateFilter);
  _restoreModalScroll(saved.scrollTop || 0);
}

/* ── Excel 다운로드 ─────────────────────────────────────────────────────────── */
/* 결과 Excel 내려받기.

   `fetch().blob()`을 쓰지 않는다 — 파일 크기만큼 브라우저 메모리를 잡고,
   서버가 이미 무거운 상태면 그게 마지막 한 방이 된다. `<a download>`는
   브라우저가 디스크로 바로 흘려보낸다.

   다만 `<a download>`는 **커스텀 헤더를 못 싣는다.** 사번을 URL에 담으면
   접근 로그·방문 기록·Referer에 남는데, 이 시스템은 사번이 유일한 인증
   수단이라 그게 곧 자격증명이다. 그래서 30초짜리 «표»를 대신 싣는다. */
async function downloadExcel() {
  try {
    const { ticket } = await apiFetch('/api/result/excel/ticket', { method: 'POST' });
    const a = document.createElement('a');
    a.href = '/api/result/excel?t=' + encodeURIComponent(ticket);
    a.download = 'QC_Result.xlsx';
    document.body.appendChild(a);
    a.click();
    a.remove();
  } catch (e) {
    alert('결과 Excel을 받지 못했습니다 - ' + (e.message || e));
  }
}

/* 지금 화면에 걸린 **조건의 지적만** Excel로 받는다.

   `downloadExcel()`은 «결과 Excel 파일 하나»를 내려준다 — 요약·결함 목록·원본
   마킹·미작업·검토 기록이 전부 든 실측 140MB짜리다. Check 카드를 열고
   「이 항목만 피벗하겠다」에 그걸 내려주면 받는 데 몇 분이 걸린다(현업 지적
   2026-08-24). 그래서 조건을 그대로 보내고 **결함 목록 한 장**만 받는다.

   열은 결과 Excel의 '결함 목록' 시트와 **같다** — 갈라지면 현업이 만들어 둔
   피벗이 파일마다 깨진다.

   `fetch().blob()`을 쓴다. 결과 Excel에서 그 방식을 버린 것은 파일이 수백 MB라
   브라우저 메모리를 잡아서였고, 한 장짜리 목록은 해당되지 않는다. */
async function downloadFlagsExcel(params, label, btn) {
  const t0 = btn ? btn.textContent : '';
  if (btn) { btn.disabled = true; btn.textContent = '만드는 중…'; }
  try {
    const r = await fetch('/api/flags/excel', {
      method: 'POST',
      headers: Object.assign({ 'Content-Type': 'application/json' }, _authHeaders()),
      body: JSON.stringify(Object.assign({ label: label || '전체' }, params)),
    });
    if (!r.ok) {
      let msg = 'HTTP ' + r.status;
      try { msg = (await r.json()).detail || msg; } catch (e) {}
      throw new Error(msg);
    }
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = '결함목록_' + (label || '전체') + '.xlsx';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  } catch (e) {
    alert('목록을 받지 못했습니다 — ' + (e.message || e));
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = t0; }
  }
}

/* Check 목록 모달 — 지금 걸린 필터 그대로. */
function downloadMckExcel(btn) {
  const m = S.mck || {};
  const meta = _ckMeta(m.checkNo);
  const bits = [];
  if (m.checkNo != null) bits.push('C' + m.checkNo + (meta ? '_' + meta.name : ''));
  if (m.dept) bits.push(m.dept);
  if (m.team) bits.push(m.team);
  if (m.q) bits.push(m.q);
  downloadFlagsExcel({ check: m.checkNo != null ? m.checkNo : null,
                       dept: m.dept || '', team: m.team || '', q: m.q || '' },
                     bits.join('_') || '전체', btn);
}

/* 상세 결과 탭 — 필터 바 옆 단추. */
function downloadResultsExcel(btn) {
  const p = _resultFilterParams();
  const no = p.check ? parseInt(p.check, 10) : null;
  const meta = _ckMeta(no);
  const bits = [];
  if (no != null) bits.push('C' + no + (meta ? '_' + meta.name : ''));
  if (p.dept) bits.push(p.dept);
  if (p.team) bits.push(p.team);
  if (p.q) bits.push(p.q);
  downloadFlagsExcel({ check: no, dept: p.dept || '', team: p.team || '', q: p.q || '' },
                     bits.join('_') || '전체', btn);
}

/* ── 유틸리티 ────────────────────────────────────────────────────────────────── */
function _n(v)   { return (v || 0).toLocaleString(); }
/* 결함률 통계의 분모 — 판정 대상 행수(미작업 제외).
   구버전 결과(judged_rows 없음)를 복원한 경우엔 active_rows로 폴백. */
function _judged(r) {
  if (!r) return 0;
  return r.judged_rows != null ? r.judged_rows : (r.active_rows || 0);
}
function _kb(b)  { return b > 1024*1024 ? (b/1024/1024).toFixed(1)+'MB' : Math.round(b/1024)+'KB'; }
function _pct(v, total) { return total ? (v/total*100).toFixed(1)+'%' : '0%'; }
/* HTML 이스케이프 — innerHTML에 들어가는 **텍스트/속성값**용. */
function _esc(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/`/g, '&#96;')
    .replace(/\\/g, '&#92;');
}

/* 인라인 핸들러 안의 JS 문자열 리터럴에 값을 넣을 때 쓴다:
       onclick="f('${_jsq(v)}')"

   **_esc()만으로는 이 자리를 막지 못한다.** HTML 파서가 속성값의 엔티티를 먼저 되돌린 뒤
   그 결과를 JS로 컴파일하기 때문에, `&#39;`는 `'`로 환원되어 문자열을 그대로 끊는다.
   실측(헤드리스 Edge):
     _esc만 : o'brien   -> 속성 `f('o'brien')`      -> onclick=null, 핸들러 미실행
     _esc만 : 탈출 시도 -> 주입된 함수가 **실제로 실행됨**
     _jsq   : 세 경우 모두 원본 문자열이 그대로 전달되고 실행 0건

   그래서 JS 문자열 이스케이프(`\` `'`)를 먼저 걸고, 그 위에 HTML 이스케이프를 덧씌운다.
   순서를 바꾸면 안 된다 — HTML 이스케이프가 먼저면 백슬래시가 엔티티로 바뀌어
   JS 이스케이프가 의미를 잃는다. */
function _jsq(s) {
  return _esc(String(s).replace(/\\/g, '\\\\').replace(/'/g, "\\'"));
}

/* 재질(M/N)·두께(J/K)처럼 이음 양쪽 값을 한 칸에 "값1/값2" 형식으로 표시.
   반대쪽(N/K)이 비어 있으면 값1만 보여준다 — 이음부 한쪽만 기록된 일반적인 경우. */
function _fmtPair(v1, v2) {
  const a = v1 || '—';
  return v2 ? `${a}/${v2}` : a;
}

/* ── 용접사 이름 / 자격 표시 공용 헬퍼 ─────────────────────────────────────────
   번호(3044, D304 …)만으로는 관리자가 대상자를 특정할 수 없어, 자격 DB의 이름과
   보유 자격을 함께 보여준다. 이름은 result.welder_info(번호 -> 정보) 맵에서 조회하며,
   자격 DB에 없는 협력사 인원은 이름이 비어 있으므로 번호만 표시된다. */
function _welderInfo(no) {
  return ((S.result && S.result.welder_info) || {})[no] || null;
}

/* 'HONG GIL DONG(홍길동)' 형식에서 한글 이름만 뽑아 표 안에서 짧게 보여준다.
   한글 표기가 없으면 영문 이름을 그대로 쓴다. */
function _welderShortName(no) {
  const info = _welderInfo(no);
  if (!info || !info.name) return '';
  const m = info.name.match(/\(([^)]+)\)\s*$/);
  return (m ? m[1] : info.name).trim();
}

/* 표의 "용접사" 칸: 번호(굵게) + 이름(작게). 퇴사자는 배지로 구분. */
function _welderCellHtml(no) {
  const name = _welderShortName(no);
  const info = _welderInfo(no);
  const retired = info && info.retired ? ` <span class="w-retired">퇴사</span>` : '';
  return `<div class="mono" style="font-weight:600">${_esc(no)}${retired}</div>` +
         (name ? `<div class="w-name">${_esc(name)}</div>` : '');
}

/* 보유 자격 한 줄 요약 — 프로세스/자세/선급/취득일. 자격 DB 미등록이면 그 사실을 표기. */
function _welderQualHtml(no) {
  const info = _welderInfo(no);
  if (!info || !info.registered) {
    return `<span class="w-unreg">자격 DB 미등록</span>`;
  }
  const bits = [];
  if (info.processes.length) bits.push(info.processes.join(', '));
  if (info.positions.length) bits.push(info.positions.join(' '));
  if (info.classes.length)   bits.push(info.classes.join(', '));
  const head = bits.join(' · ') || '자격 정보 없음';
  const date = info.first_cert_date
    ? `<div class="w-qual-sub">취득 ${info.first_cert_date}${
        info.last_cert_date && info.last_cert_date !== info.first_cert_date
          ? ` ~ ${info.last_cert_date}` : ''}${
        info.cert_count ? ` · 인증 ${info.cert_count}건` : ''}</div>`
    : '';
  return `<div class="w-qual">${_esc(head)}</div>${date}`;
}

/* ── 용접사 관리 ─────────────────────────────────────────────────────────────── */
/* 표본이 이 건수 미만이면 결함률을 순위 근거로 쓰지 않는다.
   6건 중 6건(100%)과 36건 중 36건(100%)이 같은 값으로 표시되어 교육 대상 선정이
   왜곡되기 때문 — 목록에서 빼지는 않고 배지로 경고만 한다. */
const WELDER_MIN_SAMPLE = 10;

async function renderWelderManagement(r) {
  const emptyEl   = document.getElementById('welders-empty');
  const contentEl = document.getElementById('welders-content');
  const info = (r && r.welder_info) || {};
  if (!r || !Object.keys(info).length) {
    if (emptyEl)   emptyEl.style.display   = '';
    if (contentEl) contentEl.style.display = 'none';
    return;
  }
  if (emptyEl)   emptyEl.style.display   = 'none';
  if (contentEl) contentEl.style.display = '';

  // '미검토' 열이 146명분을 동시에 쓰므로 표를 만들기 전에 한 번에 받아 둔다.
  await _loadWelderReviewCounts();

  // welder_info 하나를 단일 소스로 통합 목록을 만든다.
  const recur = _recurCountByWelder();
  S.welderRows = Object.keys(info).map(no => {
    const w = info[no];
    return {
      welder_no: no,
      name:      _welderShortName(no),
      total:     w.total || 0,
      defect:    w.defect || 0,
      rate:      w.rate || 0,
      missing:   w.missing_flags || 0,
      registered: !!w.registered,
      retired:   !!w.retired,
      recur:     recur[no] || 0,
      unreviewed: _welderUnreviewedCount(no),
      check_breakdown: w.check_breakdown || {},
      lowSample: (w.total || 0) < WELDER_MIN_SAMPLE,
      // 소속 — 건수 많은 순. 한 사람이 여러 팀에 걸치기도 한다.
      orgs:      w.orgs || [],
    };
  });

  _renderWelderKpi();
  _renderWelderChips();
  S.welderPage = 1;
  renderWelderTable();
  S.welderRecurPage = 1;
  renderWelderRecurTable();
}

/* 해당 용접사의 플래그 중 아직 검토 기록이 없는 "건수".
   Check 6은 제외한다 — 결함 열이 C6를 뺀 기준이라 범위를 맞춰야 하고, 플래그에는
   welder1_no만 실려 있어 C6를 포함하면 2~4번 용접사의 자격 문제가 1번 용접사에게
   잘못 붙는다(C6는 특정 용접사에게 귀속되는 플래그다).
   단위는 '행'이 아니라 '플래그 건'이다 — 검토 기록 자체가 플래그 단위이기 때문. */
function _welderFlags(welderNo) {
  return (S._welderFlagCache && S._welderFlagCache.get(welderNo)) || [];
}

/* 용접사 표를 그리기 전에 받아 둔다 — 표가 동기로 훑는다.
   Check 6은 서버에서 뺀다(결함 열이 C6를 뺀 기준이고, 플래그에 welder1_no만
   실려 있어 C6를 포함하면 2~4번 용접사의 자격 문제가 1번에게 잘못 붙는다). */
async function _loadWelderFlags(welderNo) {
  if (!S._welderFlagCache) S._welderFlagCache = new Map();
  if (S._welderFlagCache.has(welderNo)) return;
  try {
    // 이 화면은 Check별 분포·검토 집계·월별 차트를 «그 용접사의 전 플래그»로
    // 내므로 페이지로 자를 수 없다. 상한은 서버 config.MAX_FLAG_PAGE.
    const d = await fetchFlags({ welder: welderNo, limit: WELDER_FLAG_MAX });
    S._welderFlagCache.set(welderNo,
      (d.items || []).filter(f => String(f.check_no) !== '6'));
  } catch (e) {
    console.warn('용접사 플래그 조회 실패:', e.message);
    S._welderFlagCache.set(welderNo, []);
  }
}

/* 용접사 목록의 '미검토' 열은 146명분이 동시에 필요하다. 한 명씩 물으면
   146번을 왕복하므로 서버가 한 번에 낸다. */
async function _loadWelderReviewCounts() {
  if (S._welderReview) return;
  try {
    const d = await apiFetch('/api/flags/review-counts?by=welder');
    S._welderReview = d.by_welder || {};
  } catch (e) {
    console.warn('용접사 미검토 건수 조회 실패:', e.message);
    S._welderReview = {};
  }
}

function _welderUnreviewedCount(welderNo) {
  const r = (S._welderReview || {})[welderNo];
  return r ? r.unreviewed : 0;
}

function _renderWelderKpi() {
  const rows = S.welderRows;
  const withDefect = rows.filter(w => w.defect > 0).length;
  const unreg      = rows.filter(w => !w.registered).length;
  const recurCnt   = rows.filter(w => w.recur > 0).length;
  const unrev      = rows.reduce((s, w) => s + w.unreviewed, 0);
  document.getElementById('welder-kpi-grid').innerHTML = [
    { lbl: '용접사', val: _n(rows.length) + '명',
      sub: `자격 DB 등록 ${_n(rows.length - unreg)}명 · 미등록 ${_n(unreg)}명`, c: 'var(--text)' },
    { lbl: '결함 있는 용접사', val: _n(withDefect) + '명',
      sub: `전체의 ${rows.length ? (withDefect / rows.length * 100).toFixed(0) : 0}% · C6(자격) 제외 기준`,
      c: 'var(--ck-orange)', sev: _sevByRate(rows.length ? withDefect / rows.length * 100 : 0) },
    { lbl: '반복 패턴 보유', val: _n(recurCnt) + '명',
      sub: '교육 우선 대상 · 클릭 시 목록', c: 'var(--ck-brown)',
      sev: recurCnt >= 20 ? 'bad' : recurCnt ? 'warn' : '',
      click: recurCnt ? `setWelderFilter('recurring')` : '' },
    { lbl: '미검토 결함', val: _n(unrev) + '건',
      sub: '아직 검토 기록이 없는 플래그', c: 'var(--ck-amber)',
      sev: unrev > 0 ? 'warn' : '' },
  ].map(_kpiCardHtml).join('');
}

const WELDER_FILTERS = [
  { v: '',             l: '전체',        c: 'var(--accent)' },
  { v: 'recurring',    l: '반복 패턴',    c: 'var(--ck-brown)' },
  { v: 'unregistered', l: '자격 미등록',  c: 'var(--ck-orange)' },
  { v: 'lowsample',    l: '표본 부족',    c: 'var(--ck-gray)' },
  { v: 'clean',        l: '결함 없음',    c: 'var(--ck-green)' },
];

function _renderWelderChips() {
  const el = document.getElementById('welder-filter-chips');
  if (!el) return;
  el.innerHTML = WELDER_FILTERS.map(x => {
    const n = _welderFilterRows(x.v).length;
    return `<div class="chip ${x.v === S.welderFilter ? 'on' : ''}" style="--chip-c:${x.c}"
                 role="button" tabindex="0" onclick="setWelderFilter('${_jsq(x.v)}')">${x.l} ${_n(n)}</div>`;
  }).join('');
}

function setWelderFilter(v) {
  S.welderFilter = v;
  S.welderPage = 1;
  _renderWelderChips();
  renderWelderTable();
  setView('welders');
}

function _welderFilterRows(filter) {
  const rows = S.welderRows || [];
  switch (filter) {
    case 'recurring':    return rows.filter(w => w.recur > 0);
    case 'unregistered': return rows.filter(w => !w.registered);
    case 'lowsample':    return rows.filter(w => w.lowSample);
    case 'clean':        return rows.filter(w => w.defect === 0);
    default:             return rows;
  }
}

function renderWelderTable() {
  const txt  = (document.getElementById('welder-txt-filter')?.value || '').toLowerCase();
  const sort = document.getElementById('welder-sort')?.value || 'defect';
  let rows = _welderFilterRows(S.welderFilter);
  if (txt) {
    // 부서·팀으로도 찾을 수 있어야 한다 — 업체에 물어볼 때 조직 단위로 본다
    rows = rows.filter(w => w.welder_no.toLowerCase().includes(txt) ||
                            (w.name || '').toLowerCase().includes(txt) ||
                            _welderOrgText(w.orgs).toLowerCase().includes(txt));
  }
  // 기본 정렬은 '결함 건수' — 결함률로 정렬하면 표본이 작은 용접사(6건 중 6건)가
  // 최상단에 올라와 교육 대상 판단을 왜곡한다.
  const cmp = {
    defect: (a, b) => b.defect - a.defect || b.total - a.total,
    rate:   (a, b) => b.rate   - a.rate   || b.defect - a.defect,
    total:  (a, b) => b.total  - a.total,
    recur:  (a, b) => b.recur  - a.recur  || b.defect - a.defect,
  }[sort];
  rows = rows.slice().sort(cmp);

  const { slice, page, pages, total, start } = _paginate(rows, S.welderPage, PAGE_SIZE);
  S.welderPage = page;

  const cntEl  = document.getElementById('welder-list-cnt');
  const infoEl = document.getElementById('welder-total-info');
  const hintEl = document.getElementById('welder-list-hint');
  if (cntEl)  cntEl.textContent  = `· ${_n(total)}명`;
  if (infoEl) infoEl.textContent = `전체 ${_n((S.welderRows||[]).length)}명 중 ${_n(total)}명 표시`;
  if (hintEl) hintEl.textContent =
    `전부 C6(자격 미등록) 제외 기준 · 시공/결함은 행 수, 미검토는 플래그 건수 · ` +
    `시공 ${WELDER_MIN_SAMPLE}행 미만은 표본부족으로 표시`;

  document.getElementById('welder-list-tbody').innerHTML = slice.map(w => `
    <tr class="row-clickable" role="button" tabindex="0"
        title="클릭하면 이 용접사의 결함 상세가 열립니다"
        onclick="openWelderDetail('${_jsq(w.welder_no)}')">
      <td>${_welderCellHtml(w.welder_no)}</td>
      <td>${_welderOrgHtml(w.orgs)}</td>
      <td>${_welderQualHtml(w.welder_no)}</td>
      <td>${_n(w.total)}</td>
      <td style="font-weight:650;color:${w.defect ? 'var(--ck-orange)' : 'var(--text-3)'}">${_n(w.defect)}</td>
      <td>
        <span style="font-weight:650;color:${w.defect ? 'var(--ck-orange)' : 'var(--text-3)'}">${w.rate}%</span>
        ${w.lowSample ? ` <span class="w-lowsample" title="시공 ${w.total}건 — 표본이 적어 결함률을 순위 근거로 쓰기 어렵습니다">표본부족</span>` : ''}
      </td>
      <td>${w.recur ? `<span class="pill p-brown">${w.recur}</span>` : '<span style="color:var(--text-3)">—</span>'}</td>
      <td>${w.unreviewed ? `<span class="fb-badge fb-badge-none">${_n(w.unreviewed)}</span>` : '<span style="color:var(--text-3)">—</span>'}</td>
      <td class="mono" style="max-width:280px;overflow:hidden;text-overflow:ellipsis"
          title="${_esc(_formatCheckBreakdown(w.check_breakdown, ['6']))}">${_formatCheckBreakdownHtml(w.check_breakdown, ['6'])}</td>
    </tr>`).join('') ||
    `<tr><td colspan="9" style="text-align:center;color:var(--text-3);padding:20px">해당 조건의 용접사가 없습니다</td></tr>`;

  _setPageInfo('welder-list-page-info', total ? start + 1 : 0, Math.min(start + PAGE_SIZE, total), total);
  const btns = document.getElementById('welder-list-page-btns');
  if (btns) btns.innerHTML = _buildPagerHtml(page, pages, 'goWelderPage');
}

function goWelderPage(p) {
  S.welderPage = p;
  renderWelderTable();
}

/* 전사 반복 결함 패턴 목록 — 부서별 결함 탭의 것과 같은 데이터를 사람 관점으로
   전 부서 합쳐서 본다. 행을 클릭하면 기존 반복 패턴 상세 팝업을 그대로 연다. */
function renderWelderRecurTable() {
  const all = _allRecurringPatterns();
  const { slice, page, pages, total, start } = _paginate(all, S.welderRecurPage, PAGE_SIZE);
  S.welderRecurPage = page;

  const cntEl = document.getElementById('welder-recur-cnt');
  if (cntEl) cntEl.textContent = `· ${_n(total)}개 패턴 / ${_n(new Set(all.map(p => p.welder_no)).size)}명`;

  document.getElementById('welder-recur-tbody').innerHTML = slice.map(p => {
    const meta = CHECK_META.find(c => c.no === p.check_no);
    return `<tr class="row-clickable" role="button" tabindex="0"
                title="클릭하면 이 패턴의 발생 내역이 열립니다"
                onclick="openRecurringFromWelderTab('${_jsq(p.department)}','${_jsq(p.welder_no)}','${_jsq(p.check_no)}')">
      <td>${_welderCellHtml(p.welder_no)}</td>
      <td>${_esc(p.department)}</td>
      <td>${_patternTeamHtml(p)}</td>
      <td>
        <div><span class="pill ${meta ? meta.cls : 'p-blue'}">C${p.check_no}</span> ${_esc(p.check_name)}</div>
        ${p.summary ? `<div class="recur-summary">${_esc(p.summary)}</div>` : ''}
      </td>
      <td>${_n(p.count)}</td>
      <td>${_n(p.distinct_dates)}</td>
      <td class="mono">${_esc(p.first_date)} ~ ${_esc(p.last_date)}</td>
    </tr>`;
  }).join('') ||
    `<tr><td colspan="7" style="text-align:center;color:var(--text-3);padding:20px">반복 패턴이 없습니다</td></tr>`;

  _setPageInfo('welder-recur-page-info', total ? start + 1 : 0, Math.min(start + PAGE_SIZE, total), total);
  const btns = document.getElementById('welder-recur-page-btns');
  if (btns) btns.innerHTML = _buildPagerHtml(page, pages, 'goWelderRecurPage');
}

function goWelderRecurPage(p) {
  S.welderRecurPage = p;
  renderWelderRecurTable();
}

/* 용접사 탭에서 반복 패턴을 열 때는 그 패턴이 속한 부서를 먼저 선택해줘야
   기존 팝업(openRecurringModal)이 부서 스코프에서 패턴을 찾을 수 있다. */
function openRecurringFromWelderTab(dept, welderNo, checkNo) {
  S.currentDept = dept;
  openRecurringModal(welderNo, checkNo);
}

/* ── 용접사 상세 팝업 (wd = welder detail) ──────────────────────────────────────
   목록에서 용접사를 클릭하면 그 사람의 자격·결함 분포·반복 패턴·실제 결함 행을
   한 화면에서 본다. 모든 플래그에 welder1_no가 들어있어(Check 14 작업 때 추가)
   서버 왕복 없이 클라이언트에서 바로 구성할 수 있다. */
async function openWelderDetail(welderNo, page) {
  if (!S.result) return;
  await _loadWelderFlags(welderNo);       // 이 용접사의 플래그를 받아 둔다
  const flags = _welderFlags(welderNo);   // C6 제외 — 목록의 결함/미검토 열과 같은 기준
  const info  = _welderInfo(welderNo);
  const row   = (S.welderRows || []).find(w => w.welder_no === welderNo);
  const pats  = _allRecurringPatterns().filter(p => p.welder_no === welderNo);

  S.wd = { welderNo, flags, page: page || 1, scrollTop: 0 };

  // Check별 분포 (많은 순)
  const byCheck = {};
  flags.forEach(f => { byCheck[f.check_no] = (byCheck[f.check_no] || 0) + 1; });
  const checkRows = Object.keys(byCheck).map(Number).sort((a, b) => byCheck[b] - byCheck[a]);
  const maxCnt = Math.max(...Object.values(byCheck), 1);

  // 검토 현황
  const tally = { '결함확정': 0, '오탐': 0, '확인중': 0 };
  let unrev = 0;
  flags.forEach(f => {
    const rec = S.feedback[_fbKey(f)];
    if (rec && tally[rec.result] !== undefined) tally[rec.result] += 1; else unrev += 1;
  });

  // 월별 결함 건수 누적 막대. 상위 4개 Check만 쌓는다(색이 많아지면 구분이 어렵다).
  // 월이 1개뿐이면 추이라 부를 게 없으므로 차트를 아예 그리지 않는다.
  const monthly = _welderMonthly(welderNo);
  const trendChecks = checkRows.slice(0, 4);
  const showTrend = monthly.length >= 2 && trendChecks.length > 0;

  const name = _welderShortName(welderNo);
  _setModalWide(true);
  document.getElementById('detail-modal-title').textContent =
    `용접사 ${welderNo}${name ? ` (${name})` : ''}`;
  document.getElementById('detail-modal-sub').textContent =
    row ? `시공 ${_n(row.total)}건 · 결함 ${_n(row.defect)}건 (${row.rate}%)` +
          (row.lowSample ? ` — 표본 부족(${WELDER_MIN_SAMPLE}건 미만)이라 결함률만으로 판단하지 마세요` : '')
        : `플래그 ${_n(flags.length)}건`;

  document.getElementById('detail-modal-body').innerHTML = `
    <div id="ai-welder"></div>
    <div class="detail-sec">
      <div class="detail-sec-title">자격 정보</div>
      <div class="raw-grid">
        ${_wdCell('이름', info && info.name ? info.name : '(자격 DB 미등록)')}
        ${_wdCell('등록 상태', info && info.registered
            ? (info.retired ? '자격 DB 등록 · 퇴사' : '자격 DB 등록')
            : '자격 DB 미등록 (협력사 등)')}
        ${_wdCell('보유 프로세스', info && info.processes.length ? info.processes.join(', ') : '—')}
        ${_wdCell('자세', info && info.positions.length ? info.positions.join(' ') : '—')}
        ${_wdCell('선급', info && info.classes.length ? info.classes.join(', ') : '—')}
        ${_wdCell('자격 취득', info && info.first_cert_date
            ? `${info.first_cert_date}${info.last_cert_date && info.last_cert_date !== info.first_cert_date ? ` ~ ${info.last_cert_date}` : ''} (인증 ${info.cert_count}건)`
            : '—')}
      </div>
    </div>

    <div class="detail-sec">
      <div class="detail-sec-title">검토 현황</div>
      <div class="rcp-summary">
        <span class="fb-badge fb-badge-confirm">결함확정 ${_n(tally['결함확정'])}</span>
        <span class="fb-badge fb-badge-false">오탐 ${_n(tally['오탐'])}</span>
        <span class="fb-badge fb-badge-review">확인중 ${_n(tally['확인중'])}</span>
        <span class="fb-badge fb-badge-none">미검토 ${_n(unrev)}</span>
      </div>
    </div>

    <div class="detail-sec">
      <div class="detail-sec-title">Check별 결함 분포</div>
      ${checkRows.length ? `<div class="wd-bars">${checkRows.map(no => {
        const meta = CHECK_META.find(c => c.no === no);
        const cnt = byCheck[no];
        return `<div class="wd-bar-row">
          <span class="wd-bar-lbl"><span class="pill ${meta ? meta.cls : 'p-blue'}">C${no}</span> ${meta ? _esc(meta.name) : ''}</span>
          <span class="wd-bar-track"><span class="wd-bar-fill" style="width:${(cnt / maxCnt * 100).toFixed(1)}%;background:${meta ? meta.ckC : 'var(--accent)'}"></span></span>
          <span class="wd-bar-val">${_n(cnt)}</span>
        </div>`;
      }).join('')}</div>` : '<div style="color:var(--text-3);font-size:12px">결함 없음</div>'}
    </div>

    ${pats.length ? `<div class="detail-sec">
      <div class="detail-sec-title">반복 결함 패턴 <span class="sec-hint">서로 다른 날짜에 반복 발생 — 교육 대상 판단 근거</span></div>
      <table class="cmp-tbl">
        <thead><tr><th>Check</th><th>부서</th><th>팀</th><th>건수</th><th>일수</th><th>기간</th><th>월별</th><th>추이</th></tr></thead>
        <tbody>
          ${pats.map(p => {
            const meta = CHECK_META.find(c => c.no === p.check_no);
            const v = _monthlyVerdict(monthly, p.check_no);
            return `<tr class="row-clickable" role="button" tabindex="0"
                        onclick="openRecurringFromWelderTab('${_jsq(p.department)}','${_jsq(p.welder_no)}','${_jsq(p.check_no)}')">
              <td><span class="pill ${meta ? meta.cls : 'p-blue'}">C${p.check_no}</span> ${_esc(p.check_name)}
                ${p.summary ? `<div class="recur-summary">${_esc(p.summary)}</div>` : ''}</td>
              <td>${_esc(p.department)}</td>
              <td>${_patternTeamHtml(p)}</td>
              <td class="mono">${_n(p.count)}</td>
              <td class="mono">${_n(p.distinct_dates)}</td>
              <td class="mono">${_esc(p.first_date)} ~ ${_esc(p.last_date)}</td>
              <td>${_monthlySparkHtml(welderNo, p.check_no)}</td>
              <td>${v ? `<span class="trend-verdict ${v.cls}" title="${_esc(v.tip)}">${v.label}</span>`
                      : '<span style="color:var(--text-3);font-size:11px">단월</span>'}</td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>` : ''}

    ${showTrend ? `<div class="detail-sec">
      <div class="detail-sec-title">월별 결함 건수
        <span class="sec-hint">막대 높이 = 그달 총 결함 건수, 색 = Check별 구성 · 막대에 올리면 비율까지 표시됩니다</span>
      </div>
      <div class="chips" style="margin-bottom:6px">
        ${trendChecks.map(no => {
          const meta = CHECK_META.find(c => c.no === no);
          return `<div class="chip on" style="--chip-c:${meta ? meta.ckC : 'var(--accent)'}">C${no} ${meta ? _esc(meta.name) : ''}</div>`;
        }).join('')}
      </div>
      <div class="rcp-chart-wrap" style="position:relative">
        <canvas id="wd-trend"></canvas>
        <div id="wd-trend-tooltip" class="chart-tooltip" style="display:none"></div>
      </div>
    </div>` : (monthly.length === 1 ? `<div class="detail-sec">
      <div class="detail-sec-title">월별 결함 건수</div>
      <div style="color:var(--text-3);font-size:12px">
        작업 기간이 ${monthly[0].month} 한 달뿐이라 추이를 볼 수 없습니다
        (결함 ${_n(monthly[0].defects)}건 / 시공 ${_n(monthly[0].total)}행).
      </div>
    </div>` : '')}

    <div class="tbl-card" style="margin-top:4px">
      <div class="tbl-hd">
        <span class="tbl-hd-title">결함 목록</span>
        <span class="tbl-hd-cnt" id="wd-count"></span>
      </div>
      <div class="tbl-wrap">
        <table class="dtbl">
          <thead><tr>
            <th>행</th><th>도면번호</th><th>Joint No</th><th>블록</th><th>재질</th><th>두께</th>
            <th>WPS No</th><th>용접일</th><th>Check</th><th>검토</th><th>기준값</th><th>실제값</th>
          </tr></thead>
          <tbody id="wd-tbody"></tbody>
        </table>
      </div>
      <div class="page-row">
        <span id="wd-page-info"></span>
        <div class="page-btns" id="wd-page-btns"></div>
      </div>
    </div>`;

  _wdRenderPage();
  aiShow('welder', 'welder', { welder: welderNo }, 'ai-welder');
  document.getElementById('detail-modal').style.display = 'flex';
  // 캔버스는 부모 크기를 읽어 그리므로 모달이 표시되어 레이아웃이 확정된 뒤에 그린다.
  if (showTrend) setTimeout(() => _drawWelderMonthly('wd-trend', monthly, trendChecks), 30);
}

/* ── 용접사 Check별 결함률 추이 ────────────────────────────────────────────────
   '건수'가 아니라 '결함률'을 그린다. 플래그에는 그날 총 시공량이 없어 건수만 보면
   많이 일한 날과 잘못한 날이 구분되지 않기 때문 — 그래서 백엔드에서 날짜별 시공량
   (date_stats[].total)을 함께 받아 분모로 쓴다.
   x축은 실제 날짜다. 데이터가 드문드문(예: 2025-07 다음이 2026-05) 있어서 등간격으로
   그리면 10개월 공백이 하루 간격처럼 보여 추세를 오독하게 된다. */
/* 일 단위 date_stats를 월 단위로 접는다.
   실데이터에서 용접사당 작업 '월' 수가 평균 1.4개(최대 5개)이고 103명은 1개월뿐이라,
   일 단위로 그리면 점이 드문드문 찍히고 그 사이 공백이 커서 선이 의미를 갖지 못했다.
   월 단위로 접으면 막대 1~5개로 정리되어 한눈에 읽힌다. */
function _welderMonthly(welderNo) {
  const info = _welderInfo(welderNo);
  const ds = (info && info.date_stats) || [];
  const map = new Map();
  ds.forEach(e => {
    const m = (e.date || '').slice(0, 7);
    if (!m) return;
    if (!map.has(m)) map.set(m, { month: m, total: 0, defects: 0, checks: {} });
    const o = map.get(m);
    o.total += e.total || 0;
    Object.keys(e.checks || {}).forEach(k => {
      o.checks[k] = (o.checks[k] || 0) + e.checks[k];
      o.defects += e.checks[k];
    });
  });
  return [...map.values()].sort((a, b) => a.month.localeCompare(b.month));
}

/* 개선/악화 판정은 '건수'가 아니라 '결함률'로 한다.
   그래프는 요청대로 건수를 보여주지만, 건수는 그달 시공량에 좌우되므로(많이 일한 달이
   곧 악화로 보인다) 방향 판정까지 건수로 하면 오판을 부른다. 그래서 배지는 비율 기준이며
   툴팁에 근거 수치를 함께 넣는다. 월이 2개 미만이면 판단하지 않는다. */
function _monthlyVerdict(months, checkNo) {
  const pts = months.filter(m => m.total > 0)
    .map(m => ({ month: m.month, rate: (m.checks[String(checkNo)] || 0) / m.total * 100 }));
  if (pts.length < 2) return null;
  const mid = Math.ceil(pts.length / 2);
  const avg = a => a.reduce((s, p) => s + p.rate, 0) / (a.length || 1);
  const a = avg(pts.slice(0, mid)), b = avg(pts.slice(mid));
  const diff = b - a;
  const tip = `초기 ${a.toFixed(0)}% → 최근 ${b.toFixed(0)}% (결함률 기준, 월 ${pts.length}개)`;
  if (Math.abs(diff) < 5) return { label: '유지', cls: 'tv-flat', tip };
  return diff < 0
    ? { label: `개선 ${Math.abs(diff).toFixed(0)}%p`, cls: 'tv-good', tip }
    : { label: `악화 ${diff.toFixed(0)}%p`,           cls: 'tv-bad',  tip };
}

/* 패턴 표 안에 넣는 초소형 월별 막대. 큰 차트를 보지 않아도 행끼리 추세를 비교할 수
   있게 하는 용도라 축·눈금 없이 형태만 보여준다(정확한 값은 툴팁). */
function _monthlySparkHtml(welderNo, checkNo) {
  const months = _welderMonthly(welderNo);
  if (months.length < 2) return '<span style="color:var(--text-3);font-size:11px">—</span>';
  const vals = months.map(m => m.checks[String(checkNo)] || 0);
  const max = Math.max(...vals, 1);
  return `<span class="spark">${months.map((m, i) =>
    `<span class="spark-bar" style="height:${Math.max(8, vals[i] / max * 100)}%"
           title="${m.month} · ${vals[i]}건 / 시공 ${m.total}행"></span>`).join('')}</span>`;
}

/* 월별 결함 건수 누적 막대.
   꺾은선 대신 막대를 쓰는 이유: 월이 1~5개뿐이라 선을 그릴 점이 없고, Check가 여러 개면
   선이 서로 교차해 오히려 읽기 어려웠다. 누적 막대는 막대 높이가 그달 총 결함 건수,
   색 구간이 Check별 구성이라 총량과 원인을 동시에 보여준다.
   막대 아래에는 그달 시공량을 함께 적는다 — 건수만 보면 "많이 일한 달"과 "잘못한 달"이
   구분되지 않기 때문에 최소한의 맥락은 남긴다. */
function _drawWelderMonthly(canvasId, months, checkNos) {
  const cvs = document.getElementById(canvasId);
  if (!cvs || !months.length) return;
  const dpr = window.devicePixelRatio || 1;
  const W = Math.max(cvs.parentElement.clientWidth - 2, 320);
  const H = 220;
  cvs.width = W * dpr; cvs.height = H * dpr;
  cvs.style.width = W + 'px'; cvs.style.height = H + 'px';
  const ctx = cvs.getContext('2d');
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, W, H);

  const st = getComputedStyle(document.documentElement);
  const textC   = st.getPropertyValue('--text').trim();
  const text3C  = st.getPropertyValue('--text-3').trim();
  const borderC = st.getPropertyValue('--border-sub').trim();
  const font = '-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif';

  const padL = 38, padR = 14, padT = 20, padB = 42;
  const plotW = W - padL - padR, plotH = H - padT - padB;

  const totals = months.map(m => checkNos.reduce((s, n) => s + (m.checks[String(n)] || 0), 0));
  const maxV = Math.max(...totals, 1);

  // y축 + 0/중간/최대 그리드
  ctx.strokeStyle = borderC; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(padL, padT); ctx.lineTo(padL, padT + plotH); ctx.lineTo(padL + plotW, padT + plotH); ctx.stroke();
  ctx.font = `10px ${font}`; ctx.fillStyle = text3C; ctx.textAlign = 'right';
  [0, Math.round(maxV / 2), maxV].forEach(v => {
    const y = padT + plotH - (v / maxV) * plotH;
    if (v > 0) {
      ctx.strokeStyle = borderC; ctx.globalAlpha = .5;
      ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(padL + plotW, y); ctx.stroke();
      ctx.globalAlpha = 1;
    }
    ctx.fillText(_n(v), padL - 6, y + 3);
  });

  const slotW = plotW / months.length;
  const barW = Math.min(slotW * 0.62, 68);
  const bars = [];
  months.forEach((m, i) => {
    const cx = padL + slotW * i + slotW / 2;
    const x = cx - barW / 2;
    let yTop = padT + plotH;
    checkNos.forEach(no => {
      const cnt = m.checks[String(no)] || 0;
      if (!cnt) return;
      const h = (cnt / maxV) * plotH;
      const meta = CHECK_META.find(c => c.no === no);
      const color = st.getPropertyValue((meta ? meta.ckC : 'var(--accent)').slice(4, -1)).trim() || textC;
      yTop -= h;
      ctx.fillStyle = color;
      ctx.fillRect(x, yTop, barW, h);
      bars.push({ x, y: yTop, w: barW, h, month: m, check_no: no, cnt, name: meta ? meta.name : '' });
    });
    // 막대 위 총계
    if (totals[i]) {
      ctx.font = `600 11px ${font}`; ctx.fillStyle = textC; ctx.textAlign = 'center';
      ctx.fillText(_n(totals[i]), cx, yTop - 5);
    }
    // x축: 월 + 그달 시공량
    ctx.font = `10px ${font}`; ctx.fillStyle = text3C; ctx.textAlign = 'center';
    ctx.fillText(m.month.slice(2), cx, padT + plotH + 15);
    ctx.fillText(`시공 ${_n(m.total)}`, cx, padT + plotH + 29);
  });

  cvs._mbBars = bars;
  cvs.style.cursor = 'default';
  if (!cvs._mbBound) {
    cvs.addEventListener('mousemove', e => _onWelderMonthlyHover(e, cvs));
    cvs.addEventListener('mouseleave', () => {
      const tip = document.getElementById('wd-trend-tooltip');
      if (tip) tip.style.display = 'none';
    });
    cvs._mbBound = true;
  }
}

function _onWelderMonthlyHover(e, cvs) {
  const bars = cvs._mbBars || [];
  const tip = document.getElementById('wd-trend-tooltip');
  if (!tip) return;
  const rect = cvs.getBoundingClientRect();
  const mx = e.clientX - rect.left, my = e.clientY - rect.top;
  const hit = bars.find(b => mx >= b.x && mx <= b.x + b.w && my >= b.y && my <= b.y + b.h);
  if (!hit) { tip.style.display = 'none'; return; }
  const rate = hit.month.total ? (hit.cnt / hit.month.total * 100).toFixed(0) : '0';
  tip.style.display = 'block';
  tip.innerHTML = `${hit.month.month} · C${hit.check_no} ${_esc(hit.name)}<br>` +
                  `<b>${_n(hit.cnt)}건</b> · 시공 ${_n(hit.month.total)}행 (${rate}%)`;
  tip.style.left = (rect.left + hit.x + hit.w + 10) + 'px';
  tip.style.top  = (rect.top + hit.y - 10) + 'px';
}

function _wdCell(label, value) {
  return `<div class="raw-cell">
    <div class="raw-cell-lbl">${_esc(label)}</div>
    <div class="raw-cell-val ${!value || value === '—' ? 'empty' : ''}">${_esc(value)}</div>
  </div>`;
}

function _wdRenderPage() {
  if (!S.wd) return;
  const { slice, page, pages, total, start } = _paginate(S.wd.flags, S.wd.page, PAGE_SIZE);
  S.wd.page = page;

  const cntEl = document.getElementById('wd-count');
  if (cntEl) cntEl.textContent = `표시 중: ${_n(slice.length)}건 / 전체 ${_n(total)}건`;

  const tbody = document.getElementById('wd-tbody');
  if (!tbody) return;
  tbody.innerHTML = slice.map(f => `
    <tr class="row-clickable" role="button" tabindex="0" onclick="openFlagDetail(${f.row}, 'wd')">
      <td class="mono" style="color:var(--text-3)">${f.row}</td>
      <td class="mono" style="color:var(--text-2)">${_esc(f.drawing_no || '—')}</td>
      <td class="mono" style="font-weight:600">${_esc(f.joint_no || '—')}</td>
      <td>${_esc(f.block || '—')}</td>
      <td class="mono">${_esc(_fmtPair(f.material1, f.material2))}</td>
      <td class="mono">${_fmtPair(f.thickness1, f.thickness2)}</td>
      <td class="mono">${_esc(f.wps_no || '—')}</td>
      <td class="mono">${_esc(f.weld_date || '—')}</td>
      <td><span class="pill ${COLOR_TO_CLS[f.color] || 'p-blue'}">C${f.check_no}</span></td>
      <td>${_reviewBadgeHtml(f)}</td>
      <td class="cmp-cell"><span class="cmp-expected" title="${_esc(f.expected || f.msg)}">${_esc(f.expected || f.msg)}</span></td>
      <td class="cmp-cell"><span class="cmp-actual" title="${_esc(f.actual || '')}">${_esc(f.actual || '—')}</span></td>
    </tr>`).join('') ||
    `<tr><td colspan="12" style="text-align:center;color:var(--text-3);padding:16px">결함이 없습니다</td></tr>`;

  _setPageInfo('wd-page-info', total ? start + 1 : 0, Math.min(start + PAGE_SIZE, total), total);
  const btns = document.getElementById('wd-page-btns');
  if (btns) btns.innerHTML = _buildPagerHtml(page, pages, '_wdGoPage');
}

function _wdGoPage(p) {
  S.wd.page = p;
  _wdRenderPage();
}

/* 용접사 상세에서 행을 클릭해 결함 상세로 들어갔다가 돌아올 때 페이지/스크롤 복원 */
async function _wdReopen() {
  if (!S.wd) return;
  const saved = S.wd;
  await openWelderDetail(saved.welderNo, saved.page);
  _restoreModalScroll(saved.scrollTop || 0);
}

/* ── 부서별 결함 ─────────────────────────────────────────────────────────────── */
function renderDepartments(r) {
  const emptyEl   = document.getElementById('dept-empty');
  const contentEl = document.getElementById('dept-content');
  const depts = (r && r.departments) || {};
  const names = Object.keys(depts);
  if (!names.length) {
    if (emptyEl)   emptyEl.style.display   = '';
    if (contentEl) contentEl.style.display = 'none';
    return;
  }
  if (emptyEl)   emptyEl.style.display   = 'none';
  if (contentEl) contentEl.style.display = '';

  // 결함 건수 많은 순으로 정렬
  names.sort((a, b) => (depts[b].defect_rows || 0) - (depts[a].defect_rows || 0));

  document.getElementById('dept-list').innerHTML = names.map(name => {
    const d = depts[name];
    // 발송용 체크박스는 없앴다 — 메일 발송은 '범위별 내보내기' 탭으로 옮겼다
    return `<div class="dept-chip ${name === S.currentDept ? 'active' : ''}" role="button" tabindex="0"
                 onclick="selectDepartment('${_jsq(name)}')">
      <div class="dept-chip-name">${_esc(name)}</div>
      <div class="dept-chip-stat">판정 ${_n(d.total_rows)} · 결함 <b>${_n(d.defect_rows)}</b>${
        d.unworked_rows ? ` · 미작업 ${_n(d.unworked_rows)}` : ''}${
        d.temp_rows ? ` · 임시부재 ${_n(d.temp_rows)}` : ''}</div>
    </div>`;
  }).join('');

  if (!S.currentDept || !depts[S.currentDept]) {
    S.currentDept = names[0];
  }
  selectDepartment(S.currentDept);
}





async function selectDepartment(name) {
  // 부서를 바꾸면 앞 부서의 글은 `aiMount`가 지운다. 안 지우면 **부서를 바꿨는데
  // 앞 부서의 진단이 그대로 남고**, 오류가 나지 않아 그 부서 것으로 읽힌다.
  aiShow('dept', 'dept', { dept: name }, 'ai-dept');
  S.currentDept = name;
  document.querySelectorAll('.dept-chip').forEach(el =>
    el.classList.toggle('active', el.querySelector('.dept-chip-name').textContent === name)
  );

  const d = (S.result.departments || {})[name];
  if (!d) return;
  document.getElementById('dept-detail').style.display = '';

  const total = d.total_rows || 1;   // 부서 판정 대상 (미작업 제외)
  const rate  = d.defect_rows > 0 ? (d.defect_rows / total * 100).toFixed(1) : '0.0';
  const recurCount = (d.recurring_patterns || []).length;
  document.getElementById('dept-kpi-grid').innerHTML = [
    { lbl: '판정 대상', val: _n(d.total_rows), sub: `미작업 ${_n(d.unworked_rows || 0)}건 제외`, c: 'var(--text)' },
    { lbl: '결함 발생', val: _n(d.defect_rows), sub: `판정 대상의 ${rate}%`,
      c: 'var(--ck-orange)', sev: _sevByRate(rate) },
    { lbl: '결함 있는 용접사', val: _n((d.welder_defect_rate || []).length) + '명', sub: '교육 참고용',
      c: 'var(--ck-amber)', sev: (d.welder_defect_rate || []).length >= 20 ? 'warn' : '' },
    { lbl: '반복 결함 패턴', val: _n(recurCount) + '건', sub: '용접사·Check 조합 · 클릭 시 목록', c: 'var(--ck-brown)',
      sev: recurCount >= 20 ? 'bad' : recurCount ? 'warn' : '',
      click: recurCount > 0 ? `setDeptSubtab('recurring')` : '' },
  ].map(_kpiCardHtml).join('');

  S.deptWelderPage = 1;
  S.deptDefectPage = 1;
  S.deptRecurringPage = 1;
  renderDeptWelderTable();
  loadDeptDefectPage();
  renderDeptRecurringTable();
  setDeptSubtab(S.deptSubtab);

}

function setDeptSubtab(name) {
  S.deptSubtab = name;
  document.getElementById('dept-subtab-defects').classList.toggle('active', name === 'defects');
  document.getElementById('dept-subtab-welders').classList.toggle('active', name === 'welders');
  document.getElementById('dept-subtab-recurring').classList.toggle('active', name === 'recurring');
  document.getElementById('dept-panel-defects').style.display   = name === 'defects'   ? '' : 'none';
  document.getElementById('dept-panel-welders').style.display   = name === 'welders'   ? '' : 'none';
  document.getElementById('dept-panel-recurring').style.display  = name === 'recurring' ? '' : 'none';
}

/* ── 부서별 대시보드 (부서 -> 팀 드릴다운) ──────────────────────────────────────
   기존 "부서별 결함" 탭은 결함 리스트 위주이고, 이 탭은 메인 대시보드와 같은
   지표(KPI/체크그리드)를 부서 단위로, 그 아래 팀 단위로 다시 볼 수 있게 한다. */
function renderDeptDashboard(r) {
  const emptyEl   = document.getElementById('deptdash-empty');
  const contentEl = document.getElementById('deptdash-content');
  const depts = (r && r.departments) || {};
  const names = Object.keys(depts);
  if (!names.length) {
    if (emptyEl)   emptyEl.style.display   = '';
    if (contentEl) contentEl.style.display = 'none';
    return;
  }
  if (emptyEl)   emptyEl.style.display   = 'none';
  if (contentEl) contentEl.style.display = '';

  names.sort((a, b) => (depts[b].defect_rows || 0) - (depts[a].defect_rows || 0));

  document.getElementById('deptdash-dept-list').innerHTML = names.map(name => {
    const d = depts[name];
    return `<div class="dept-chip ${name === S.deptDashDept ? 'active' : ''}" role="button" tabindex="0"
                 onclick="selectDeptDashDept('${_jsq(name)}')">
      <div class="dept-chip-name">${_esc(name)}</div>
      <div class="dept-chip-stat">판정 ${_n(d.total_rows)} · 결함 <b>${_n(d.defect_rows)}</b>${
        d.unworked_rows ? ` · 미작업 ${_n(d.unworked_rows)}` : ''}${
        d.temp_rows ? ` · 임시부재 ${_n(d.temp_rows)}` : ''}</div>
    </div>`;
  }).join('');

  if (!S.deptDashDept || !depts[S.deptDashDept]) {
    S.deptDashDept = names[0];
    S.deptDashTeam = null;
  }
  selectDeptDashDept(S.deptDashDept);
}

function selectDeptDashDept(name) {
  S.deptDashDept = name;
  S.deptDashTeam = null;
  document.querySelectorAll('#deptdash-dept-list .dept-chip').forEach(el =>
    el.classList.toggle('active', el.querySelector('.dept-chip-name').textContent === name)
  );
  _renderDeptDashScope();
}

function selectDeptDashTeam(name) {
  S.deptDashTeam = (S.deptDashTeam === name) ? null : name;
  _renderDeptDashScope();
}

let _deptDashSeq = 0;

async function _renderDeptDashScope() {
  aiShow('deptdash', 'dept',
         { dept: S.deptDashDept, team: S.deptDashTeam || '' }, 'ai-deptdash');
  const dept = (S.result.departments || {})[S.deptDashDept];
  document.getElementById('deptdash-detail').style.display = dept ? '' : 'none';
  if (!dept) return;

  const teams = dept.teams || {};
  const teamNames = Object.keys(teams).sort((a, b) => (teams[b].defect_rows||0) - (teams[a].defect_rows||0));
  const scope = S.deptDashTeam && teams[S.deptDashTeam] ? teams[S.deptDashTeam] : dept;

  document.getElementById('deptdash-scope-title').textContent =
    S.deptDashTeam ? `${S.deptDashDept} › ${S.deptDashTeam}` : `${S.deptDashDept} (부서 전체)`;
  document.getElementById('deptdash-scope-hint').textContent =
    S.deptDashTeam ? '팀 단위로 집계한 지표입니다 — 다시 누르면 부서 전체로 돌아갑니다' : '부서 전체(하위 팀 합산) 지표입니다';

  const seq = ++_deptDashSeq;
  let agg;
  try {
    agg = await _deptDashAggregate(scope);
  } catch (e) {
    if (seq !== _deptDashSeq) return;
    console.warn('부서 대시보드 집계 조회 실패:', e.message);
    return;
  }
  if (seq !== _deptDashSeq) return;
  _tempNote('deptdash-temp-note', scope.temp_rows);
  // 분모도 «지금 보고 있는 기준»이어야 한다 — 안 그러면 결함률이 틀린다
  const judged   = agg.flaggedRows + agg.cleanRows;
  const flagRate = judged > 0 ? (agg.flaggedRows / judged * 100).toFixed(1) : '0.0';
  const cleanRate = judged > 0 ? (agg.cleanRows   / judged * 100).toFixed(1) : '0.0';
  const cards = [
    { lbl:'판정 대상', val: _n(judged), sub:`미작업 ${_n(scope.unworked_rows||0)}건 제외`, c:'var(--text)' },
    { lbl:'미작업 수량', val: _n(scope.unworked_rows||0), sub:'결함 아님 · 판정 제외', c:'var(--text-2)' },
    { lbl:'결함 행',   val: _n(agg.flaggedRows), sub:`판정 대상의 ${flagRate}%`,
      c:'var(--ck-orange)', sev: _sevByRate(flagRate) },
    { lbl:'이상 없음 (클린)', val: _n(agg.cleanRows), sub:`판정 대상의 ${cleanRate}%`, c:'var(--ck-green)' },
  ];
  document.getElementById('deptdash-kpi-grid').innerHTML = cards.map(_kpiCardHtml).join('');

  document.getElementById('deptdash-check-grid').innerHTML =
    _buildDeptDashCheckGridHtml(agg.cardStats);
  const dsel = _deptDashSelectedChecks();
  const dAllSelected = dsel.size === _activeMeta().length;
  const dResetBtn = document.getElementById('deptdash-check-grid-reset');
  const dHint = document.getElementById('deptdash-check-grid-hint');
  if (dResetBtn) dResetBtn.style.display = dAllSelected ? 'none' : '';
  if (dHint) dHint.textContent = dAllSelected
    ? '정렬은 아래 «검사 항목별 플래그 현황»의 단추를 따릅니다 · 카드는 클릭 시 상세 목록, 우상단 체크박스로 집계에서 제외 — 부서/팀을 옮겨도 선택이 유지됩니다'
    : `${dsel.size}/${_activeMeta().length}개 선택됨 · 제외된 항목은 정상 판정으로 처리됩니다 (부서/팀 전환 시에도 유지)`;

  document.getElementById('deptdash-team-list').innerHTML = teamNames.length
    ? teamNames.map(name => {
        const t = teams[name];
        return `<div class="dept-chip ${name === S.deptDashTeam ? 'active' : ''}" role="button" tabindex="0"
                     onclick="selectDeptDashTeam('${_jsq(name)}')">
          <div class="dept-chip-name">${_esc(name)}</div>
          <div class="dept-chip-stat">판정 ${_n(t.total_rows)} · 결함 <b>${_n(t.defect_rows)}</b>${
            t.unworked_rows ? ` · 미작업 ${_n(t.unworked_rows)}` : ''}${
            t.temp_rows ? ` · 임시부재 ${_n(t.temp_rows)}` : ''}</div>
        </div>`;
      }).join('')
    : `<div style="color:var(--text-3);font-size:12px;padding:8px">하위 팀 정보가 없습니다</div>`;

  // 캔버스는 부모 요소 크기를 읽어 그리므로, chart-row가 display:''로 바뀌어
  // 레이아웃이 확정된 다음 틱에 그린다(메인 대시보드 renderDashboard와 동일한 패턴).
  setTimeout(() => _drawDeptDashCharts(scope), 30);
}

/* ── 부서별 대시보드 Check 취사선택 ──────────────────────────────────────────
   메인 대시보드(_dashSelectedChecks 등)와 동작은 동일하지만 상태를 별도로 둔다
   (S.deptDashCheckSel) — 이 화면만의 탐색 맥락이라 메인 대시보드의 선택과
   섞이지 않아야 한다. 부서 하나에만 묶이지 않고 "이 대시보드를 보는 동안"
   유지되는 단일 상태라, 부서를 바꾸거나(selectDeptDashDept) 팀으로 들어가도
   (selectDeptDashTeam) 그대로 이어진다 — 새 검증 결과가 올 때만 초기화된다. */
function _deptDashSelectedChecks() {
  if (!S.deptDashCheckSel) S.deptDashCheckSel = new Set(_activeMeta().map(c => c.no));
  return S.deptDashCheckSel;
}

function toggleDeptDashCheck(checkNo) {
  const sel = _deptDashSelectedChecks();
  if (sel.has(checkNo)) sel.delete(checkNo); else sel.add(checkNo);
  _renderDeptDashScope();
}

function resetDeptDashCheckSel() {
  S.deptDashCheckSel = new Set(_activeMeta().map(c => c.no));
  _renderDeptDashScope();
}

/* 부서/팀 범위에서 선택된 Check만으로 다시 집계한다. 메인 대시보드와 같은
   엔드포인트를 쓰되 dept/team을 함께 보낸다 — 분모(판정 대상)도 그 버킷 값이
   되어야 하고, 그건 flag에서 셀 수 없어 서버가 저장된 값을 쓴다. */
async function _deptDashAggregate(scope) {
  const scopeParams = { dept: S.deptDashDept || '', team: S.deptDashTeam || '' };
  // 메인 대시보드와 같은 이유로 두 번 묻는다 — 카드 건수는 «행 범위»만 반영한다
  const [d, cards] = await Promise.all([
    fetchAggregate(Object.assign({ checks: _checksParam(_deptDashSelectedChecks()) },
                                 scopeParams)),
    fetchAggregate(scopeParams),
  ]);
  return {
    flaggedRows: d.flagged_rows,
    cleanRows:   d.clean_rows,
    stats:       d.stats,
    cardStats:   cards.stats,
    trend:       d.trend,
  };
}

/* 부서별 대시보드 전용 Check 카드 — 메인 대시보드의 _buildDashCheckGridHtml과 같은
   구성(본문 클릭=상세 목록, 체크박스=취사선택)이며 스코프별 진입점만 다르다
   (goToCheckDetailScoped로 현재 부서/팀 필터가 함께 걸린다).

   건수는 «행 범위»(부서/팀 + 1C 제외)만 반영한다. 예전에는 `scope.check_stats`
   원본을 그대로 썼는데, 1C를 뺀 순간 바로 옆 막대그래프와 숫자가 어긋났다. */
function _buildDeptDashCheckGridHtml(statsObj) {
  const sel = _deptDashSelectedChecks();
  statsObj = statsObj || {};
  return _sortedCheckMeta(statsObj, S.deptDashCheckSort).map(c => {
    const cnt = statsObj[String(c.no)] || 0;
    const selected = sel.has(c.no);
    const canDrill = cnt > 0;
    return `<div class="ck-card ${canDrill ? 'clickable' : ''} ${selected ? '' : 'ck-off'}" style="--ck-c:${c.ckC}"
                 ${canDrill ? `role="button" tabindex="0" title="클릭하면 상세 목록으로 이동" onclick="goToCheckDetailScoped('${_jsq(c.no)}')"` : ''}>
      <span class="ck-toggle-box" role="button" tabindex="0" aria-pressed="${selected}"
            title="${selected ? '클릭하면 대시보드 집계에서 제외(정상 판정으로 처리)' : '클릭하면 다시 포함'}"
            onclick="event.stopPropagation(); toggleDeptDashCheck('${_jsq(c.no)}')"></span>
      <div class="ck-num">CHECK ${_ckLabel(c.no)}<span class="ck-cat ck-cat-${_ckCategory(c.no) === '공통' ? 'common' : 'project'}">${_ckCategory(c.no)}</span>${_provMark(c.no)}${_scopeMark(c.no)}</div>
      <div class="ck-name">${c.name}</div>
      <div class="ck-count ${cnt === 0 ? 'zero' : ''}">${_n(cnt)}</div>
      <div class="ck-col">${c.col}열</div>
    </div>`;
  }).join('');
}

/* 현재 선택된 부서/팀 범위(scope) 객체를 반환 — 부서 전체면 dept 객체, 팀 선택 시 그 팀 객체. */
function _currentDeptDashScope() {
  if (!S.result || !S.deptDashDept) return null;
  const dept = (S.result.departments || {})[S.deptDashDept];
  if (!dept) return null;
  const teams = dept.teams || {};
  return (S.deptDashTeam && teams[S.deptDashTeam]) ? teams[S.deptDashTeam] : dept;
}

async function _drawDeptDashCharts(scope) {
  let agg;
  try {
    agg = await _deptDashAggregate(scope);
  } catch (e) {
    console.warn('부서 대시보드 차트 집계 실패:', e.message);
    return;
  }
  drawBarChart('deptdash-bar-chart', agg.stats, S.deptDashCheckSort);
  drawDonutChart('deptdash-donut-chart', 'deptdash-donut-legend',
                 agg.stats, agg.flaggedRows, agg.cleanRows,
                 agg.flaggedRows + agg.cleanRows);
  drawTrendChart('deptdash-trend-chart', 'deptdash-trend-tooltip', agg.trend);
}

function renderDeptWelderTable() {
  const d = (S.result.departments || {})[S.currentDept];
  const all = (d && d.welder_defect_rate) || [];
  const txt = (document.getElementById('dept-welder-filter')?.value || '').toLowerCase();
  const filtered = txt
    ? all.filter(w => w.welder_no.toLowerCase().includes(txt) ||
                      _welderShortName(w.welder_no).toLowerCase().includes(txt))
    : all;

  const { slice, page, pages, total, start } = _paginate(filtered, S.deptWelderPage, PAGE_SIZE);
  S.deptWelderPage = page;

  // 시공 행이 적으면 결함률이 극단값으로 튄다(6행 중 6건이면 100%). 용접사 관리 탭과
  // 같은 기준(WELDER_MIN_SAMPLE)으로 표본부족을 표시해, 부서 담당자가 이 숫자를
  // 개인 성과 순위로 오독하지 않게 한다.
  document.getElementById('dept-welder-tbody').innerHTML = slice.map(w => {
    const low = (w.total || 0) < WELDER_MIN_SAMPLE;
    return `<tr>
      <td>${_welderCellHtml(w.welder_no)}</td>
      <td>${_welderQualHtml(w.welder_no)}</td>
      <td>${_n(w.total)}</td>
      <td style="color:var(--ck-orange);font-weight:600">${_n(w.defect)}</td>
      <td>${w.rate}%${low ? ` <span class="w-lowsample" title="시공 ${w.total}건 — 표본이 적어 결함률을 순위 근거로 쓰기 어렵습니다">표본부족</span>` : ''}</td>
    </tr>`;
  }).join('') || `<tr><td colspan="5" style="text-align:center;color:var(--text-3);padding:16px">결함이 발생한 용접사가 없습니다</td></tr>`;

  _setPageInfo('dept-welder-page-info', total ? start + 1 : 0, Math.min(start + PAGE_SIZE, total), total);
  const btns = document.getElementById('dept-welder-page-btns');
  if (btns) btns.innerHTML = _buildPagerHtml(page, pages, 'goDeptWelderPage');
}

function goDeptWelderPage(p) {
  S.deptWelderPage = p;
  renderDeptWelderTable();
}

/* 6번 서브에이전트(recurrence.py) 결과 — 같은 용접사가 같은 Check에서 서로 다른
   날짜에 반복 발생한 조합. 행 판정이 아니라 이미 확정된 결함들의 사후 집계이므로
   기준값/실측값 비교가 아니라 발생 건수·일수·기간만 보여준다. */
function renderDeptRecurringTable() {
  const d = (S.result.departments || {})[S.currentDept];
  const all = (d && d.recurring_patterns) || [];

  const { slice, page, pages, total, start } = _paginate(all, S.deptRecurringPage, PAGE_SIZE);
  S.deptRecurringPage = page;

  document.getElementById('dept-recurring-tbody').innerHTML = slice.map(rp => {
    const meta = CHECK_META.find(c => c.no === rp.check_no);
    const cls = meta ? meta.cls : 'p-blue';
    return `<tr class="row-clickable" role="button" tabindex="0"
                title="클릭하면 이 용접사·Check의 반복 발생 내역을 볼 수 있습니다"
                onclick="openRecurringModal('${_jsq(rp.welder_no)}', '${_jsq(rp.check_no)}')">
      <td>${_welderCellHtml(rp.welder_no)}</td>
      <td>
        <div><span class="pill ${cls}">C${rp.check_no}</span> ${_esc(rp.check_name)}</div>
        ${rp.summary ? `<div class="recur-summary">${_esc(rp.summary)}</div>` : ''}
      </td>
      <td>${_n(rp.count)}</td>
      <td>${_n(rp.distinct_dates)}</td>
      <td class="mono">${_esc(rp.first_date)} ~ ${_esc(rp.last_date)}</td>
    </tr>`;
  }).join('') || `<tr><td colspan="5" style="text-align:center;color:var(--text-3);padding:16px">반복되는 패턴이 없습니다</td></tr>`;

  _setPageInfo('dept-recurring-page-info', total ? start + 1 : 0, Math.min(start + PAGE_SIZE, total), total);
  const btns = document.getElementById('dept-recurring-page-btns');
  if (btns) btns.innerHTML = _buildPagerHtml(page, pages, 'goDeptRecurringPage');
}

function goDeptRecurringPage(p) {
  S.deptRecurringPage = p;
  renderDeptRecurringTable();
}

/* 결과를 갈아끼울 때 파생 캐시를 반드시 함께 버린다.
   flags에서 만든 것들이라 옛 결과의 캐시가 남으면 새 검증 화면에 옛 결함이 섞인다. */
function _setResult(result) {
  _syncBasis(result);
  S.result = result;
  S._patternTeams = null;
  S._welderFlagCache = null;
  S._welderReview = null;
  S.resultPage = null;
  S.deptDefectData = null;
  _deptDefectCache.clear();
  _teamFacetCache.clear();
  _rawCache.clear();
}

/* 부서/팀 결함 목록은 응답에 «행 번호»로만 실려 온다(defect_row_order).
   항목 전체는 flags에서 만들 수 있어 세 번 보낼 이유가 없다 — 실측으로 부서·팀
   사본 합이 payload의 44%였다(2,737KB -> 40.5KB).

   서버의 result_store.expand_defects()와 **같은 규칙**이어야 한다. 갈라지면
   «부서 메일에 적힌 건수»와 «화면에서 본 건수»가 달라진다. */
const _deptDefectCache = new Map();

/* 부서 결함 목록도 서버가 낸다. 4단계에서는 화면이 flags로 직접 만들었는데,
   그건 전체 배열이 있다는 전제였다. 그 전제가 없어졌다.
   서버의 result_store.dept_defects()와 같은 결과이고, 검색 범위(Joint No ·
   용접사 번호)도 서버가 화면과 같게 맞춰 두었다. */
let _deptDefectSeq = 0;

async function loadDeptDefectPage() {
  const seq = ++_deptDefectSeq;
  const dept = S.currentDept;
  if (!dept) return;
  const q = (document.getElementById('dept-defect-filter')?.value || '');
  try {
    // 부서명에 슬래시가 든 경우가 있어(`Q530-SMR/ITER생산부`) 경로가 아니라
    // 질의 파라미터로 보낸다 — 경로에 넣으면 라우트가 쪼개져 404가 된다.
    const d = await apiFetch('/api/departments/defects?' +
      _qs({ dept: dept, q: q,
            offset: (S.deptDefectPage - 1) * PAGE_SIZE, limit: PAGE_SIZE }));
    if (seq !== _deptDefectSeq) return;   // 더 새로운 요청이 이미 나갔다
    S.deptDefectData = d;
  } catch (e) {
    if (seq !== _deptDefectSeq) return;
    console.warn('부서 결함 목록 조회 실패:', e.message);
    S.deptDefectData = { total: 0, offset: 0, items: [] };
  }
  renderDeptDefectTable();
}

function renderDeptDefectTable() {
  const d = S.deptDefectData || { total: 0, items: [] };
  const total = d.total;
  const pages = Math.ceil(total / PAGE_SIZE) || 1;
  const page  = Math.min(Math.max(1, S.deptDefectPage || 1), pages);
  const start = (page - 1) * PAGE_SIZE;
  const slice = d.items;
  S.deptDefectPage = page;

  document.getElementById('dept-defect-cnt').textContent = `· ${_n(total)}건`;
  document.getElementById('dept-defect-tbody').innerHTML = slice.map(x =>
    `<tr class="row-clickable" role="button" tabindex="0" onclick="openFlagDetail(${x.row})">
      <td class="mono" style="color:var(--text-3)">${x.row}</td>
      <td class="mono" style="font-weight:600">${_esc(x.joint_no || '—')}</td>
      <td>${_esc(x.block || '—')}</td>
      <td class="mono">${_esc(x.wps_no || '—')}</td>
      <td class="mono">${_esc(x.weld_date || '—')}</td>
      <td class="mono">${_esc(x.welder1_no || '—')}</td>
      <td style="color:var(--text-2)">${_esc(x.checks.map(c => c.check_name).join(', '))}</td>
      <td style="color:var(--ck-green);max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"
          title="${_esc(x.checks.map(c => c.expected || c.msg).join(' / '))}">${_esc(x.checks.map(c => c.expected || c.msg).join(' / '))}</td>
      <td style="color:var(--ck-red);max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"
          title="${_esc(x.checks.map(c => c.actual || '').join(' / '))}">${_esc(x.checks.map(c => c.actual || '').join(' / '))}</td>
    </tr>`
  ).join('') || `<tr><td colspan="9" style="text-align:center;color:var(--text-3);padding:16px">결함이 없습니다</td></tr>`;

  _setPageInfo('dept-defect-page-info', total ? start + 1 : 0, Math.min(start + PAGE_SIZE, total), total);
  const btns = document.getElementById('dept-defect-page-btns');
  if (btns) btns.innerHTML = _buildPagerHtml(page, pages, 'goDeptDefectPage');
}

function goDeptDefectPage(p) {
  S.deptDefectPage = p;
  return loadDeptDefectPage();   // 페이지가 바뀌면 그 페이지를 새로 가져온다
}






/* ── 로그인 배경 영상 (핑퐁 루프) ──────────────────────────────────────────────
   <video>는 압축 영상을 프레임 단위로 역재생하는 기능이 없다(currentTime을 매 프레임
   되감아 흉내내면 GOP 구조 때문에 매끄럽게 되감기지 않고 그냥 앞으로 다시 재생되는
   것처럼 보임 — 실제로 겪은 문제). 그래서 index.html에 정방향(#bg-video-fwd)과,
   미리 역순으로 인코딩해둔 파일을 재생하는 #bg-video-rev 두 <video>를 같은 자리에
   겹쳐두고, 하나가 끝나면 숨기고 다른 하나를 보이며 재생하는 식으로 전환한다. */
function bgVideoSwap(hideId, showId) {
  const hideEl = document.getElementById(hideId);
  const showEl = document.getElementById(showId);
  if (!hideEl || !showEl) return;
  hideEl.pause();
  hideEl.classList.add('hidden');
  showEl.classList.remove('hidden');
  showEl.currentTime = 0;
  showEl.play();
}

/* ── 로그인 ─────────────────────────────────────────────────────────────────── */
async function submitLogin() {
  const input = document.getElementById('emp-id');
  const errEl = document.getElementById('login-error');
  const id    = (input.value || '').trim();
  if (!id) { errEl.textContent = '사번을 입력하세요'; return; }
  errEl.textContent = '';

  try {
    const res = await fetch('/api/auth/login', {
      method:  'POST',
      headers: {'Content-Type': 'application/json'},
      body:    JSON.stringify({employee_id: id}),
    });
    if (res.ok) {
      const data = await res.json();
      localStorage.setItem('qc_employee_id', data.employee_id);
      localStorage.setItem('qc_is_admin', data.is_admin ? '1' : '0');
      _applyLogin(data.employee_id, data.is_admin);
    } else {
      const err = await res.json().catch(() => ({}));
      errEl.textContent = err.detail || '등록되지 않은 사번입니다';
      input.focus();
    }
  } catch {
    errEl.textContent = '서버 연결 오류. 잠시 후 다시 시도하세요';
  }
}

/* 서버에 남아 있는 마지막 검증 결과를 화면에 되살린다.
   서버는 재시작해도 data/app_state.json에서 결과를 복원하므로, 사용자는 접속만 하면
   지난번에 보던 화면을 그대로 이어서 볼 수 있어야 한다. */
async function _restoreLastResult() {
  if (S.result) return;                     // 이미 있으면 21MB를 다시 받지 않는다
  try {
    const s = await apiFetch('/api/status');
    if (!s.has_result) return;
    const result = await apiFetch('/api/result');
    _setResult(result);
    await _loadPatternTeams();
    showResult(result);
  } catch (e) {
    console.warn('이전 검증 결과 복원 실패:', e.message);
  }
}

function _applyLogin(empId, isAdmin) {
  document.getElementById('login-overlay').classList.add('hidden');
  const footer    = document.getElementById('sidebar-footer');
  const logoutBtn = document.getElementById('logout-btn');
  if (footer)    footer.textContent = empId;
  if (logoutBtn) logoutBtn.style.display = 'block';

  const navSection = document.getElementById('nav-section-admin');
  const navSettings = document.getElementById('nav-settings');
  if (navSection)  navSection.style.display  = isAdmin ? '' : 'none';
  if (navSettings) navSettings.style.display = isAdmin ? '' : 'none';

  loadFeedback();
  // 로그인이 끝난 **뒤에** 이전 검증 결과를 되살린다.
  // /api/result가 인증을 요구하게 되면서, 로그인 전에 호출하면 401이 나 조용히 버려진다.
  // 예전에는 그 호출이 무인증이라 페이지 로드 시점에 이미 채워졌지만 지금은 아니어서,
  // 새로 로그인하면 대시보드가 "검증 결과 없음"으로 비어 보였다.
  _restoreLastResult();
}

/* ── 검토 피드백 (Human-in-the-loop) ─────────────────────────────────────────── */
const FEEDBACK_RESULTS = ['결함확정', '오탐', '확인중'];

/* 검토 기록 식별 키. 반드시 도면번호를 포함해야 한다 — Joint No는 도면 안에서만
   유일해서(Check 14 참고) 도면번호를 빼면 서로 다른 도면의 무관한 조인트가 같은 키를
   공유하게 되고, 한 건을 검토하면 다른 조인트까지 검토 완료로 표시된다.
   플래그 객체를 통째로 받는 이유는 새 호출부에서 구성요소를 빠뜨리지 않게 하기 위함. */
function _fbKey(f) {
  return `${f.drawing_no || ''}|${f.joint_no || ''}|${f.wps_no || ''}|${f.check_no}`;
}

/* 결과 테이블/Check 목록 팝업의 "검토" 열 배지 — 결함확정/오탐/확인중/미검토. */
function _reviewBadgeHtml(f) {
  const rec = S.feedback[_fbKey(f)];
  if (!rec) return `<span class="fb-badge fb-badge-none">미검토</span>`;
  const cls = rec.result === '결함확정' ? 'fb-badge-confirm'
            : rec.result === '오탐'     ? 'fb-badge-false'
            : 'fb-badge-review';
  const title = `${_esc(rec.reviewer_id)} · ${_esc((rec.updated_at || '').replace('T', ' ').slice(0, 16))}`;
  return `<span class="fb-badge ${cls}" title="${title}">${_esc(rec.result)}</span>`;
}

async function loadFeedback() {
  try {
    const data = await _adminFetch('/api/feedback');
    S.feedback = data.feedback || {};
  } catch {
    S.feedback = {};
  }
}

function logout() {
  localStorage.removeItem('qc_employee_id');
  localStorage.removeItem('qc_is_admin');
  location.reload();
}

/* ── 설정 (관리자 전용: 사번 관리 + Outlook 발송 설정) ───────────────────────────── */
async function _adminFetch(url, opts = {}) {
  const empId = localStorage.getItem('qc_employee_id') || '';
  const headers = Object.assign({}, opts.headers || {}, {'X-Employee-Id': empId});
  const res = await fetch(url, Object.assign({}, opts, {headers}));
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const e = new Error(err.detail || `HTTP ${res.status}`);
    e.status = res.status;
    throw e;
  }
  return res.json();
}

async function loadSettings() {
  try {
    const empData = await _adminFetch('/api/settings/employees');
    renderEmployeeTable(empData.employees || []);
  } catch (e) {
    document.getElementById('settings-emp-error').textContent = '사번 목록 로드 실패: ' + e.message;
  }
  await loadAiSettings();
  try {
    const outlookData = await _adminFetch('/api/settings/outlook');
    document.getElementById('outlook-enabled').checked = !!outlookData.enabled;
    S.recipients = outlookData.recipients || [];
    renderRecipientChips();
  } catch (e) {
    console.warn('outlook settings load error:', e.message);
  }
}

/* ══ AI 분석 ════════════════════════════════════════════════════════════════
   종류가 열이지만 **부품은 하나다.** 대시보드 AI분석 보고서 · 부서 진단 · 용접사
   코칭 · 이상치 해설… 물음은 달라도 돌려받는 모양이 같다:

       {grade, headline, summary:{verdict, points}, sections:[{claims}], visuals}

   종류마다 화면을 따로 만들면 근거 칩 · 비용 확인 · 중복 클릭 잠금을 열 벌
   만들게 되고, 그중 하나는 반드시 빠진다. 빠진 자리는 «돈이 두 번 나가는» 자리다.

   ## 탭 안에는 «한 줄»만 둔다

   보고서를 탭 본문 위에 끼워 넣었더니 아래 내용이 통째로 밀려 내려가, 표와
   보고서를 같이 보려면 위아래로 오가야 했다. 그래서 탭에 남는 것은 **단추 한
   줄**이고, 보고서는 **떠 있는 창**으로 나온다 — 옆으로 밀어 두면 본문과 나란히
   읽힌다. 자리와 크기는 브라우저에 기억시킨다(`localStorage`).

   ## 누르지 않으면 나가지 않는다

   현업 지시(2026-08-21). 돈이 나가는 길은 둘뿐이고 둘 다 `onclick`에서만 출발한다:

       [분석 실행] -> aiStart()  -> POST /api/ai/estimate   (무료 · 비용 표시)
                    -> [실행]    -> aiGo()                  (여기서 처음 과금)

   `aiShow()`는 렌더 함수가 부른다. 그건 `GET /api/ai/saved` — **이미 만들어 둔
   글을 DB에서 읽는 것**이라 과금이 아니다. `tests/test_ai_cards.py`가 app.js의
   모든 함수를 훑어 이 구분을 정적으로 지킨다. */
const AIC = { models: [], configured: false, sdk: true, kinds: {}, cards: {},
              z: 400, stale: false };

/* 새 화면이 부르는 주소를 서버가 모른다(404) = **백엔드가 옛 버전**이다.

   파이썬 모듈은 프로세스 시작 시 1회만 로드되고 정적 파일은 요청마다 읽힌다.
   그래서 파일을 덮어쓰고 Ctrl+F5만 하면 «화면은 새것 · 서버는 옛것»이 되는데,
   그때 보이는 것은 404 하나뿐이다. 「Not found」로만 적으면 파일을 잘못 옮긴
   것인지 서버를 안 내린 것인지 알 방법이 없다. */
const AI_STALE_MSG =
  '이 서버는 AI 기능 주소를 모릅니다 (404) — 백엔드가 옛 버전입니다. ' +
  'backend 폴더를 덮어썼는지 확인하고, 서버를 내렸다가 다시 띄운 뒤 Ctrl+F5 하세요. ' +
  '파일만 덮어쓰고 새로고침하면 화면만 새것이 됩니다.';

function _aiErr(e) {
  return (e && e.status === 404) ? AI_STALE_MSG : ((e && e.message) || String(e));
}

async function aiLoadModels() {
  try {
    const d = await apiFetch('/api/ai/models');
    AIC.models = d.models || [];
    AIC.configured = !!d.configured;
    AIC.sdk = d.sdk_available !== false;
    AIC.kinds = d.kinds || {};
  } catch (e) {
    AIC.stale = !!(e && e.status === 404);
    console.warn('AI 모델 목록 조회 실패:', e.message);
  }
  Object.keys(AIC.cards).forEach(id => aiRender(id));
}

/* 카드를 자리에 건다. **여기서 AI를 부르지 않는다.**
   `scope`는 «어디를»이다 — {dept, team, welder, item, row}. */
function aiMount(cardId, kind, scope, elId) {
  const el = document.getElementById(elId);
  if (!el) return;
  const prev = AIC.cards[cardId];
  const same = prev && prev.kind === kind &&
               JSON.stringify(prev.scope || {}) === JSON.stringify(scope || {});
  AIC.cards[cardId] = {
    kind, scope: scope || {}, elId,
    // 범위가 바뀌면 앞 범위의 글을 지운다 — 안 지우면 **부서를 바꿨는데 앞
    // 부서의 진단이 그대로 남는다.** 오류가 나지 않아 그냥 그 부서 것으로 읽힌다.
    state: same ? prev.state : { phase: 'idle', report: null, est: null, err: '' },
    model: (prev && prev.model) || '',
    win: same && prev.win ? prev.win : null,
    seq: prev ? prev.seq : 0,
  };
  if (!same && prev && prev.win) aiCloseWin(cardId);
  aiRender(cardId);
  return AIC.cards[cardId];
}

/* 카드를 걸고 **저장된 글이 있으면 단추를 «보고서 열기»로 바꾼다.**
   회차에 매달려 있으므로 탭을 오가도 재과금이 없다. 재검증하면 회차와 함께
   사라진다 — 옛 글이 새 숫자 옆에 남지 않게 하려는 것이다.
   **창을 저절로 열지는 않는다.** 탭을 옮길 때마다 창이 튀어나오면 성가시다. */
async function aiShow(cardId, kind, scope, elId) {
  const c = aiMount(cardId, kind, scope, elId);
  if (!c || c.state.report || c.state.phase === 'run') return;
  const q = new URLSearchParams({ kind });
  ['dept', 'team', 'welder', 'item', 'row'].forEach(k => {
    if (scope && scope[k]) q.set(k, scope[k]);
  });
  const seq = (c.seq = (c.seq || 0) + 1);
  try {
    const d = await apiFetch('/api/ai/saved?' + q.toString());
    const cur = AIC.cards[cardId];
    if (!cur || cur.seq !== seq) return;     // 그 사이 범위가 바뀌었다
    if (d.report) { cur.state.report = d.report; cur.state.phase = 'done'; }
  } catch (e) {
    console.warn('저장된 AI 분석 조회 실패:', e.message);
  }
  aiRender(cardId);
}

function _aiModelOf(cardId) {
  const c = AIC.cards[cardId];
  const sel = document.getElementById('aim-' + cardId);
  return (sel && sel.value) || (c && c.model) || '';
}

/* ── ① 첫 관문 — 예상 비용 (무료) ─────────────────────────────────────────── */
async function aiStart(cardId) {
  const c = AIC.cards[cardId];
  if (!c) return;
  c.model = _aiModelOf(cardId);
  c.state.phase = 'est'; c.state.err = ''; c.state.est = null;
  aiOpenWin(cardId);
  try {
    c.state.est = await apiFetch('/api/ai/estimate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind: c.kind, scope: c.scope, model: c.model || null }),
    });
  } catch (e) {
    c.state.phase = 'idle';
    c.state.err = e.message;
  }
  aiRender(cardId);
}

/* ── ② 두 번째 관문 — 여기서 처음 과금된다 ───────────────────────────────── */
async function aiGo(cardId) {
  const c = AIC.cards[cardId];
  if (!c || c.state.phase === 'run') return;
  c.state.phase = 'run'; c.state.err = '';
  aiRender(cardId);
  try {
    c.state.report = await apiFetch('/api/ai/report', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind: c.kind, scope: c.scope, model: c.model || null }),
    });
    c.state.phase = 'done';
  } catch (e) {
    c.state.phase = 'idle';
    c.state.err = e.message;
  }
  aiRender(cardId);
}

function aiCancel(cardId) {
  const c = AIC.cards[cardId];
  if (!c) return;
  c.state.phase = c.state.report ? 'done' : 'idle';
  c.state.est = null;
  if (!c.state.report) aiCloseWin(cardId); else aiRender(cardId);
}

function aiAgain(cardId) {
  const c = AIC.cards[cardId];
  if (!c) return;
  c.state.phase = 'idle';
  aiStart(cardId);
}

/* ── 떠 있는 창 ───────────────────────────────────────────────────────────
   `position: fixed`라 탭 본문을 밀어내지 않는다. 머리를 끌어 옮기고 오른쪽
   아래 모서리로 크기를 바꾼다. 자리는 **카드마다 따로** 기억한다 — 부서 진단과
   용접사 코칭을 나란히 놓고 보는 일이 실제로 있다. */
const _AI_WIN_MIN = { w: 380, h: 260 };

function _aiWinKey(cardId) { return 'qc_aiwin_' + cardId; }

function _aiWinDefault(n) {
  // 오른쪽에 붙여 연다. 본문은 왼쪽에 남으므로 그대로 읽을 수 있다.
  const w = Math.min(560, Math.max(_AI_WIN_MIN.w, window.innerWidth * 0.38));
  const h = Math.max(_AI_WIN_MIN.h, window.innerHeight - 140);
  return { x: Math.max(8, window.innerWidth - w - 24 - (n % 4) * 26),
           y: 84 + (n % 4) * 26, w, h, min: false };
}

function _aiWinLoad(cardId, n) {
  let saved = null;
  try { saved = JSON.parse(localStorage.getItem(_aiWinKey(cardId)) || 'null'); }
  catch { saved = null; }
  const d = _aiWinDefault(n);
  if (!saved) return d;
  // 창을 옮긴 뒤 모니터가 바뀌면 저장된 자리가 화면 밖일 수 있다. 그러면
  // **보이지 않는 창이 열린 상태**가 되어 사용자에게는 아무 일도 안 난 것과 같다.
  const w = Math.min(Math.max(saved.w || d.w, _AI_WIN_MIN.w), window.innerWidth - 16);
  const h = Math.min(Math.max(saved.h || d.h, _AI_WIN_MIN.h), window.innerHeight - 16);
  return {
    x: Math.min(Math.max(saved.x || 0, 0), Math.max(0, window.innerWidth - w - 8)),
    y: Math.min(Math.max(saved.y || 0, 44), Math.max(44, window.innerHeight - 80)),
    w, h, min: !!saved.min,
  };
}

function _aiWinSave(cardId) {
  const c = AIC.cards[cardId];
  if (!c || !c.win) return;
  try { localStorage.setItem(_aiWinKey(cardId), JSON.stringify(c.win)); } catch {}
}

function _aiWinHost() {
  let host = document.getElementById('ai-wins');
  if (!host) {
    host = document.createElement('div');
    host.id = 'ai-wins';
    document.body.appendChild(host);
  }
  return host;
}

function aiOpenWin(cardId) {
  const c = AIC.cards[cardId];
  if (!c) return;
  if (!c.win) c.win = _aiWinLoad(cardId, Object.values(AIC.cards).filter(x => x.win).length);
  c.win.min = false;
  aiFocus(cardId);
  aiRender(cardId);
}

function aiCloseWin(cardId) {
  const c = AIC.cards[cardId];
  if (!c) return;
  c.win = null;
  const el = document.getElementById('aiw-' + cardId);
  if (el) el.remove();
  aiRender(cardId);
}

function aiMinWin(cardId) {
  const c = AIC.cards[cardId];
  if (!c || !c.win) return;
  c.win.min = !c.win.min;
  _aiWinSave(cardId);
  aiRender(cardId);
}

/* 화면 절반에 딱 붙인다. 본문과 나란히 보려고 여는 창이라 이게 가장 많이 쓰인다. */
function aiDock(cardId, side) {
  const c = AIC.cards[cardId];
  if (!c || !c.win) return;
  const w = Math.max(_AI_WIN_MIN.w, Math.round(window.innerWidth * 0.42));
  c.win = { x: side === 'left' ? 8 : window.innerWidth - w - 8, y: 76,
            w, h: window.innerHeight - 92, min: false };
  _aiWinSave(cardId);
  aiFocus(cardId);
  aiRender(cardId);
}

function aiFocus(cardId) {
  const el = document.getElementById('aiw-' + cardId);
  if (el) el.style.zIndex = ++AIC.z;
}

/* 머리를 끌어 옮긴다. `pointer` 이벤트 하나로 마우스와 펜을 같이 받는다. */
function aiDragStart(ev, cardId) {
  const c = AIC.cards[cardId];
  if (!c || !c.win) return;
  if (ev.target.closest && ev.target.closest('button, select, a')) return;
  ev.preventDefault();
  aiFocus(cardId);
  const el = document.getElementById('aiw-' + cardId);
  const ox = ev.clientX - c.win.x, oy = ev.clientY - c.win.y;
  const move = e => {
    // 머리가 화면 밖으로 완전히 나가면 다시 잡을 수가 없다.
    c.win.x = Math.min(Math.max(e.clientX - ox, -c.win.w + 90), window.innerWidth - 90);
    c.win.y = Math.min(Math.max(e.clientY - oy, 0), window.innerHeight - 40);
    if (el) { el.style.left = c.win.x + 'px'; el.style.top = c.win.y + 'px'; }
  };
  const up = () => {
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', up);
    if (el) { c.win.w = el.offsetWidth; c.win.h = el.offsetHeight; }
    _aiWinSave(cardId);
  };
  window.addEventListener('pointermove', move);
  window.addEventListener('pointerup', up);
}

/* ── 그리기 ──────────────────────────────────────────────────────────────── */
const _AI_GRADE_CLS = { '양호': 'g0', '주의': 'g1', '시정 필요': 'g2', '판단 보류': 'g3' };
const _AI_SEV_LBL = { high: '즉시', medium: '계획', low: '관찰', info: '참고' };

function _aiModelSelHtml(cardId) {
  const c = AIC.cards[cardId];
  if (!AIC.models.length) return '';
  // **종류마다 기본 모델이 다르다.** 하나로 고정하면 전체 진단에도 기본급이
  // 미리 골라져, 사용자는 그게 설계된 급인 줄 안다.
  const cur = c.model || (AIC.kinds[c.kind] || {}).model || '';
  return `<select class="f-sel" id="aim-${_esc(cardId)}" title="모델을 올리면 분석이 깊어지고 비용이 오릅니다">` +
    AIC.models.map(m =>
      `<option value="${_esc(m.id)}" ${m.id === cur ? 'selected' : ''}>${_esc(m.label)}</option>`
    ).join('') + '</select>';
}

/* 탭에 남는 것은 이 «한 줄»뿐이다. 본문을 밀어내지 않는다. */
function aiRender(cardId) {
  const c = AIC.cards[cardId];
  if (!c) return;
  const el = document.getElementById(c.elId);
  const meta = AIC.kinds[c.kind] || {};
  const ready = AIC.sdk && AIC.configured && !!S.result;
  const busy = c.state.phase === 'run' || c.state.phase === 'est';
  const rep = c.state.report;

  if (el) {
    const why = AIC.stale ? '백엔드가 옛 버전입니다 (서버를 다시 띄우세요)'
              : !AIC.sdk ? 'anthropic 패키지가 없습니다'
              : !AIC.configured ? 'API 키가 필요합니다 (설정 탭)'
              : !S.result ? '먼저 검증을 실행하세요'
              : '누르면 예상 비용을 먼저 보여 줍니다';
    el.innerHTML = `<div class="ai-launch">
      <span class="ai-launch-ico">🧠</span>
      <span class="ai-launch-title">${_esc(meta.title || 'AI 분석')}</span>
      ${rep ? `<span class="ai-launch-note">판정 ${_n(rep.judged_rows)}행 기준
                 ${rep.grade ? `· <span class="ai-grade ${_AI_GRADE_CLS[rep.grade] || 'g3'}">${_esc(rep.grade)}</span>` : ''}</span>`
            : `<span class="ai-launch-note">${_esc(ready ? '아직 분석하지 않았습니다' : why)}</span>`}
      <span class="ai-launch-sp"></span>
      ${ready ? _aiModelSelHtml(cardId) : ''}
      ${rep ? `<button class="btn btn-sm" onclick="aiOpenWin('${_jsq(cardId)}')">보고서 열기</button>` : ''}
      <button class="btn btn-sm btn-primary" ${ready && !busy ? '' : 'disabled'}
              title="${_esc(why)}"
              onclick="${rep ? 'aiAgain' : 'aiStart'}('${_jsq(cardId)}')">${
        busy ? '진행 중…' : (rep ? '다시 분석' : '분석 실행')}</button>
    </div>`;
  }

  // ── 떠 있는 창
  const host = _aiWinHost();
  let win = document.getElementById('aiw-' + cardId);
  if (!c.win) { if (win) win.remove(); return; }
  if (!win) {
    win = document.createElement('div');
    win.id = 'aiw-' + cardId;
    win.className = 'ai-win';
    win.style.zIndex = ++AIC.z;
    host.appendChild(win);
  }
  win.style.left = c.win.x + 'px';
  win.style.top = c.win.y + 'px';
  win.style.width = c.win.w + 'px';
  win.style.height = c.win.min ? 'auto' : c.win.h + 'px';
  win.classList.toggle('min', !!c.win.min);
  win.onpointerdown = () => aiFocus(cardId);

  const target = rep && rep.target ? rep.target : '';
  win.innerHTML = `
    <div class="ai-win-hd" onpointerdown="aiDragStart(event,'${_jsq(cardId)}')">
      <span class="ai-win-ico">🧠</span>
      <span class="ai-win-title">${_esc(meta.title || 'AI 분석')}</span>
      ${target ? `<span class="ai-win-target">${_esc(target)}</span>` : ''}
      ${(AIC.kinds[c.kind] || {}).tier === 'deep'
        ? '<span class="ai-tier" title="이 분석만 한 급 위 모델로 돕니다">심층</span>' : ''}
      <span class="ai-win-sp"></span>
      <button class="ai-win-btn" title="화면 왼쪽에 붙이기" onclick="aiDock('${_jsq(cardId)}','left')">◧</button>
      <button class="ai-win-btn" title="화면 오른쪽에 붙이기" onclick="aiDock('${_jsq(cardId)}','right')">◨</button>
      <button class="ai-win-btn" title="${c.win.min ? '펼치기' : '접기'}" onclick="aiMinWin('${_jsq(cardId)}')">${c.win.min ? '▢' : '—'}</button>
      <button class="ai-win-btn" title="인쇄 / PDF로 저장"
              ${rep ? '' : 'disabled'} onclick="aiPrint('${_jsq(cardId)}')">⎙</button>
      <button class="ai-win-btn" title="닫기" onclick="aiCloseWin('${_jsq(cardId)}')">✕</button>
    </div>
    ${c.win.min ? '' : `<div class="ai-win-body">${_aiBodyHtml(cardId)}</div>`}`;
}

/* 인쇄 / PDF로 저장.

   **새 창을 열지 않는다.** `window.open`은 팝업 차단에 걸리고, 걸리면 아무 일도
   일어나지 않는 것처럼 보인다(사내 브라우저 정책이 대개 막아 둔다). 대신 인쇄할
   창에 표식을 달고 `@media print`가 나머지를 감춘다 — 브라우저 인쇄 대화상자에
   「PDF로 저장」이 이미 있으므로 그것으로 PDF가 된다.

   떠 있는 창은 `position: fixed`에 높이가 정해져 있고 안쪽이 스크롤된다. 그대로
   인쇄하면 **첫 장만 나오고 나머지가 잘린다** — 인쇄용 규칙이 그 셋을 푼다. */
function aiPrint(cardId) {
  const c = AIC.cards[cardId];
  if (!c || !c.state.report) return;
  const win = document.getElementById('aiw-' + cardId);
  if (!win) return;

  // 머리말은 인쇄물에만 붙인다 — 화면에는 이미 창 제목이 있다. 종이로 나가면
  // «어느 프로젝트의 · 몇 행 기준 · 언제 만든 글인가»가 남아야 한다.
  const rep = c.state.report;
  const meta = AIC.kinds[c.kind] || {};
  const old = win.querySelector('.ai-print-hd');
  if (old) old.remove();
  const hd = document.createElement('div');
  hd.className = 'ai-print-hd';
  hd.innerHTML = `<div class="ai-print-t">${_esc(meta.title || 'AI 분석')}</div>
    <div class="ai-print-s">
      ${_esc(S.projectName || document.title || '')}
      ${rep.target ? ' · ' + _esc(rep.target) : ''}
      · 판정 대상 ${_n(rep.judged_rows)}행 기준
      ${rep.run_at ? ' · 검증 ' + _esc(rep.run_at) : ''}
      · ${_esc(rep.model || '')}
      · 출력 ${_esc(new Date().toLocaleString('ko-KR'))}
    </div>
    <div class="ai-print-w">AI가 생성한 글입니다 — 검토가 필요합니다.</div>`;
  win.insertBefore(hd, win.firstChild);

  document.body.classList.add('ai-printing');
  win.classList.add('ai-print-me');
  const done = () => {
    document.body.classList.remove('ai-printing');
    win.classList.remove('ai-print-me');
    const h = win.querySelector('.ai-print-hd');
    if (h) h.remove();
    window.removeEventListener('afterprint', done);
  };
  window.addEventListener('afterprint', done);
  // `afterprint`를 안 주는 브라우저가 있다. 안 지우면 **화면이 인쇄 모양으로
  // 굳는다** — 그쪽이 훨씬 나쁘므로 시간으로도 한 번 더 푼다.
  setTimeout(done, 60000);
  window.print();
}

function _aiBodyHtml(cardId) {
  const c = AIC.cards[cardId];
  const st = c.state;
  const parts = [];
  // 서버가 주소를 모르면 그 밖의 안내는 전부 헛말이다 — 이것부터 말한다.
  if (AIC.stale) return `<div class="ai-err">⚠ ${_esc(AI_STALE_MSG)}</div>`;
  if (st.err) parts.push(`<div class="ai-err">⚠ ${_esc(st.err)}</div>`);

  if (st.phase === 'run') {
    parts.push(`<div class="ai-hint"><span class="ai-spin">●</span>
      분석 중입니다. 30초~2분쯤 걸립니다 — 이 창을 옆으로 밀어 두고 계속 보셔도 됩니다.</div>`);
  } else if (st.phase === 'est') {
    parts.push(_aiCostHtml(cardId));
  }
  if (st.report) parts.push(_aiReportHtml(cardId, st.report));
  return parts.join('') || `<div class="ai-hint">아직 분석하지 않았습니다.</div>`;
}

function _aiCostHtml(cardId) {
  const e = AIC.cards[cardId].state.est;
  if (!e) return `<div class="ai-cost"><span class="ai-spin">●</span> 예상 비용을 재는 중…</div>`;
  const rows = `<div class="ai-cost-row">
      <span>보낼 재료 <b>${_n(e.input_tokens)}</b> 토큰</span>
      <span>출력 상한 <b>${_n(e.max_output_tokens)}</b> 토큰</span>
      <span>예상 비용 <b>$${(e.estimated_usd || 0).toFixed(4)}</b></span>
      <span class="ai-sub">${_esc(e.model)}</span>
    </div>`;
  if (!e.fits) {
    return `<div class="ai-cost">${rows}
      <div class="ai-err">⚠ ${_esc(e.message)}</div>
      <div style="margin-top:8px"><button class="btn" onclick="aiCancel('${_jsq(cardId)}')">닫기</button></div>
    </div>`;
  }
  return `<div class="ai-cost">${rows}
    <div class="ai-hint" style="margin-bottom:8px">이 값은 <b>상한</b>입니다 —
      실제 출력이 짧으면 그만큼 덜 나갑니다. 결과는 이번 검증 회차에 붙어 저장되므로
      탭을 오가도 다시 과금되지 않습니다.</div>
    <button class="btn btn-primary" onclick="aiGo('${_jsq(cardId)}')">실행 (여기서 과금)</button>
    <button class="btn" onclick="aiCancel('${_jsq(cardId)}')">취소</button>
  </div>`;
}

function _aiReportHtml(cardId, rep) {
  const out = [];

  // ── 두괄식. 결론이 먼저다 — 절을 여덟 개 읽어야 요지를 알면 아무도 안 읽는다.
  const sum = rep.summary || {};
  out.push(`<div class="ai-top">
    ${rep.grade ? `<span class="ai-grade ${_AI_GRADE_CLS[rep.grade] || 'g3'}">${_esc(rep.grade)}</span>` : ''}
    <div class="ai-headline">${_esc(rep.headline || '')}</div>
    ${sum.verdict ? `<div class="ai-verdict">${_esc(sum.verdict)}</div>` : ''}
    ${(sum.points || []).length ? `<div class="ai-points">${
      sum.points.map((p, i) => `<div class="ai-point sev-${_esc(p.severity || 'info')}">
        <div class="ai-point-lbl">${_esc(p.label)}</div>
        <div class="ai-point-val">${_esc(p.value)}</div>
        ${p.note ? `<div class="ai-point-note">${_esc(p.note)}</div>` : ''}
      </div>`).join('')}</div>` : ''}
  </div>`);

  const vis = rep.visuals || {};
  (rep.sections || []).forEach((sec, si) => {
    const claims = sec.claims || [];
    const charts = (vis[sec.id] || []).map(_aiVisual).join('');
    out.push(`<div class="ai-sec"><div class="ai-sec-title">${_esc(sec.title || '')}</div>` +
      charts +
      (claims.length
        ? `<div class="ai-claims">${claims.map((cl, ci) =>
            `<div class="ai-claim sev-${_esc(cl.severity || 'info')}">
               <span class="ai-sev">${_esc(_AI_SEV_LBL[cl.severity] || '참고')}</span>
               <span class="ai-claim-t">${_esc(cl.text)}</span>
               ${_aiEvHtml(cardId, si, ci, cl.evidence)}
             </div>`).join('')}</div>`
        : (charts ? '' : `<div class="ai-hint">근거를 댈 수 있는 내용이 없었습니다.</div>`)) +
      '</div>');
  });

  const u = rep.usage || {};
  out.push(`<div class="ai-meta">
    <span>${_esc(rep.model || '')}</span>
    <span>입력 ${_n(u.input)} · 출력 ${_n(u.output)}${u.cache_read ? ' · 캐시읽기 ' + _n(u.cache_read) : ''}</span>
    <span>판정 대상 ${_n(rep.judged_rows)}행 기준</span>
    ${rep.dropped_claims ? `<span title="근거를 대지 못해 서버가 버렸습니다">버린 주장 ${_n(rep.dropped_claims)}</span>` : ''}
    ${rep.saved === false ? '<span>⚠ 저장 실패 — 창을 닫으면 사라집니다</span>' : ''}
  </div>
  <div class="ai-warn">⚠ AI 생성 — 검토가 필요합니다. 도표는 서버가 같은 재료에서 직접 만든 것이고,
    각 문장의 근거 칩을 누르면 그 목록으로 갑니다.</div>`);
  return out.join('');
}

/* ── 도표 — **서버가 만든 것을 그리기만 한다** ─────────────────────────────
   숫자를 모델에게 그리게 하면 「AI는 숫자를 세지 않는다」가 정면으로 깨진다.
   그리고 **그림은 글보다 더 믿긴다** — 틀린 막대는 틀린 문장보다 오래 남는다. */
function _aiVisual(v) {
  const head = v.title ? `<div class="ai-v-title">${_esc(v.title)}</div>` : '';
  const foot = v.note ? `<div class="ai-v-note">${_esc(v.note)}</div>` : '';
  let body = '';
  if (v.type === 'kpi')         body = _aiVKpi(v);
  else if (v.type === 'funnel') body = _aiVFunnel(v);
  else if (v.type === 'bar')    body = _aiVBar(v);
  else if (v.type === 'line')   body = _aiVLine(v);
  else if (v.type === 'table')  body = _aiVTable(v);
  else return '';
  return `<div class="ai-v">${head}${body}${foot}</div>`;
}

function _aiVKpi(v) {
  return `<div class="ai-kpis">${(v.items || []).map(i => `
    <div class="ai-kpi ${i.tone === 'warn' ? 'warn' : ''}">
      <div class="ai-kpi-lbl">${_esc(i.label)}</div>
      <div class="ai-kpi-val">${_n(i.value)}<span class="ai-kpi-u">${_esc(i.unit || '')}</span></div>
      ${i.sub ? `<div class="ai-kpi-sub">${_esc(i.sub)}</div>` : ''}
    </div>`).join('')}</div>`;
}

/* 원본에서 판정 대상까지 무엇이 얼마나 빠졌는가. **1절을 «보고»로 만드는 그림이다** —
   없으면 「9,995행을 검사했다」로 읽힌다. */
function _aiVFunnel(v) {
  const steps = v.steps || [];
  const max = Math.max(...steps.map(s => s.value || 0), 1);
  return `<div class="ai-funnel">${steps.map(s => `
    <div class="ai-fn-row ${s.drop ? 'drop' : ''} ${s.final ? 'final' : ''}">
      <span class="ai-fn-lbl">${_esc(s.label)}</span>
      <span class="ai-fn-track"><span class="ai-fn-fill" style="width:${(s.value / max * 100).toFixed(1)}%"></span></span>
      <span class="ai-fn-val">${s.drop ? '−' : ''}${_n(s.value)}</span>
    </div>`).join('')}</div>`;
}

function _aiVBar(v) {
  const items = v.items || [];
  const max = Math.max(...items.map(i => i.value || 0), 1);
  return `<div class="ai-bars">${items.map(i => {
    const meta = i.check_no != null ? CHECK_META.find(c => String(c.no) === String(i.check_no)) : null;
    const col = meta ? meta.ckC : (i.me ? 'var(--accent)' : 'var(--ck-blue)');
    return `<div class="ai-bar-row ${i.me ? 'me' : ''}">
      <span class="ai-bar-lbl" title="${_esc(i.label + (i.sub ? ' · ' + i.sub : ''))}">${_esc(i.label)}${
        i.sub ? ` <span class="ai-bar-sub">${_esc(i.sub)}</span>` : ''}</span>
      <span class="ai-bar-track"><span class="ai-bar-fill" style="width:${(i.value / max * 100).toFixed(1)}%;background:${col}"></span></span>
      <span class="ai-bar-val">${_n(i.value)}${_esc(v.unit || '')}</span>
    </div>`;
  }).join('')}</div>`;
}

/* 추이는 **결함률**이다. 건수로 그리면 물량이 는 날이 «악화»로 보인다. */
function _aiVLine(v) {
  const series = (v.series || []).filter(s => (s.points || []).length >= 2);
  if (!series.length) return '';
  const xs = [...new Set(series.flatMap(s => s.points.map(p => p.x)))].sort();
  const maxY = Math.max(...series.flatMap(s => s.points.map(p => p.y || 0)), 1);
  const W = 100, H = 34, PAD = 2;
  const xpos = x => xs.length < 2 ? W / 2 : PAD + xs.indexOf(x) / (xs.length - 1) * (W - PAD * 2);
  const ypos = y => H - PAD - (y / maxY) * (H - PAD * 2);
  const paths = series.map((s, si) => {
    const meta = s.check_no != null ? CHECK_META.find(c => String(c.no) === String(s.check_no)) : null;
    const col = meta ? meta.ckC : ['var(--accent)', 'var(--ck-blue)', 'var(--ck-orange)',
                                   'var(--ck-purple)', 'var(--ck-teal)', 'var(--ck-rose)'][si % 6];
    const pts = s.points.map(p => `${xpos(p.x).toFixed(2)},${ypos(p.y).toFixed(2)}`).join(' ');
    const dots = s.points.map(p =>
      `<circle cx="${xpos(p.x).toFixed(2)}" cy="${ypos(p.y).toFixed(2)}" r="0.7" fill="${col}">
         <title>${_esc(p.x)} · ${p.y}% (${_n(p.n)}/${_n(p.d)})</title></circle>`).join('');
    return { col, label: s.label,
             svg: `<polyline points="${pts}" fill="none" stroke="${col}" stroke-width="0.7"
                     stroke-linejoin="round" vector-effect="non-scaling-stroke"/>${dots}` };
  });
  return `<div class="ai-line">
    <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" class="ai-line-svg">
      <line x1="0" y1="${H - PAD}" x2="${W}" y2="${H - PAD}" stroke="var(--border-sub)" stroke-width="0.3"/>
      ${paths.map(p => p.svg).join('')}
    </svg>
    <div class="ai-line-ax"><span>${_esc(xs[0])}</span><span>최대 ${maxY}${_esc(v.unit || '')}</span><span>${_esc(xs[xs.length - 1])}</span></div>
    <div class="ai-line-lg">${paths.map(p =>
      `<span class="ai-line-key"><i style="background:${p.col}"></i>${_esc(p.label)}</span>`).join('')}</div>
  </div>`;
}

function _aiVTable(v) {
  return `<div class="ai-tblwrap"><table class="ai-tbl">
    <thead><tr>${(v.columns || []).map(c => `<th>${_esc(c)}</th>`).join('')}</tr></thead>
    <tbody>${(v.rows || []).map(r =>
      `<tr>${r.map(c => `<td>${_esc(c == null ? '' : c)}</td>`).join('')}</tr>`).join('')}</tbody>
  </table></div>`;
}

/* 근거 칩 — **누르면 그 숫자로 돌아간다.**
   근거를 달게만 하고 확인할 길을 안 주면 읽는 사람은 그럴듯한 문장을 그냥 믿는다. */
const _AI_EV_ROUTABLE = ['check', 'department', 'team', 'welder', 'block', 'wps', 'material', 'row'];

function _aiEvHtml(cardId, si, ci, ev) {
  if (!ev) return '';
  const label = String(ev.label || '').trim();
  const value = String(ev.value || '').trim();
  if (!label && !value) return '';
  const txt = (label && value) ? `${label} · ${value}` : (label || value);
  const can = _AI_EV_ROUTABLE.indexOf(String(ev.kind)) >= 0;
  const tip = can ? '눌러서 근거가 된 목록으로 이동' : '참고 수치 (이동할 목록이 없습니다)';
  return `<button class="${can ? 'ai-ev' : 'ai-ev flat'}" title="${_esc(tip)}" ${can
    ? `onclick="aiEv('${_jsq(cardId)}',${si},${ci})"` : 'disabled'}>${_esc(txt)}</button>`;
}

/* 문자열에서 «아는 값»을 골라낸다. 모델이 「Q520-해양내업생산부의 T1팀」처럼
   말을 붙여 보내도 실제로 있는 이름을 집는다. 없으면 null —
   **없는 것을 억지로 열지 않는다.** */
function _aiPick(text, candidates) {
  const s = String(text || '');
  let best = null;
  (candidates || []).forEach(c => {
    if (c && s.indexOf(c) >= 0 && (!best || c.length > best.length)) best = c;
  });
  return best;
}

function aiEv(cardId, si, ci) {
  const c = AIC.cards[cardId];
  const rep = c && c.state.report;
  if (!rep) return;
  const cl = ((rep.sections || [])[si] || {}).claims || [];
  const ev = (cl[ci] || {}).evidence;
  if (!ev) return;

  const label = String(ev.label || '');
  const both  = label + ' ' + String(ev.value || '');
  const depts = Object.keys((S.result && S.result.departments) || {});

  switch (String(ev.kind)) {
    case 'check': {
      const m = (String(ev.check_no || '').match(/\d+/) || both.match(/\d+/));
      if (m) openCheckListModal(Number(m[0]),
                                _aiPick(both, depts) || (c.scope && c.scope.dept) || '',
                                (c.scope && c.scope.team) || '');
      return;
    }
    case 'row': {
      const m = both.match(/\d+/);
      if (m) openFlagDetail(Number(m[0]));
      return;
    }
    case 'welder': {
      const nos = (S.welderRows || []).map(w => w.welder_no);
      const w = _aiPick(both, nos) || (c.scope && c.scope.welder);
      if (!w) return;
      setView('welders');
      openWelderDetail(w);
      return;
    }
    case 'department':
    case 'team': {
      const dept = _aiPick(both, depts) || String(ev.dept || '') || (c.scope && c.scope.dept);
      if (!dept || !depts.includes(dept)) return;
      setView('dept-dashboard');
      selectDeptDashDept(dept);
      const teams = Object.keys(((S.result.departments || {})[dept] || {}).teams || {});
      const team = _aiPick(both, teams);
      if (team) selectDeptDashTeam(team);
      return;
    }
    default: {
      // 블록 · WPS · 재질 — 상세 결과의 검색으로 보낸다.
      // 검색 열은 서버가 고른다(`_FLAG_SEARCH_COLS`) — 화면에서 따로 거르지 않는다.
      if (!label) return;
      setView('results');
      const box = document.getElementById('txt-filter');
      if (box) { box.value = label; filterResults(); }
    }
  }
}

/* ── AI 분석 설정 ─────────────────────────────────────────────────────────
   **키는 화면으로 내려오지 않는다.** 서버가 주는 것은 «설정됨» 여부와 앞 6자
   힌트뿐이다. 입력칸은 언제나 비어 있고, 비운 채로 저장하면 키는 그대로 두고
   모델만 바뀐다 — 모델을 바꿀 때마다 키를 다시 넣게 만들면 사람들이 키를
   메모장에 적어 둔다. */
const AI = { models: [], configured: false };

function _aiModelOptions(sel) {
  return AI.models.map(m =>
    `<option value="${_esc(m.id)}" ${m.id === sel ? 'selected' : ''}>${_esc(m.label)}</option>`
  ).join('');
}

/* 고른 모델의 «창»과 «단가»를 옆에 적는다. 기본(Haiku 4.5)만 창이 200K라,
   적어 두지 않으면 왜 상한에 걸리는지 알 수 없다. */
function _aiModelNote(id) {
  const m = AI.models.find(x => x.id === id);
  if (!m) return '';
  return `창 ${_n(m.context)} 토큰 · 입력 $${m.in_price}/M · 출력 $${m.out_price}/M`;
}

function _aiSyncNotes() {
  [['ai-model-deep', 'ai-model-deep-note'],
   ['ai-model-report', 'ai-model-report-note'],
   ['ai-model-chat', 'ai-model-chat-note']].forEach(([sel, note]) => {
    const s = document.getElementById(sel), n = document.getElementById(note);
    if (s && n) n.textContent = _aiModelNote(s.value);
  });
}

async function loadAiSettings() {
  let d;
  try {
    d = await _adminFetch('/api/settings/ai');
  } catch (e) {
    // 404면 이 서버에 아직 AI 엔드포인트가 없다 — **모델 목록이 비는 이유가
    // 이것이다.** 선택 상자가 비어 있는 것만 보면 «목록을 못 만들었나» 싶지만
    // 실제로는 설정을 물어볼 주소 자체가 없는 것이다.
    AIC.stale = !!(e && e.status === 404);
    const sdk = document.getElementById('ai-sdk-note');
    if (sdk) {
      sdk.innerHTML = AIC.stale
        ? '<b style="color:var(--ck-red)">⚠ ' + _esc(AI_STALE_MSG) + '</b>'
        : '설정을 불러오지 못했습니다: ' + _esc(e.message);
    }
    console.warn('ai settings load error:', e.message);
    return;
  }
  AI.models = d.models || [];
  AI.configured = !!d.configured;

  [['ai-model-deep', d.model_deep], ['ai-model-report', d.model_report],
   ['ai-model-chat', d.model_chat]].forEach(([id, val]) => {
    const el = document.getElementById(id);
    if (el) { el.innerHTML = _aiModelOptions(val); el.onchange = _aiSyncNotes; }
  });
  _aiSyncNotes();

  const hint = document.getElementById('ai-key-hint');
  if (hint) hint.textContent = d.configured ? `현재: ${d.key_hint}` : '아직 등록되지 않았습니다';
  const sdk = document.getElementById('ai-sdk-note');
  if (sdk) {
    sdk.innerHTML = d.sdk_available
      ? '키를 등록하면 각 탭의 <b>AI 분석</b> 단추가 켜집니다. 단추를 누를 때만 호출됩니다 — 저절로 도는 것은 없습니다.'
      : '<b style="color:var(--ck-orange)">anthropic 패키지가 설치돼 있지 않습니다.</b> ' +
        '<code>pip install anthropic</code> 후 서버를 다시 띄우세요.';
  }
  _aiSyncChip();
}

function toggleAiKeyVisible() {
  const el = document.getElementById('ai-key');
  if (!el) return;
  el.type = el.type === 'password' ? 'text' : 'password';
  const eye = document.getElementById('ai-key-eye');
  if (eye) eye.textContent = el.type === 'password' ? '👁' : '🙈';
}

function _aiMsg(text, ok) {
  const el = document.getElementById('ai-save-msg');
  if (!el) return;
  el.style.color = ok ? 'var(--ck-green)' : 'var(--ck-red)';
  el.textContent = text;
}

async function saveAiSettings() {
  const keyEl = document.getElementById('ai-key');
  const key = keyEl ? keyEl.value.trim() : '';
  const body = {
    model_deep:   document.getElementById('ai-model-deep').value,
    model_report: document.getElementById('ai-model-report').value,
    model_chat:   document.getElementById('ai-model-chat').value,
  };
  // **빈 값은 «바꾸지 않음»이다.** 빈 문자열을 보내면 키가 지워진다.
  if (key) body.api_key = key;

  _aiMsg('저장 중…', true);
  try {
    const d = await _adminFetch('/api/settings/ai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (keyEl) keyEl.value = '';        // 화면에 남겨 두지 않는다
    const p = d.probe || {};
    _aiMsg((p.ok ? '✓ 저장 · ' : '✓ 저장 (연결 실패) · ') + (p.message || ''), !!p.ok);
    await loadAiSettings();
    // 급별 모델이 바뀌었으므로 카드가 고르는 기본값도 다시 받아야 한다.
    // 안 하면 설정은 바뀌었는데 카드는 옛 모델을 보여 준다.
    await aiLoadModels();
  } catch (e) {
    _aiMsg('저장 실패: ' + _aiErr(e), false);
  }
}

async function testAiSettings() {
  _aiMsg('시험 중…', true);
  try {
    const d = await _adminFetch('/api/settings/ai/test', { method: 'POST' });
    _aiMsg((d.ok ? '✓ ' : '⚠ ') + (d.message || ''), !!d.ok);
  } catch (e) {
    _aiMsg('시험 실패: ' + _aiErr(e), false);
  }
}

/* 헤더 칩 — 상태만 보여주고 누르면 설정 탭으로 보낸다.
   관리자가 아니면 «미설정»을 알려도 할 수 있는 일이 없으므로 숨긴다. */
function _aiSyncChip() {
  const chip = document.getElementById('ai-status-chip');
  if (!chip) return;
  const isAdmin = localStorage.getItem('qc_is_admin') === '1';
  if (!isAdmin || AI.configured) { chip.style.display = 'none'; return; }
  chip.style.display = '';
  chip.className = 'excel-status-chip';
  chip.textContent = '🔑 AI 키 미설정';
  chip.title = '누르면 설정 탭으로 갑니다';
}

function renderEmployeeTable(employees) {
  const tbody = document.getElementById('emp-tbody');
  if (!tbody) return;
  tbody.innerHTML = employees.map(e => `
    <tr>
      <td class="mono" style="font-weight:600">${_esc(e.id)}</td>
      <td>${e.admin ? '<span class="emp-admin-badge">관리자</span>' : '<span style="color:var(--text-3)">일반</span>'}</td>
      <td><button class="emp-del-btn" onclick="deleteEmployee('${_jsq(e.id)}')">삭제</button></td>
    </tr>
  `).join('');
}

async function addEmployee() {
  const input   = document.getElementById('new-emp-id');
  const adminCb = document.getElementById('new-emp-admin');
  const errEl   = document.getElementById('settings-emp-error');
  const id = (input.value || '').trim();
  errEl.textContent = '';
  if (!id) { errEl.textContent = '사번을 입력하세요'; return; }
  try {
    const data = await _adminFetch('/api/settings/employees', {
      method:  'POST',
      headers: {'Content-Type': 'application/json'},
      body:    JSON.stringify({id, admin: adminCb.checked}),
    });
    renderEmployeeTable(data.employees || []);
    input.value = '';
    adminCb.checked = false;
  } catch (e) {
    errEl.textContent = e.message;
  }
}

async function deleteEmployee(id) {
  if (!confirm(`사번 '${id}'를 삭제하시겠습니까?`)) return;
  const errEl = document.getElementById('settings-emp-error');
  try {
    const data = await _adminFetch(`/api/settings/employees/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    });
    renderEmployeeTable(data.employees || []);
  } catch (e) {
    errEl.textContent = e.message;
  }
}

function renderRecipientChips() {
  const box = document.getElementById('recipient-chips');
  if (!box) return;
  box.innerHTML = S.recipients.map(r => `
    <span class="chip-recipient">${_esc(r)}<span class="rm" onclick="removeRecipient('${_jsq(r)}')">✕</span></span>
  `).join('');
}

function addRecipient() {
  const input = document.getElementById('new-recipient');
  const email = (input.value || '').trim();
  if (!email) return;
  if (!S.recipients.includes(email)) S.recipients.push(email);
  input.value = '';
  renderRecipientChips();
}

function removeRecipient(email) {
  S.recipients = S.recipients.filter(r => r !== email);
  renderRecipientChips();
}

async function saveOutlookSettings() {
  const enabled = document.getElementById('outlook-enabled').checked;
  const msgEl   = document.getElementById('outlook-save-msg');
  try {
    await _adminFetch('/api/settings/outlook', {
      method:  'POST',
      headers: {'Content-Type': 'application/json'},
      body:    JSON.stringify({enabled, recipients: S.recipients}),
    });
    msgEl.textContent = '✓ 저장되었습니다';
    setTimeout(() => { msgEl.textContent = ''; }, 2500);
  } catch (e) {
    msgEl.style.color = 'var(--ck-red)';
    msgEl.textContent = '저장 실패: ' + e.message;
  }
}

/* ── 어느 프로젝트 서버를 보고 있는가 ────────────────────────────────────────

   데이터 폴더가 프로젝트별로 갈라진 뒤로 같은 PC에 서버 둘(8001·8002)이 동시에
   뜬다. 두 창은 생김새가 완전히 같아서, **틀린 창에 파일을 올리면 남의 프로젝트
   결과를 덮어쓴다** — 되돌릴 방법이 없고, 올린 사람은 알 수가 없다.

   전환 자리가 **두 곳**이어야 한다:

     로그인 화면   처음 들어오는 사람
     상단 배지     이미 로그인해 둔 사람 — 로그인 화면을 아예 지나가지 않는다

   랜딩 앱(8000)에만 두면 8001을 즐겨찾기에 넣은 사람은 선택 화면을 영원히 못
   보고, «프로젝트를 고른다»는 개념 자체를 모른 채 쓴다. 실제로 그렇게 됐다.

   생사 판정은 서버가 대신 해 준 것을 쓴다 — 브라우저에서 다른 포트를 직접
   부르면 CORS에 걸려 «꺼졌다»와 «막혔다»를 구분할 수 없다. */
let PROJECTS = [];

/* 이름만 남긴다. 데이터 폴더 경로·포트·«지금 이 서버»는 **관리자 정보**라
   고르는 자리에서는 소음이다 — 지금 어느 서버인지는 초록 테두리가 말해 주고,
   포트는 주소창에 이미 있다.

   **«중지됨»만은 남긴다.** 이건 설명이 아니라 «누를 수 없다»는 사실이고,
   없으면 흐린 줄이 왜 안 눌리는지 알 방법이 없다. */
function _projRowsHtml(cls) {
  const here = String(location.port || '80');
  return PROJECTS.map(p => {
    const cur = String(p.port) === here;
    const inner = '<span class="lp-name">' + _esc(p.project || p.name) + '</span>'
                + (p.up ? '' : '<span class="lp-note">중지됨</span>');
    if (cur) return '<div class="' + cls + ' lp-cur" aria-current="true">' + inner + '</div>';
    // 꺼진 서버는 링크로 만들지 않는다 — 눌러 봐야 브라우저 오류 화면이 뜨고,
    // 그건 «이 프로그램이 고장났다»로 읽힌다.
    if (!p.up) return '<div class="' + cls + ' lp-down" title="서버가 실행 중이 아닙니다">'
                    + inner + '</div>';
    return '<a class="' + cls + '" href="http://' + location.hostname + ':' + p.port + '/">'
         + inner + '</a>';
  }).join('');
}

function toggleProjectMenu() {
  const m = document.getElementById('server-menu');
  const b = document.getElementById('server-project');
  if (!m || !b) return;
  const open = m.style.display === 'none';
  m.style.display = open ? '' : 'none';
  b.setAttribute('aria-expanded', String(open));
}

/* 바깥을 누르면 닫는다. 열어 둔 채 다른 곳을 눌렀는데 남아 있으면
   «눌리지 않는 화면»처럼 보인다. */
document.addEventListener('click', (e) => {
  const m = document.getElementById('server-menu');
  if (!m || m.style.display === 'none') return;
  if (_closest(e.target, '.srv-wrap')) return;
  m.style.display = 'none';
  const b = document.getElementById('server-project');
  if (b) b.setAttribute('aria-expanded', 'false');
});

/* **로그인 전에 부른다.** 로그인 화면에서도 어느 서버인지 보여야 하기 때문이다. */
async function _loadServerInfo() {
  const badge = document.getElementById('server-project');
  const menu = document.getElementById('server-menu');
  const box = document.getElementById('login-proj');
  const list = document.getElementById('login-proj-list');
  if (!badge) return;

  let info = {}, here = String(location.port || '80');
  try { const r = await fetch('/api/server-info'); if (r.ok) info = await r.json(); }
  catch (e) { /* 못 받아도 앱은 그대로 돈다 */ }
  // 인쇄물 머리말이 «어느 프로젝트의 글인가»를 적어야 한다. 종이에는 배지가 없다.
  S.projectName = info.project || '';
  try {
    const r = await fetch('/api/projects');
    if (r.ok) PROJECTS = (await r.json()).projects || [];
  } catch (e) { PROJECTS = []; }

  // 목록에 이름이 있으면 그것도 쓴다 — 폴더를 안 나눈 서버는 QC_PROJECT가 없어
  // `info.project`가 비지만, projects.json에는 이름이 적혀 있을 수 있다.
  const mine = PROJECTS.find(p => String(p.port) === here) || {};
  const name = info.project || mine.name || '';

  // 고를 것이 하나뿐이고 이름도 없으면 아무것도 띄우지 않는다 — 소음이다.
  if (PROJECTS.length > 1) {
    if (menu) menu.innerHTML = _projRowsHtml('srv-menu-item');
    if (list) list.innerHTML = _projRowsHtml('lp-item');
    if (box) box.style.display = '';
  }
  if (!name && PROJECTS.length < 2) return;

  badge.textContent = name || ('포트 ' + here);
  badge.title = (info.data_root ? '데이터 폴더: ' + info.data_root : '')
              + (info.wps_ref_found === false
                   ? '\n⚠ WPS 참조 파일이 없습니다 — Raw data 폴더를 확인하세요'
                   : (info.wps_ref ? '\nWPS 참조: ' + info.wps_ref : ''))
              + (PROJECTS.length > 1 ? '\n\n클릭하면 다른 프로젝트로 전환합니다' : '');
  if (info.wps_ref_found === false) badge.classList.add('srv-badge-warn');
  if (PROJECTS.length > 1) badge.classList.add('srv-badge-btn');
  else badge.disabled = true;
  badge.style.display = '';
  if (name) document.title = name + ' · QC 자동검증';
}

/* ── 초기화 ─────────────────────────────────────────────────────────────────── */
window.addEventListener('load', async () => {
  _loadServerInfo();   // 로그인 여부와 무관하다 — 기다리지 않는다

  // 로그인 상태 확인
  const savedId = localStorage.getItem('qc_employee_id');
  if (savedId) {
    _applyLogin(savedId, localStorage.getItem('qc_is_admin') === '1');
  }

  aiLoadModels();      // 모델 목록만 받는다 — 과금도 키 노출도 없다
  setView('dashboard');
  // 결과 복원은 _applyLogin() 안에서 한다 — 인증이 붙은 뒤라야 /api/result가 200이다.
  // 저장된 세션이 없으면 로그인 화면이 뜨고, 로그인 성공 시 같은 경로로 복원된다.
  await pollStatus();
});
window.addEventListener('resize', _redrawVisibleCharts);
/* 도식은 다시 그리지 않고 «폭만» 맞춘다 — Mermaid 렌더는 비싸고, 폭 조정은
   viewBox 비율만 바꾸면 되기 때문이다. */
window.addEventListener('resize', () => {
  if (S.view !== 'logic') return;
  document.querySelectorAll('.lg-canvas').forEach(_lgFitSvg);
});

/* ── 그리드 선택 모델 ────────────────────────────────────────────────────────
   포커스(:focus)와 선택은 다른 개념이다. 포커스는 브라우저 창이 활성일 때만 유지되고
   다른 곳을 클릭하면 사라지지만, "지금 보고 있던 행"은 남아 있어야 한다.
   그래서 선택 상태를 클래스로 명시해 관리한다. */
function _selectRow(tr) {
  if (!tr) return;
  const scope = tr.closest('tbody') || document;
  scope.querySelectorAll('tr.is-selected').forEach(el => el.classList.remove('is-selected'));
  tr.classList.add('is-selected');
  // 상태바 우측에 현재 위치를 표시 — 프로그램은 "지금 어디에 있는지"를 항상 알려준다
  const rows = Array.from(scope.querySelectorAll('tr.row-clickable'));
  const i = rows.indexOf(tr);
  const first = (tr.querySelector('td') || {}).textContent || '';
  if (i >= 0) setStatusContext(`${CRUMBS[S.view] || S.view} · 행 ${first.trim()} (${i + 1}/${rows.length})`);
}

/* 이벤트 대상이 항상 Element인 것은 아니다(document/텍스트 노드로 올 수 있음).
   .closest를 바로 부르면 TypeError가 나므로 안전하게 감싼다. */
function _closest(node, sel) {
  return (node && typeof node.closest === 'function') ? node.closest(sel) : null;
}

/* 표의 행을 클릭하면 선택 상태로 표시 (행 클릭 동작 자체는 기존 onclick이 처리) */
document.addEventListener('click', (e) => {
  const tr = _closest(e.target, 'tr.row-clickable');
  if (tr) _selectRow(tr);
}, true);

/* 입력 중에는 단축키를 가로채지 않는다 */
function _isTyping(el) {
  if (!el) return false;
  const t = (el.tagName || '').toLowerCase();
  return t === 'input' || t === 'textarea' || t === 'select' || el.isContentEditable;
}

/* role="button"인 요소(순수 표시용 <div>로 구현된 nav/칩/드롭존)를 키보드로도 조작 가능하게 함.
   더불어 데이터 그리드를 프로그램처럼 다룰 수 있도록 행 단위 키보드 이동을 붙인다 —
   테이블마다 렌더 함수를 고치지 않고, 포커스된 tr을 기준으로 위임 처리한다. */
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    // 모달이 둘이다(상세 결과 / 에이전트). detail-modal만 보면 에이전트 모달은 Esc로
    // 닫히지 않는다. 열려 있는 것을 닫되, 겹쳐 열릴 일이 없으므로 하나만 처리한다.
    const mlu = document.getElementById('mlu-modal');
    if (mlu && mlu.style.display !== 'none') { closeMluModal(); return; }
    const agent = document.getElementById('agent-modal');
    if (agent && agent.style.display !== 'none') { closeAgentModal(); return; }
    const modal = document.getElementById('detail-modal');
    if (modal && modal.style.display !== 'none') closeDetailModal();
    return;
  }

  // '/' — 현재 화면의 첫 검색 입력으로 포커스 이동
  if (e.key === '/' && !_isTyping(e.target)) {
    const scope = document.getElementById('detail-modal');
    const inModal = scope && scope.style.display !== 'none';
    const root = inModal ? scope : document.getElementById('view-' + S.view);
    // type="search"도 포함한다 — 내보내기 탭의 범위 검색이 이 형태다
    const inp = root && root.querySelector('input.f-inp, input[type="text"], input[type="search"]');
    if (inp) { e.preventDefault(); inp.focus(); inp.select(); }
    return;
  }

  // ↑/↓ — 그리드 행 이동. 선택된 행이 기준이며, 없으면 현재 화면의 첫 행부터 시작한다.
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    if (_isTyping(e.target)) return;
    const modal = document.getElementById('detail-modal');
    const root = (modal && modal.style.display !== 'none')
      ? modal : document.getElementById('view-' + S.view);
    if (!root) return;
    let cur = root.querySelector('tr.row-clickable.is-selected');
    if (!cur) {
      cur = _closest(document.activeElement, 'tr.row-clickable');
    }
    let next;
    if (!cur) {
      next = root.querySelector('tr.row-clickable');            // 아직 선택 없음 → 첫 행
    } else {
      const rows = Array.from(cur.parentElement.querySelectorAll('tr.row-clickable'));
      next = rows[rows.indexOf(cur) + (e.key === 'ArrowDown' ? 1 : -1)];
    }
    if (!next) return;
    e.preventDefault();
    _selectRow(next);
    next.focus();
    next.scrollIntoView({ block: 'nearest' });
    return;
  }

  // Enter — 선택된 행의 상세 열기 (포커스가 어디 있든 선택 행 기준)
  if (e.key === 'Enter' && !_isTyping(e.target)) {
    const modal = document.getElementById('detail-modal');
    const root = (modal && modal.style.display !== 'none')
      ? modal : document.getElementById('view-' + S.view);
    const selRow = root && root.querySelector('tr.row-clickable.is-selected');
    if (selRow && !_closest(e.target, '[role="button"]')) {
      e.preventDefault();
      selRow.click();
      return;
    }
  }

  if (e.key !== 'Enter' && e.key !== ' ') return;
  if (_isTyping(e.target)) return;
  const el = _closest(e.target, '[role="button"]');
  if (!el) return;
  e.preventDefault();
  el.click();
});

/* ══ 에이전트 탭 ═══════════════════════════════════════════════════════════════
   검증 서브에이전트의 정의(.claude/agents/*.md)와 실행 리포트를 열람한다.

   서버는 읽기만 한다 — 에이전트 실행은 Claude Code에서 이뤄지고, 각 에이전트가
   작업 마지막에 data/agent_reports/ 아래에 리포트를 남긴다. 이 탭은 그 디렉터리를
   보여줄 뿐이므로, 서버에 실행 버튼이 없어도 이력이 계속 쌓인다. */

const AG = {
  data:    null,   // /api/agents 응답
  filter:  '',     // 에이전트 이름 필터 ('' = 전체)
  loading: false,
};

const _AG_VERDICT = {
  PASS:    { cls: 'ag-v-pass',    label: 'PASS'    },
  FAIL:    { cls: 'ag-v-fail',    label: 'FAIL'    },
  PARTIAL: { cls: 'ag-v-partial', label: 'PARTIAL' },
  UNKNOWN: { cls: 'ag-v-unknown', label: '-'       },
};

function _agVerdictHtml(v) {
  const m = _AG_VERDICT[v] || _AG_VERDICT.UNKNOWN;
  return '<span class="ag-verdict ' + m.cls + '">' + m.label + '</span>';
}

async function loadAgents(force) {
  if (AG.loading) return;
  if (AG.data && !force) { renderAgents(); return; }
  AG.loading = true;
  try {
    const r = await fetch('/api/agents', { headers: _authHeaders() });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    AG.data = await r.json();
    renderAgents();
  } catch (e) {
    // 그리드가 전용/서브 둘로 나뉘어 있다. 한쪽에만 넣으면 다른 쪽이 빈 채로 남아
    // 실패했다는 사실이 화면에 드러나지 않는다.
    const msg = '<div class="ag-empty">에이전트 정보를 불러오지 못했습니다 — ' +
                _esc(String(e.message || e)) + '</div>';
    ['ag-grid-project', 'ag-grid-vendor'].forEach(id => {
      const g = document.getElementById(id);
      if (g) g.innerHTML = id === 'ag-grid-project' ? msg : '';
    });
  } finally {
    AG.loading = false;
  }
}

function renderAgents() {
  const d = AG.data;
  if (!d) return;

  const sub = document.getElementById('ag-bar-sub');
  if (sub) sub.textContent = '정의 ' + d.agents.length + '개 · 실행 이력 ' + d.total_runs + '건';

  const badge = document.getElementById('badge-agents');
  if (badge) {
    badge.textContent = d.total_runs;
    badge.style.display = d.total_runs ? '' : 'none';
  }

  // 전용(project) / 서브(vendor)를 나눠 보여준다. 성격이 달라 같은 잣대로 읽으면 안 된다 —
  // 전용은 이 저장소의 불변식을 담고 있고, 서브는 범용 지침에 제약을 덧댄 것이다.
  const proj = d.agents.filter(a => a.origin === 'project');
  const vend = d.agents.filter(a => a.origin !== 'project');
  _agFillGrid('ag-grid-project', proj, '.claude/agents/ 에 전용 에이전트가 없습니다');
  _agFillGrid('ag-grid-vendor',  vend, '설치된 서브에이전트가 없습니다');
  _agSetHint('ag-hint-project', proj.length,
             '이 프로젝트를 위해 직접 작성 — 이 저장소의 불변식과 함정을 담고 있습니다');
  _agSetHint('ag-hint-vendor', vend.length,
             '외부 컬렉션에서 선별해 설치 — 각 정의 상단의 "이 저장소의 제약" 블록이 원본 지침보다 우선합니다');

  _agRenderFilter();
  _agRenderReports();
}

function _agSetHint(elId, n, text) {
  const el = document.getElementById(elId);
  if (el) el.textContent = n + '개 · ' + text;
}

function _agFillGrid(elId, list, emptyMsg) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.innerHTML = list.length
    ? list.map(_agCardHtml).join('')
    : '<div class="ag-empty">' + _esc(emptyMsg) + '</div>';
}

function _agCardHtml(a) {
  const st = a.stats || {};
  const last = st.runs
    ? _esc(st.last_run) + ' ' + _agVerdictHtml(st.last_verdict)
    : '<span class="ag-never">실행 이력 없음</span>';
  // 읽기 전용(Write/Edit 없음)인지는 이 에이전트가 코드를 고칠 수 있는지와 직결되므로
  // 카드에서 바로 구분되게 한다.
  const perm = a.read_only
    ? '<span class="ag-perm ag-ro" title="Write/Edit 권한이 없어 코드를 수정할 수 없습니다">읽기 전용</span>'
    : '<span class="ag-perm ag-rw" title="Write/Edit 권한이 있어 코드를 수정할 수 있습니다">쓰기 가능</span>';
  return '<div class="ag-card" role="button" tabindex="0" onclick="openAgentDefinition(\'' + _jsq(a.name) + '\')">' +
      '<div class="ag-card-hd"><span class="ag-name">' + _esc(a.name) + '</span>' + perm + '</div>' +
      // 카드에는 한국어 기능 요약을 쓴다. 외부에서 가져온 정의는 description이 영문이라
      // 무슨 일을 하는지 한눈에 읽히지 않는다(원문은 카드를 눌러 정의에서 볼 수 있다).
      '<div class="ag-desc">' + _esc(a.summary || a.description || '(설명 없음)') + '</div>' +
      '<div class="ag-meta"><span>실행 <b>' + (st.runs || 0) + '</b>회</span>' +
        '<span class="ag-dot"></span><span>' + last + '</span></div>' +
    '</div>';
}

function _agRenderFilter() {
  const d = AG.data;
  const names = [...new Set(d.reports.map(r => r.agent))].sort();
  const chip = (val, label, n) =>
    '<span class="chip ' + (AG.filter === val ? 'active' : '') + '" role="button" tabindex="0" ' +
    'onclick="setAgentFilter(\'' + _jsq(val) + '\')">' + _esc(label) + ' <b>' + n + '</b></span>';
  document.getElementById('ag-filter').innerHTML =
    chip('', '전체', d.reports.length) +
    names.map(n => chip(n, n, d.reports.filter(r => r.agent === n).length)).join('');
}

function setAgentFilter(v) {
  AG.filter = v;
  _agRenderFilter();
  _agRenderReports();
}

function _agRenderReports() {
  const d = AG.data;
  const rows = AG.filter ? d.reports.filter(r => r.agent === AG.filter) : d.reports;
  const hint = document.getElementById('ag-hist-hint');
  if (hint) {
    hint.textContent = rows.length
      ? '최신순 ' + rows.length + '건 · 행을 누르면 리포트 전문'
      : '리포트가 없습니다 — 에이전트를 실행하면 ' + d.reports_dir + ' 에 쌓입니다';
  }

  document.getElementById('ag-report-tbody').innerHTML = rows.length
    ? rows.map(r =>
        '<tr class="ag-row" role="button" tabindex="0" onclick="openAgentReport(\'' + _jsq(r.id) + '\')">' +
          '<td class="ag-ts">' + _esc(r.run_at) + '</td>' +
          '<td>' + _esc(r.agent) + '</td>' +
          '<td>' + _agVerdictHtml(r.verdict) + '</td>' +
          '<td class="ag-sum">' + _esc(r.summary || r.preview || '') + '</td>' +
        '</tr>').join('')
    : '<tr><td colspan="4" style="text-align:center;color:var(--text-3);padding:18px">' +
      '아직 실행 리포트가 없습니다</td></tr>';
}

async function openAgentReport(id) {
  _agOpenModal('리포트', id);
  try {
    const r = await fetch('/api/agents/reports/' + encodeURIComponent(id),
                          { headers: _authHeaders() });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const rep = await r.json();
    document.getElementById('agent-modal-title').textContent = rep.agent || id;
    document.getElementById('agent-modal-sub').innerHTML =
      _esc(rep.run_at) + ' ' + _agVerdictHtml(rep.verdict) + ' ' + _esc(rep.summary || '');
    document.getElementById('agent-modal-body').innerHTML =
      '<div class="ag-md">' + _mdToHtml(rep.markdown) + '</div>';
  } catch (e) {
    document.getElementById('agent-modal-body').innerHTML =
      '<div class="ag-empty">리포트를 불러오지 못했습니다 — ' + _esc(String(e.message || e)) + '</div>';
  }
}

async function openAgentDefinition(name) {
  _agOpenModal('에이전트 정의', name);
  try {
    const r = await fetch('/api/agents/definition/' + encodeURIComponent(name),
                          { headers: _authHeaders() });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const def = await r.json();
    document.getElementById('agent-modal-title').textContent = def.name;
    document.getElementById('agent-modal-sub').textContent =
      // 카드에서는 한국어 요약을 보여주므로, 정의를 열었을 때는 원문 description을 함께 보여준다
      (def.description ? def.description + '  —  ' : '') +
      (def.model ? 'model ' + def.model + ' · ' : '') + 'tools: ' + (def.tools.join(', ') || '-');
    document.getElementById('agent-modal-body').innerHTML =
      '<div class="ag-md">' + _mdToHtml(def.markdown) + '</div>';
  } catch (e) {
    document.getElementById('agent-modal-body').innerHTML =
      '<div class="ag-empty">정의를 불러오지 못했습니다 — ' + _esc(String(e.message || e)) + '</div>';
  }
}

function _agOpenModal(kind, subtitle) {
  document.getElementById('agent-modal-title').textContent = kind;
  document.getElementById('agent-modal-sub').textContent = subtitle;
  document.getElementById('agent-modal-body').innerHTML = '<div class="ag-empty">불러오는 중…</div>';
  document.getElementById('agent-modal').style.display = 'flex';
}

function closeAgentModal() {
  document.getElementById('agent-modal').style.display = 'none';
}

/* 리포트는 에이전트가 쓴 마크다운이다. 외부 라이브러리를 들이지 않으려고 이 앱이 실제로
   쓰는 문법(제목/표/코드블록/목록/굵게/인라인코드/인용)만 직접 변환한다.
   모든 텍스트는 _esc()를 거치므로 리포트 본문이 HTML로 실행되지 않는다. */
function _mdToHtml(md) {
  if (!md) return '<div class="ag-empty">(내용 없음)</div>';

  // 코드블록을 먼저 빼두고 마지막에 되돌린다 — 안쪽이 표/목록으로 오인되지 않게
  const blocks = [];
  let src = String(md).replace(/```[\w-]*\n([\s\S]*?)```/g, (_, code) => {
    blocks.push(code);
    return '\uE000CODE' + (blocks.length - 1) + '\uE000';
  });
  // HTML 주석은 마크다운에서 보이지 않아야 한다. 걷어내지 않으면 _esc()를 거쳐 화면에
  // 그대로 찍힌다 (에이전트 정의의 origin 표식이 실제로 그랬다).
  // 코드블록을 먼저 빼둔 뒤라 코드 안의 주석은 지워지지 않는다.
  src = src.replace(/<!--[\s\S]*?-->/g, '');

  const inline = s => _esc(s)
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

  const out = [];
  const lines = src.split('\n');
  let i = 0;
  let list = null;   // 'ul' | 'ol' | null
  const closeList = () => { if (list) { out.push('</' + list + '>'); list = null; } };

  while (i < lines.length) {
    const line = lines[i];

    // 표: | a | b | 다음 줄이 |---| 인 경우
    if (/^\s*\|/.test(line) && i + 1 < lines.length && /^\s*\|[\s:|-]+\|\s*$/.test(lines[i + 1])) {
      closeList();
      const cells = l => l.trim().replace(/^\||\|$/g, '').split('|').map(c => c.trim());
      const head = cells(line);
      i += 2;
      const body = [];
      while (i < lines.length && /^\s*\|/.test(lines[i])) { body.push(cells(lines[i])); i++; }
      out.push('<div class="ag-tbl-wrap"><table class="ag-tbl"><thead><tr>' +
        head.map(h => '<th>' + inline(h) + '</th>').join('') + '</tr></thead><tbody>' +
        body.map(r => '<tr>' + r.map(c => '<td>' + inline(c) + '</td>').join('') + '</tr>').join('') +
        '</tbody></table></div>');
      continue;
    }

    let m;
    if ((m = line.match(/^(#{1,6})\s+(.*)$/))) {
      closeList();
      // 리포트/정의 본문은 frontmatter를 걷어내면 항상 ##부터 시작하므로 그대로 매핑한다
      const lv = Math.min(Math.max(m[1].length, 2), 6);
      out.push('<h' + lv + '>' + inline(m[2]) + '</h' + lv + '>');
    } else if ((m = line.match(/^\s*[-*]\s+(.*)$/))) {
      if (list !== 'ul') { closeList(); out.push('<ul>'); list = 'ul'; }
      out.push('<li>' + inline(m[1]) + '</li>');
    } else if ((m = line.match(/^\s*\d+\.\s+(.*)$/))) {
      if (list !== 'ol') { closeList(); out.push('<ol>'); list = 'ol'; }
      out.push('<li>' + inline(m[1]) + '</li>');
    } else if ((m = line.match(/^>\s?(.*)$/))) {
      closeList();
      out.push('<blockquote>' + inline(m[1]) + '</blockquote>');
    } else if (/^\s*---+\s*$/.test(line)) {
      closeList();
      out.push('<hr>');
    } else if (line.trim() === '') {
      closeList();
    } else {
      closeList();
      out.push('<p>' + inline(line) + '</p>');
    }
    i++;
  }
  closeList();

  return out.join('\n').replace(/\uE000CODE(\d+)\uE000/g,
    (_, n) => '<pre class="ag-code">' + _esc(blocks[+n]) + '</pre>');
}

/* ══ 현업 검증사항 탭 ═══════════════════════════════════════════════════════════
   QC_검사로직_상세분석.md §11과 양방향으로 붙어 있다.

   - 조회: 서버가 매 요청마다 문서를 다시 판다. 문서를 손으로 고쳐도 새로고침이면 반영된다.
   - 등록: 답변을 쓰면 그 항목 밑에 `#### [x] 현업 답변(...)` 블록으로 문서에 기록된다.
     문서 파일에 접근할 수 없는 현업 담당자가 답변을 남기게 하는 것이 이 탭의 목적이다.

   서버는 헤딩의 상태 표기를 바꾸지 않는다 — 답변이 왔다고 자동으로 '완료'가 되면
   판정 코드는 그대로인데 종결된 것처럼 보이기 때문이다. 그래서 답변이 달렸지만
   헤딩이 아직 완료가 아닌 항목은 '반영 대기'로 따로 표시한다. */

const RV = {
  data:    null,
  filter:  'all',   // all | open | provisional | done | followup
  editing: null,    // 답변 입력 폼이 열려 있는 항목 id
  loading: false,
};

const _RV_MARK = {
  ' ': { cls: 'rv-m-open', label: '미결' },
  '~': { cls: 'rv-m-prov', label: '잠정결론' },
  'x': { cls: 'rv-m-done', label: '완료' },
};

function _rvMarkHtml(mark) {
  const m = _RV_MARK[mark] || { cls: 'rv-m-open', label: mark };
  return '<span class="rv-mark ' + m.cls + '">' + m.label + '</span>';
}

async function loadReviewItems(force) {
  if (RV.loading) return;
  if (RV.data && !force) { renderReviewItems(); return; }
  RV.loading = true;
  try {
    RV.data = await apiFetch('/api/review-items');
    renderReviewItems();
  } catch (e) {
    document.getElementById('rv-list').innerHTML =
      '<div class="ag-empty">확인 필요 사항을 불러오지 못했습니다 — ' +
      _esc(String(e.message || e)) + '</div>';
  } finally {
    RV.loading = false;
  }
}

function renderReviewItems() {
  const d = RV.data;
  if (!d) return;
  const c = d.counts;

  const sub = document.getElementById('rv-bar-sub');
  if (sub) sub.textContent = '전체 ' + c.total + '건 · 미결 ' + c.open +
                             ' · 잠정 ' + c.provisional + ' · 완료 ' + c.done;

  const badge = document.getElementById('badge-review');
  if (badge) {
    const pending = c.open + c.provisional;
    badge.textContent = pending;
    badge.style.display = pending ? '' : 'none';
  }

  // 문서가 정본이라는 사실과, 지금 보고 있는 파일의 상태를 명시한다
  const doc = d.doc || {};
  document.getElementById('rv-doc-note').innerHTML = doc.exists
    ? '이 목록은 <code>' + _esc(doc.path) + '</code> 의 <b>§11</b>을 그대로 읽은 것입니다 · ' +
      '문서 최종 수정 ' + _esc(doc.mtime) + ' · ' +
      '여기서 남긴 답변은 그 문서에 기록되고, 문서를 직접 고쳐도 새로고침하면 여기에 반영됩니다'
    : '<b>분석 문서를 찾을 수 없습니다.</b> ' + _esc(doc.path || '');

  document.getElementById('rv-kpi').innerHTML = [
    { lbl: '미결',      val: c.open,        c: 'var(--ck-orange)', f: 'open' },
    { lbl: '잠정결론',  val: c.provisional, c: 'var(--ck-amber)',  f: 'provisional' },
    { lbl: '완료',      val: c.done,        c: 'var(--ck-green)',  f: 'done' },
    { lbl: '반영 대기', val: c.needs_followup, c: 'var(--ck-brown)', f: 'followup',
      sub: '답변 접수 · 헤딩/코드 반영 전' },
  ].map(k =>
    '<div class="rv-kpi-card" role="button" tabindex="0" onclick="setReviewFilter(\'' + _jsq(k.f) + '\')">' +
      '<div class="rv-kpi-lbl">' + _esc(k.lbl) + '</div>' +
      '<div class="rv-kpi-val" style="color:' + k.c + '">' + k.val + '</div>' +
      '<div class="rv-kpi-sub">' + _esc(k.sub || '') + '</div>' +
    '</div>').join('');

  _rvRenderFilter();
  _rvRenderList();
}

function _rvRenderFilter() {
  const d = RV.data, c = d.counts;
  const chip = (v, label, n) =>
    '<span class="chip ' + (RV.filter === v ? 'active' : '') + '" role="button" tabindex="0" ' +
    'onclick="setReviewFilter(\'' + _jsq(v) + '\')">' + _esc(label) + ' <b>' + n + '</b></span>';
  document.getElementById('rv-filter').innerHTML =
    chip('all', '전체', c.total) +
    chip('open', '미결', c.open) +
    chip('provisional', '잠정결론', c.provisional) +
    chip('done', '완료', c.done) +
    chip('followup', '반영 대기', c.needs_followup);
}

function setReviewFilter(v) {
  RV.filter = v;
  _rvRenderFilter();
  _rvRenderList();
}

function _rvVisible() {
  const items = (RV.data && RV.data.items) || [];
  switch (RV.filter) {
    case 'open':        return items.filter(i => i.mark === ' ');
    case 'provisional': return items.filter(i => i.mark === '~');
    case 'done':        return items.filter(i => i.mark === 'x');
    case 'followup':    return items.filter(i => i.needs_followup);
    default:            return items;
  }
}

function _rvRenderList() {
  const rows = _rvVisible();
  document.getElementById('rv-list').innerHTML = rows.length
    ? rows.map(_rvItemHtml).join('')
    : '<div class="ag-empty">해당하는 항목이 없습니다</div>';
}

function _rvItemHtml(it) {
  const open = RV.editing === it.id;
  const ans = it.answer;

  const answerBlock = ans
    ? '<div class="rv-answer">' +
        '<div class="rv-answer-hd">현업 답변' +
          '<span class="rv-answer-meta">' + _esc(ans.answered_on) +
          (ans.author ? ' · ' + _esc(ans.author) : '') + '</span>' +
        '</div>' +
        '<div class="rv-answer-body">' + _mdToHtml(ans.text) + '</div>' +
      '</div>'
    : '';

  const followup = it.needs_followup
    ? '<div class="rv-followup">답변이 접수됐습니다. 헤딩 상태 동기화와 판정 코드 반영은 ' +
      '담당자가 확인 후 진행합니다.</div>'
    : '';

  const form = open
    ? '<div class="rv-form">' +
        '<label class="rv-lbl">결론 <span class="rv-req">필수</span></label>' +
        '<textarea id="rv-conclusion" class="rv-input" rows="3" ' +
          'placeholder="무엇으로 확정되었는지 적어주세요"></textarea>' +
        '<label class="rv-lbl">비고</label>' +
        '<textarea id="rv-remark" class="rv-input" rows="2" ' +
          'placeholder="추가 설명이 있으면 적어주세요 (선택)"></textarea>' +
        '<label class="rv-lbl">답변자 <span class="rv-req">필수</span></label>' +
        '<input id="rv-author" class="rv-input" type="text" placeholder="이름 또는 사번">' +
        '<div class="rv-form-btns">' +
          '<button class="btn btn-primary" onclick="submitReviewAnswer(\'' + _jsq(it.id) + '\')">문서에 기록</button>' +
          '<button class="btn" onclick="toggleReviewForm(null)">취소</button>' +
          '<span class="rv-form-hint">기록하면 분석 문서 §11의 이 항목 밑에 답변 블록이 추가됩니다</span>' +
        '</div>' +
      '</div>'
    : '';

  return '<div class="rv-item" id="rv-item-' + _esc(it.id) + '">' +
      '<div class="rv-hd">' +
        '<span class="rv-id">' + _esc(it.id) + '</span>' +
        _rvMarkHtml(it.mark) +
        '<span class="rv-title">' + _esc(it.title) + '</span>' +
        (it.needs_followup ? '<span class="rv-tag">반영 대기</span>' : '') +
      '</div>' +
      (it.status_text ? '<div class="rv-status">' + _esc(it.status_text) + '</div>' : '') +
      '<div class="rv-body">' + _mdToHtml(it.body) + '</div>' +
      answerBlock + followup +
      '<div id="ai-rv-' + _esc(it.id) + '"></div>' +
      (open ? form :
        '<div class="rv-actions">' +
          '<button class="btn btn-sm" onclick="toggleReviewForm(\'' + _jsq(it.id) + '\')">' +
          (ans ? '답변 수정' : '현업 답변 남기기') + '</button>' +
          '<button class="btn btn-sm" onclick="aiShow(\'rv-' + _jsq(it.id) +
            '\',\'review\',{item:\'' + _jsq(it.id) + '\'},\'ai-rv-' + _jsq(it.id) +
            '\')">🧠 AI 답변 초안</button>' +
          (ans ? '<span class="rv-form-hint">수정하면 기존 답변을 대체합니다 (이전 내용은 git 이력에 남습니다)</span>' : '') +
        '</div>') +
    '</div>';
}

function toggleReviewForm(id) {
  RV.editing = (RV.editing === id) ? null : id;
  _rvRenderList();
  if (RV.editing) {
    const it = (RV.data.items || []).find(x => x.id === RV.editing);
    // 수정이면 기존 내용을 미리 채워준다 — 처음부터 다시 쓰게 하지 않는다
    if (it && it.answer) {
      const t = it.answer.text || '';
      const mc = t.match(/^결론:\s*([\s\S]*?)(?:\n비고:|$)/);
      const mr = t.match(/\n비고:\s*([\s\S]*)$/);
      const ce = document.getElementById('rv-conclusion');
      const re = document.getElementById('rv-remark');
      const ae = document.getElementById('rv-author');
      if (ce) ce.value = mc ? mc[1].trim() : t.trim();
      if (re) re.value = mr ? mr[1].trim() : '';
      if (ae) ae.value = it.answer.author || '';
    }
    const el = document.getElementById('rv-item-' + RV.editing);
    if (el) el.scrollIntoView({ block: 'nearest' });
    const first = document.getElementById('rv-conclusion');
    if (first) first.focus();
  }
}

async function submitReviewAnswer(id) {
  const conclusion = (document.getElementById('rv-conclusion') || {}).value || '';
  const remark     = (document.getElementById('rv-remark') || {}).value || '';
  const author     = (document.getElementById('rv-author') || {}).value || '';
  if (!conclusion.trim()) { alert('결론 내용을 입력하세요'); return; }
  if (!author.trim())     { alert('답변자를 입력하세요'); return; }

  try {
    await apiFetch('/api/review-items/' + encodeURIComponent(id) + '/answer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ conclusion: conclusion, remark: remark, author: author }),
    });
    RV.editing = null;
    await loadReviewItems(true);   // 문서를 다시 읽어 실제 기록된 내용을 보여준다
  } catch (e) {
    alert('문서에 기록하지 못했습니다 — ' + (e.message || e));
  }
}

/* ══ 범위별 내보내기 탭 ═════════════════════════════════════════════════════════
   전체/부서/팀 단위로 결과 Excel을 만들고 받는다.

   생성 비용이 범위마다 크게 달라(작은 부서 약 7초, 큰 부서 약 1분) 서버가 백그라운드로
   만들고 여기서는 상태를 폴링한다. 검증을 다시 돌리면 서버가 기존 파일을 전부 버리므로
   이 화면도 새로고침하면 미생성으로 돌아온다.

   대상 데이터가 커지면 팀 수도 함께 늘어난다. 목록을 스크롤해서 찾는 방식은 그때
   무너지므로 **검색 + 부서 좁히기 + 정렬 + 다중 선택**을 기본으로 둔다. 화면에 한 번에
   그리는 행 수도 제한하고(더 보기), 선택은 화면 밖 항목까지 유지된다. */

const EX = {
  data:     null,
  recipients: {},     // 부서 -> 수신인 목록 (관리자만 조회 가능)
  isAdmin:  false,
  filter:   'all',      // all | dept | team  (구분 칩)
  search:   '',
  dept:     '',         // 특정 부서로 좁히기 ('' = 전체)
  sort:     'defect',   // defect | judged | name
  hideZero: false,
  sel:      new Set(),  // 선택된 범위 key
  limit:    50,         // 한 번에 그리는 행 수
  loading:  false,
  timer:    null,
};

const _EX_KIND = { all: '전체', dept: '부서', team: '팀' };
const EX_PAGE = 50;

function _exKey(s) { return (s.dept || '') + '||' + (s.team || ''); }

/* 예전에는 여기에 1C 제외 토글이 있었다. 켜면 «만들어지는 파일»이 달라지므로
   서버 캐시 키와 파일 이름에까지 들어가야 했다 — 이름이 같으면 «뺀 줄 알고
   받았는데 들어 있는» 파일이 나가고, 받은 사람이 열어 보기 전에는 알 수 없다.

   2026-08-20부터 1C는 판정 대상이 아니라 파일이 한 가지뿐이다. 대신 **빠졌다는
   사실은 화면이 말한다**(`_exTempNote`) — 안 말하면 「우리 팀 판정 대상이 왜
   이렇게 적지」가 된다. */
function _exTempNote() {
  const el = document.getElementById('ex-temp-note');
  if (!el) return;
  const temp = (S.result && S.result.temp_rows) || 0;
  el.style.display = temp > 0 ? '' : 'none';
  el.innerHTML = temp > 0
    ? '임시부재(1C 도면) <b>' + _n(temp) + '행</b>은 판정 대상이 아니라 ' +
      '표의 건수·원본 시트·메일 본문 어디에도 들어 있지 않습니다'
    : '';
}

async function loadExports(force) {
  if (EX.loading) return;
  if (EX.data && !force) { renderExports(); return; }
  EX.loading = true;
  try {
    EX.data = await apiFetch('/api/exports');
    EX.isAdmin = localStorage.getItem('qc_is_admin') === '1';
    if (EX.isAdmin) {
      // 발송 가능 여부를 행마다 보여주려면 수신인 설정을 알아야 한다.
      // 관리자 전용 엔드포인트라 실패해도 목록 자체는 떠야 한다.
      try { EX.recipients = await apiFetch('/api/settings/dept-recipients') || {}; }
      catch (e) { EX.recipients = {}; }
      try { EX.teamRecipients = await apiFetch('/api/settings/team-recipients') || {}; }
      catch (e) { EX.teamRecipients = {}; }
    }
    renderExports();
  } catch (e) {
    document.getElementById('ex-tbody').innerHTML =
      '<tr><td colspan="7" style="text-align:center;color:var(--text-3);padding:18px">' +
      '목록을 불러오지 못했습니다 — ' + _esc(String(e.message || e)) + '</td></tr>';
  } finally {
    EX.loading = false;
  }
}

function renderExports() {
  const d = EX.data;
  _exTempNote();
  if (!d) return;

  if (!d.has_result) {
    ['ex-gen-team', 'ex-gen-dept', 'ex-gen-all'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.disabled = true;
    });
    document.getElementById('ex-note').innerHTML =
      '<b>검증 결과가 없습니다.</b> 먼저 파일을 업로드하고 검증을 실행하세요.';
    document.getElementById('ex-filter').innerHTML = '';
    document.getElementById('ex-tbody').innerHTML =
      '<tr><td colspan="7" style="text-align:center;color:var(--text-3);padding:18px">-</td></tr>';
    return;
  }

  _exRenderBatch();

  const n = { all: 0, dept: 0, team: 0 };
  d.scopes.forEach(s => { n[s.kind] = (n[s.kind] || 0) + 1; });

  document.getElementById('ex-bar-sub').textContent =
    '부서 ' + n.dept + ' · 팀 ' + n.team + ' · 검증 ' + d.run_at;

  document.getElementById('ex-note').innerHTML =
    '각 파일에는 <b>요약 · 결함 목록 · 원본(색상 마킹)</b> 시트가 들어갑니다' +
    '(미작업·검토 기록은 해당 건이 있을 때만 추가). ' +
    '<b>결함 목록</b> 시트는 지적 1건이 1행이라 엑셀에서 필터·정렬·피벗이 됩니다 — ' +
    '주석에만 있던 기준값/실제값도 실제 셀 값으로 들어갑니다. ' +
    '<b>팀별 파일 생성</b>을 누르면 팀 파일이 한 번에 전부 만들어집니다 — ' +
    '원본을 한 번만 읽으므로 하나씩 누르는 것보다 훨씬 빠릅니다. ' +
    '<b>전체 파일</b>은 가장 무거워서 따로 떼어 두었습니다. ' +
    '검증을 다시 실행하면 만들어둔 파일은 모두 폐기됩니다.';

  // 부서 드롭다운 — 목록이 길어지면 이걸로 먼저 좁힌다
  const depts = [...new Set(d.scopes.filter(s => s.dept).map(s => s.dept))].sort();
  const sel = document.getElementById('ex-dept');
  if (sel) {
    const cur = EX.dept;
    sel.innerHTML = '<option value="">모든 부서</option>' +
      depts.map(x => '<option value="' + _esc(x) + '">' + _esc(x) + '</option>').join('');
    sel.value = cur;
  }

  const chip = (v, label, cnt) =>
    '<span class="chip ' + (EX.filter === v ? 'active' : '') + '" role="button" tabindex="0" ' +
    'onclick="setExportFilter(\'' + _jsq(v) + '\')">' + _esc(label) + ' <b>' + cnt + '</b></span>';
  document.getElementById('ex-filter').innerHTML =
    chip('all', '전체 보기', d.scopes.length) +
    chip('dept', '부서만', n.all + n.dept) +
    chip('team', '팀만', n.team);

  _exRenderRows();
}

/* ── 필터/정렬 조작 ── */
function setExportFilter(v)   { EX.filter = v;   EX.limit = EX_PAGE; renderExports(); }
function setExportDept(v)     { EX.dept = v;     EX.limit = EX_PAGE; _exRenderRows(); }
function setExportSort(v)     { EX.sort = v;     _exRenderRows(); }
function setExportHideZero(v) { EX.hideZero = v; EX.limit = EX_PAGE; _exRenderRows(); }
function setExportSearch(v)   { EX.search = (v || '').trim().toLowerCase(); EX.limit = EX_PAGE; _exRenderRows(); }
function showMoreExports()    { EX.limit += EX_PAGE; _exRenderRows(); }

/* 현재 조건에 맞는 범위 전체(표시 상한 적용 전). 선택/일괄 동작은 이 집합을 기준으로 한다. */
function _exMatched() {
  let rows = (EX.data && EX.data.scopes) || [];
  if (EX.filter === 'dept') rows = rows.filter(s => s.kind !== 'team');
  if (EX.filter === 'team') rows = rows.filter(s => s.kind === 'team');
  if (EX.dept)              rows = rows.filter(s => s.dept === EX.dept);
  if (EX.hideZero)          rows = rows.filter(s => (s.defect_rows || 0) > 0);
  if (EX.search) {
    const q = EX.search;
    rows = rows.filter(s => (s.label || '').toLowerCase().includes(q));
  }
  const by = {
    defect: (a, b) => (b.defect_rows || 0) - (a.defect_rows || 0),
    judged: (a, b) => (b.judged_rows || 0) - (a.judged_rows || 0),
    name:   (a, b) => (a.label || '').localeCompare(b.label || '', 'ko'),
  }[EX.sort];
  // '전체'는 늘 맨 위에 둔다 — 가장 자주 쓰는데 정렬에 밀려 내려가면 찾기 어렵다
  return rows.slice().sort((a, b) =>
    (a.kind === 'all' ? -1 : b.kind === 'all' ? 1 : by(a, b)));
}

function _exRenderRows() {
  const matched = _exMatched();
  const shown = matched.slice(0, EX.limit);

  document.getElementById('ex-tbody').innerHTML = shown.map(_exRowHtml).join('') ||
    '<tr><td colspan="7" style="text-align:center;color:var(--text-3);padding:18px">' +
    (EX.search ? '검색 결과가 없습니다' : '해당하는 범위가 없습니다') + '</td></tr>';

  const more = matched.length - shown.length;
  document.getElementById('ex-more-row').innerHTML = more > 0
    ? '<span class="page-info">' + shown.length + ' / ' + matched.length + '개 표시</span>' +
      '<button class="btn btn-sm" onclick="showMoreExports()">' + more + '개 더 보기</button>'
    : (matched.length ? '<span class="page-info">' + matched.length + '개</span>' : '');

  // 헤더 체크박스는 '보이는 것 전부 선택됨'일 때만 켠다
  const allBox = document.getElementById('ex-all');
  if (allBox) {
    const keys = shown.map(_exKey);
    allBox.checked = keys.length > 0 && keys.every(k => EX.sel.has(k));
    allBox.indeterminate = !allBox.checked && keys.some(k => EX.sel.has(k));
  }
  _exUpdateSelInfo();
}

/* 그 범위에 설정된 수신인. 부서는 부서 목록에서, 팀은 «부서 아래 팀» 순으로 찾는다.
   팀 이름만으로 찾지 않는 이유는 서버(config.TEAM_RECIPIENTS_FILE)와 같다 —
   팀 이름이 부서를 넘어 유일하다는 보장이 없다. */
function _exRecipientsOf(s) {
  if (s.kind === 'dept') return (EX.recipients || {})[s.dept] || [];
  if (s.kind === 'team') return ((EX.teamRecipients || {})[s.dept] || {})[s.team] || [];
  return [];
}

/* 메일 발송 버튼.

   부서와 팀 범위에 붙는다. '전체'에는 없다 — 수신인이 조직 단위로만 정의된다.
   관리자가 아니면 아예 보여주지 않는다(서버도 _require_admin으로 막는다). */
function _exMailBtn(s) {
  if (!EX.isAdmin || (s.kind !== 'dept' && s.kind !== 'team')) return '';
  const to = _exRecipientsOf(s);
  const what = s.kind === 'team' ? '팀' : '부서';
  if (!to.length) {
    return '<button class="btn btn-sm" disabled ' +
           'title="설정 탭에서 이 ' + what + '의 수신인을 먼저 등록하세요">메일 발송</button> ';
  }
  return '<button class="btn btn-sm" onclick="sendExportMail(\'' + _jsq(s.dept) +
         '\',\'' + _jsq(s.team || '') + '\')" ' +
         'title="' + _esc(to.join(', ')) +
         ' — 내려받은 .eml을 더블클릭하면 내 Outlook에서 초안으로 열립니다">' +
         '메일 발송 (' + to.length + ')</button> ';
}

/* 리포트 메일을 **누른 사람의 PC에서** 열리도록 `.eml`로 내려받는다.

   예전에는 서버가 `win32com`으로 자기 PC의 Outlook에 초안을 열었다. 사내망
   다른 PC에서 쓰기 시작하니 **원격 접속자가 눌러도 초안은 서버 PC에 열렸다** —
   누른 사람에게는 아무 일도 안 일어난 것처럼 보인다.

   내려온 파일을 더블클릭하면 자기 Outlook에서 수신인·제목·본문·첨부가 채워진
   «작성 중인 초안»으로 열린다(서버가 `X-Unsent` 헤더를 붙인다).

   이건 **임시조치**다 — 최종적으로는 누르면 저장된 수신처로 바로 나간다.
   지금은 사람이 한 번 보고 보내므로 잘못된 수신처·첨부가 그대로 안 나간다. */
async function sendExportMail(dept, team) {
  team = team || '';
  const kind = team ? 'team' : 'dept';
  const to = _exRecipientsOf({ kind: kind, dept: dept, team: team });
  const label = team ? (dept + ' > ' + team) : dept;
  if (!confirm(label + ' 리포트 메일을 만듭니다.\n\n수신인: ' + to.join(', ') +
               '\n첨부: 이 범위의 결과 Excel' +
               '\n\n내려받은 파일을 더블클릭하면 Outlook에서 초안으로 열립니다.' +
               '\n\n계속할까요?')) return;
  try {
    // 부서명·팀명 모두 질의 파라미터로 — 경로에 두면 `Q530-SMR/ITER생산부`가 404다
    const qs = new URLSearchParams();
    qs.set('department', dept);
    if (team) qs.set('team', team);
    // 결과 Excel 내려받기와 **같은 표**를 쓴다 — 창구가 둘이면 갈라진다
    const { ticket } = await apiFetch('/api/result/excel/ticket', { method: 'POST' });
    qs.set('t', ticket);
    const a = document.createElement('a');
    a.href = '/api/mail/draft?' + qs.toString();
    a.download = 'QC리포트_' + (team || dept) + '.eml';
    document.body.appendChild(a);
    a.click();
    a.remove();
  } catch (e) {
    alert('메일을 만들지 못했습니다 — ' + (e.message || e));
  }
}

function _exRowHtml(s) {
  const key = _exKey(s);
  const checked = EX.sel.has(key) ? ' checked' : '';
  let fileCell, actionCell;

  if (s.status === 'building') {
    fileCell = '<span class="ex-building">생성 중…</span>';
    actionCell = '<span class="rv-form-hint">' + _esc(s.message || '') + '</span>';
  } else if (s.status === 'error') {
    fileCell = '<span class="ex-err">실패</span>';
    actionCell = '<button class="btn btn-sm" onclick="buildExport(\'' + _jsq(s.dept || '') +
                 '\',\'' + _jsq(s.team || '') + '\')">다시 시도</button>' +
                 '<span class="rv-form-hint">' + _esc(s.error || '') + '</span>';
  } else if (s.status === 'ready' && s.info) {
    fileCell = '<span class="ex-ready">' + (s.info.size / 1024).toFixed(0) + ' KB</span>';
    actionCell =
      '<button class="btn btn-sm btn-primary" onclick="downloadExport(\'' + _jsq(s.dept || '') +
      '\',\'' + _jsq(s.team || '') + '\')">⬇ 내려받기</button> ' +
      _exMailBtn(s) +
      '<button class="btn btn-sm" onclick="buildExport(\'' + _jsq(s.dept || '') +
      '\',\'' + _jsq(s.team || '') + '\')">다시 생성</button>';
  } else {
    fileCell = '<span class="ex-idle">미생성</span>';
    actionCell = '<button class="btn btn-sm" onclick="buildExport(\'' + _jsq(s.dept || '') +
                 '\',\'' + _jsq(s.team || '') + '\')">생성</button>';
  }

  return '<tr>' +
    '<td><input type="checkbox"' + checked + ' onchange="toggleExportSel(\'' + _jsq(key) + '\',this.checked)"></td>' +
    '<td><span class="ex-kind ex-k-' + _esc(s.kind) + '">' + _esc(_EX_KIND[s.kind] || s.kind) + '</span></td>' +
    '<td>' + _exLabelHtml(s.label) + '</td>' +
    '<td>' + _n(s.judged_rows) + '</td>' +
    '<td style="color:var(--ck-orange);font-weight:600">' + _n(s.defect_rows) + '</td>' +
    '<td>' + fileCell + '</td>' +
    '<td>' + actionCell + '</td>' +
  '</tr>';
}

/* 검색어에 걸린 부분을 굵게 — 목록이 길 때 어디가 맞았는지 바로 보이게 한다. */
function _exLabelHtml(label) {
  const safe = _esc(label || '');
  if (!EX.search) return safe;
  const low = (label || '').toLowerCase();
  const i = low.indexOf(EX.search);
  if (i < 0) return safe;
  const j = i + EX.search.length;
  return _esc(label.slice(0, i)) + '<mark class="ex-hit">' + _esc(label.slice(i, j)) +
         '</mark>' + _esc(label.slice(j));
}

/* ── 선택 ── */
function toggleExportSel(key, on) {
  if (on) EX.sel.add(key); else EX.sel.delete(key);
  _exRenderRows();
}

function toggleExportAll(on) {
  // 화면에 보이는 것만 대상으로 한다 — '더 보기'로 안 펼친 것까지 잡히면 놀란다
  _exMatched().slice(0, EX.limit).forEach(s => {
    if (on) EX.sel.add(_exKey(s)); else EX.sel.delete(_exKey(s));
  });
  _exRenderRows();
}

function _exSelected() {
  const byKey = {};
  ((EX.data && EX.data.scopes) || []).forEach(s => { byKey[_exKey(s)] = s; });
  return [...EX.sel].map(k => byKey[k]).filter(Boolean);
}

function _exUpdateSelInfo() {
  const sel = _exSelected();
  const info = document.getElementById('ex-selinfo');
  const bBuild = document.getElementById('ex-bulk-build');
  const bDl = document.getElementById('ex-bulk-dl');
  const ready = sel.filter(s => s.status === 'ready');
  if (info) info.textContent = sel.length ? sel.length + '개 선택 (생성됨 ' + ready.length + ')' : '';
  if (bBuild) bBuild.disabled = sel.length === 0;
  if (bDl) bDl.disabled = ready.length === 0;
}

/* ── 생성 / 내려받기 ── */
async function buildExport(dept, team) {
  try {
    await apiFetch('/api/exports/build', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dept: dept || null, team: team || null }),
    });
    await loadExports(true);
    _exStartPolling();
  } catch (e) {
    alert('생성을 시작하지 못했습니다 — ' + (e.message || e));
  }
}

/* 여러 범위를 **한 요청**으로 보낸다.

   예전에는 여기서 `/exports/build`를 범위 수만큼 연달아 불렀다. 서버가 요청마다
   스레드를 하나씩 띄우므로 워크북이 그만큼 동시에 살아 있게 되고, 38만 행에서는
   한 벌이 4.5GB라 몇 개만 겹쳐도 워크스테이션이 멎는다. 지금은 서버가 원본을
   한 번 읽어 전부 만든다. */
async function _postBuildMany(rows, what) {
  try {
    await apiFetch('/api/exports/build-many', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        scopes: rows.map(s => ({ dept: s.dept || null, team: s.team || null })),
      }),
    });
  } catch (e) {
    alert((what || '생성') + '을 시작하지 못했습니다 — ' + (e.message || e));
    return;
  }
  await loadExports(true);
  _exStartPolling();
}

async function bulkBuildExports() {
  const sel = _exSelected().filter(s => s.status !== 'ready' && s.status !== 'building');
  if (!sel.length) { alert('생성할 항목이 없습니다 (이미 생성됐거나 생성 중입니다)'); return; }
  if (!confirm(sel.length + '개 범위를 생성합니다.\n계속할까요?')) return;
  await _postBuildMany(sel, '선택 생성');
}

/* [팀별] / [부서별] / [전체] 묶음 생성.

   **전체 한 벌을 팀별과 함께 만들지 않는다.** 전체는 모든 행을 담아 가장 무거운데
   («팀별 전부»와 같은 양을 혼자 쓴다) 늘 필요하지는 않다. 함께 만들면 팀별을
   받으려는 사람이 그 비용을 매번 같이 치른다. */
const _EX_GROUP = {
  team: { label: '팀별',  what: '팀' },
  dept: { label: '부서별', what: '부서' },
  all:  { label: '전체',  what: '전체' },
};

async function buildScopeGroup(kind) {
  if (!EX.data || !EX.data.has_result) { alert('검증 결과가 없습니다'); return; }
  if ((EX.data.batch || {}).running) { alert('이미 생성이 진행 중입니다'); return; }
  const g = _EX_GROUP[kind] || _EX_GROUP.team;
  const rows = (EX.data.scopes || []).filter(s => s.kind === kind);
  if (!rows.length) { alert(g.label + ' 범위가 없습니다'); return; }

  const pending = rows.filter(s => s.status !== 'ready' && s.status !== 'building');
  let targets = pending;
  if (!pending.length) {
    if (!confirm(g.label + ' 파일 ' + rows.length + '개가 이미 생성돼 있습니다.\n\n' +
                 '다시 만들까요?')) return;
    targets = rows;
  } else if (!confirm(g.label + ' 파일 ' + targets.length + '개를 만듭니다' +
                      (rows.length - targets.length
                        ? ' (이미 생성된 ' + (rows.length - targets.length) + '개는 건너뜁니다)' : '') +
                      '.\n\n원본을 한 번만 읽으므로 하나씩 만드는 것보다 훨씬 빠릅니다.' +
                      '\n\n계속할까요?')) {
    return;
  }
  await _postBuildMany(targets, g.label + ' 생성');
}

/* 진행 줄 + 생성 단추 상태. 도는 동안에는 세 단추를 모두 잠근다 —
   서버도 409로 막지만, 눌리는 단추를 두면 «눌렀는데 아무 일도 안 난다»가 된다. */
function _exRenderBatch() {
  const b = (EX.data && EX.data.batch) || {};
  const box = document.getElementById('ex-batch');
  const running = !!b.running;
  ['ex-gen-team', 'ex-gen-dept', 'ex-gen-all'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.disabled = running;
  });
  if (!box) return;
  if (!running) { box.style.display = 'none'; return; }
  const total = b.total || 0;
  const done = (b.done || 0) + (b.failed || 0);
  const pct = total ? Math.round(done / total * 100) : 0;
  box.style.display = 'flex';
  box.innerHTML =
    '<b>생성 중 ' + done + ' / ' + total + '</b>' +
    '<span class="ex-batch-bar"><span class="ex-batch-fill" style="width:' + pct + '%"></span></span>' +
    '<span class="ex-batch-msg">' + _esc(b.message || '') +
    (b.failed ? ' · 실패 ' + b.failed + '건' : '') + '</span>';
}

async function bulkDownloadExports() {
  const sel = _exSelected().filter(s => s.status === 'ready');
  if (!sel.length) { alert('내려받을 수 있는 항목이 없습니다'); return; }
  // 브라우저가 연속 다운로드를 막지 않도록 사이를 조금 띄운다
  for (const s of sel) {
    await downloadExport(s.dept || '', s.team || '');
    await new Promise(r => setTimeout(r, 400));
  }
}

/* 생성 중인 범위가 하나라도 있으면 주기적으로 상태를 갱신한다.
   전부 끝나면 스스로 멈춘다 — 화면을 켜둔 채 방치해도 계속 요청하지 않게. */
function _exStartPolling() {
  if (EX.timer) return;
  EX.timer = setInterval(async () => {
    if (S.view !== 'exports') { _exStopPolling(); return; }
    await loadExports(true);
    const busy = (EX.data.scopes || []).some(s => s.status === 'building') ||
                 ((EX.data.batch || {}).running === true);
    if (!busy) _exStopPolling();
  }, 3000);
}

function _exStopPolling() {
  if (EX.timer) { clearInterval(EX.timer); EX.timer = null; }
}

async function downloadExport(dept, team) {
  const qs = new URLSearchParams();
  if (dept) qs.set('dept', dept);
  if (team) qs.set('team', team);
  try {
    // 결과 Excel과 **같은 방식**이다 — 창구가 둘이면 한쪽만 고쳐진다.
    const { ticket } = await apiFetch('/api/result/excel/ticket', { method: 'POST' });
    qs.set('t', ticket);
    const a = document.createElement('a');
    a.href = '/api/exports/download?' + qs.toString();
    a.download = 'QC_Result_' + (team || dept || '전체') + '.xlsx';
    document.body.appendChild(a);
    a.click();
    a.remove();
  } catch (e) {
    alert('내려받지 못했습니다 — ' + (e.message || e));
  }
}

/* ── 부서별 수신인 (설정 탭) ─────────────────────────────────────────────────
   예전에는 부서별 결함 탭 안에서 부서를 고를 때마다 관리했는데, 발송 기능이
   '범위별 내보내기'로 옮겨가면서 이 설정만 남아 자리가 어색해졌다.
   Outlook 설정이 이미 설정 탭에 있으므로 그 옆으로 모은다. */
const DR = { all: {}, dept: '', draft: [] };

async function loadRecipientSettings() {
  const sel = document.getElementById('dr-dept');
  if (!sel) return;
  try {
    DR.all = await _adminFetch('/api/settings/dept-recipients') || {};
  } catch (e) {
    DR.all = {};
    _drMsg('수신인 로드 실패: ' + e.message, true);
  }
  // 부서 목록은 검증 결과에서 가져온다 — 설정만으로는 어떤 부서가 있는지 알 수 없다
  const depts = S.result ? Object.keys(S.result.departments || {}).sort() : [];
  const known = [...new Set(depts.concat(Object.keys(DR.all)))].sort();
  sel.innerHTML = known.length
    ? known.map(d => '<option value="' + _esc(d) + '">' + _esc(d) + '</option>').join('')
    : '<option value="">(검증 결과가 없어 부서를 알 수 없습니다)</option>';
  DR.dept = sel.value || '';
  DR.draft = (DR.all[DR.dept] || []).slice();
  _drRenderChips();
  _drRenderTable();
}

function selectRecipientDept(name) {
  DR.dept = name;
  DR.draft = (DR.all[name] || []).slice();
  _drMsg('');
  _drRenderChips();
}

function _drRenderChips() {
  const box = document.getElementById('dr-chips');
  if (!box) return;
  box.innerHTML = DR.draft.length
    ? DR.draft.map(r =>
        '<span class="chip-recipient">' + _esc(r) +
        '<span class="rm" onclick="removeRecipientEmail(\'' + _jsq(r) + '\')">✕</span></span>').join('')
    : '<span class="rv-form-hint">등록된 수신인이 없습니다 — 이 부서는 발송할 수 없습니다</span>';
}

function _drRenderTable() {
  const tb = document.getElementById('dr-tbody');
  if (!tb) return;
  const rows = Object.keys(DR.all).sort();
  tb.innerHTML = rows.length
    ? rows.map(d =>
        '<tr><td>' + _esc(d) + '</td><td>' + (DR.all[d] || []).length + '명</td>' +
        '<td>' + _esc((DR.all[d] || []).join(', ')) + '</td></tr>').join('')
    : '<tr><td colspan="3" style="text-align:center;color:var(--text-3);padding:14px">' +
      '등록된 부서가 없습니다</td></tr>';
}

function addRecipientEmail() {
  const input = document.getElementById('dr-new');
  const email = (input.value || '').trim();
  if (!email) return;
  if (!DR.draft.includes(email)) DR.draft.push(email);
  input.value = '';
  _drRenderChips();
}

function removeRecipientEmail(email) {
  DR.draft = DR.draft.filter(r => r !== email);
  _drRenderChips();
}

async function saveRecipientDept() {
  if (!DR.dept) { _drMsg('부서를 먼저 선택하세요', true); return; }
  try {
    await _adminFetch('/api/settings/dept-recipients', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ department: DR.dept, recipients: DR.draft }),
    });
    DR.all[DR.dept] = DR.draft.slice();
    _drRenderTable();
    _drMsg('✓ 저장되었습니다');
    setTimeout(() => _drMsg(''), 2500);
  } catch (e) {
    _drMsg('저장 실패: ' + e.message, true);
  }
}

/* ── 팀별 수신인 (설정 탭) ───────────────────────────────────────────────────
   부서와 «짝»으로만 다룬다. 팀 이름만으로 키를 잡으면, 같은 이름의 팀이 두 부서에
   생기는 순간 한쪽 수신인이 다른 쪽 리포트를 받는다 — 조용히 틀리고, 받은 사람이
   말해 주기 전에는 알 수 없는 종류의 사고다. 서버 저장 모양도 `{부서: {팀: [...]}}`다. */
const TR = { all: {}, dept: '', team: '', draft: [] };

async function loadTeamRecipientSettings() {
  const sel = document.getElementById('tr-dept');
  if (!sel) return;
  try {
    TR.all = await _adminFetch('/api/settings/team-recipients') || {};
  } catch (e) {
    TR.all = {};
    _trMsg('팀 수신인 로드 실패: ' + e.message, true);
  }
  const depts = S.result ? Object.keys(S.result.departments || {}).sort() : [];
  const known = [...new Set(depts.concat(Object.keys(TR.all)))].sort();
  sel.innerHTML = known.length
    ? known.map(d => '<option value="' + _esc(d) + '">' + _esc(d) + '</option>').join('')
    : '<option value="">(검증 결과가 없어 부서를 알 수 없습니다)</option>';
  TR.dept = sel.value || '';
  _trFillTeams();
  _trRenderTable();
}

/* 그 부서의 팀 목록. 검증 결과가 원본이고, 결과에 없는 팀이라도 이미 등록돼 있으면
   함께 보여준다 — 안 그러면 «저장은 돼 있는데 화면에서 지울 수 없는» 항목이 생긴다. */
function _trFillTeams() {
  const sel = document.getElementById('tr-team');
  if (!sel) return;
  const bucket = (S.result && (S.result.departments || {})[TR.dept]) || {};
  const fromResult = Object.keys(bucket.teams || {});
  const saved = Object.keys(TR.all[TR.dept] || {});
  const teams = [...new Set(fromResult.concat(saved))].sort((a, b) => a.localeCompare(b, 'ko'));
  sel.innerHTML = teams.length
    ? teams.map(t => '<option value="' + _esc(t) + '">' + _esc(t) + '</option>').join('')
    : '<option value="">(팀이 없습니다)</option>';
  TR.team = sel.value || '';
  TR.draft = ((TR.all[TR.dept] || {})[TR.team] || []).slice();
  _trRenderChips();
}

function selectRecipientTeamDept(name) {
  TR.dept = name;
  _trMsg('');
  _trFillTeams();
}

function selectRecipientTeam(name) {
  TR.team = name;
  TR.draft = ((TR.all[TR.dept] || {})[name] || []).slice();
  _trMsg('');
  _trRenderChips();
}

function _trRenderChips() {
  const box = document.getElementById('tr-chips');
  if (!box) return;
  box.innerHTML = TR.draft.length
    ? TR.draft.map(r =>
        '<span class="chip-recipient">' + _esc(r) +
        '<span class="rm" onclick="removeTeamRecipientEmail(\'' + _jsq(r) + '\')">✕</span></span>').join('')
    : '<span class="rv-form-hint">등록된 수신인이 없습니다 — 이 팀은 발송할 수 없습니다</span>';
}

function _trRenderTable() {
  const tb = document.getElementById('tr-tbody');
  if (!tb) return;
  const rows = [];
  Object.keys(TR.all).sort().forEach(d => {
    Object.keys(TR.all[d] || {}).sort().forEach(t => rows.push([d, t, TR.all[d][t] || []]));
  });
  tb.innerHTML = rows.length
    ? rows.map(([d, t, to]) =>
        '<tr><td>' + _esc(d) + '</td><td>' + _esc(t) + '</td><td>' + to.length + '명</td>' +
        '<td>' + _esc(to.join(', ')) + '</td></tr>').join('')
    : '<tr><td colspan="4" style="text-align:center;color:var(--text-3);padding:14px">' +
      '등록된 팀이 없습니다</td></tr>';
}

function addTeamRecipientEmail() {
  const input = document.getElementById('tr-new');
  const email = (input.value || '').trim();
  if (!email) return;
  if (!TR.draft.includes(email)) TR.draft.push(email);
  input.value = '';
  _trRenderChips();
}

function removeTeamRecipientEmail(email) {
  TR.draft = TR.draft.filter(r => r !== email);
  _trRenderChips();
}

async function saveRecipientTeam() {
  if (!TR.dept || !TR.team) { _trMsg('부서와 팀을 먼저 선택하세요', true); return; }
  try {
    await _adminFetch('/api/settings/team-recipients', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ department: TR.dept, team: TR.team, recipients: TR.draft }),
    });
    // 서버는 빈 목록을 «삭제»로 본다. 화면 상태도 같게 맞춰야 표가 어긋나지 않는다.
    const bucket = TR.all[TR.dept] || (TR.all[TR.dept] = {});
    if (TR.draft.length) {
      bucket[TR.team] = TR.draft.slice();
    } else {
      delete bucket[TR.team];
      if (!Object.keys(bucket).length) delete TR.all[TR.dept];
    }
    _trRenderTable();
    _trMsg('✓ 저장되었습니다');
    setTimeout(() => _trMsg(''), 2500);
  } catch (e) {
    _trMsg('저장 실패: ' + e.message, true);
  }
}

function _trMsg(text, isErr) {
  const el = document.getElementById('tr-msg');
  if (!el) return;
  el.style.color = isErr ? 'var(--ck-orange)' : 'var(--ck-green)';
  el.textContent = text;
}

function _drMsg(text, isErr) {
  const el = document.getElementById('dr-msg');
  if (!el) return;
  el.style.color = isErr ? 'var(--ck-orange)' : 'var(--ck-green)';
  el.textContent = text;
}

/* ══ 머신러닝 분석 — 비지도학습 (Check 13) ═══════════════════════════════════
   서버가 검증할 때 계산해 둔 result.ml.unsupervised를 그린다.

   화면이 답하려는 질문은 하나다: **이 행이 그룹에서 얼마나, 무엇 때문에 벗어났나.**
   Isolation Forest는 점수 하나만 주고 이유를 말해주지 않으므로, 같은 데이터를
   사람이 읽을 수 있는 형태로 네 가지로 나눠 보여준다.

     분포 지도       정상은 영역, 이상치는 점 — '얼마나 밖에 있나'
     점수 분포       임계선이 사람이 정한 가정임을 드러냄
     피처별 이탈도   어떤 항목이 각각 얼마나 드문가
     동종 그룹 대비  비슷한 것들 중에서는 몇 건인가

   전체를 점으로 뿌리지 않는 이유: 20만 행이면 렌더가 불가능하고, 회색 점 더미에
   정작 봐야 할 이상치가 묻힌다. 서버가 정상 분포를 고정 크기 밀도 격자로 요약해
   보내므로 화면이 받는 데이터 양은 행수와 무관하다. */

const MLU = {
  data:   null,   // result.ml.unsupervised
  rows:   [],     // 이상치 목록 (평면화)
  sel:    null,   // 선택된 원본 행 번호
  stack:  [],     // 지도에서 마지막으로 누른 자리에 겹쳐 있던 행들
  search: '',
  sort:   'score',
  limit:  50,
  // **모델이 정한 1.5%를 «더 좁혀 보는» 값이다.** null이면 모델 임계 그대로.
  // 0.001(0.1%)처럼 더 작은 값은 1.5%의 부분집합이라 재검증이 필요 없다 —
  // 학습을 다시 하는 것이 아니라 점수 상위 N%만 «보는» 것이다.
  pct:    null,
  // 지도 확대/이동. k는 배율, ox/oy는 화면 픽셀 이동량.
  view:   { k: 1, ox: 0, oy: 0 },
};

const MLU_PAGE = 50;

/* 좁혀 보기 단계. 큰 물량에서 1.5%는 수천 건이라 지도가 «점으로 채운 띠»가
   된다(현업 지적 2026-08-24). 0.01%부터 훑어 내려가면 «가장 드문 것»부터
   손에 잡힌다. 모델 임계보다 큰 값은 두지 않는다 — 없는 행을 보여줄 수 없다. */
const MLU_LEVELS = [
  { v: 0.0001, l: '0.01%' },
  { v: 0.0005, l: '0.05%' },
  { v: 0.001,  l: '0.1%'  },
  { v: 0.005,  l: '0.5%'  },
  { v: null,   l: '전체'  },
];

/* 지금 «보는» 이상치. 점수가 낮을수록 더 드물다 — 오름차순으로 상위 N개.

   **모델이 찾은 집합은 그대로다.** 여기서 줄이는 것은 보는 범위뿐이고,
   Check 13의 결함 건수도 그대로다. 그 사실을 화면에도 적는다 — 안 적으면
   「0.01%로 보다가 결함이 줄었다」로 읽힌다. */
function _mluVisible() {
  const all = MLU.rows.slice().sort((a, b) => a.score - b.score);
  if (MLU.pct == null) return all;
  const total = (MLU.data && MLU.data.meta && MLU.data.meta.total_rows) || 0;
  // 적어도 1건은 남긴다 — 0건이면 «좁혔더니 사라졌다»가 되어 되돌릴 실마리가 없다
  return all.slice(0, Math.max(1, Math.round(total * MLU.pct)));
}

function setMluPct(v) {
  MLU.pct = (v === '' || v == null) ? null : Number(v);
  MLU.limit = MLU_PAGE;
  MLU.sel = null;
  const d = document.getElementById('mlu-detail');
  if (d) d.style.display = 'none';
  _mluResetView();
  _mluRenderLevels();
  _mluRenderList();
  _mluDrawScatter();
  _mluDrawHist();
}

function _mluRenderLevels() {
  const box = document.getElementById('mlu-levels');
  if (!box) return;
  const total = (MLU.data && MLU.data.meta && MLU.data.meta.total_rows) || 0;
  const cut = (MLU.data && MLU.data.meta && MLU.data.meta.contamination) || 0;
  box.innerHTML = MLU_LEVELS.map(x => {
    // 모델 임계(1.5%)보다 넓은 단계는 뜻이 없다 — 그만큼의 행이 아예 없다
    if (x.v != null && x.v > cut) return '';
    const n = x.v == null ? MLU.rows.length : Math.max(1, Math.round(total * x.v));
    const on = (MLU.pct == null && x.v == null) || MLU.pct === x.v;
    return '<button class="mlu-lv' + (on ? ' on' : '') + '" ' +
      'onclick="setMluPct(' + (x.v == null ? "''" : x.v) + ')" ' +
      'title="점수가 가장 낮은(가장 드문) 상위 ' + _esc(x.l) + '만 봅니다">' +
      _esc(x.l) + ' <b>' + _n(Math.min(n, MLU.rows.length)) + '</b></button>';
  }).join('');
}

function _mluResetView() { MLU.view = { k: 1, ox: 0, oy: 0 }; }

/* 예전에는 여기 1C 토글이 있었고, 서버가 모델을 **두 벌** 만들었다. 거르기만
   하면 남은 행의 점수가 여전히 1C가 만든 분포로 매긴 값이라 «뺐다»가 아니라
   «감췄다»가 되기 때문이다. 2026-08-20부터 1C가 판정 대상에서 빠져 **이 모델이
   이미 1C 없는 모집단으로 학습한다** — 갈아탈 두 번째가 없다. */
function renderMlUnsup() {
  aiShow('mlu', 'anomaly', {}, 'ai-mlu');
  const ml = (S.result && S.result.ml && S.result.ml.unsupervised) || null;
  const cur = ml;
  MLU.data = cur;

  const empty = !cur || !cur.available || !cur.meta;
  document.getElementById('mlu-model').innerHTML = empty
    ? '<b>이상치 분석 결과가 없습니다.</b> 검증을 실행하면 생성됩니다. ' +
      '(scikit-learn이 없거나 판정 대상이 30행 미만이면 건너뜁니다)'
    : _mluModelHtml(cur.meta);

  if (empty) {
    document.getElementById('mlu-kpi').innerHTML = '';
    document.getElementById('mlu-tbody').innerHTML =
      '<tr><td colspan="6" style="text-align:center;color:var(--text-3);padding:18px">-</td></tr>';
    document.getElementById('mlu-detail').style.display = 'none';
    return;
  }

  const m = cur.meta;
  document.getElementById('mlu-bar-sub').textContent =
    'Check 13 · 학습 대상 ' + _n(m.total_rows) + '행 중 ' + _n(m.anomaly_count) + '건';

  // 사이드바 배지는 **Check 13 결함 건수**이고, 이 모델이 그 근거다.
  const badge = document.getElementById('badge-ml-unsup');
  if (badge && ml.meta) { badge.textContent = ml.meta.anomaly_count; badge.style.display = ''; }

  document.getElementById('mlu-kpi').innerHTML = [
    { lbl: '학습 대상', val: _n(m.total_rows),
      sub: '이상치 탐지에 쓰인 행 (임시부재 1C 제외)',
      c: 'var(--text)' },
    { lbl: '탐지된 이상치', val: _n(m.anomaly_count), sub: '규칙 위반이 아니라 확인 필요',
      c: 'var(--ck-cyan, #00B0C0)', sev: m.anomaly_count ? 'warn' : '' },
    { lbl: '임계 기준', val: (m.contamination * 100).toFixed(1) + '%',
      sub: '사람이 정한 값 — 데이터가 정한 것이 아님', c: 'var(--text-2)' },
    { lbl: '투영 설명력', val: (m.projection.explained.reduce((a, b) => a + b, 0) * 100).toFixed(0) + '%',
      sub: '2D 그림이 원본을 담는 정도', c: 'var(--text-2)' },
  ].map(_kpiCardHtml).join('');

  MLU.rows = Object.keys(cur.detail).map(k => Object.assign({ row: Number(k) }, cur.detail[k]));
  MLU.limit = MLU_PAGE;
  MLU.sel = null;
  MLU.pct = null;
  _mluResetView();
  document.getElementById('mlu-detail').style.display = 'none';

  _mluRenderLevels();
  _mluRenderList();
  _mluDrawScatter();
  _mluDrawHist();
}

function _mluModelHtml(m) {
  const mo = m.model || {};
  // **어느 기준으로 학습했는지를 먼저 말한다.** 이걸 적지 않으면 「탭 건수와
  // 결함 목록 건수가 왜 다른가」를 보는 사람이 알 방법이 없다.
  return '학습 방식 <b>' + _esc(mo.algorithm || '-') + '</b> · 트리 ' + _n(mo.n_estimators || 0) +
    '그루 · 인코딩 ' + _esc(mo.encoding || '-') + '<br>' +
    _esc(mo.note || '') +
    ' · 정답(라벨) 없이 <b>드문 조합</b>만 찾는 <b>비지도학습</b>이므로, 결과는 결함 확정이 아니라 ' +
    '<b>사람이 확인할 후보</b>입니다.' +
    '<br><b>임시부재(1C)는 학습에도 판정에도 들어가지 않습니다.</b> 임시 용접이라 작업도 ' +
    '결과 처리도 불완전해서, 포함하면 «흔한 조합»이 임시 용접의 모양이 되고 본 작업이 ' +
    '오히려 드물게 보입니다. 여기 건수가 곧 Check 13 결함 건수입니다.';
}

/* ── 목록 ── */
function setMluSearch(v) { MLU.search = (v || '').trim().toLowerCase(); MLU.limit = MLU_PAGE; _mluRenderList(); }
function setMluSort(v)   { MLU.sort = v; _mluRenderList(); }
function showMoreMlu()   { MLU.limit += MLU_PAGE; _mluRenderList(); }

function _mluMatched() {
  let rows = _mluVisible();
  if (MLU.search) {
    const q = MLU.search;
    rows = rows.filter(r =>
      (r.drawing_no || '').toLowerCase().includes(q) ||
      (r.joint_no || '').toLowerCase().includes(q) ||
      (r.department || '').toLowerCase().includes(q));
  }
  // score는 낮을수록 더 이상치다 — '이탈 큰 순'은 오름차순 정렬이 맞다
  rows.sort(MLU.sort === 'row' ? (a, b) => a.row - b.row : (a, b) => a.score - b.score);
  return rows;
}

function _mluRenderList() {
  const matched = _mluMatched();
  const shown = matched.slice(0, MLU.limit);
  document.getElementById('mlu-tbody').innerHTML = shown.map(r =>
    '<tr class="mlu-row ' + (MLU.sel === r.row ? 'is-selected' : '') + '" role="button" tabindex="0" ' +
        'onclick="selectMluRow(' + r.row + ')">' +
      '<td class="mono">' + r.row + '</td>' +
      '<td class="mono">' + _esc(r.drawing_no || '—') + '</td>' +
      '<td class="mono">' + _esc(r.joint_no || '—') + '</td>' +
      '<td>' + _esc(r.department || '—') + '</td>' +
      '<td class="mono" style="color:var(--ck-orange);font-weight:600">' + r.score.toFixed(4) + '</td>' +
      '<td>' + _esc(r.reason) + '</td>' +
    '</tr>').join('') ||
    '<tr><td colspan="6" style="text-align:center;color:var(--text-3);padding:18px">' +
    (MLU.search ? '검색 결과가 없습니다' : '탐지된 이상치가 없습니다') + '</td></tr>';

  const more = matched.length - shown.length;
  document.getElementById('mlu-more-row').innerHTML = more > 0
    ? '<span class="page-info">' + shown.length + ' / ' + matched.length + '건 표시</span>' +
      '<button class="btn btn-sm" onclick="showMoreMlu()">' + more + '건 더 보기</button>'
    : (matched.length ? '<span class="page-info">' + matched.length + '건</span>' : '');
}

function selectMluRow(row) {
  MLU.sel = (MLU.sel === row) ? null : row;
  _mluRenderList();
  _mluRenderDetail();
  _mluDrawScatter();     // 선택 행을 지도에서 강조
}

/* ── 선택 행 상세 ── */
function _mluRenderDetail() {
  const box = document.getElementById('mlu-detail');
  const r = MLU.rows.find(x => x.row === MLU.sel);
  if (!r) { box.style.display = 'none'; return; }
  box.style.display = '';

  document.getElementById('mlu-detail-title').textContent =
    '행 ' + r.row + ' · ' + (r.drawing_no || '') + ' · Joint ' + (r.joint_no || '');
  document.getElementById('mlu-dev').innerHTML = _mluDevHtml(r);
  document.getElementById('mlu-peer-tbody').innerHTML =
    (r.peers || []).map(p =>
      '<tr><td>' + _esc(p.group) + '</td>' +
        '<td class="mono">' + _n(p.base) + '건</td>' +
        '<td class="mono">' + _n(p.match) + '건</td>' +
        '<td class="mono" style="font-weight:600">' + p.pct.toFixed(2) + '%</td>' +
        '<td>' + _esc(p.what) + '</td></tr>').join('') ||
    '<tr><td colspan="5" style="text-align:center;color:var(--text-3);padding:14px">비교 그룹 없음</td></tr>';
}

/* ── 분포 지도 (정상=영역, 이상치=점) ── */
function _mluDrawScatter() {
  const cvs = document.getElementById('mlu-scatter');
  if (!cvs || !MLU.data || !MLU.data.meta) return;
  const W = cvs.parentElement.clientWidth - 24;
  if (W < 40) return;                    // 숨겨진 화면에서는 그리지 않는다
  const H = 300;
  const dpr = window.devicePixelRatio || 1;
  cvs.width = W * dpr; cvs.height = H * dpr;
  cvs.style.width = W + 'px'; cvs.style.height = H + 'px';
  const ctx = cvs.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);

  const st = getComputedStyle(document.documentElement);
  const accent = st.getPropertyValue('--accent').trim() || '#00A84F';
  const warn   = st.getPropertyValue('--ck-orange').trim() || '#C94D10';
  const line   = st.getPropertyValue('--line').trim() || '#ddd';
  const text3  = st.getPropertyValue('--text-3').trim() || '#888';

  const p = MLU.data.meta.projection;
  const pad = 26;
  const [x0, x1] = p.x_range, [y0, y1] = p.y_range;
  const PW = W - pad * 2, PH = H - pad * 2;

  // **점 크기는 확대해도 그대로여야 한다.** `ctx.scale()`을 쓰면 점과 글자까지
  // 같이 커져서, 확대할수록 서로 더 겹친다 — 겹친 것을 떼어 보려고 확대하는데
  // 그러면 목적이 뒤집힌다. 그래서 좌표만 손으로 바꾼다.
  MLU.view = _mluClampView(MLU.view, PW, PH);
  const vw = MLU.view;
  const sx = v => pad + ((v - x0) / (x1 - x0) * PW) * vw.k + vw.ox;
  const sy = v => pad + (PH - (v - y0) / (y1 - y0) * PH) * vw.k + vw.oy;

  // 배경 격자 테두리
  ctx.strokeStyle = line; ctx.lineWidth = 1;
  ctx.strokeRect(pad, pad, PW, PH);

  // 확대하면 내용이 테두리 밖으로 나간다 — 잘라 낸다. 안 자르면 축 설명 위로
  // 점이 올라와 «그림이 깨진 것»처럼 보인다.
  ctx.save();
  ctx.beginPath();
  ctx.rect(pad, pad, PW, PH);
  ctx.clip();

  // 정상 분포 = 밀도 영역. 셀 밀도를 알파로 칠한다.
  const g = p.grid, dens = p.density;
  const cw = PW / g * vw.k, ch = PH / g * vw.k;
  for (let iy = 0; iy < g; iy++) {
    for (let ix = 0; ix < g; ix++) {
      const v = dens[iy] ? dens[iy][ix] : 0;
      if (v <= 0.02) continue;
      const cx = pad + (ix * PW / g) * vw.k + vw.ox;
      const cy = pad + (PH - (iy + 1) * PH / g) * vw.k + vw.oy;
      if (cx > pad + PW || cy > pad + PH || cx + cw < pad || cy + ch < pad) continue;
      ctx.fillStyle = _hexA(accent, 0.08 + v * 0.55);
      ctx.fillRect(cx, cy, cw + 0.6, ch + 0.6);
    }
  }

  // 이상치 = 점. 화면 좌표를 남겨 마우스 히트 테스트에 쓴다.
  const vis = _mluVisible();
  const sel = vis.find(r => r.row === MLU.sel);
  const hits = [];
  vis.forEach(r => {
    if (!r.xy) return;
    const isSel = sel && r.row === sel.row;
    const px = sx(r.xy[0]), py = sy(r.xy[1]);
    hits.push({ row: r.row, x: px, y: py, ref: r });
    ctx.beginPath();
    ctx.arc(px, py, isSel ? 5.5 : 2.6, 0, Math.PI * 2);
    ctx.fillStyle = isSel ? warn : _hexA(warn, 0.55);
    ctx.fill();
    if (isSel) { ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.6; ctx.stroke(); }
  });
  cvs._hits = hits;
  _mluBindScatter(cvs);

  // 선택 행 → 정상 영역 중심까지 선. '이만큼 벗어났다'를 문자 그대로 보여준다.
  if (sel && sel.xy) {
    const c = p.centroid;
    ctx.setLineDash([4, 3]);
    ctx.strokeStyle = warn; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(sx(c[0]), sy(c[1])); ctx.lineTo(sx(sel.xy[0]), sy(sel.xy[1])); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath(); ctx.arc(sx(c[0]), sy(c[1]), 3.5, 0, Math.PI * 2);
    ctx.fillStyle = accent; ctx.fill();
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.4; ctx.stroke();
  }

  ctx.restore();

  ctx.fillStyle = text3; ctx.font = '10px system-ui';
  ctx.fillText('← 흔한 조합', pad + 4, H - pad + 14);
  ctx.textAlign = 'right';
  ctx.fillText('드문 조합 →', W - pad, H - pad + 14);
  ctx.textAlign = 'left';
  if (vw.k > 1.01) {
    ctx.fillStyle = _hexA(accent, 0.9);
    ctx.font = '600 10px system-ui';
    ctx.fillText('×' + vw.k.toFixed(1), pad + 4, pad - 8);
  }

  const narrowed = MLU.pct != null;
  document.getElementById('mlu-scatter-legend').innerHTML =
    '<span class="mlu-lg"><i class="area"></i> 정상 분포 영역 (' + _n(p.normal_count) + '행)</span>' +
    '<span class="mlu-lg"><i class="dot"></i> 이상치 ' + _n(vis.length) + '건' +
      (narrowed ? ' <b>(전체 ' + _n(MLU.rows.length) + '건 중 상위)</b>' : '') + '</span>' +
    (sel ? '<span class="mlu-lg"><i class="cen"></i> 정상 중심 — 점선이 이탈 거리</span>' : '') +
    '<span class="mlu-note">휠로 확대 · 끌어서 이동 · 두 번 눌러 되돌리기. ' +
    '축은 주성분이라 단위가 없습니다. ' +
    '범주형을 빈도로 인코딩했기 때문에 <b>바깥으로 갈수록 드문 값들의 조합</b>이라는 읽는 법만 성립합니다.' +
    (narrowed ? ' <b>좁혀 보는 중입니다 — 모델이 찾은 이상치와 Check 13 건수는 그대로입니다.</b>' : '') +
    '</span>';
}

/* 확대/이동을 화면 안으로 가둔다.

   안 가두면 **내용이 통째로 밖으로 나가 빈 상자만 남는다** — 사용자에게는
   «그림이 사라졌다»로 보이고, 되돌릴 방법을 스스로 찾기 어렵다. */
function _mluClampView(v, PW, PH) {
  const k = Math.min(Math.max(v.k || 1, 1), 40);
  return {
    k: k,
    ox: Math.min(0, Math.max(v.ox || 0, PW - PW * k)),
    oy: Math.min(0, Math.max(v.oy || 0, PH - PH * k)),
  };
}

/* ── 점수 분포 히스토그램 ── */
function _mluDrawHist() {
  const cvs = document.getElementById('mlu-hist');
  if (!cvs || !MLU.data || !MLU.data.meta) return;
  const W = cvs.parentElement.clientWidth - 24;
  if (W < 40) return;
  const H = 300;
  const dpr = window.devicePixelRatio || 1;
  cvs.width = W * dpr; cvs.height = H * dpr;
  cvs.style.width = W + 'px'; cvs.style.height = H + 'px';
  const ctx = cvs.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);

  const st = getComputedStyle(document.documentElement);
  const accent = st.getPropertyValue('--accent').trim() || '#00A84F';
  const warn   = st.getPropertyValue('--ck-orange').trim() || '#C94D10';
  const line   = st.getPropertyValue('--line').trim() || '#ddd';
  const text3  = st.getPropertyValue('--text-3').trim() || '#888';

  const h = MLU.data.meta.histogram;
  const pad = 30, n = h.counts.length;
  const maxC = Math.max.apply(null, h.counts) || 1;
  const bw = (W - pad * 2) / n;
  const lo = h.bins[0], hi = h.bins[h.bins.length - 1];
  const sx = v => pad + (v - lo) / (hi - lo) * (W - pad * 2);

  ctx.strokeStyle = line; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(pad, H - pad); ctx.lineTo(W - pad, H - pad); ctx.stroke();

  h.counts.forEach((c, i) => {
    // log 스케일 — 정상이 압도적으로 많아 선형으로는 이상치 구간이 안 보인다
    const bh = (Math.log1p(c) / Math.log1p(maxC)) * (H - pad * 2);
    const mid = (h.bins[i] + h.bins[i + 1]) / 2;
    ctx.fillStyle = mid <= h.threshold ? warn : _hexA(accent, 0.75);
    ctx.fillRect(pad + i * bw, H - pad - bh, Math.max(bw - 1, 1), bh);
  });

  const tx = sx(h.threshold);
  ctx.setLineDash([5, 3]); ctx.strokeStyle = warn; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(tx, pad - 6); ctx.lineTo(tx, H - pad); ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = warn; ctx.font = 'bold 10px system-ui';
  ctx.fillText('임계선', Math.min(tx + 4, W - pad - 34), pad - 8);

  ctx.fillStyle = text3; ctx.font = '10px system-ui';
  ctx.fillText('← 더 이상함', pad, H - pad + 14);
  ctx.textAlign = 'right';
  ctx.fillText('더 평범함 →', W - pad, H - pad + 14);
  ctx.textAlign = 'left';

  const m = MLU.data.meta;
  document.getElementById('mlu-hist-legend').innerHTML =
    '<span class="mlu-lg"><i class="dot"></i> 임계선 왼쪽 = 이상치 ' + _n(m.anomaly_count) + '건</span>' +
    '<span class="mlu-lg"><i class="area"></i> 오른쪽 = 정상 ' + _n(m.total_rows - m.anomaly_count) + '건</span>' +
    '<span class="mlu-note">임계선 위치는 <b>contamination=' + m.contamination +
    '</b>(상위 ' + (m.contamination * 100).toFixed(1) + '%)로 <b>사람이 지정</b>한 값입니다. ' +
    '모델이 “' + _n(m.anomaly_count) + '건이 이상하다”고 판단한 것이 아니라, ' +
    '점수 순으로 상위 ' + (m.contamination * 100).toFixed(1) + '%를 자른 결과입니다. ' +
    '막대 높이는 log 스케일입니다.</span>';
}

/* ── 분포 지도 상호작용 ──────────────────────────────────────────────────────
   점 하나가 2.6px이라 정확히 맞히기 어렵고, 드문 조합끼리는 좌표가 겹친다
   (같은 재질·WPS면 인코딩 값이 같아 완전히 포개진다). 그래서:

     호버  - 반경 안에서 가장 가까운 점 하나의 요약을 보여준다
     클릭  - 반경 안 점이 하나면 바로 선택, 여럿이면 목록을 띄워 고르게 한다

   목록을 안 띄우면 겹친 점 중 하나만 계속 잡혀 나머지는 영영 못 고른다. */

const MLU_HIT_R = 9;      // 마우스 히트 반경(px) — 점 반지름보다 넉넉하게

function _mluBindScatter(cvs) {
  if (cvs._mluBound) return;
  cvs.addEventListener('mousemove', e => _mluHover(e, cvs));
  cvs.addEventListener('mouseleave', () => _mluHideTip());
  cvs.addEventListener('click', e => _mluClick(e, cvs));

  // ── 휠로 확대 — **커서가 가리키던 점이 제자리에 있어야 한다.**
  // 그냥 중앙 기준으로 키우면 보려던 점이 화면 밖으로 밀려나, 확대할 때마다
  // 다시 찾아야 한다.
  cvs.addEventListener('wheel', e => {
    e.preventDefault();
    const pad = 26;
    const PW = cvs.clientWidth - pad * 2, PH = cvs.clientHeight - pad * 2;
    const rect = cvs.getBoundingClientRect();
    const mx = e.clientX - rect.left - pad, my = e.clientY - rect.top - pad;
    const v = MLU.view;
    const k2 = Math.min(Math.max(v.k * (e.deltaY < 0 ? 1.25 : 0.8), 1), 40);
    MLU.view = _mluClampView({
      k: k2,
      ox: mx - (mx - v.ox) * (k2 / v.k),
      oy: my - (my - v.oy) * (k2 / v.k),
    }, PW, PH);
    _mluHideTip();
    _mluDrawScatter();
  }, { passive: false });

  // ── 끌어서 이동. 5px 넘게 움직였으면 «클릭»으로 치지 않는다 —
  // 옮기려다 엉뚱한 행이 선택되면 상세가 통째로 바뀐다.
  cvs.addEventListener('pointerdown', e => {
    if (e.button !== 0) return;
    const start = { x: e.clientX, y: e.clientY, ox: MLU.view.ox, oy: MLU.view.oy };
    let moved = 0;
    const pad = 26;
    const PW = cvs.clientWidth - pad * 2, PH = cvs.clientHeight - pad * 2;
    const move = ev => {
      const dx = ev.clientX - start.x, dy = ev.clientY - start.y;
      moved = Math.max(moved, Math.hypot(dx, dy));
      if (moved < 3) return;
      cvs.style.cursor = 'grabbing';
      MLU.view = _mluClampView({ k: MLU.view.k, ox: start.ox + dx, oy: start.oy + dy }, PW, PH);
      _mluHideTip();
      _mluDrawScatter();
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      cvs.style.cursor = 'default';
      cvs._mluDragged = moved > 5;
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  });

  // 두 번 누르면 되돌린다 — 확대해 들어갔다가 길을 잃었을 때의 출구다.
  cvs.addEventListener('dblclick', () => { _mluResetView(); _mluDrawScatter(); });

  cvs._mluBound = true;
}

function _mluHitsAt(e, cvs) {
  const rect = cvs.getBoundingClientRect();
  const mx = e.clientX - rect.left, my = e.clientY - rect.top;
  const found = [];
  (cvs._hits || []).forEach(h => {
    const d = Math.hypot(h.x - mx, h.y - my);
    if (d <= MLU_HIT_R) found.push({ h: h, d: d });
  });
  found.sort((a, b) => a.d - b.d);
  return { list: found.map(f => f.h), mx: mx, my: my, rect: rect };
}

function _mluHideTip() {
  const tip = document.getElementById('mlu-tooltip');
  if (tip) tip.style.display = 'none';
}

function _mluHover(e, cvs) {
  const tip = document.getElementById('mlu-tooltip');
  if (!tip) return;
  const { list, rect } = _mluHitsAt(e, cvs);
  if (!list.length) { tip.style.display = 'none'; cvs.style.cursor = 'default'; return; }

  const r = list[0].ref;
  const top = (r.deviations || [])[0];
  cvs.style.cursor = 'pointer';
  tip.style.display = 'block';
  tip.innerHTML =
    '행 ' + r.row + ' · ' + _esc(r.joint_no || '—') + '<br>' +
    _esc(r.drawing_no || '—') + '<br>' +
    '<b>' + _esc(top ? top.label + ' ' + top.value : r.reason) + '</b>' +
    (top ? ' <span style="opacity:.8">' + _esc(top.text) + '</span>' : '') +
    '<br><span style="opacity:.8">이탈 점수 ' + r.score.toFixed(4) + '</span>' +
    (list.length > 1
      ? '<br><span style="opacity:.8">이 자리에 ' + list.length + '건 겹침 — 클릭하면 목록</span>'
      : '');
  // 캔버스 오른쪽 끝에서는 툴팁이 잘리므로 왼쪽으로 뒤집는다
  const flip = (list[0].x + 220) > rect.width;
  tip.style.left = (rect.left + list[0].x + (flip ? -210 : 14)) + 'px';
  tip.style.top  = (rect.top + list[0].y - 12) + 'px';
}

function _mluClick(e, cvs) {
  // **끌어서 옮긴 뒤의 클릭은 선택이 아니다.** 안 막으면 지도를 조금 옮길
  // 때마다 엉뚱한 행이 열려 상세가 통째로 바뀐다.
  if (cvs._mluDragged) { cvs._mluDragged = false; return; }
  const { list } = _mluHitsAt(e, cvs);
  if (!list.length) return;
  _mluHideTip();
  // 겹친 점이 여럿이면 목록부터, 하나면 바로 상세.
  // 예전에는 캔버스 위 작은 상자에 목록을 띄우고 선택하면 아래 패널로 스크롤했는데,
  // 상자가 좁아 읽기 어렵고 화면이 갑자기 튀어 어디를 보던 중이었는지 잃었다.
  // 지금은 모달 안에서 목록 <-> 상세를 오가므로 화면이 움직이지 않는다.
  MLU.stack = list.map(h => h.row);
  if (list.length === 1) openMluModalDetail(list[0].row, false);
  else _mluOpenModalList();
}

function _mluOpenModal() {
  document.getElementById('mlu-modal').style.display = 'flex';
}

function closeMluModal() {
  document.getElementById('mlu-modal').style.display = 'none';
}

/* 겹친 점 목록. 이 자리에 몇 건이 포개져 있는지 먼저 보여주고 고르게 한다. */
function _mluOpenModalList() {
  const rows = (MLU.stack || [])
    .map(n => MLU.rows.find(r => r.row === n))
    .filter(Boolean)
    .sort((a, b) => a.score - b.score);

  document.getElementById('mlu-modal-title').textContent =
    '이 자리에 ' + rows.length + '건이 겹쳐 있습니다';
  document.getElementById('mlu-modal-sub').textContent =
    '같은 재질·WPS 등 값이 같으면 좌표가 완전히 포개집니다 · 행을 누르면 무엇 때문에 걸렸는지 나옵니다';

  document.getElementById('mlu-modal-body').innerHTML =
    '<div class="tbl-wrap"><table class="dtbl">' +
    '<thead><tr><th style="width:80px">원본 행</th><th>도면번호</th>' +
    '<th style="width:120px">Joint No</th><th style="width:180px">부서</th>' +
    '<th style="width:170px">팀</th><th style="width:92px">이탈 점수</th>' +
    '<th>주된 이유</th></tr></thead><tbody>' +
    rows.map(r =>
      '<tr class="mlu-row" role="button" tabindex="0" onclick="openMluModalDetail(' + r.row + ', true)">' +
        '<td class="mono">' + r.row + '</td>' +
        '<td class="mono">' + _esc(r.drawing_no || '—') + '</td>' +
        '<td class="mono">' + _esc(r.joint_no || '—') + '</td>' +
        '<td>' + _esc(r.department || '—') + '</td>' +
        '<td>' + _esc(r.team || '—') + '</td>' +
        '<td class="mono" style="color:var(--ck-orange);font-weight:600">' + r.score.toFixed(4) + '</td>' +
        '<td>' + _esc(r.reason) + '</td>' +
      '</tr>').join('') +
    '</tbody></table></div>';
  _mluOpenModal();
}

/* 모달 안 상세. 아래 패널과 같은 내용이지만 화면을 움직이지 않고 그 자리에서 보여준다.
   backToList가 참이면 목록으로 돌아가는 버튼을 단다. */
function openMluModalDetail(row, backToList) {
  const r = MLU.rows.find(x => x.row === row);
  if (!r) return;

  // 지도/표의 선택 상태도 맞춰준다 — 모달을 닫았을 때 어디를 봤는지 남아 있어야 한다.
  MLU.sel = row;
  _mluRenderList();
  _mluRenderDetail();
  _mluDrawScatter();

  document.getElementById('mlu-modal-title').textContent =
    '행 ' + r.row + ' · ' + (r.drawing_no || '') + ' · Joint ' + (r.joint_no || '');
  document.getElementById('mlu-modal-sub').textContent =
    (r.department || '') + ' / ' + (r.team || '') + ' · 이탈 점수 ' + r.score.toFixed(4) +
    ' · 규칙 위반이 아니라 확인이 필요한 후보입니다';

  const back = backToList
    ? '<div style="margin-bottom:12px">' +
      '<button class="btn btn-sm" onclick="_mluOpenModalList()">‹ 겹친 목록으로 돌아가기 (' +
      (MLU.stack || []).length + '건)</button></div>'
    : '';

  document.getElementById('mlu-modal-body').innerHTML = back +
    '<div class="mlu-detail-grid">' +
      '<div class="tbl-card">' +
        '<div class="mlu-sub">피처별 이탈도 — 전체 대비</div>' +
        _mluDevHtml(r) +
      '</div>' +
      '<div class="tbl-card">' +
        '<div class="mlu-sub">동종 그룹 대비 — 비슷한 것들 중에서</div>' +
        _mluPeerHtml(r) +
      '</div>' +
    '</div>';
  _mluOpenModal();
}

/* 이탈도/동종그룹 HTML은 모달과 아래 패널 양쪽에서 쓰므로 따로 뽑아둔다.
   한쪽만 고쳐서 둘이 달라지는 일이 없게 한다. */
function _mluDevHtml(r) {
  return (r.deviations || []).map(d => {
    const pct = Math.round(d.deviation * 100);
    const strong = d.deviation >= 0.9;
    return '<div class="mlu-dev-row">' +
        '<span class="mlu-dev-label">' + _esc(d.label) + '</span>' +
        '<span class="mlu-dev-val">' + _esc(d.value === null ? '—' : String(d.value)) + '</span>' +
        '<span class="mlu-dev-bar"><i class="' + (strong ? 'hot' : '') +
          '" style="width:' + pct + '%"></i></span>' +
        '<span class="mlu-dev-text">' + _esc(d.text) + '</span>' +
      '</div>';
  }).join('');
}

function _mluPeerHtml(r) {
  const rows = (r.peers || []).map(p =>
    '<tr><td>' + _esc(p.group) + '</td>' +
      '<td class="mono">' + _n(p.base) + '건</td>' +
      '<td class="mono">' + _n(p.match) + '건</td>' +
      '<td class="mono" style="font-weight:600">' + p.pct.toFixed(2) + '%</td>' +
      '<td>' + _esc(p.what) + '</td></tr>').join('') ||
    '<tr><td colspan="5" style="text-align:center;color:var(--text-3);padding:14px">비교 그룹 없음</td></tr>';
  return '<div class="tbl-wrap"><table class="dtbl">' +
    '<thead><tr><th>비교 그룹</th><th style="width:90px">모집단</th>' +
    '<th style="width:90px">해당</th><th style="width:80px">비율</th><th>무엇이</th></tr></thead>' +
    '<tbody>' + rows + '</tbody></table></div>';
}


/* #RRGGBB + 알파 -> rgba(). 테마 토큰이 hex로 들어오므로 변환이 필요하다. */
function _hexA(hex, a) {
  const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec((hex || '').trim());
  if (!m) return 'rgba(0,168,79,' + a + ')';
  return 'rgba(' + parseInt(m[1], 16) + ',' + parseInt(m[2], 16) + ',' + parseInt(m[3], 16) + ',' + a + ')';
}

/* ══ 프로젝트 값(params) ══════════════════════════════════════════════════════

   공통 Check가 **그대로 쓰는 값**이다. `checks`(별도 검증항목)와 나누는 기준:

       params  공통 Check가 쓰는 값       repair_prefix · wps_corrections · temp_member
       checks  자기 번호를 갖는 판정항목   재질별·WPS별 두께 허용범위

   예전에는 화면에서 못 고쳐서 `data/project_rules.json`을 직접 열어야 했다.
   그래서 새 프로젝트가 값을 안 정하고 지나가기 쉬웠고, **비어 있으면 규칙이
   조용히 죽는다** — 「검사를 돌렸는데 아무것도 안 나왔다」를 「문제가 없다」로
   읽게 된다. 그래서 칸마다 «비우면 무엇이 죽는지»를 함께 적는다. */
const PM = { data: null, draft: null };

/* 칸의 생김새와 설명. `defaults`에 있는데 여기 없는 키는 **JSON 칸**으로 나온다 —
   키가 늘었는데 화면이 모르면 그 값을 못 정하고 지나가기 때문이다. */
const PM_FIELDS = {
  repair_prefix: {
    kind: 'text', label: '수리 WPS 접두사', ph: '예: RP',
    hint: '이 접두사로 시작하는 WPS를 «수리»로 본다',
    empty: '비우면 수리 시공 행까지 Check 2·4·11이 지적해 오탐이 크게 늘어납니다',
  },
  inspection_grace_days: {
    kind: 'int', label: '검사 유예일', ph: '30',
    hint: '데이터 안 최종 용접일 기준으로 이 일수가 지나야 미수행으로 본다 (Check 16·17)',
  },
  temp_member: {
    kind: 'list', label: '임시부재 도면 접두사', path: 'drawing_prefixes', ph: '1C',
    hint: '쉼표로 구분 · 이 접두사로 시작하는 도면을 임시부재로 본다',
    empty: '비우면 «임시부재 제외» 토글이 아무것도 걸러내지 않습니다',
  },
  wps_corrections: {
    kind: 'pairs', label: 'WPS 보정', kh: 'WPS (예: FC-G01)', vh: '보정값',
    hint: '문서의 기재 누락을 보정한다 · 앞자리 프로젝트 번호는 떼고 맞춘다',
    empty: '비우면 Check 4·11에 오탐이 늘 수 있습니다',
  },
  check8: { kind: 'obj', label: 'Check 8', hint: '대상 WPS · 최대 두께 · 충격시험 온도' },
  check9: { kind: 'obj', label: 'Check 9', hint: '대상 WPS · 금지 두께 · 허용 오차' },
};

async function loadProjectParams(force) {
  if (PM.data && !force) { _pmRender(); return; }
  try {
    PM.data = await apiFetch('/api/rules/params');
    PM.draft = JSON.parse(JSON.stringify(PM.data.params || {}));
    _pmRender();
  } catch (e) {
    const f = document.getElementById('pm-form');
    if (f) f.innerHTML = '<span class="rv-form-hint">프로젝트 값을 불러오지 못했습니다 — ' +
                         _esc(String(e.message || e)) + '</span>';
  }
}

/* 지금 값이 «무엇을 죽이고 있는가». 서버가 판단한 것을 그대로 보여준다 —
   화면에서 다시 판단하면 저장 전후로 다른 말을 하게 된다. */
function _pmWarnHtml(warns) {
  if (!warns || !warns.length) {
    return '<div class="rv-form-hint" style="color:var(--ck-green)">' +
           '지금 값으로 모든 검사가 대조할 대상을 갖습니다</div>';
  }
  return warns.map(w =>
    '<div class="pm-warn ' + (w.level === 'warn' ? 'pm-bad' : 'pm-note') + '">' +
    (w.level === 'warn' ? '⚠ ' : 'ℹ ') + _esc(w.msg) + '</div>').join('');
}

function _pmRender() {
  const d = PM.data;
  if (!d) return;
  const warnBox = document.getElementById('pm-warn');
  if (warnBox) warnBox.innerHTML = _pmWarnHtml(d.warnings);

  const keys = Object.keys(d.defaults || {});
  const form = document.getElementById('pm-form');
  if (!form) return;
  form.innerHTML = keys.map(k => {
    const f = PM_FIELDS[k] || { kind: 'json', label: k, hint: '' };
    const cur = PM.draft[k];
    let body;
    if (f.kind === 'text' || f.kind === 'int') {
      body = '<input class="f-inp pm-inp" data-k="' + _esc(k) + '" ' +
             'placeholder="' + _esc(f.ph || '') + '" value="' +
             _esc(cur === undefined || cur === null ? '' : String(cur)) + '">';
    } else if (f.kind === 'list') {
      const arr = ((cur || {})[f.path]) || [];
      body = '<input class="f-inp pm-inp" data-k="' + _esc(k) + '" ' +
             'placeholder="' + _esc(f.ph || '') + '" value="' + _esc(arr.join(', ')) + '">';
    } else if (f.kind === 'pairs') {
      body = _pmPairsHtml(k, cur || {}, f);
    } else {
      body = '<textarea class="f-inp pm-ta" data-k="' + _esc(k) + '" rows="3">' +
             _esc(JSON.stringify(cur === undefined ? d.defaults[k] : cur, null, 1)) +
             '</textarea>';
    }
    return '<div class="pm-row">' +
      '<div class="pm-lbl">' + _esc(f.label || k) +
        '<span class="pm-key">' + _esc(k) + '</span></div>' +
      '<div class="pm-body">' + body +
        (f.hint ? '<div class="pm-hint">' + _esc(f.hint) + '</div>' : '') +
        (f.empty ? '<div class="pm-hint pm-empty">비우면: ' + _esc(f.empty) + '</div>' : '') +
      '</div></div>';
  }).join('');
}

function _pmPairsHtml(k, obj, f) {
  const rows = Object.keys(obj).map(kk =>
    '<div class="pm-pair">' +
    '<input class="f-inp" data-pk="' + _esc(k) + '" placeholder="' + _esc(f.kh) +
      '" value="' + _esc(kk) + '">' +
    '<input class="f-inp" data-pv="' + _esc(k) + '" placeholder="' + _esc(f.vh) +
      '" value="' + _esc(String(obj[kk])) + '">' +
    '<button class="btn btn-sm" onclick="_pmDropPair(this)">✕</button></div>').join('');
  return '<div class="pm-pairs" id="pm-pairs-' + _esc(k) + '">' + rows + '</div>' +
         '<button class="btn btn-sm" onclick="_pmAddPair(\'' + _jsq(k) + '\')">+ 줄 추가</button>';
}

function _pmAddPair(k) {
  _pmCollect();
  PM.draft[k] = PM.draft[k] || {};
  PM.draft[k][''] = '';
  _pmRender();
}

function _pmDropPair(btn) {
  const row = _closest(btn, '.pm-pair');
  if (row) row.remove();
  _pmCollect();
  _pmRender();
}

/* 화면의 값을 draft로 걷는다. **저장 직전에만 부르면 안 된다** — 줄을 더하거나
   지울 때 다시 그리므로, 그 전에 걷지 않으면 사용자가 친 내용이 사라진다. */
function _pmCollect() {
  const d = PM.data;
  if (!d) return;
  Object.keys(d.defaults || {}).forEach(k => {
    const f = PM_FIELDS[k] || { kind: 'json' };
    if (f.kind === 'pairs') {
      const box = document.getElementById('pm-pairs-' + k);
      if (!box) return;
      const out = {};
      box.querySelectorAll('.pm-pair').forEach(row => {
        const ke = row.querySelector('[data-pk]');
        const ve = row.querySelector('[data-pv]');
        const kk = ke ? (ke.value || '') : '';
        const vv = ve ? (ve.value || '') : '';
        if (kk.trim()) out[kk.trim()] = vv.trim();
      });
      PM.draft[k] = out;
      return;
    }
    const el = document.querySelector('[data-k="' + k + '"]');
    if (!el) return;
    const raw = (el.value || '').trim();
    if (f.kind === 'int') {
      const n = parseInt(raw, 10);
      PM.draft[k] = (raw === '' || isNaN(n)) ? undefined : n;
    } else if (f.kind === 'list') {
      const arr = raw ? raw.split(',').map(s => s.trim()).filter(Boolean) : [];
      PM.draft[k] = Object.assign({}, PM.draft[k] || {}, { [f.path]: arr });
    } else if (f.kind === 'text') {
      PM.draft[k] = raw;
    } else {
      try { PM.draft[k] = raw ? JSON.parse(raw) : undefined; }
      catch (e) { PM.draft[k] = { __bad: raw }; }   // 저장 때 걸러낸다
    }
  });
}

async function saveProjectParams() {
  _pmCollect();
  const out = {};
  let bad = null;
  Object.keys(PM.draft).forEach(k => {
    const v = PM.draft[k];
    if (v === undefined) return;
    if (v && v.__bad !== undefined) { bad = k; return; }
    out[k] = v;
  });
  if (bad) { _pmMsg('«' + bad + '» 칸이 올바른 JSON이 아닙니다', true); return; }

  _pmMsg('저장 중…');
  try {
    const r = await apiFetch('/api/rules/params', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ params: out }),
    });
    PM.data = Object.assign({}, PM.data, {
      params: r.params, warnings: r.warnings, effective: r.effective });
    PM.draft = JSON.parse(JSON.stringify(r.params || {}));
    _pmRender();
    _pmMsg('저장했습니다 — 판정 기준이 바뀌었으니 다시 검증해야 반영됩니다');
    // 세팅 토글과 같은 배지를 쓴다 — 사용자에게는 같은 뜻이다
    if (r.needs_reverify) {
      const b = document.getElementById('rl-reverify');
      if (b) b.style.display = '';
    }
  } catch (e) {
    _pmMsg('저장 실패 — ' + (e.message || e), true);
  }
}

function _pmMsg(t, isErr) {
  const el = document.getElementById('pm-msg');
  if (!el) return;
  el.textContent = t;
  el.classList.toggle('err', !!isErr);
}


/* ══ 프로젝트 서버 목록 (data/projects.json) ══════════════════════════════════

   **공용**이다 — 이 PC의 것이지 프로젝트의 것이 아니다. 프로젝트별 폴더에 두면
   서버마다 다른 목록을 보게 되어, 어느 창에서 보느냐에 따라 있는 프로젝트가
   없어 보인다.

   **여기서 서버가 떠지지는 않는다.** 사내망에 열린 페이지가 이 PC에서 프로세스를
   만들 수 있게 되는 것은 '에이전트' 탭에서 실행 기능을 뺀 것과 같은 이유로 안
   된다. 새로 추가한 프로젝트는 `start_all.bat`을 다시 돌려야 뜬다. */
const PL = { rows: null, warn: [] };

async function loadProjectList(force) {
  if (PL.rows && !force) { _plRender(); return; }
  try {
    const d = await apiFetch('/api/projects/edit');
    PL.rows = (d.projects || []).map(p => ({
      name: p.name || '', port: p.port, data_dir: p.data_dir || '' }));
    PL.warn = d.warnings || [];
    _plRender();
  } catch (e) {
    const b = document.getElementById('pl-tbody');
    if (b) b.innerHTML = '<tr><td colspan="4" class="rv-form-hint">목록을 불러오지 못했습니다 — ' +
                         _esc(String(e.message || e)) + '</td></tr>';
  }
}

function _plRender() {
  const tb = document.getElementById('pl-tbody');
  if (!tb) return;
  const here = String(location.port || '80');
  tb.innerHTML = (PL.rows || []).map((p, i) =>
    '<tr>' +
    '<td><input class="f-inp" data-pl="name" data-i="' + i + '" value="' + _esc(p.name) + '"></td>' +
    '<td><input class="f-inp" data-pl="port" data-i="' + i + '" value="' + _esc(String(p.port)) +
        '" style="width:76px"></td>' +
    '<td><input class="f-inp" data-pl="data_dir" data-i="' + i + '" value="' + _esc(p.data_dir) +
        '" placeholder="비우면 저장소 안의 data 폴더"></td>' +
    '<td>' + (String(p.port) === here
        ? '<span class="rv-form-hint">지금 여기</span>'
        : '<button class="btn btn-sm" onclick="_plDrop(' + i + ')">✕</button>') + '</td>' +
    '</tr>').join('') ||
    '<tr><td colspan="4" class="rv-form-hint">등록된 프로젝트가 없습니다</td></tr>';
  const w = document.getElementById('pl-warn');
  if (w) w.innerHTML = (PL.warn || []).map(m =>
    '<div class="pm-warn pm-note">ℹ ' + _esc(m) + '</div>').join('');
}

function _plCollect() {
  (PL.rows || []).forEach((p, i) => {
    ['name', 'port', 'data_dir'].forEach(f => {
      const el = document.querySelector('[data-pl="' + f + '"][data-i="' + i + '"]');
      if (el) p[f] = (el.value || '').trim();
    });
  });
}

function addProjectRow() {
  _plCollect();
  const used = new Set((PL.rows || []).map(p => parseInt(p.port, 10)));
  let port = 8001;
  while (used.has(port) && port < 8011) port += 1;
  PL.rows = (PL.rows || []).concat([{ name: '', port: port, data_dir: '' }]);
  _plRender();
}

/* **지금 접속해 있는 서버는 못 지운다.** 지우면 배지와 목록이 «없는 프로젝트»를
   가리키게 되고, 서버는 계속 도는데 목록에서만 사라져 되돌리기 어렵다. */
function _plDrop(i) {
  _plCollect();
  const p = (PL.rows || [])[i];
  if (!p) return;
  if (String(p.port) === String(location.port || '80')) {
    _plMsg('지금 접속해 있는 서버는 목록에서 지울 수 없습니다', true);
    return;
  }
  if (!confirm('«' + (p.name || '이름 없음') + '»를 목록에서 지웁니다.\n\n' +
               '서버가 꺼지지는 않고 데이터도 지워지지 않습니다 — ' +
               '목록에서만 사라집니다.\n\n계속할까요?')) return;
  PL.rows.splice(i, 1);
  _plRender();
}

async function saveProjectList() {
  _plCollect();
  _plMsg('저장 중…');
  try {
    const r = await apiFetch('/api/projects/edit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projects: PL.rows || [] }),
    });
    PL.rows = (r.projects || []).map(p => ({
      name: p.name, port: p.port, data_dir: p.data_dir || '' }));
    PL.warn = r.warnings || [];
    _plRender();
    _plMsg('저장했습니다 — 새로 추가한 서버는 이 PC에서 start_all.bat을 다시 실행해야 뜹니다');
    // 로그인 화면·배지가 쓰는 목록이라 지금 화면에도 바로 반영한다
    if (typeof _loadServerInfo === 'function') _loadServerInfo();
  } catch (e) {
    _plMsg('저장 실패 — ' + (e.message || e), true);
  }
}

function _plMsg(t, isErr) {
  const el = document.getElementById('pl-msg');
  if (!el) return;
  el.textContent = t;
  el.classList.toggle('err', !!isErr);
}

/* ══ 용접사 목록의 소속 · 엑셀 내보내기 ═════════════════════════════════════ */

/* 소속 표시 — 한 사람이 여러 팀에 걸치면 «건수 많은 순»으로 나열한다.
   첫 줄만 진하게 두고 나머지는 흐리게 — 주로 어디 사람인지가 먼저 보여야 한다. */
function _welderOrgHtml(orgs) {
  if (!orgs || !orgs.length) return '<span style="color:var(--text-3)">—</span>';
  const main = orgs[0];
  const rest = orgs.length - 1;
  return '<div style="line-height:1.35">' +
    '<div>' + _esc(main.team || main.department || '(미기재)') + '</div>' +
    '<div style="font-size:11px;color:var(--text-3)">' + _esc(main.department || '') +
    (rest ? ' <span title="' + _esc(_welderOrgText(orgs)) + '">외 ' + rest + '곳</span>' : '') +
    '</div></div>';
}

/* 검색·엑셀에 쓰는 평문. 화면 표시와 **같은 순서**여야 한다 — 갈라지면
   검색으로 찾은 사람이 파일에서 다른 소속으로 보인다. */
function _welderOrgText(orgs) {
  return (orgs || []).map(o => (o.department || '') + ' / ' + (o.team || '')).join(' · ');
}

/* 지금 화면 조건(칩 + 검색)에 맞는 전체 — **쪽 나눔 전**이다.
   보이는 50명만 내보내면 «71명이라고 적힌 화면에서 50명짜리 파일»이 나간다. */
function _welderVisibleRows() {
  const el = document.getElementById('welder-txt-filter');
  const txt = ((el && el.value) || '').toLowerCase();
  let rows = _welderFilterRows(S.welderFilter);
  if (txt) {
    rows = rows.filter(w => w.welder_no.toLowerCase().includes(txt) ||
                            (w.name || '').toLowerCase().includes(txt) ||
                            _welderOrgText(w.orgs).toLowerCase().includes(txt));
  }
  return rows;
}

/* 지금 보고 있는 목록을 그대로 Excel로 받는다.

   **화면에 보이는 것과 같아야 한다.** 서버가 다시 거르면 필터·검색이 어긋나
   「화면은 71명인데 파일은 146명」이 된다 — 받는 사람은 어느 쪽이 맞는지 알 수
   없다. 그래서 **번호 목록을 보내고** 서버는 그것만 채운다.

   `fetch().blob()`을 쓴다. 결과 Excel에서 그 방식을 버린 것은 파일이 수백 MB라
   브라우저 메모리를 잡아서였고, 이 목록은 수십~수백 줄이라 해당되지 않는다. */
async function downloadWelderList() {
  const rows = _welderVisibleRows();
  if (!rows.length) { alert('내보낼 용접사가 없습니다'); return; }
  const f = WELDER_FILTERS.find(x => x.v === S.welderFilter);
  const chip = (f && f.l) || '전체';
  const btn = document.getElementById('welder-xlsx');
  if (btn) { btn.disabled = true; btn.textContent = '만드는 중…'; }
  try {
    const r = await fetch('/api/welders/excel', {
      method: 'POST',
      headers: Object.assign({ 'Content-Type': 'application/json' }, _authHeaders()),
      body: JSON.stringify({ welder_nos: rows.map(w => w.welder_no), label: chip }),
    });
    if (!r.ok) {
      let msg = 'HTTP ' + r.status;
      try { msg = (await r.json()).detail || msg; } catch (e) {}
      throw new Error(msg);
    }
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = '용접사_' + chip + '.xlsx';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  } catch (e) {
    alert('목록을 받지 못했습니다 — ' + (e.message || e));
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '⬇ 목록 Excel'; }
  }
}
