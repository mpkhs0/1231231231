"""
WPS 번호에 묶인 판정 규칙을 소스에서 분리해 설정으로 다룬다.

## 왜 필요한가

Check 5·8·9와 §11-1 두께 override, 수리 WPS 판별이 전부 WPS 번호를 소스에
박아두고 있었다. 그런데 원본 매크로 시트를 보면 **접두사가 `RU-`** 다:

    매크로 B=10:  "WPS가 RU-FC-G03일 경우 …"
    매크로 B=11:  "WPS가 RU-SMFC-G01 사용했을 경우 …"

현재 실데이터는 전부 `TR-` 이라 코드가 맞지만, 접두사가 다른 프로젝트가 들어오면
**Check 5·8·9가 조용히 전부 0건이 된다.** 예외도 경고도 나지 않는다.
"검사를 돌렸는데 아무것도 안 나왔다"를 "문제가 없다"로 읽게 된다.

## 이 모듈의 진짜 목적은 설정화가 아니라 경고다

설정 파일로 빼는 것 자체보다, **`check_rules_alive()`가 "이 규칙은 지금 죽어 있다"를
알려주는 것**이 값어치다. 규칙이 참조하는 WPS가 WPS 목록에 하나도 없으면 경고를 남긴다.

## 파일이 없으면 지금 동작 그대로다

`data/wps_rules.json`이 없으면 아래 기본값을 쓴다. 기본값은 2026-08 시점 소스에
박혀 있던 값을 그대로 옮긴 것이라, 설정을 도입해도 판정 결과가 바뀌지 않는다.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from .. import config

logger = logging.getLogger(__name__)

# 소스에 박혀 있던 값 그대로. 설정 파일이 없을 때 이걸 쓴다.
DEFAULTS: dict[str, Any] = {
    "project": "(기본값 — data/wps_rules.json 없음)",
    # **프로젝트 값은 DEFAULTS에 두지 않는다.** 여기 있던 TRION 값들
    # (repair_prefix="TR-FC-R" · wps_corrections 3건 · temp_member=["1C"] ·
    # wps_thickness · material_thickness · check8/9.target_wps)은 전부
    # '프로젝트 세팅'의 프로파일 `params`·`checks`로 옮겼다.
    #
    # `data/wps_rules.json`이 없어서 이 값들이 늘 쓰였고, **다른 프로젝트를
    # 올리면 그대로 물려받았다.** 그게 이 작업이 없앤 사고다.
    #
    # 빈 값으로 남기는 이유: «키가 없어 KeyError»와 «값이 없어 규칙이 안 돈다»를
    # 구분해야 한다. 후자는 `check_rules_alive()`가 경고로 잡는다.
    "repair_prefix": "",
    "wps_corrections": {},
    # **`temp_member`만 예외다 — 이건 조선소 공통 규약이다**(현업 확인 2026-08-13).
    #
    # 위 둘은 WPS 이름이라 프로젝트마다 진짜로 다르지만, `1C`는 도면 번호 체계라
    # 어느 프로젝트에서나 같다. 프로파일에 두었더니 **새 프로젝트마다 같은 사고가
    # 반복됐다** — RUYA에서 「임시부재 제외」 토글이 아무것도 못 걸렀고(그 물량의
    # 95%가 1C 도면이었다), 오류도 경고도 아닌 «안 걸러진다»로만 보였다.
    #
    # 다른 규약을 쓰는 프로젝트는 프로파일 `params`에서 덮어쓰면 된다.
    "temp_member": {"drawing_prefixes": ["1C"]},
    "check8": {
        "target_wps": "",  # 프로파일 params가 채운다
        "max_thickness": 12.0,
        # `material_keyword: "-40"`이었는데 판정은 **문자열 포함이 아니라 온도
        # 임계**로 한다(`_material_impact_temp_c()`가 숫자를 파싱한다). 이름이
        # 판정 방식을 잘못 설명하고 있어 바꿨다.
        "impact_temp_c": -40.0,
    },
    # Check 9 — 대상 WPS에 **API 재질일 때 쓸 수 없는** 두께 목록.
    # 예전에는 `thickness: 12.7` 하나를 «확인 필요»로 표시했는데, 현업 확인
    # (2026-08-13)으로 «API 재질 + 12.7·8.2·6mm 사용 불가»가 됐다. 옛 키
    # `thickness`는 지웠다 — 남겨 두면 파일에 적어도 안 먹는 죽은 값이 된다.
    "check9": {
        "target_wps": "",  # 프로파일 params가 채운다
        "banned_thickness": [12.7, 8.2, 6.0],
        "tolerance": 0.05,
    },
    # Check 16(NDT 요구 대비 미수행) / Check 17(VT 미수행) 공통 유예기간.
    #
    # 용접 직후에는 검사가 아직 안 끝난 것이 정상이다. 유예 없이 "공란=미수행"으로
    # 보면 최근 용접분이 통째로 결함이 되어 지표가 쓸모없어진다.
    #
    # 30일의 근거 — 실데이터 VT 리드타임(용접일 -> VT일) 분포:
    #   50분위 10일 / 75분위 26일 / 90분위 206일
    # 75분위(26일)를 넘기는 30일로 잡으면 «정상 진행 중»의 4분의 3이 걸러진다.
    # 90분위가 206일까지 벌어지는 긴 꼬리가 있어 더 키우면 검출이 거의 사라진다.
    #
    # **기준일은 «오늘»이 아니라 데이터 내 최종 용접일이다.** 같은 파일을 언제
    # 돌려도 같은 결과가 나와야 재검증 비교(개선계획 9번)가 성립한다.
    "inspection_grace_days": 30,
    # **잠정 표식** — 「이 Check는 다른 프로젝트 값을 빌려 쓰는 중이라 재확인이
    # 필요하다」를 화면에 남긴다. `{Check 번호: 사유}`.
    #
    # RUYA가 TRION의 `wps_corrections`·`repair_prefix`를 빌려 쓰면서 생겼다.
    # 지금은 두 프로젝트가 같은 WPS 참조 문서를 쓰고 있어 값이 맞지만, RUYA의
    # WPS 문서가 확정되면 다시 봐야 한다. 표식이 없으면 빌려 온 값으로 나온
    # 숫자를 **확정된 판정으로 읽게 된다** — 오류가 나지 않아 그냥 잊는다.
    "provisional": {},
    # ── WPS 문서의 «기재 누락»을 여기서 보정한다 ────────────────────────
    #
    # 현업 확인(2026-08-10) 결과, Check 4·11의 지적 622건이 실제로는 **WPS 문서에
    # 적히지 않았을 뿐 자격은 있는** 것이었다:
    #
    #   TR-FC-G01   Joint Detail에 PJP/PP가 빠져 있었다        -> Check 4  600건 오탐
    #   TR-SMFC-G01 허용재질에 ASTM A500이 빠져 있었다         -> Check 11  22건 오탐
    #   TR-FC-G01/F01 허용재질에 NV-DW420·EO420이 빠져 있었다
    #
    # 원본 .xlsm을 고칠 수 없으므로(현업이 관리하는 문서다) 읽은 뒤 여기서 더한다.
    # **문서가 갱신되면 해당 항목을 지워야 한다** — 안 지우면 나중에 진짜로 빠진
    # 것까지 덮어 버린다.
    # Check 18(용접봉 Lot 미기재). 현업 확인 결과 Lot 번호와 WPS 브랜드명을 대조할
    # 방법이 없어(매핑표 부재), «누락만 본다»로 범위를 줄였다.
    # ── 프로젝트별 두께 허용범위 ────────────────────────────────────────────
    #
    # 현업 확인(2026-08-11). **공통 규칙이 아니라 이 프로젝트의 합의값**이므로
    # 프로젝트가 바뀌면 반드시 다시 정해야 한다. 그래서 '프로젝트 세팅' 탭에서
    # 구분(프로젝트)으로 표시된다.
    #
    # `wps_thickness`  — WPS 번호에 **부분일치**하는 이름에 적용(TR-FC-F03 등
    #                    접두사가 프로젝트마다 달라서 완전일치로 두면 조용히 죽는다)
    # `material_thickness` — M열 재질 표기에 부분일치. 위에서부터 **먼저 맞는
    #                    것**을 쓴다(S355KT-40이 'KT'와 'KL-'에 동시에 걸리지
    #                    않도록 좁은 것을 앞에 둔다).
    # ── 임시부재(temporary member) 판별 ────────────────────────────────────
    #
    # 현업 확인(2026-08-10): 「도면번호가 1C로 시작하면 임시부재」.
    #
    # **판정에서 빼지 않고 «화면에서 걸러 볼 수 있게»만 했다.** 실측하니 판정
    # 대상 5,516행 중 5,142행(93.2%)이 1C라, 판정 자체에서 빼면 결함이 76건만
    # 남아 «문제가 거의 없는 시스템»이 된다. 되돌리기 어려운 결정이라 대시보드
    # 토글로 두고, 범위 확인은 §11-11로 추적한다.
}

_cache: dict[str, Any] | None = None


def load(force: bool = False) -> dict[str, Any]:
    """설정을 읽는다. 파일이 없거나 깨졌으면 기본값.

    깨진 파일에 대해 예외를 던지지 않는 이유: 설정 하나 때문에 검증 전체가
    멈추면 안 된다. 대신 경고를 남기고 기본값으로 돈다 — 그러면 최소한
    지금까지와 같은 결과가 나온다.
    """
    global _cache
    if _cache is not None and not force:
        return _cache

    rules = json.loads(json.dumps(DEFAULTS))  # 깊은 복사
    path = config.WPS_RULES_FILE
    if path.is_file():
        try:
            user = json.loads(path.read_text(encoding="utf-8"))
            _deep_merge(rules, user)
            logger.info("WPS 규칙 설정 로드: %s (project=%s)", path.name, rules.get("project"))
        except Exception:
            logger.exception("WPS 규칙 설정을 읽지 못해 기본값을 쓴다: %s", path)

    # 마지막에 «활성 프로젝트 프로파일의 params»가 이긴다.
    #
    #     DEFAULTS  <  data/wps_rules.json  <  프로파일 params
    #
    # 프로파일이 단일 진실이고 `wps_rules.json`은 이행기 호환층이다. 프로파일에
    # 값을 넣으면 «프로젝트를 바꿀 때 값도 함께 바뀐다» — 파일 하나에 두면
    # 프로파일을 전환해도 앞 프로젝트의 두께 규칙이 그대로 남는다.
    params = _profile_params()
    if params:
        _deep_merge(rules, params)
    _cache = rules
    return rules


def invalidate() -> None:
    """캐시를 버린다. **프로파일을 바꾸면 반드시 불러야 한다.**

    안 부르면 프로젝트를 전환해도 앞 프로젝트의 `repair_prefix`·`wps_corrections`가
    그대로 남아 판정에 쓰인다 — 화면은 새 프로젝트를 가리키는데 값은 옛것이다.
    오류가 나지 않아 발견이 아주 늦다.
    """
    global _cache
    _cache = None


def _profile_params() -> dict[str, Any]:
    """활성 프로파일의 `params`. 순환 임포트를 피해 함수 안에서 읽는다."""
    try:
        from . import rule_catalog
        return rule_catalog.active_params()
    except Exception:
        logger.exception("프로파일 params를 읽지 못했다 — 설정 파일 값으로 진행한다")
        return {}


def _deep_merge(base: dict[str, Any], over: dict[str, Any]) -> None:
    """`over`를 `base`에 겹쳐 쓴다. **dict는 재귀, 그 외는 통째 교체.**

    리스트를 인덱스로 병합하지 않는 이유: `material_thickness`는 **순서가 곧
    의미**다(위에서부터 먼저 맞는 것, 좁은 조건을 앞에). 인덱스로 섞으면
    `S355KT-40`이 'KT-40' 대신 'KT'에 걸리는 식으로 조용히 뒤집힌다.

    dict를 재귀로 내려가는 이유: 예전 1단계 병합에서는
    `{"wps_corrections": {"TR-FC-G01": {...}}}`를 쓰면 그 WPS의 나머지 보정
    (`add_joint_detail`/`add_materials`)이 **통째로 날아갔다.**
    """
    for k, v in over.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _deep_merge(base[k], v)
        else:
            base[k] = v


def referenced_wps() -> list[str]:
    """규칙이 이름으로 지목하는 WPS 전부. 죽은 규칙 경고에 쓴다."""
    r = load()
    # Check 5는 폐지됐다(§11-2). 폐지된 규칙의 WPS에 «죽어 있다» 경고를 내면
    # 소음이 되어 진짜 경고를 가린다.
    out: list[str] = [
        r["check8"]["target_wps"],
        r["check9"]["target_wps"],
    ]
    out.extend(wps_corrections().keys())
    seen: list[str] = []
    for w in out:
        w = (w or "").strip().upper()
        if w and w not in seen:
            seen.append(w)
    return seen


def check_rules_alive(known_wps: set[str], used_wps: set[str]) -> list[dict[str, Any]]:
    """규칙이 지목하는 WPS가 실제로 존재/사용되는지 확인하고 경고한다.

    known_wps: WPS 목록(.xlsm)에 등재된 WPS 번호
    used_wps:  QMG 데이터에서 실제 시공에 쓰인 WPS 번호

    두 가지를 나눠 보는 이유가 있다:
      - **등재조차 안 됨** -> 접두사가 다르거나 오타. 규칙이 영원히 안 걸린다. 심각.
      - **등재는 됐으나 미사용** -> 이 프로젝트에서 안 쓴 WPS. Check가 0건인 게 정상.
        (실제 사례: TR-FC-G03은 목록에 있으나 시공 0건 -> Check 8·10이 구조적으로 0)
    """
    known = {(w or "").strip().upper() for w in known_wps}
    used = {(w or "").strip().upper() for w in used_wps}
    findings: list[dict[str, Any]] = []

    # ── 목록과 원시 데이터가 «서로 맞는가» ────────────────────────────────
    #
    # 새 프로젝트를 올릴 때 **가장 먼저 깨지는 것이 이름 맞추기**다. RUYA에서는
    # WPS List가 `RU-FC-G01(Rev.8)`인데 원시 데이터는 `RU-FC-G01`이라 한 건도
    # 안 맞았고, Check 2가 100% 오탐이 났다. 그보다 나쁜 것은 조용한 쪽이다 —
    # 이름을 못 찾으면 Check 3·4·11·27은 **그냥 `return None`** 한다. 두께
    # 위반이 있어도 «판정하지 않음»으로 지나간다.
    #
    # 두 집합은 예전부터 이 함수에 들어오고 있었다. **세기만 하면 됐다.**
    if known and used:
        miss = sorted(used - known)
        if miss:
            pct = round(len(miss) * 100 / len(used), 1)
            lvl = "missing" if pct >= 20 else "unused"
            findings.append({"wps": "", "level": lvl,
                             "msg": f"시공에 쓰인 WPS {len(used)}종 중 {len(miss)}종"
                                    f"({pct}%)이 WPS 목록에 없다 — 이름 표기가 서로 "
                                    f"다를 수 있다(개정 표기·접두사·공백). Check 2가 "
                                    f"그만큼 오탐이 되고, Check 3·4·11·27은 그 행을 "
                                    f"**판정하지 않는다**. 예: "
                                    + ", ".join(miss[:5])})
    elif used and not known:
        findings.append({"wps": "", "level": "missing",
                         "msg": "WPS 목록이 비어 있다 — Check 2가 전 행을 «목록에 "
                                "없음»으로 지적하고 Check 3·4·11·27은 한 행도 "
                                "판정하지 않는다"})

    for w in referenced_wps():
        if w not in known:
            findings.append({"wps": w, "level": "missing",
                             "msg": f"규칙이 참조하는 WPS '{w}'가 WPS 목록에 없다 "
                                    f"— 관련 Check는 항상 0건이 된다"})
        elif w not in used:
            findings.append({"wps": w, "level": "unused",
                             "msg": f"WPS '{w}'는 목록에 있으나 시공에 쓰이지 않았다 "
                                    f"— 관련 Check가 0건인 것은 정상이다"})

    # 프로젝트 값이 비어 있으면 «규칙이 안 도는» 상태다. 조용히 넘어가면
    # «검사를 돌렸는데 아무것도 안 나왔다»를 «문제가 없다»로 읽게 된다.
    r = load()
    if not repair_prefixes():
        findings.append({"wps": "", "level": "missing",
                         "msg": "수리 WPS 접두사가 비어 있다 — 수리 WPS를 구분할 수 "
                                "없다. 이 상태로는 수리 시공 행까지 Check 2·4·11이 "
                                "지적해 오탐이 늘어난다 ('프로젝트 세팅'에서 정하라)"})
    if not (r.get("wps_corrections") or {}):
        findings.append({"wps": "", "level": "unused",
                         "msg": "WPS 보정이 비어 있다 — 문서의 기재 누락을 보정하지 "
                                "않으므로 Check 4·11에 오탐이 늘 수 있다"})
    if not ((r.get("temp_member") or {}).get("drawing_prefixes") or []):
        findings.append({"wps": "", "level": "unused",
                         "msg": "임시부재 도면 접두사가 비어 있다 — «임시부재 제외» "
                                "토글이 아무것도 걸러내지 않는다"})

    for f in findings:
        (logger.warning if f["level"] == "missing" else logger.info)("WPS 규칙 점검: %s", f["msg"])
    return findings


# ─── 판정 코드가 쓰는 접근자 ──────────────────────────────────────────────────
def as_prefix_list(raw: Any) -> list[str]:
    """설정값을 접두사 **목록**으로. 문자열·쉼표·목록을 다 받는다.

    **순수 함수로 빼 둔다.** `check_params()`는 «지금 활성 프로파일»이 아니라
    «검사하려고 넘긴 dict»를 봐야 하는데, 전역을 읽는 접근자를 쓰면 인자가
    조용히 무시된다 — 실제로 그렇게 만들었다가 「빈 값인데 경고가 없다」로
    테스트가 잡았다.
    """
    if isinstance(raw, (list, tuple)):
        items = [str(x) for x in raw]
    else:
        items = str(raw or "").split(",")
    return [p for p in (x.strip().upper() for x in items) if p]


def repair_prefixes() -> list[str]:
    """수리 WPS 접두사 **목록**. 문자열 하나로 적어도 받는다.

    현업 자료(2026-08-24, RUYA): 수리로 보이는 WPS가 세 계열에 걸쳐 있다 —
    `RU-FC-R01/R02` · `RU-GTFC-R02` · `RU-SMFC-R01/R02`. 접두사가 하나뿐이면
    `TR-FC-R`로 `FC` 계열만 덮고 나머지는 못 알아본다. 그러면 그 행에 Check 4·11이
    그대로 붙는다 — 과거 600건 규모 오탐과 같은 모양이다.

    쉼표로 적어도 받는다. 화면의 «프로젝트 값» 칸이 한 줄짜리 입력이라,
    목록을 넣으려면 손으로 JSON을 쓰거나 쉼표로 적게 된다.
    """
    return as_prefix_list(load().get("repair_prefix"))


def repair_prefix() -> str:
    """**첫 접두사 하나.** 예전 호출부와 화면 표시를 위해 남긴다.

    비면 `_is_repair_wps()`가 항상 False가 되어 수리 WPS까지 Check 4·11이
    지적한다 — 과거 600건 규모 오탐의 재발이다. 조용히 떨어지지 않도록
    `check_rules_alive()`가 경고를 남긴다.
    """
    got = repair_prefixes()
    return got[0] if got else ""


# `check5()` 접근자는 지웠다. Check 5는 현업 확인(§11-2)으로 폐지됐고, 폐지된
# 규칙의 설정이 남아 있으면 「끈 줄 알았는데 왜 안 되냐」가 된다.


def check8() -> dict[str, Any]:
    return load()["check8"]


def check9() -> dict[str, Any]:
    return load()["check9"]


def inspection_grace_days() -> int:
    """Check 16·17이 «아직 진행 중»으로 봐주는 일수. 0이면 유예 없음."""
    try:
        return max(0, int(load().get("inspection_grace_days", 30)))
    except (TypeError, ValueError):
        return 30


def wps_corrections() -> dict[str, dict]:
    """WPS 번호 -> 보정 항목. 키는 대문자로 정규화해 돌려준다."""
    return {k.upper(): v for k, v in (load().get("wps_corrections") or {}).items()}


_REV_RE = re.compile(
    r"""[\s_-]*                 # 앞의 공백·언더바·하이픈
        \(?                     # 괄호는 있을 수도 없을 수도
        \s*(?:REV|REVISION)     # REV / REVISION
        [\s.:#-]*               # 구분자
        # **개정 번호의 «꼴»을 좁힌다.** `[0-9A-Z]{1,4}`로 두면 `RU-REV-G01`의
        # `G01`까지 개정으로 보아 이름이 `RU`로 잘린다(실측). 개정은 숫자이거나
        # 숫자+글자 하나이거나 글자 하나다 — `G01`처럼 글자로 시작해 숫자가
        # 이어지는 것은 개정이 아니라 이름의 일부다.
        (?:[0-9]{1,3}[A-Z]?|[A-Z])
        \s*\)?                 # 닫는 괄호
        \s*$""",
    re.I | re.X)


def strip_revision(wps_no: str) -> str:
    """WPS 이름 끝의 **Rev 표기를 뗀다.**

        RU-FC-G01(Rev.8)  ->  RU-FC-G01
        RU-FC-G01 Rev 8   ->  RU-FC-G01
        RU-FC-G01-REV.08  ->  RU-FC-G01

    현업 보고(2026-08-24, RUYA): WPS List에는 개정 번호가 붙어 있는데 원시
    데이터에는 없다. 이름을 그대로 맞추면 **한 행도 안 맞아** Check 2가 전량
    「WPS List에 없음」이 되고, Check 3·8·9·24는 조용히 죽는다.

    **끝에 붙은 것만 뗀다.** 이름 가운데의 «REV»는 건드리지 않는다 —
    `RU-REV-G01` 같은 이름이 있을 수 있고, 그건 개정 표기가 아니다.
    """
    return _REV_RE.sub("", (wps_no or "").strip()).strip()


def wps_core(wps_no: str) -> str:
    """WPS 번호에서 **맨 앞 프로젝트 코드를 뗀** 부분. 이름을 맞출 때 이걸 쓴다.

        TR-FC-G01   ->  FC-G01
        RU-FC-G01   ->  FC-G01      같은 WPS다
        TR-SMFC-G01 ->  SMFC-G01

    현업 확인(2026-08-14): **맨 앞 «TR»은 프로젝트 번호**다. RUYA는 TRION 자료를
    기반으로 WPS를 새로 만들므로 뒤쪽 구분은 같고 앞자리만 바뀐다. 이름을 통째로
    비교하면 프로젝트가 바뀌는 순간 `wps_corrections`도 `repair_prefix`도
    `check8/9.target_wps`도 **한 행에도 안 맞고 조용히 죽는다.**

    **세 마디 이상일 때만 뗀다.** `FC-G01`처럼 접두사가 없는 이름에서 첫 마디를
    떼면 `G01`만 남아 너무 헐거워진다 — 접두사를 안 쓰는 프로젝트를 망가뜨린다.
    """
    # **Rev를 먼저 뗀다.** 안 떼면 `FC-G01(REV.8)`이 되어 보정 규칙·수리 접두사·
    # check8/9의 `target_wps`가 전부 어긋난다 — 이름 맞추기가 존재 이유인 함수다.
    parts = [p for p in strip_revision(wps_no).upper().split("-") if p]
    return "-".join(parts[1:]) if len(parts) >= 3 else "-".join(parts)


def apply_corrections(wps_table: dict[str, dict]) -> list[str]:
    """읽어 온 WPS 표에 «기재 누락» 보정을 입힌다. 바뀐 WPS 목록을 돌려준다.

    **읽은 직후 한 번만 부른다.** 판정 코드 여기저기서 보정을 따지면 어느 Check가
    무엇을 보정했는지 추적할 수 없게 된다 — 한 곳에서 표를 고쳐 두면 그 뒤로는
    모든 Check가 «보정된 WPS»를 그냥 읽는다.

    보정 키는 **프로젝트 코드를 뗀 이름**으로도 찾는다(`wps_core`). 키가
    `TR-FC-G01`이어도 RUYA의 `RU-FC-G01`에 걸려야 한다 — 같은 WPS를 프로젝트
    번호만 바꿔 만들기 때문이다. 이름을 통째로 비교하면 프로젝트가 바뀌는 순간
    보정이 **한 행에도 안 맞고 조용히 죽는다.**
    """
    by_core: dict[str, list[str]] = {}
    for name in wps_table:
        by_core.setdefault(wps_core(name), []).append(name)

    touched: list[str] = []
    for key, corr in wps_corrections().items():
        # 이름이 그대로 있으면 그것만. 없으면 프로젝트 코드를 뗀 이름으로 찾는다.
        names = [key] if key in wps_table else by_core.get(wps_core(key), [])
        for name in names:
            _apply_one(wps_table[name], corr, name, touched)

    for t in touched:
        logger.info("WPS 기재 보정: %s", t)
    return touched


def _apply_one(entry: dict, corr: dict, wps_no: str, touched: list[str]) -> None:
    """보정 하나를 WPS 표 항목에 입힌다. `touched`에 무엇을 고쳤는지 남긴다."""
    add_jd = [x for x in (corr.get("add_joint_detail") or [])]
    if add_jd:
        cur = entry.get("joint_detail") or ""
        missing = [x for x in add_jd if x.upper() not in cur.upper()]
        if missing:
            entry["joint_detail"] = (cur + ", " if cur else "") + ", ".join(missing)
            touched.append(f"{wps_no} Joint Detail += {missing}")

    add_mat = [x for x in (corr.get("add_materials") or [])]
    if add_mat:
        mats = entry.setdefault("materials", [])
        blob = " ".join((m.get("base_metal") or "") for m in mats).upper()
        missing = [x for x in add_mat if x.upper() not in blob]
        if missing:
            # 기존 항목의 두께 범위를 건드리지 않도록 **새 항목으로** 더한다.
            # 같은 항목에 재질만 밀어 넣으면 그 재질이 남의 두께 범위를 물려받는다.
            mats.append({"base_metal": ", ".join(missing), "thk_range": ""})
            touched.append(f"{wps_no} 허용재질 += {missing}")


def temp_member_prefixes() -> tuple[str, ...]:
    """임시부재로 보는 도면번호 접두사. 비면 «임시부재 구분 없음»이다."""
    raw = (load().get("temp_member") or {}).get("drawing_prefixes") or []
    return tuple(str(x).strip().upper() for x in raw if str(x).strip())


def is_temp_member(drawing_no: str) -> bool:
    pre = temp_member_prefixes()
    if not pre:
        return False
    return (drawing_no or "").strip().upper().startswith(pre)


# `check18_enabled()`는 지웠다. 켬/끔 스위치가 둘이면 **JSON이 UI를 이긴다** —
# '프로젝트 세팅'에서 켰는데 아무 일도 안 일어나고, 결과 스냅샷에는 «켬»으로
# 남아 결과가 거짓말을 한다. 스위치는 `rule_catalog` 하나뿐이다.

def check_params(rules: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """프로젝트 값이 «규칙을 죽이고 있는가»를 본다. WPS 목록 없이도 답한다.

    `check_rules_alive()`는 검증이 끝난 뒤 실데이터와 대조하지만, 값을 고치는
    그 자리에서는 아직 대조할 데이터가 없다. 그런데 **비어 있으면 그 순간 이미
    규칙이 죽는다.** 저장하고 나서야 알면 늦다.

    빈 값이 조용히 넘어가면 «검사를 돌렸는데 아무것도 안 나왔다»를 «문제가
    없다»로 읽게 된다. 실제로 겪은 것들이다:

        repair_prefix 비었음   -> 수리 WPS를 구분 못 해 Check 2·4·11이 그 행까지
                                  지적한다 (과거 600건 규모 오탐의 재발)
        wps_corrections 비었음 -> 문서 기재 누락을 보정하지 않아 Check 4·11 오탐
                                  (RUYA 실측 622건)
        temp_member 비었음     -> «임시부재 제외» 토글이 아무것도 안 거른다
        target_wps 비었음      -> 그 특수 검사가 한 행도 대조하지 않는다

    `level`: `warn`(규칙이 죽는다) / `note`(그럴 수도 있다).
    **막지는 않는다** — 프로젝트에 따라 정말 없을 수도 있다.
    """
    r = rules if rules is not None else load()
    out: list[dict[str, Any]] = []

    def add(key: str, level: str, msg: str) -> None:
        out.append({"key": key, "level": level, "msg": msg})

    if not as_prefix_list(r.get("repair_prefix")):
        add("repair_prefix", "warn",
            "수리 WPS 접두사가 비어 있습니다 — 수리 시공 행까지 Check 2·4·11이 "
            "지적해 오탐이 크게 늘어납니다")
    if not (r.get("wps_corrections") or {}):
        add("wps_corrections", "note",
            "WPS 보정이 비어 있습니다 — 문서의 기재 누락을 보정하지 않으므로 "
            "Check 4·11에 오탐이 늘 수 있습니다")
    if not ((r.get("temp_member") or {}).get("drawing_prefixes") or []):
        add("temp_member", "warn",
            "임시부재 도면 접두사가 비어 있습니다 — «임시부재 제외» 토글이 "
            "아무것도 걸러내지 않습니다")
    for key, checks in (("check8", "8"), ("check9", "9")):
        if not ((r.get(key) or {}).get("target_wps") or "").strip():
            add(key, "note",
                f"Check {checks}의 대상 WPS가 비어 있습니다 — 이 검사는 한 행도 "
                f"대조하지 않습니다(«위반 0건»이 아니라 «대상 0건»입니다)")
    days = r.get("inspection_grace_days")
    if not isinstance(days, int) or days < 0:
        add("inspection_grace_days", "warn",
            "검사 유예일이 0 이상의 정수가 아닙니다 — Check 16·17이 어긋납니다")
    return out
