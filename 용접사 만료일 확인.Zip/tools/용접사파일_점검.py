# -*- coding: utf-8 -*-
"""용접사 파일이 «어떻게 읽히는가»를 그대로 보여준다.

「전체가 자격 미등록으로 잡힌다」는 증상은 원인이 여럿인데, 화면에는 전부 똑같이
보인다. 이 도구가 그 셋을 갈라 준다:

    ① 형식을 잘못 골랐다      -> 이름 열을 번호로 읽는다
    ② 열 위치가 다르다         -> 번호나 Process가 빈 칸으로 읽힌다
    ③ 번호 표기가 어긋난다     -> 파일은 `0310`, QMG는 `310` (또는 반대)

**저장소 코드를 임포트하지 않는다.** 서버에 어느 버전이 올라가 있든 파일 자체를
있는 그대로 보기 위해서다 — 코드가 옛것이면 그것도 이 결과와 대조해 알 수 있다.

    python tools/용접사파일_점검.py <용접사파일.xlsx> [QMG파일.xlsx] [찾을번호 ...]

결과는 콘솔과 `용접사파일_점검.txt`에 함께 쓴다 — 콘솔이 cp949라 한글이 깨질 수
있어서 파일로도 남긴다.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

from openpyxl import load_workbook

# 두 형식. `verifier.WelderLayout`과 같아야 한다 — 여기를 고치면 그쪽도 고쳐라.
LAYOUTS = (
    ("만료일 포함", 10, {"no": 2, "name": 3, "process": 4, "expire": 13, "disq": 14}),
    ("기존 자격 DB", 3, {"no": 3, "name": 4, "process": 6}),
)
# 용접 프로세스인가 — `verifier._looks_like_process`와 같아야 한다.
# 「ASCII 대문자면 프로세스」로 보면 이름(`NA YEONG SEOG(나영석)` -> `NAYEONGSEOG`)
# 까지 통과해서 형식을 잘못 고른다. 실측상 실제 값은 넷뿐이다.
PROCESS_FULL = frozenset(("SMAW", "GMAW", "GTAW", "FCAW", "SAW", "PAW",
                          "ESW", "EGW", "OFW", "SW", "GMAWP", "FCAWS", "FCAWG"))
PROCESS_ROOTS = frozenset(("SM", "GM", "GT", "FC", "SA", "PA", "ES", "EG", "OF"))


def looks_like_process(s: str) -> bool:
    for part in re.split(r"[,/+]", s):
        p = part.strip()
        if not p:
            continue
        if p in PROCESS_FULL:
            return True
        if len(p) == 4 and p[:2] in PROCESS_ROOTS and p[2:] in PROCESS_ROOTS:
            return True
    return False

# QMG 원본의 용접사 열 (AP · AR · AT · AV)
QMG_WELDER_COLS = (42, 44, 46, 48)
QMG_HEADER_ROWS = 5

_out: list[str] = []


def say(s: str = "") -> None:
    _out.append(s)
    try:
        print(s)
    except UnicodeEncodeError:          # cp949 콘솔
        print(s.encode("cp949", "replace").decode("cp949"))


def cell(row, col: int):
    return row[col - 1] if row and col <= len(row) else None


def clean(v) -> str:
    return "" if v is None else str(v).strip()


def norm_process(v) -> str:
    s = clean(v).upper()
    s = re.sub(r"\(.*?\)", "", s)
    s = re.sub(r"[\n\r\s]+", "", s)
    s = re.sub(r"-CARRIAGE$", "", s)
    return s


def main() -> int:
    if len(sys.argv) < 2:
        say(__doc__ or "")
        return 1
    wpath = Path(sys.argv[1])
    qpath = Path(sys.argv[2]) if len(sys.argv) > 2 and Path(sys.argv[2]).exists() else None
    wanted = [a for a in sys.argv[2:] if not Path(a).exists()]

    say(f"용접사 파일: {wpath.name}  ({wpath.stat().st_size:,} bytes)")

    # 서식(취소선)까지 보려면 read_only 를 끄고 한 번 더 읽어야 한다
    wb = load_workbook(str(wpath), data_only=True, read_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = list(ws.iter_rows(values_only=True))
    sheets = wb.sheetnames
    wb.close()
    say(f"시트: {sheets}  (첫 시트를 쓴다)")
    say(f"전체 {len(rows):,}행")
    say("")

    # ── 형식 판별 ────────────────────────────────────────────────────────────
    say("=" * 68)
    say("① 형식 판별 — 번호와 «프로세스처럼 생긴» 값이 몇 행에서 나오는가")
    say("=" * 68)
    scores = []
    for name, header, cols in LAYOUTS:
        ok = bad_no = bad_proc = 0
        for r in rows[header:]:
            if not r:
                continue
            no = clean(cell(r, cols["no"]))
            prc = norm_process(cell(r, cols["process"]))
            if not no:
                bad_no += 1
                continue
            if looks_like_process(prc):
                ok += 1
            else:
                bad_proc += 1
        scores.append((ok, name, header, cols))
        say(f"  {name:14s} 머리말 {header}행 · 번호 {cols['no']}열 · Process {cols['process']}열")
        say(f"       읽힘 {ok:6,}행 · 번호 빈칸 {bad_no:6,}행 · Process 이상 {bad_proc:6,}행")
    scores.sort(key=lambda x: -x[0])
    if not scores[0][0]:
        say("")
        say("  !! 어느 형식으로도 «번호+Process»를 못 찾았다.")
        say("     -> 열 위치가 둘 다 아니다. 아래 ②의 실제 값을 보고 열을 정하라.")
        chosen = None
    else:
        chosen = scores[0]
        say("")
        say(f"  => «{chosen[1]}» 형식으로 읽는다 ({chosen[0]:,}행)")
        if len(scores) > 1 and scores[1][0]:
            say(f"     (다른 형식도 {scores[1][0]:,}행 나옴 — 차이가 작으면 위험하다)")
    say("")

    # ── 실제 값 ──────────────────────────────────────────────────────────────
    say("=" * 68)
    say("② 데이터가 실제로 어디서 시작하고 무엇이 들어 있는가")
    say("=" * 68)
    for i, r in enumerate(rows[:16], start=1):
        vals = [(c, clean(cell(r, c))) for c in range(1, 16)]
        vals = [(c, v) for c, v in vals if v]
        if not vals:
            continue
        head = "  ".join(f"{chr(64+c) if c<27 else c}={v[:18]!r}" for c, v in vals[:7])
        say(f"  {i:3d}행  {head}")
    say("")

    # ── 취소선 ───────────────────────────────────────────────────────────────
    say("=" * 68)
    say("③ 취소선 — 서식을 읽지 않으므로 «판정에 영향이 없어야» 한다")
    say("=" * 68)
    try:
        wb2 = load_workbook(str(wpath), data_only=True)     # 서식을 보려면 read_only 끔
        ws2 = wb2[wb2.sheetnames[0]]
        strike, strike_rows = 0, []
        col_no = (chosen[3]["no"] if chosen else 2)
        for i in range(1, min(ws2.max_row, 20000) + 1):
            c = ws2.cell(row=i, column=col_no)
            if c.font and c.font.strike:
                strike += 1
                if len(strike_rows) < 8:
                    strike_rows.append((i, clean(c.value)))
        wb2.close()
        say(f"  번호 열({col_no})에 취소선이 그어진 행: {strike:,}개")
        for i, v in strike_rows:
            say(f"     {i}행  {v!r}")
        say("")
        say("  * 로더는 `values_only=True`로 읽어 **서식을 아예 보지 않는다.**")
        say("    취소선 행도 다른 행과 똑같이 «등록된 용접사»로 적재된다.")
        say("    따라서 취소선은 «자격 미등록» 오탐의 원인이 될 수 없다.")
    except Exception as exc:
        say(f"  (서식을 읽지 못했다: {exc})")
    say("")

    # ── 특정 번호 ────────────────────────────────────────────────────────────
    if wanted:
        say("=" * 68)
        say(f"④ 찾는 번호: {', '.join(wanted)}")
        say("=" * 68)
        for target in wanted:
            found = []
            for i, r in enumerate(rows, start=1):
                if not r:
                    continue
                for c in range(1, 16):
                    v = clean(cell(r, c))
                    if v == target or v.lstrip("0") == target.lstrip("0"):
                        found.append((i, c, v, cell(r, c)))
            if not found:
                say(f"  '{target}': 파일 어디에도 없다")
                continue
            for i, c, v, raw in found[:6]:
                col = chr(64 + c) if c < 27 else str(c)
                mark = ""
                if chosen and c == chosen[3]["no"]:
                    prc = norm_process(cell(rows[i - 1], chosen[3]["process"]))
                    ok = bool(looks_like_process(prc))
                    mark = (f"  <- 번호 열 · Process={prc!r} "
                            f"{'(정상)' if ok else '(!! 이 행은 건너뛴다)'}")
                    if i <= chosen[2]:
                        mark += f"  !! 머리말({chosen[2]}행) 안이라 안 읽는다"
                say(f"  '{target}': {i}행 {col}열 = {v!r} (원값 {raw!r}, {type(raw).__name__}){mark}")
        say("")

    # ── QMG 대조 ─────────────────────────────────────────────────────────────
    if qpath:
        say("=" * 68)
        say("⑤ QMG 원본의 용접사 번호와 «표기가 맞는가»")
        say("=" * 68)
        wbq = load_workbook(str(qpath), data_only=True, read_only=True)
        wsq = wbq[wbq.sheetnames[0]]
        qnos: set[str] = set()
        for i, r in enumerate(wsq.iter_rows(values_only=True), start=1):
            if i <= QMG_HEADER_ROWS:
                continue
            for c in QMG_WELDER_COLS:
                v = clean(cell(r, c))
                if v:
                    qnos.add(v)
        wbq.close()
        if chosen:
            _, _, header, cols = chosen
            fnos = {clean(cell(r, cols["no"])) for r in rows[header:] if r}
            fnos.discard("")
            miss = sorted(qnos - fnos)
            say(f"  QMG에 나온 용접사 {len(qnos):,}명 · 파일에 있는 번호 {len(fnos):,}개")
            say(f"  파일에 없는 사람: {len(miss):,}명  (이들이 «자격 미등록»으로 잡힌다)")
            for m in miss[:12]:
                near = [f for f in fnos if f.lstrip("0") == m.lstrip("0")]
                say(f"     '{m}'" + (f"   <- 파일엔 {near[0]!r} 로 있다 (앞자리 0 차이)" if near else ""))
            if len(miss) > 12:
                say(f"     ... 외 {len(miss)-12:,}명")
            if len(miss) == len(qnos):
                say("")
                say("  !! 전원이 파일에 없다 -> 형식이나 열 위치가 어긋난 것이다.")
                say("     위 ①②를 보고 실제 번호 열을 확인하라.")
        say("")

    out = Path("용접사파일_점검.txt")
    out.write_text("\n".join(_out), encoding="utf-8")
    say(f"(같은 내용을 {out} 에도 저장했다)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
