"""
판정 로직 도식 생성기 — Mermaid 소스를 **코드에서 뽑아낸다.**

## 왜 손으로 그리지 않는가

이 프로젝트가 반복해서 치른 비용이 전부 «정의가 여러 곳에 흩어져 하나를 빠뜨린»
종류였다. 색상 정의가 여섯 곳에 있고 그중 셋을 빠뜨려도 예외가 나지 않았다.
문서(`QC_검사로직_상세분석.md`)도 판정 로직보다 늦게 갱신되곤 했다.

도식은 그중에서도 가장 조용히 낡는다 — 그림은 틀려도 아무 데서도 오류가 나지
않고, 보는 사람은 그림을 믿는다. 그래서 **`verifier.py`를 원본으로 삼아 매번
새로 만든다.** Check를 추가하면 도식이 저절로 따라오고, 어긋나면 테스트가 잡는다.

## 무엇을 어디서 읽는가

| 정보 | 출처 |
|---|---|
| Check 번호·이름 | `verifier.CHECK_NAMES` |
| 색상 | `verifier.CHECK_COLORS` + `_FILLS`(실제 RGB) |
| 겹칠 때의 승자 | `verifier._PRIORITY` |
| 마킹 열 | `Flag(...)` 호출을 **AST로 훑어서** |
| 1차/2차 패스 | `Flag(...)`가 `_check_row` 안에 있는지 |
| 행 회계 숫자 | 인자로 받은 검증 결과 (없으면 숫자 없이 구조만) |

마킹 열과 패스를 AST로 읽는 이유: 이 둘만 상수 테이블에 없다. 별도 표를 새로
만들면 그 표가 또 하나의 «어긋날 수 있는 자리»가 된다. 판정 코드를 고치지 않고
읽기만 하는 쪽이 안전하다.
"""

from __future__ import annotations

import ast
import inspect
import logging
import os
from pathlib import Path
from typing import Any

from .. import config
from . import verifier as V

logger = logging.getLogger(__name__)

# 판정 흐름에서 축(axis)별로 묶는 방법.
#
# 이 묶음만은 코드에서 유도할 수 없다 — «무엇을 보는 검사인가»는 사람이 정한
# 분류이지 코드에 적힌 사실이 아니다. 대신 여기 없는 Check가 생기면 자동으로
# '기타'로 떨어지고, 테스트가 «분류되지 않은 Check»를 알려준다.
_AXES: tuple[tuple[str, str, tuple[int, ...]], ...] = (
    ("proc", "절차 적합 — 기재된 값이 WPS 규칙에 맞는가",
     (2, 3, 4, 5, 8, 9, 10, 11, 12, 18, 20, 23, 24, 25, 27)),
    ("qual", "자격·일정 — 누가 언제 했는가",
     (1, 6, 7, 19)),
    ("insp", "검사 이행 — 해야 할 검사를 했는가",
     (16, 17, 22, 26)),
    ("data", "데이터 품질 — 기록 자체가 성립하는가",
     (13, 14, 21)),
)

# Check 15는 결번이다. 번호를 재사용하면 검토 기록 키(`…|Check No`)가
# 과거 의견을 무관한 항목에 붙인다.
_RETIRED_NOTE = {
    15: "결번 — 대조할 조합이 0건이라 착수하지 않음",
    28: "결번 — 「미승인 용접봉」은 Check 18로 합쳤음",
}


# ─── verifier에서 사실을 뽑아낸다 ────────────────────────────────────────────
def _col_letter(col_no: int) -> str:
    from openpyxl.utils import get_column_letter
    return get_column_letter(col_no)


def emitted_checks() -> dict[int, dict[str, Any]]:
    """`Flag(...)`를 실제로 만드는 Check만 골라 마킹 열·패스를 함께 돌려준다.

    `CHECK_NAMES`에는 있는데 아무 데서도 만들지 않는 번호가 있다 — Check 5·7은
    현업 답변으로 규칙을 걷어냈지만 **이름은 남겨 두었다**(검토 기록 키가 그
    번호를 쓰고 있어서 지우면 과거 의견이 붙을 자리를 잃는다).
    도식에서 그 둘을 «활성»으로 그리면 없는 검사를 있는 것처럼 보여준다.
    """
    tree = ast.parse(inspect.getsource(V))

    # 1차 패스는 `_check_row`와 그것이 부르는 `_cN_…` 헬퍼 안에서 일어난다.
    # 2차 패스(13/14)는 `run()`에서 `_register_flag`로 뒤늦게 합류한다 —
    # 이 구분이 중요한 이유는 2차 패스가 **집계를 소급 갱신해야** 하기 때문이다
    # (그걸 빠뜨려 257행이 용접사 집계에서 누락된 적이 있다).
    def _in_first_pass(fn_name: str) -> bool:
        return fn_name.startswith("_c") and fn_name not in ("_c13", "_c14")

    out: dict[int, dict[str, Any]] = {}
    for fn in ast.walk(tree):
        if not isinstance(fn, ast.FunctionDef):
            continue
        for node in ast.walk(fn):
            if not (isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Name)
                    and node.func.id == "Flag"
                    and node.args):
                continue
            first = node.args[0]
            if not (isinstance(first, ast.Constant) and isinstance(first.value, int)):
                continue
            no = first.value
            info = out.setdefault(no, {"cols": set(), "pass": 1})
            # 두 번째 인자가 마킹 열. `Col.X` 형태이거나 변수(행마다 달라지는 것).
            if len(node.args) > 1:
                col = node.args[1]
                if isinstance(col, ast.Attribute) and isinstance(col.value, ast.Name) \
                        and col.value.id == "Col":
                    info["cols"].add(_col_letter(getattr(V.Col, col.attr)))
                else:
                    info["cols"].add("*")   # 조건에 따라 달라진다
            if no in (13, 14) or not _in_first_pass(fn.name):
                info["pass"] = 2
    return out


def _rgb(color: str) -> str:
    """`_FILLS`의 실제 채우기 색. openpyxl은 알파를 붙여 8자리로 준다."""
    raw = str(V._FILLS[color].start_color.rgb or "")
    return raw[-6:] if len(raw) >= 6 else "999999"


def _fg(color: str) -> str:
    """배경 위에 얹을 글자색. 어두운 배경에는 흰 글자."""
    r, g, b = (int(_rgb(color)[i:i + 2], 16) for i in (0, 2, 4))
    return "#ffffff" if (r * 299 + g * 587 + b * 114) / 1000 < 145 else "#111111"


# 노드 라벨에 `<b>`·`<i>`를 쓰지 않는다.
#
# Mermaid는 HTML 라벨의 높이를 «굵지 않은 글꼴» 기준으로 재서, 굵은 첫 줄이 있으면
# 상자가 한 줄만큼 짧아진다 — 실측으로 세 줄짜리 Check 노드의 마지막 줄이 잘렸다.
# 잘려도 오류가 나지 않아 그림만 보면 «원래 두 줄인가 보다»로 읽힌다.
# 강조가 필요하면 줄을 나누거나 색으로 구분한다.

# ─── ① 판정 흐름 + 행 회계 ───────────────────────────────────────────────────
def flow(result: dict | None = None) -> str:
    """전체 행이 어떤 갈래를 거쳐 «결함»에 도달하는지.

    행 회계 숫자를 함께 싣는다 — 이 도식이 답해야 하는 질문이 «왜 결함률의
    분모가 10,034가 아니라 5,516인가»이기 때문이다. 결과가 없으면 구조만 그린다.
    """
    r = result or {}

    def n(key: str) -> str:
        v = r.get(key)
        return f"<br/>{v:,}행" if isinstance(v, int) else ""

    checks_1 = sorted(k for k, v in emitted_checks().items() if v["pass"] == 1)
    checks_2 = sorted(k for k, v in emitted_checks().items() if v["pass"] == 2)
    lbl1 = ", ".join(f"C{c}" for c in checks_1)
    lbl2 = ", ".join(f"C{c}" for c in checks_2)

    temp = r.get("temp_judged_rows")
    temp_note = ("" if not isinstance(temp, int) or not temp else
                 f'\n  JUDGED -. "임시부재(1C) {temp:,}행<br/>화면 토글로만 제외" .-> TEMP[["보기에서 제외 가능"]]')

    return f"""flowchart TD
  ALL["원본 전체{n('total_rows')}"] --> DEL{{"X열 삭제 표시"}}
  DEL -- 있음 --> DELETED["판정 대상 아님{n('deleted_rows')}"]
  DEL -- 없음 --> ACTIVE["유효 행{n('active_rows')}"]

  ACTIVE --> UW{{"AJ열 WPS No 공란"}}
  UW -- 공란 --> UNWORKED["미작업 · Check 0{n('unworked_rows')}<br/>결함이 아니다"]
  UW -- 있음 --> JUDGED["판정 대상{n('judged_rows')}<br/>모든 결함률의 분모"]

  JUDGED --> P1["1차 패스<br/>{lbl1}"]
  P1 --> P2["2차 패스<br/>{lbl2}<br/>집계를 소급 갱신한다"]
  P2 --> HIT{{"플래그가 붙었나"}}
  HIT -- 예 --> FLAGGED["결함 행{n('flagged_rows')}"]
  HIT -- 아니오 --> CLEAN["정상 행{n('clean_rows')}"]

  FLAGGED --> MARK["셀 색칠 · 주석<br/>겹치면 우선순위 1개만"]{temp_note}

  classDef out fill:#eeeeee,stroke:#bbbbbb,color:#555555;
  classDef key fill:#1F3864,stroke:#1F3864,color:#ffffff;
  classDef bad fill:#C0504D,stroke:#C0504D,color:#ffffff;
  classDef ok  fill:#00B050,stroke:#00B050,color:#ffffff;
  class DELETED,UNWORKED out;
  class JUDGED key;
  class FLAGGED bad;
  class CLEAN ok;
"""


# ─── ② Check 지도 ────────────────────────────────────────────────────────────
def checks() -> str:
    """16가지 검사를 축별로 묶고, 각자의 색·마킹 열·패스를 함께 보여준다.

    **subgraph가 아니라 «축 노드 + 간선»으로 그린다.** 처음에는 축마다 subgraph를
    두고 노드를 그 안에 넣었는데, 간선이 하나도 없는 그래프가 되어 Mermaid의
    레이아웃이 폭주했다 — 실측 viewBox 16,530 × 16,463px(노드 18개). 화면에서는
    «점 하나»로 줄어들어 아무것도 읽을 수 없었다.

    간선으로 이으면 방향이 정해져 dagre가 정상적으로 배치한다. 덤으로 «판정 대상
    행 하나가 이 축들을 모두 지난다»는 사실이 그림에 드러난다.
    """
    emitted = emitted_checks()
    placed: set[int] = set()
    lines = ["flowchart LR", '  ROW(["판정 대상 행"])']
    styles = ['  style ROW fill:#1F3864,stroke:#1F3864,color:#ffffff']

    def node(no: int) -> str:
        name = V.CHECK_NAMES.get(no, "")
        color = V.CHECK_COLORS.get(no, "Gray")
        info = emitted.get(no)
        styles.append(f"  style C{no} fill:#{_rgb(color)},stroke:#{_rgb(color)},"
                      f"color:{_fg(color)}")
        if not info:
            # 이름은 남아 있으나 판정하지 않는 것. «없다»가 아니라 «걷어냈다»이다.
            styles.append(f"  style C{no} stroke-dasharray:4 3,opacity:0.45")
            return f'  C{no}["Check {no}<br/>{name}<br/>판정하지 않음"]'
        # 마킹 열이 행마다 달라지는 검사가 있다(두께는 J/K, Check 16은 검사 종류별
        # 수행일 열). 한 열로 적으면 «다른 열은 안 칠한다»로 읽힌다.
        cols = sorted(info["cols"])
        col_txt = "열 가변" if "*" in cols else "·".join(cols) + "열"
        return (f'  C{no}["Check {no}<br/>{name}<br/>'
                f'{col_txt} · {info["pass"]}차 · {color}"]')

    for key, title, members in _AXES:
        head, _, tail = title.partition(" — ")
        lines.append(f'  AX_{key}["{head}<br/>{tail}"]')
        styles.append(f"  style AX_{key} fill:none,stroke:#888888,stroke-width:1px")
        lines.append(f"  ROW --> AX_{key}")
        for no in members:
            if no in V.CHECK_NAMES:
                lines.append(node(no))
                lines.append(f"  AX_{key} --> C{no}")
                placed.add(no)

    rest = [no for no in sorted(V.CHECK_NAMES)
            if no not in placed and no != V.CHECK_UNWORKED]
    retired = sorted(_RETIRED_NOTE)
    if rest or retired:
        lines.append('  AX_etc["번호만 남은 것<br/>검토 기록 키가 이 번호를 쓰고 있어 지우지 않는다"]')
        styles.append("  style AX_etc fill:none,stroke:#888888,stroke-dasharray:4 3")
        lines.append("  ROW -.-> AX_etc")
        for no in rest:
            lines.append(node(no))
            lines.append(f"  AX_etc -.-> C{no}")
        for no in retired:
            lines.append(f'  R{no}["Check {no}<br/>{_RETIRED_NOTE[no]}"]')
            lines.append(f"  AX_etc -.-> R{no}")
            styles.append(f"  style R{no} fill:#eeeeee,stroke-dasharray:4 3,"
                          f"stroke:#bbbbbb,color:#777777")

    return "\n".join(lines + styles) + "\n"


# ─── ③ 색 우선순위 ───────────────────────────────────────────────────────────
def priority() -> str:
    """한 셀에 여러 Check가 걸렸을 때 어느 색이 이기는가.

    왼쪽이 이긴다. 이 순서는 `_PRIORITY` 하나가 정하고, 그것을 그대로 그린다.
    «어느 Check도 쓰지 않는 색»은 흐리게 둔다 — 지금은 없지만 Check를 걷어내면
    생기고, 그때 «남아 있는 정의»를 보여주는 편이 낫다.
    """
    order = sorted(V._PRIORITY.items(), key=lambda kv: kv[1])
    used: dict[str, list[int]] = {}
    for no, color in V.CHECK_COLORS.items():
        if no != V.CHECK_UNWORKED:
            used.setdefault(color, []).append(no)

    lines = ["flowchart LR"]
    styles: list[str] = []
    prev: str | None = None
    for color, rank in order:
        owners = used.get(color)
        who = ("Check " + "·".join(str(n) for n in sorted(owners))) if owners             else "쓰는 Check 없음"
        lines.append(f'  {color}["{rank}. {color}<br/>{who}"]')
        styles.append(f"  style {color} fill:#{_rgb(color)},stroke:#{_rgb(color)},"
                      f"color:{_fg(color)}")
        if not owners:
            styles.append(f"  style {color} opacity:0.4")
        if prev:
            # 이긴다 -> 진다 방향. 떠 있는 범례 노드를 두지 않는다(간선 없는 노드는
            # 레이아웃을 망가뜨린다). 읽는 법은 카드 설명이 말한다.
            lines.append(f"  {prev} -->|이긴다| {color}")
        prev = color
    return "\n".join(lines + styles) + "\n"


# ─── 그림 옆에 붙는 설명 ─────────────────────────────────────────────────────
#
# 도식만 놓으면 «무엇이 그려졌는지»는 보이지만 «왜 그런지»는 안 보인다. 그런데
# 이 프로젝트에서 사람이 실제로 묻는 것은 후자다 — 「왜 결함률 분모가 1만이
# 아니라 5,516인가」, 「왜 이 셀은 주황인가」.
#
# 설명도 **코드에서 만든다.** 손으로 적으면 도식은 갱신되는데 설명만 옛말이
# 남고, 그건 그림이 틀린 것보다 더 나쁘다(글은 더 믿기 때문이다).
# 숫자는 결과가 있을 때만 넣는다 — 문서에 박히면 회차마다 더러워진다.
def _notes_flow(result: dict | None) -> list[dict[str, str]]:
    r = result or {}
    em = emitted_checks()
    n1 = sorted(k for k, v in em.items() if v["pass"] == 1)
    n2 = sorted(k for k, v in em.items() if v["pass"] == 2)

    def num(key: str, unit: str = "행") -> str:
        v = r.get(key)
        return f" 지금 회차는 **{v:,}{unit}**이다." if isinstance(v, int) else ""

    out = [
        {"heading": "판정 대상이 곧 분모다",
         "body": "결함률을 말할 때 분모는 언제나 **판정 대상**이다. 원본 전체가 아니다."
                 + num("judged_rows") +
                 " 삭제 표시(X열)가 있는 행과 미작업 행이 먼저 빠지기 때문이다."},
        {"heading": "미작업은 «결함 아님»이다",
         "body": "WPS No(AJ열)가 공란이면 아직 용접이 수행되지 않은 계획 물량으로 본다"
                 " — Check 0."
                 + num("unworked_rows") +
                 " 이 행들은 결함률·용접사 평가·부서 실적 **어디에도 섞이지 않는다.**"
                 " 실데이터 전수 확인 결과 WPS가 공란인 행은 우측 실적 열이 100% 공란이었고,"
                 " WPS가 있는데 용접일이 없는 행은 0건이었다."},
        {"heading": "검사는 두 번에 나눠 돈다",
         "body": f"1차 패스에서 {', '.join('C' + str(c) for c in n1)}가 한 행씩 판정한다."
                 f" {', '.join('C' + str(c) for c in n2)}는 **전체를 다 본 뒤에야** 알 수 있어"
                 " 2차 패스에서 뒤늦게 합류한다(이상치 분포, 조인트 중복 그룹)."
                 " 그래서 2차 패스는 부서·팀·용접사 집계를 **소급 갱신**해야 한다."
                 " 과거에 이걸 빠뜨려 257행이 용접사 집계에서 통째로 빠진 적이 있다."},
        {"heading": "한 행에 여러 플래그가 붙을 수 있다",
         "body": "«결함 행»과 «플래그»는 다른 단위다. 한 행에 Check가 여럿 걸리면"
                 " 플래그는 여러 개지만 결함 행은 하나다. 그래서 Check별 건수를 다 더해도"
                 " 결함 행수가 되지 않는다."},
    ]
    temp = r.get("temp_judged_rows")
    if isinstance(temp, int) and temp:
        out.append({
            "heading": "임시부재(1C)는 판정에서 빼지 않는다",
            "body": "현업 확인(§11-11): 도면번호가 `1C`로 시작하는 임시부재도"
                    " **다른 행과 똑같이 판정한다.** 대시보드의 「임시부재 제외」는"
                    f" 보는 방식만 바꾸는 토글이다. 지금 회차는 판정 대상의 **{temp:,}행**"
                    " 이 1C라, 판정에서 빼 버리면 검증 대상이 거의 사라진다."})
    return out


def _notes_checks(result: dict | None) -> list[dict[str, str]]:
    em = emitted_checks()
    inactive = sorted(set(V.CHECK_NAMES) - set(em) - {V.CHECK_UNWORKED})
    out = [{"heading": title.split(" — ")[0],
            "body": title.split(" — ")[1] + " — "
                    + ", ".join(f"Check {n}" for n in members if n in em) + "."}
           for _, title, members in _AXES]
    out += [
        {"heading": "1차 · 2차는 «언제 알 수 있는가»의 차이다",
         "body": "1차는 그 행만 보면 판정된다. 2차(Check 13·14)는 전체 분포나 다른 행과의"
                 " 비교가 있어야 알 수 있다. 정확도의 차이가 아니라 **필요한 시야**의 차이다."},
        {"heading": "Check 6은 행이 아니라 사람의 문제다",
         "body": "용접사 자격 미등록은 그 행의 작업 품질이 아니라 특정 용접사의 서류 문제다."
                 " 그래서 **용접사별 결함률에서 제외**한다 — 넣으면 같은 행에서 함께 일한"
                 " 다른 용접사에게 오귀속된다."},
        {"heading": "Check 13은 «위반»이 아니다",
         "body": "이상치 탐지는 규칙을 어겼다는 뜻이 아니라 «이 데이터 안에서 드문 조합»이라는"
                 " 뜻이다. 사람이 확인해 판단을 남기는 것이 전제다. 매 검증마다 새로 학습하므로"
                 " «작년 데이터로 배운 모델»이 아니다."},
    ]
    if inactive:
        out.append({
            "heading": "점선은 «걷어낸» 검사다",
            "body": f"Check {' · '.join(str(n) for n in inactive)}는 현업 확인으로 규칙을"
                    " 삭제했지만 **번호와 이름은 남겨 둔다.** 검토 기록 키가"
                    " `도면번호|Joint No|WPS No|Check No`라, 번호를 지우거나 재사용하면"
                    " 과거 검토 의견이 무관한 항목에 붙는다. Check 15도 같은 이유로 결번이다."})
    return out


def _notes_priority(result: dict | None) -> list[dict[str, str]]:
    order = sorted(V._PRIORITY.items(), key=lambda kv: kv[1])
    return [
        {"heading": "한 셀에는 한 색만 칠한다",
         "body": "같은 셀에 여러 Check가 걸릴 수 있다(예: 두께가 범위 밖이면서 동시에"
                 " 특수 규칙 대상). 셀은 하나라 색도 하나여야 하므로, 미리 정해 둔 순서로"
                 " 이긴 색만 남긴다. **지적 내용은 전부 주석에 남으므로 사라지지 않는다.**"},
        {"heading": f"가장 센 색은 {order[0][0]}이다",
         "body": "순서는 «심각도»가 아니라 «눈에 먼저 들어와야 하는 것»으로 정해져 있다."
                 " 복합 오류처럼 여러 문제가 겹친 것을 맨 앞에 둔다."},
        {"heading": "색을 추가하면 여섯 곳을 함께 고친다",
         "body": "판정 엔진의 채우기·색이름·표시이름·우선순위, 결과 Excel의 색표,"
                 " 화면의 배지 색까지 여섯 군데다. 빠뜨려도 예외가 나지 않아 발견이 늦다."
                 " 다섯 곳은 테스트가 강제한다."},
    ]


_NOTES = {"flow": _notes_flow, "checks": _notes_checks, "priority": _notes_priority}


# ─── 목록 ────────────────────────────────────────────────────────────────────
DIAGRAMS: dict[str, dict[str, Any]] = {
    "flow": {
        "title": "판정 흐름과 행 회계",
        "hint": "원본 한 행이 «삭제 / 미작업 / 정상 / 결함» 중 어디로 가는지. "
                "결함률의 분모가 판정 대상 행수인 이유가 여기 있다.",
        "build": flow,
        "needs_result": True,
    },
    "checks": {
        "title": "16가지 검사 지도",
        "hint": "각 검사가 무엇을 보고, 어느 열을 칠하고, 몇 차 패스에서 붙는지. "
                "점선은 이름은 남아 있으나 지금은 판정하지 않는 항목이다.",
        "build": checks,
        "needs_result": False,
    },
    "priority": {
        "title": "색 우선순위",
        "hint": "한 셀에 여러 검사가 걸리면 하나만 칠한다. 왼쪽이 이긴다 — 앞 번호일수록 우선한다.",
        "build": priority,
        "needs_result": False,
    },
}


def build(name: str, result: dict | None = None) -> dict[str, Any]:
    spec = DIAGRAMS[name]
    src = spec["build"](result) if spec["needs_result"] else spec["build"]()
    return {"name": name, "title": spec["title"], "hint": spec["hint"],
            "mermaid": src, "notes": _NOTES[name](result)}


def build_all(result: dict | None = None) -> list[dict[str, Any]]:
    return [build(name, result) for name in DIAGRAMS]


# ─── 문서에 심기 ─────────────────────────────────────────────────────────────
#
# 같은 Mermaid 소스를 `QC_검사로직_상세분석.md`에도 넣는다. 문서 쪽은 Obsidian과
# GitHub가 그대로 렌더한다 — 화면을 못 보는 사람도 같은 그림을 본다.
#
# **손으로 붙여넣지 않는다.** 붙여넣는 순간 그것은 «판정 코드와 갈라질 수 있는
# 두 번째 정의»가 된다. 아래 표식 사이를 통째로 갈아끼우고, 테스트가 어긋남을 잡는다:
#
#     python -m backend.services.diagrams        (문서 갱신)
#     pytest tests/test_diagrams.py              (어긋나면 실패)
DOC_BEGIN = "<!-- DIAGRAMS:BEGIN — 이 블록은 생성된다. 손으로 고치지 마라 -->"
DOC_END = "<!-- DIAGRAMS:END -->"


def markdown_block() -> str:
    """문서에 넣을 부분. 행 회계 숫자는 넣지 않는다 — 검증할 때마다 바뀌어서
    문서가 매번 더러워지고, 문서를 보는 사람은 «지금 수치»가 아니라 «구조»를
    알고 싶어 한다. 수치가 붙은 그림은 화면(검사 로직 탭)에 있다."""
    parts = [DOC_BEGIN, ""]
    for name in DIAGRAMS:
        d = build(name, None)
        parts += [f"#### {d['title']}", "", d["hint"], "",
                  "```mermaid", d["mermaid"].rstrip(), "```", ""]
        for n in d["notes"]:
            parts += [f"**{n['heading']}** — {n['body']}", ""]
    parts.append(DOC_END)
    return "\n".join(parts)


def sync_markdown(path: Path | None = None) -> bool:
    """문서의 표식 사이를 갈아끼운다. 바뀌었으면 True.

    파일 전체를 다시 쓰지 않고 그 블록만 바꾼다 — 같은 파일의 다른 편집(§11 답변
    기록 등)이 날아가지 않게 하려는 것이고, `review_items.py`와 같은 원칙이다.
    """
    target = path or (config.BASE / "QC_검사로직_상세분석.md")
    text = target.read_text(encoding="utf-8")
    if DOC_BEGIN not in text or DOC_END not in text:
        raise RuntimeError(
            f"{target.name}에 도식 표식이 없다. 넣을 자리에 다음 두 줄을 두어라: "
            f"{DOC_BEGIN} / {DOC_END}")
    head, _, rest = text.partition(DOC_BEGIN)
    _, _, tail = rest.partition(DOC_END)
    new = head + markdown_block() + tail
    if new == text:
        return False
    tmp = target.with_suffix(target.suffix + ".tmp")
    tmp.write_text(new, encoding="utf-8", newline="")
    os.replace(tmp, target)
    return True


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    changed = sync_markdown()
    logging.info("문서 도식 %s", "갱신함" if changed else "이미 최신")
