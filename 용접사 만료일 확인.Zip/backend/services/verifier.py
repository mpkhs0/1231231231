"""
QMG4520 QC 검증 핵심 로직
FastAPI 서비스용 — qc_verifier.py CLI와 동일한 검사 로직, API 친화적 출력 반환
"""
import io
import re
import logging
from datetime import datetime, date
from pathlib import Path
from collections import Counter, defaultdict
from typing import Any, Callable, Optional

from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font
from openpyxl.utils import get_column_letter
from openpyxl.comments import Comment

from . import anomaly
from . import recurrence
from . import project_checks
from . import rule_catalog
from . import wps_rules
from . import drm_convert

logger = logging.getLogger(__name__)


def _open_workbook(path: Path, **kwargs):
    """DRM 파일이면 메모리 변환 후 열고, 아니면 직접 연다."""
    if drm_convert.is_drm(path):
        logger.info("DRM 파일 감지 — 메모리 변환 후 오픈: %s", path.name)
        data = drm_convert.convert_to_bytes(path)
        return load_workbook(io.BytesIO(data), **kwargs)
    return load_workbook(str(path), **kwargs)


# ─── 컬럼 상수 (1-based) ─────────────────────────────────────────────────────
class Col:
    DRAWING_NO    = 1   # A
    BLOCK         = 2   # B
    JOINT_NO      = 4   # D  Weld No
    # E  헤더가 'RE' — 수리(Repair) 구분란. 값은 `RE`·`R1`·`U1`·`M1`처럼 다양하고,
    # **비어 있지 않기만 하면 수리 시공**이라는 뜻이다(현업 확인 2026-08-13).
    # 실데이터 10,031행 중 4행에만 값이 있다.
    REPAIR_MARK   = 5   # E
    OUT_DIA       = 9   # I  Out Dia (관재/형강의 외경·형상 규격, 예: 'SHS80X6')
    THICKNESS1    = 10  # J
    THICKNESS2    = 11  # K
    MATERIAL1     = 13  # M
    MATERIAL2     = 14  # N
    NDT_CAT       = 16  # P
    # Q  이음 Type. 실데이터 분포: T 9,626 · B 361 · TT 8.
    # `TT`는 TKY 이음(관재 교차부)이라 전용 WPS를 써야 한다(Check 24).
    JOINT_TYPE    = 17  # Q
    # NDT Extent — 이 조인트에 요구되는 NDT 비율(%). 값이 있으면 그 검사가 요구된다.
    NDT_EXT_RT    = 19  # S
    NDT_EXT_UT    = 20  # T
    NDT_EXT_MT    = 21  # U
    NDT_EXT_PT    = 22  # V
    GROOVE        = 18  # R
    DELETE_STATUS = 24  # X
    CONSUMABLE_LOT = 38  # AL  용접봉 Lot 번호
    WPS_NO        = 36  # AJ
    WPS_PROCESS   = 37  # AK
    WELD_DATE     = 39  # AM
    NDT_DATE      = 41  # AO
    WELDER1_NO    = 42  # AP
    WELDER1_PROC  = 43  # AQ
    WELDER2_NO    = 44  # AR
    WELDER2_PROC  = 45  # AS
    WELDER3_NO    = 46  # AT
    WELDER3_PROC  = 47  # AU
    WELDER4_NO    = 48  # AV
    WELDER4_PROC  = 49  # AW
    # BE  NDT Inspection Plan/Application > Report — NDT 리포트 번호(예: 'SAVI14996')
    #
    # 산출물의 **추적 키**다. 현업은 도면번호가 아니라 이 번호로 원본 검사기록을
    # 찾는다. 실데이터 9,997행 중 5,520행(55.2%)에 값이 있고 서로 다른 번호가
    # 166개다 — 한 리포트가 여러 조인트를 덮으므로 행마다 유일하지 않다.
    # 공란(44.8%)은 NDT 계획 자체가 없는 행이라, 비어 있는 것이 정상이다.
    # BD  NDT Inspection Plan/Application > Date — 계획/신청일.
    # 이 날짜가 있으면 «검사를 걸어 둔 조인트»라는 뜻이라, 리포트 번호가 확정돼야 한다.
    NDT_PLAN_DATE = 56  # BD
    NDT_REPORT    = 57  # BE
    DEPARTMENT    = 58  # BF  Dep't
    TEAM          = 59  # BG  Team (부서 하위 팀/협력사)
    VT_DATE       = 61  # BI  Visual Inspection 수행일
    RT_DATE       = 65  # BM  RT(방사선) 수행일
    UT_DATE       = 68  # BP  UT(초음파) 수행일
    MT_DATE       = 71  # BS  MT(자분) 수행일
    PT_DATE       = 74  # BV  PT(침투) 수행일
    # 검사별 리포트 번호 — 각 수행일 바로 오른쪽 열이다.
    #
    # **번호 끝의 `*`는 «촬영하지 않은 수량»**이라는 표기다(현업 확인 2026-08-13).
    # `MSOU00001`(촬영함) 2건 + `MSOU00001*`(안 함) 8건이면 그 리포트 묶음의 실제
    # 촬영율은 20%다 — Check 26이 이 묶음 요율을 S~V열 요구 요율과 대조한다.
    RT_REPORT     = 66  # BN
    UT_REPORT     = 69  # BQ
    MT_REPORT     = 72  # BT
    PT_REPORT     = 75  # BW

class WPSCol:
    WPS_NO       = 3   # C
    PROCESS      = 5   # E
    BASE_METAL   = 6   # F
    THICKNESS    = 7   # G
    POSITION     = 11  # K
    JOINT_DETAIL = 12  # L

# ─── 용접사 파일의 «두 형식» ─────────────────────────────────────────────────
#
# 2026-08-20에 현업이 **만료일이 든 새 파일**로 갈아탔다. 자격 DB와 만료일 파일을
# 따로 올리던 것을 하나로 합친 것이다 — 두 파일에 같은 사람이 있어도 서로 몰라서
# «한쪽에만 있는 사람»이 Check 6과 7에서 **따로 지적되던** 문제가 있었다.
#
# **옛 형식을 계속 읽는 이유**: 이미 올려 둔 파일이 그대로 있는 설치가 있다.
# 그걸 새 형식으로 읽으면 B열에서 번호를 못 찾아 **전원이 «자격 미등록»으로
# 잡힌다** — 오류가 아니라 «갑자기 결함이 수천 건»으로만 보여서 원인을 짐작할
# 단서가 없다. 그래서 둘 다 시도해 보고 사람이 나오는 쪽을 쓴다.
#
# 어느 형식으로 읽었는지는 **로그와 업로드 응답에 남긴다.** 안 남기면 «왜 만료일
# 검사가 안 도나»를 되짚을 방법이 없다.
class WelderLayout:
    """(이름, 머리말 행수, 열 번호들). `cols`에 없는 키는 그 형식에 없는 것이다."""

    NEW = ("만료일 포함", 10, {
        "no": 2,        # B
        "name": 3,      # C
        "process": 4,   # D
        "expire": 13,   # M  Expire date
        "disq": 14,     # N  Dis-qualified date
    })
    OLD = ("기존 자격 DB", 3, {
        "no": 3,        # C
        "name": 4,      # D
        "spec": 5,      # E
        "process": 6,   # F
        "cert_no": 9,   # I
        "cert_date": 10,  # J
        "position": 11,   # K
        "cls": 68,      # BP
        "status": 80,   # CB
    })
    ALL = (NEW, OLD)


class WelderCol:
    NO        = 3   # C
    NAME      = 4   # D  Name(Kor) — 'HONG GIL DONG(홍길동)' 형식
    SPEC      = 5   # E  Applicable Spec. (AWS 등)
    PROCESS   = 6   # F
    CERT_NO   = 9   # I  Certified No.
    CERT_DATE = 10  # J  자격 취득일 (만료일 L열은 전량 공란 — 11-6 참조)
    POSITION  = 11  # K
    CLASS     = 68  # BP 선급 (DNV 등)
    STATUS    = 80  # CB

# ─── 색상 (Excel 출력용 + API 전달용 이름) ──────────────────────────────────
_FILLS: dict[str, PatternFill] = {
    "Red":    PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid"),
    "Green":  PatternFill(start_color="00B050", end_color="00B050", fill_type="solid"),
    "Blue":   PatternFill(start_color="0070C0", end_color="0070C0", fill_type="solid"),
    "Yellow": PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid"),
    "Orange": PatternFill(start_color="FF7F00", end_color="FF7F00", fill_type="solid"),
    "Black":  PatternFill(start_color="000000", end_color="000000", fill_type="solid"),
    "Purple": PatternFill(start_color="7030A0", end_color="7030A0", fill_type="solid"),
    "Teal":   PatternFill(start_color="008080", end_color="008080", fill_type="solid"),
    "Gray":   PatternFill(start_color="BFBFBF", end_color="BFBFBF", fill_type="solid"),
    "Cyan":   PatternFill(start_color="00B0C0", end_color="00B0C0", fill_type="solid"),
    "Brown":  PatternFill(start_color="833C00", end_color="833C00", fill_type="solid"),
    "Olive":  PatternFill(start_color="808000", end_color="808000", fill_type="solid"),
    "Maroon": PatternFill(start_color="7B2E2E", end_color="7B2E2E", fill_type="solid"),
    "Indigo": PatternFill(start_color="4B3F8F", end_color="4B3F8F", fill_type="solid"),
    "Navy":   PatternFill(start_color="1F3864", end_color="1F3864", fill_type="solid"),
    "Rose":   PatternFill(start_color="C0504D", end_color="C0504D", fill_type="solid"),
}
_PRIORITY: dict[str, int] = {
    "Black": 0, "Red": 1, "Purple": 2, "Orange": 3, "Yellow": 4,
    "Blue": 5, "Teal": 6, "Olive": 7, "Green": 8, "Navy": 9,
    "Gray": 10, "Cyan": 11, "Brown": 12, "Rose": 13,
    "Maroon": 14, "Indigo": 15,
}

CHECK_COLORS: dict[int, str] = {
    0: "Gray",
    1: "Red", 2: "Green", 3: "Blue", 4: "Yellow", 5: "Blue",
    6: "Orange", 7: "Yellow", 8: "Blue", 9: "Green", 10: "Black",
    11: "Purple", 12: "Teal", 13: "Cyan", 14: "Brown",
    # 18은 Rose에서 Orange로 바꿨다(2026-08-20) — 승인 목록 대조가 들어와
    # «기재 누락»보다 무거운 판정을 함께 하게 됐다. 같은 AL열을 보는 Check 21
    # (Rose=13)과 겹치면 우선순위가 높은 쪽(Orange=3)이 칠해진다.
    16: "Olive", 17: "Navy", 18: "Orange",
    19: "Maroon", 20: "Indigo",
    # 2026-08-13 추가. 색은 기존 16색에서 고른다 — `_FILLS`에 없는 색을 쓰면
    # 엑셀이 무색이 되고, `style.css`에 `--ck-*`가 없으면 화면 배지도 무색이 된다.
    21: "Rose", 22: "Olive", 23: "Gray", 24: "Cyan",
    25: "Teal", 26: "Navy", 27: "Purple",
}
CHECK_NAMES: dict[int, str] = {
    0:  "미작업 수량",
    1:  "일정 오류",           2:  "WPS/Process 불일치",
    3:  "두께 허용범위 초과",  4:  "Groove 불일치",
    5:  "특수규칙 P+G01",      6:  "용접사 자격 미등록",
    7:  "용접사 승인기간 이후 작업",
    8:  "TR-FC-G03 특수",
    9:  "TR-SMFC-G01 특수",    10: "복합 오류 (3+8)",
    11: "재질-WPS 부적합",     12: "관재 DIA 확인 필요",
    13: "이상치(특이 조합) 확인 필요",
    14: "Joint 중복 등록 (값 불일치)",
    16: "NDT 요구 대비 미수행",
    17: "육안검사(VT) 미수행",
    18: "용접봉 Lot 미기재·미승인",
    19: "WPS Process 자격자 미투입",
    20: "API 재질 Groove별 프로세스 부적합",
    21: "혼합 프로세스 용접재료 누락",
    22: "NDT 리포트 번호 미확정",
    23: "수리 시공 · 수리 WPS 미적용",
    24: "TKY 이음 전용 WPS 미적용",
    25: "Q01 WPS · 이음 Type 부적합",
    26: "NDT 적용 요율 미달",
    27: "이종재 상위 그레이드 WPS 부적합",
}

# Check 16이 쓰는 «요구 Extent 열 -> 수행일 열» 대응.
# 엑셀에서 두 묶음이 멀리 떨어져 있어(S~V열 vs BM~BV열) 짝을 눈으로 맞추기 어렵다.
# 한 줄에 나란히 두는 편이 열을 바꿔 넣는 실수를 막는다.
_NDT_EXTENT_PAIRS: tuple[tuple[str, int, int], ...] = (
    ('RT', Col.NDT_EXT_RT, Col.RT_DATE),
    ('UT', Col.NDT_EXT_UT, Col.UT_DATE),
    ('MT', Col.NDT_EXT_MT, Col.MT_DATE),
    ('PT', Col.NDT_EXT_PT, Col.PT_DATE),
)

# Check 0(미작업)은 '결함'이 아니라 '아직 용접이 수행되지 않은 계획 물량'이다.
# 결함률 통계·용접사 평가·부서 실적 어디에도 결함으로 섞이면 표본이 오염되므로
# 판정 대상(judged_rows)에서 아예 제외하고 별도 수량으로만 집계한다.
CHECK_UNWORKED = 0

# ─── 유틸리티 ────────────────────────────────────────────────────────────────
def _clean(v: Any) -> str:
    return "" if v is None else str(v).strip()

def _normalize_process(v: Any) -> str:
    s = _clean(v).upper()
    s = re.sub(r'\(.*?\)', '', s)
    s = re.sub(r'[\n\r\s]+', '', s)
    s = re.sub(r'-CARRIAGE$', '', s)
    return s

# 어떤 자격이 어떤 시공 프로세스를 «덮는가».
#
# 현업 확인(2026-08-11): **SMFC 자격 보유자는 FCAW 작업이 허용된다.**
# 실데이터에서 Check 6의 «프로세스 자격 없음» 36건이 **전부** 이 경우였다
# (FCAW 시공 / 보유 SMFC 또는 SAW,SMFC). 오탐이므로 결함으로 잡지 않는다.
#
# Check 6과 Check 19가 **같은 함수**를 쓴다 — 갈라지면 «6에서는 통과인데
# 19에서는 결함»이 되어, 같은 행에 서로 모순되는 지적이 붙는다.
# 용접 프로세스인가 — **닫힌 집합으로 본다.** 파일 형식을 가릴 때만 쓴다.
#
# 처음에는 «ASCII 대문자면 프로세스»로 봤는데 그게 부족했다. 옛 파일의 이름 열
# `NA YEONG SEOG(나영석)`이 괄호가 벗겨지면 `NAYEONGSEOG`가 되어 그 조건을
# 통과한다 — 옛 파일이 새 형식으로 989행, 옛 형식으로 1,020행 읽혀 **판별이
# 종이 한 장 차이**였다. 조금만 달랐으면 통째로 잘못 읽었을 것이다.
#
# 용접 프로세스는 표준 코드라 실제로는 몇 개뿐이다(실측: FCAW · SMFC · SAW ·
# GTFC 넷). 두 글자 어근의 조합(SM+FC = SMAW+FCAW)까지 받아 주면 충분하다.
#
# **적재에는 이 조건을 쓰지 않는다** — 판별에만 쓴다. 여기 없는 표기를 만나도
# 그 행을 버리지 않아야 한다.
_PROCESS_FULL = frozenset((
    "SMAW", "GMAW", "GTAW", "FCAW", "SAW", "PAW", "ESW", "EGW", "OFW", "SW",
    "GMAWP", "FCAWS", "FCAWG",
))
_PROCESS_ROOTS = frozenset(("SM", "GM", "GT", "FC", "SA", "PA", "ES", "EG", "OF"))


def _looks_like_process(s: str) -> bool:
    """`FCAW` · `SMFC` · `SAW,SMFC`는 참, `NAYEONGSEOG` · `Q557`은 거짓."""
    for part in re.split(r"[,/+]", s):
        p = part.strip()
        if not p:
            continue
        if p in _PROCESS_FULL:
            return True
        # 4글자 합성(SMFC = SMAW + FCAW) — 두 글자 어근 둘로 나뉘는가
        if len(p) == 4 and p[:2] in _PROCESS_ROOTS and p[2:] in _PROCESS_ROOTS:
            return True
    return False

_PROCESS_COVERS: dict[str, tuple[str, ...]] = {
    "SMFC": ("FCAW",),
}


def _process_covers(qualification: str, worked: str) -> bool:
    """`qualification` 자격으로 `worked` 프로세스를 시공할 수 있는가."""
    q = _normalize_process(qualification)
    w = _normalize_process(worked)
    if not q or not w:
        return False
    if q == w:
        return True
    return w in _PROCESS_COVERS.get(q, ())


# 두 프로세스를 한 이음에서 함께 쓰는 «혼합» 프로세스. 이런 이음은 용접재료를
# 둘 적어야 하고(Check 21), 자격자는 4명 중 한 명만 있으면 된다(Check 6 완화).
_MIXED_PROCESSES = ("SMFC", "GTFC", "FCSA")


def _is_mixed_process(process: str) -> bool:
    p = _normalize_process(process)
    return bool(p) and any(m in p for m in _MIXED_PROCESSES)


# 재질 등급의 «상하»를 아는 만큼만. **[보류] — 전체 등급표는 아직 없다.**
#
# 현업이 2026-08-13에 확인해 준 두 가지만 담는다:
#   · 재질명 끝의 시험온도 — 낮을수록 상위 (-40 > -20)
#   · S355 < S420
#
# 등급표를 받으면 `_GRADE_ORDER`를 채운다. 그때까지 나머지 조합은 None을
# 돌려 판정하지 않는다 — 근거 없이 찍으면 오탐이고, 오탐은 «이 검사는 못
# 믿는다»로 이어져 진짜 결함까지 묻힌다.
_GRADE_ORDER: dict[str, int] = {
    "S355": 1,
    "S420": 2,
}


def _material_token(material: str) -> str:
    """재질명을 «표기 흔들림을 지운» 형태로. 같은 강재인지 볼 때 쓴다.

    `ASTM-A36` · `ASTM A36` · `astma36`이 전부 `ASTMA36`이 된다. 이걸 안 하면
    표기만 다른 같은 강재가 이종재로 분류되어 Check 3의 K열 판정이 사라진다.
    """
    return "".join(ch for ch in (material or "").upper() if ch.isalnum())


def _material_grade_rank(material: str) -> Optional[int]:
    """`_GRADE_ORDER`로 아는 등급이면 순위, 모르면 None."""
    m = (material or "").upper().replace(" ", "")
    for key, rank in _GRADE_ORDER.items():
        if key in m:
            return rank
    return None


# 재질명 **끝**에 시험온도가 붙는 표기: `S355KT-40` · `S355KL-0` · `S355KL-50Z`.
#
# `K`(KT/KL 등 온도 등급 문자) 뒤의 `-숫자`만 온도로 읽는다. 그냥 «끝의 -숫자»로
# 잡으면 **`ASTM-A36`의 36을 -36℃로 읽어 버린다** — A36은 강도 등급이지 온도가
# 아니다. 선급강 표기(`NV-E36`)는 `_material_impact_temp_c()`가 따로 안다.
_TEMP_IN_NAME = re.compile(r"K[A-Z]?-(\d{1,3})Z?$")


def _temp_from_name(material: str) -> Optional[int]:
    m = _TEMP_IN_NAME.search((material or "").upper().replace(" ", ""))
    return -int(m.group(1)) if m else None


def _higher_material_grade(a: str, b: str) -> Optional[str]:
    """둘 중 «상위 그레이드». 판단 근거가 없으면 None.

    먼저 시험온도로 본다(낮을수록 상위). 온도가 없거나 같으면 등급표를 본다.
    둘 다 모르면 None이다 — **여기서 임의로 하나를 고르면 조용히 틀린다.**
    """
    ta = _material_impact_temp_c(a)
    if ta is None:
        ta = _temp_from_name(a)
    tb = _material_impact_temp_c(b)
    if tb is None:
        tb = _temp_from_name(b)
    if ta is not None and tb is not None and ta != tb:
        return a if ta < tb else b
    ra, rb = _material_grade_rank(a), _material_grade_rank(b)
    if ra is not None and rb is not None and ra != rb:
        return a if ra > rb else b
    return None


def _parse_date(v: Any) -> Optional[date]:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    s = _clean(v)
    if not s or s in (' ', 'None'):
        return None
    for fmt in ('%Y-%m-%d', '%Y/%m/%d', '%d/%m/%Y', '%m/%d/%Y', '%Y.%m.%d'):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None

def _to_float(v: Any) -> Optional[float]:
    if v is None:
        return None
    try:
        return float(str(v).strip())
    except (ValueError, TypeError):
        return None

def _is_deleted(row: tuple) -> bool:
    v = _clean(row[Col.DELETE_STATUS - 1] if len(row) >= Col.DELETE_STATUS else None)
    return bool(v)

def _same_wps(a: str, b: str) -> bool:
    """두 WPS 번호가 «같은 WPS»인가. 맨 앞 프로젝트 코드는 빼고 본다.

        TR-FC-G03  ==  RU-FC-G03      같은 WPS다
        TR-FC-G03  !=  TR-FC-G01
    """
    if not a or not b:
        return False
    return a.upper() == b.upper() or wps_rules.wps_core(a) == wps_rules.wps_core(b)


def _is_repair_wps(wps_no: str) -> bool:
    """수리(repair) WPS인지. 접두사는 활성 프로파일의 `params`에서 온다.

    매크로 원문의 접두사는 `RU-`인데 실데이터는 `TR-`이다(§11-9). 프로젝트마다
    다를 수 있어 설정으로 뺐다.

    **접두사가 비면 «수리 WPS 없음»이다.** `startswith("")`는 항상 True라, 그냥
    넘기면 **모든 WPS가 수리로 분류되어 Check 2·4·11이 통째로 빠진다.**
    실측(params 없는 프로파일): Check 4 36 -> 0, Check 11 94 -> 0.

    params가 없는 프로파일은 «새 프로젝트를 처음 돌리는» 경로 그 자체라, 이 결함은
    가장 중요한 순간에 «결함이 거의 없는 깨끗한 결과»를 만들어 낸다. 오류도 경고도
    나지 않는다 — `check_rules_alive()`가 접두사가 빈 것을 따로 경고한다.
    """
    prefix = wps_rules.repair_prefix()
    if not wps_no or not prefix:
        return False
    # 맨 앞 «TR»은 프로젝트 번호다(현업 확인 2026-08-14). 접두사가 `TR-FC-R`이어도
    # RUYA의 `RU-FC-R01`에 걸려야 한다 — 같은 WPS를 프로젝트 번호만 바꿔 만든다.
    # 통째로 비교하면 프로젝트가 바뀌는 순간 **수리 WPS를 한 행도 못 알아본다.**
    return (wps_no.upper().startswith(prefix)
            or wps_rules.wps_core(wps_no).startswith(wps_rules.wps_core(prefix)))

def _groove_in_joint_detail(groove: str, joint_detail: str) -> bool:
    """QMG의 Groove(R열)가 WPS의 Joint Detail(L열)에 포함되는지.

    Check 4가 쓰던 로직을 모듈 수준으로 올린 것이다. Check 5 재정의(개선계획 4번)가
    "이 Groove를 추천 WPS가 받을 수 있는가"를 판단할 때 같은 규칙이 필요해졌다.
    두 곳이 서로 다르게 매칭하면 «G03으로 옮기라 해놓고 옮기면 Check 4 위반»이 되는
    모순이 생긴다.

    괄호 주석과 repair/multi/pass 같은 수식어를 걷어낸 뒤 토큰으로 쪼개 비교한다.
    PP(Partial Penetration)는 WPS 표기가 PJP인 경우가 있어 별칭으로 함께 본다.
    """
    if not groove or not joint_detail:
        return True          # 판단 근거가 없으면 «아니다»라고 단정하지 않는다
    gr = groove.upper().strip()
    aliases = {gr}
    if gr == "PP":
        aliases.add("PJP")
    return bool(aliases & _joint_detail_tokens(joint_detail))


def _joint_detail_tokens(joint_detail: str) -> set[str]:
    """WPS의 Joint Detail(L열)을 비교 가능한 토큰 집합으로 만든다.

    괄호 주석과 repair/multi/pass 같은 수식어를 걷어낸 뒤 쪼갠다.
    Check 4의 오류 메시지가 «허용되는 값 목록»을 보여줄 때도 같은 집합을 쓴다 —
    판정에 쓴 것과 다른 목록을 보여주면 현장이 메시지를 못 믿는다.
    """
    jd = re.sub(r"\(.*?\)", "", joint_detail or "", flags=re.DOTALL)
    jd = re.sub(r"\.?\s*(repair|multi|pass|side|run|both)[^,\n]*", "", jd, flags=re.IGNORECASE)
    return {t.strip().upper() for t in re.split(r"[,\n\r\s]+", jd) if t.strip()}


def _row_val(row: tuple, col: int) -> Any:
    idx = col - 1
    return row[idx] if idx < len(row) else None

# 상세 결과 화면의 "원본 데이터" 패널에 표시할 컬럼 — 엑셀 원문 순서대로.
_RAW_SNAPSHOT_COLS: list[tuple[str, int]] = [
    ('도면번호',      Col.DRAWING_NO),
    ('블록',          Col.BLOCK),
    ('Joint No',      Col.JOINT_NO),
    ('Out Dia',       Col.OUT_DIA),
    ('두께 1',        Col.THICKNESS1),
    ('두께 2',        Col.THICKNESS2),
    ('재질 1',        Col.MATERIAL1),
    ('재질 2',        Col.MATERIAL2),
    ('NDT Cat',       Col.NDT_CAT),
    ('Groove',        Col.GROOVE),
    ('WPS No',        Col.WPS_NO),
    ('WPS Process',   Col.WPS_PROCESS),
    ('용접일',        Col.WELD_DATE),
    ('NDT 계획일',    Col.NDT_DATE),
    # 추적 키. 검색은 되는데 «찾은 행에서 그 번호를 볼 수 없는» 상태였다.
    ('NDT REPORT 번호', Col.NDT_REPORT),
    ('VT 수행일',     Col.VT_DATE),
    ('RT 수행일',     Col.RT_DATE),
    ('UT 수행일',     Col.UT_DATE),
    ('MT 수행일',     Col.MT_DATE),
    ('PT 수행일',     Col.PT_DATE),
    ('용접사 1',      Col.WELDER1_NO),
    ('용접사 1 Proc', Col.WELDER1_PROC),
    ('용접사 2',      Col.WELDER2_NO),
    ('용접사 2 Proc', Col.WELDER2_PROC),
    ('용접사 3',      Col.WELDER3_NO),
    ('용접사 3 Proc', Col.WELDER3_PROC),
    ('용접사 4',      Col.WELDER4_NO),
    ('용접사 4 Proc', Col.WELDER4_PROC),
    ('부서',          Col.DEPARTMENT),
    ('팀',            Col.TEAM),
]

def _row_snapshot(row: tuple) -> list[dict]:
    """상세 결과 화면에서 보여줄 '원본 데이터' 스냅샷 (엑셀 컬럼 순서 그대로)."""
    out = []
    for label, col in _RAW_SNAPSHOT_COLS:
        val = _clean(_row_val(row, col))
        out.append({'label': label, 'col': get_column_letter(col), 'value': val})
    return out

# ─── 두께 범위 파싱 ──────────────────────────────────────────────────────────
def _parse_thickness_ranges(text: str) -> list[tuple[float, float]]:
    """
    "3~50", "3 ~ 50", "3-50", "12.5-50" 등 지원.
    matched set으로 공백 tilde 삼중매칭 버그 방지.
    """
    ranges: list[tuple[float, float]] = []
    matched: set[int] = set()

    # 1) "숫자 [~|-] 숫자" (양쪽 경계)
    for m in re.finditer(r'(\d+(?:\.\d+)?)\s*[~\-]\s*(\d+(?:\.\d+)?)', text):
        lo, hi = float(m.group(1)), float(m.group(2))
        if lo <= hi:
            ranges.append((lo, hi))
            matched.update(range(m.start(), m.end()))

    # 2) "숫자~" (상한 없음)
    for m in re.finditer(r'(\d+(?:\.\d+)?)\s*~', text):
        if m.start() not in matched:
            ranges.append((float(m.group(1)), 9999.0))

    # 3) "~숫자" (하한 없음)
    for m in re.finditer(r'~\s*(\d+(?:\.\d+)?)', text):
        if m.start() not in matched:
            ranges.append((0.0, float(m.group(1))))

    return ranges

def _thickness_in_range(thickness: float, range_text: str) -> bool:
    if not range_text:
        return True
    ranges = _parse_thickness_ranges(range_text)
    if not ranges:
        return True
    return any(lo <= thickness <= hi for lo, hi in ranges)

# 선급강 등급 접미사(A/D/E/F) -> 샤르피 충격시험 온도(°C). Check 8은 -40°C 이하
# 등급에서만 발동해야 하는데, 예전 minus40 키워드 리스트는 'DH36'(-20°C, 오류)을
# 포함하고 'NV-E36'/'NV-E36Z'/'NV-EW420Z'(전부 -40°C, 판정대상 기준 각 113/40/3건,
# 합계 156건 실존)를 빠뜨리고
# 있었다(감사에서 확인). MATERIAL_MAP의 'E36' 키는 WPS 커버리지 목적상 A/D/E
# 등급을 하나로 묶어버려 온도 구분에 못 쓰므로, 원문 표기에서 직접 등급 문자를
# 추출한다.
_GRADE_IMPACT_TEMP_C: dict[str, int] = {'A': 0, 'D': -20, 'E': -40, 'F': -60}
_GRADE_SUFFIX_RE = re.compile(r'^([ADEF])[HWO]?(?:36|420)Z?$')

def _material_impact_temp_c(raw_material: str) -> Optional[int]:
    """
    선급강 표기(NV-EH36, NV-EW420Z, DH36 등)에서 등급 접미사를 추출해 충격시험
    온도를 반환한다. ASTM A36처럼 등급 접미사가 없는 일반 표기는 None(판단 불가).
    """
    up = re.sub(r'[\s\-_]+', '', raw_material.upper())
    up = re.sub(r'^NV', '', up)
    m = _GRADE_SUFFIX_RE.match(up)
    return _GRADE_IMPACT_TEMP_C[m.group(1)] if m else None

# ─── 재질 매핑 ────────────────────────────────────────────────────────────────
MATERIAL_MAP: dict[str, list[str]] = {
    'EO420':  ['EO420', 'NV-EO420', 'NV EO420'],
    'EW420':  ['EW420', 'NV-EW420', 'NV EW420', 'NV-EW420Z'],
    'DW420':  ['DW420', 'NV-DW420', 'NV DW420'],
    'API2H':  ['API 2H', 'API2H', 'API-2H'],
    'API5L':  ['API 5L', 'API5L', 'API-5L'],
    'A53B':   ['A53GRB', 'ASTM A53B', 'ASTM-A53B', 'A53B', 'STPG370'],
    'A36_AR': ['ASTM A36', 'ASTM-A36', 'A36 (AS', 'A36(AS', 'AH36 (AS', 'AB AH36'],
    # 11-4 1차 처리(2026-08-02): 예전에는 A500을 'A36_AR' 키로 묶어 F열의
    # "ASTM A36" 문구에 매칭시켰다. A500 Gr.B(냉간성형 중공형강, ~315MPa)는
    # A36(열간압연 판재, 250MPa)보다 강도가 높고 성형이력이 달라 표준 논리상
    # 같은 자격으로 묶일 근거가 없다(QC_검사로직_상세분석.md §11-4 참고) — 그래서
    # 별도 키로 분리한다. WPS F열에 'ASTM A500'이 명시적으로 없는 한 이제
    # 미승인 재질로 잡힌다(실데이터 22건, TR-SMFC-G01).
    'A500':   ['ASTM A500', 'A500'],
    # 'SM355'(KS/JIS 계열 355MPa급)은 WPS G열에서 S355NH와 같은 항목으로 묶여
    # 관리된다는 현업 확인에 따라 S355NH 키로 취급한다(실데이터 SM355A 2,076건).
    'S355NH': ['S355NH', 'EN S355NH', 'SM355', 'KS SS275', 'JIS SS400'],
    'EH36':   ['NV-EH36', 'EH36', 'NV EH36'],
    'DH36':   ['NV-DH36', 'DH36', 'NV DH36'],
    'AH36':   ['NV-AH36', 'AH36', 'NV AH36'],
    # 'E36'은 A/D/E(W)36 계열의 통칭 키. 'AW36','DW36','EW36'만 있고 'E36' 자체가
    # 빠져 있어서 실제 운영 데이터의 'NV-E36'/'NV-E36Z'(153건)가 매핑 실패로
    # 두께 검사에서 통째로 제외되고 있었다(감사에서 확인). 'E36','D36','A36'을 보강.
    # EH36/DH36/AH36 키가 이 항목보다 먼저 조회되므로 'NV-EH36' 등은 여기 걸리지 않는다.
    'E36':    ['NV-A36', 'NV A36', 'A36', 'D36', 'E36', 'AW36', 'DW36', 'EW36'],
}

# ─── §11-1 종결 (2026-08-08 -> 2026-08-10) ────────────────────────────────────
# 한동안 WPS G열의 "A36, S355NH(As Rolled): 3~24"를 PQR 승인범위(12.5~50)로
# 덮어쓰고 있었다. 표준 조사로 «G열 값은 AH36 12mm 시험재에서 나온 것이고 SM355A에는
# 해당하지 않는다»고 추론했기 때문이다.
#
# **현업 확인 결과 그 추론이 틀렸다** — G열의 3~24가 회사가 적용하는 값이다.
# WPS가 PQR보다 좁게 제한한 경우였고, 그건 표준상 허용된다(WPS 범위 ⊆ PQR 범위).
# 오버라이드를 걷어냈다. Check 3이 45건 -> 약 790건으로 돌아온다.
#
# 남길 교훈: **공개 표준으로 도출한 결론은 그 문서의 실제 의도를 대신하지 못한다.**
# 같은 날 §11-3(PJP)·§11-4(A500)도 같은 방식으로 뒤집혔다.

def _get_material_key(material: str) -> str | None:
    """
    QMG M열 재질 표기를 표준 재질 키로 변환.
    매핑표에 없는 재질은 'E36'으로 임의 폴백하지 않고 None을 반환한다 —
    실제 운영 데이터에 A53GRB/ASTM A53B/NV-DW420 등 매핑표에 없던 재질이
    존재했는데, 예전처럼 'E36'으로 폴백하면 전혀 무관한 재질에 E36 계열의
    느슨한 두께범위가 잘못 적용되어 결함을 놓칠 수 있었다(감사 결과 확인됨).
    """
    # 공백/하이픈/언더스코어를 전부 제거해 비교한다 — 'ASTM A36' / 'ASTM-A36' / 'ASTMA36'처럼
    # 구분자 유무만 다른 표기가 서로 다른 키로 갈리는 것을 막는다. 예전에는 하이픈만
    # 공백으로 바꿔서 비교했는데, 구분자가 아예 없는 'ASTMA36'(70건 실존)이 A36_AR의
    # 'ASTM A36' 패턴과 매칭되지 않고 뒤쪽 E36 키의 느슨한 'A36' 패턴에 먼저 걸려
    # 선급 고장력강으로 오분류되고 있었다(감사에서 확인, 두께가 낮아 현재 결과는 무변경).
    m_up = re.sub(r'[\s\-_]+', '', material.upper())
    for key, patterns in MATERIAL_MAP.items():
        for pat in patterns:
            pat_up = re.sub(r'[\s\-_]+', '', pat.upper())
            if pat_up in m_up:
                return key
    return None

def _material_covered_by_wps(material_key: str, wps_base_metal: str) -> bool:
    bm = wps_base_metal.upper()
    checks: dict[str, list[str]] = {
        'EO420':  ['EO420'],
        'EW420':  ['EW420'],
        # 11-4 1차 처리(2026-08-02): DNV 등급 문자는 충격시험 온도를 뜻한다
        # (D=-20℃, E=-40℃). EO420(E등급, -40℃)은 DW420(D등급, -20℃)보다 더
        # 가혹한 조건으로 자격된 것이므로, 420 강도 등급에서 EO420 자격이
        # DW420을 포괄한다고 볼 표준 논리가 성립한다(QC_검사로직_상세분석.md
        # §11-4 참고) — F열에 DW420이 없어도 EO420이 있으면 커버된 것으로 본다.
        'DW420':  ['DW420', 'EO420'],
        'API2H':  ['API 2H', 'API2H', '2H GR'],
        # WPS G열은 API 5L 계열을 그레이드명 'X52'로만 표기하는 경우가 있다
        # (TR-SMFC-G01의 'X52 and No Impact Grade' 항목).
        'API5L':  ['API 5L', 'API5L', 'X52'],
        'A53B':   ['A53B', 'ASTM A53', 'STPG370'],
        'A36_AR': ['A36', 'AS ROLL', 'ASTM A36', 'S355NH'],
        # 11-4 1차 처리: A500은 더 이상 A36_AR과 묶이지 않으므로, WPS F열에
        # 'ASTM A500'이 명시적으로 있어야만 커버된 것으로 본다.
        'A500':   ['ASTM A500', 'A500'],
        'S355NH': ['S355NH', 'SS275', 'SS400'],
        'EH36':   ['E(EW)36', 'EH36', 'EW36', 'A(AW)~E(EW)36'],
        'DH36':   ['D(DW)36', 'DH36', 'A(AW)~E(EW)36'],
        'AH36':   ['A(AW)36', 'AH36', 'AW36', 'A(AW)~E(EW)36'],
        # 'NV E'는 너무 짧아 'NV EO420(Z)'(EO420 전용 WPS)에도 걸려서, E36 계열이
        # EO420 전용 WPS에서 허용된 것으로 오판됐다 → 'NV E36'으로 좁힌다.
        'E36':    ['A(AW)~E(EW)36', 'A36', 'NV A', 'NV E36', 'KS SS', 'JIS SS'],
    }
    for pat in checks.get(material_key, ['A(AW)~E(EW)36']):
        if pat.upper() in bm:
            return True
    return False

_E36_FAMILY = {'AH36', 'DH36', 'EH36', 'E36'}

# 관재(각관·강관) 재질 — 철판이 아니라 I열 Out Dia 규격이 판정 기준이 된다.
# 현재는 현업 확인이 된 A500 계열만 대상으로 한다(Check 12).
_TUBULAR_PATTERNS = ('A500',)

def _is_tubular_material(material: str) -> bool:
    m_up = material.upper().replace('-', ' ').replace('_', ' ')
    return any(p in m_up for p in _TUBULAR_PATTERNS)

# 충격시험 면제강(Impact test exemption grade) 그룹.
# WPS G열은 이 강종들의 두께범위를 개별 재질명이 아니라 강종 그룹명으로 적는다
# (예: TR-FC-F01 'Normal strength steel(Impct exemption steel)',
#      TR-GTFC-G01 'Others, Impact Test Exemption Grades',
#      TR-SMFC-G01 'X52 and No Impact Grade').
# 그룹명 라벨과 개별 재질을 이어주지 않으면 해당 행들이 두께 검사에서 통째로
# 빠지므로(실데이터 1,546건), 아래 재질 키를 그룹 라벨에 매칭시킨다.
_IMPACT_EXEMPT_KEYS = {'A36_AR', 'A53B', 'S355NH'}
_IMPACT_EXEMPT_LABEL_RE = re.compile(
    r'IMPACT\s*(TEST)?\s*EXEMPTION|IMPCT\s*EXEMPTION|NO\s*IMPACT|NORMAL\s*STRENGTH',
    re.IGNORECASE,
)

def _parse_material_thickness_entries(text: str) -> list[tuple[str, str]]:
    """
    WPS G열(두께범위) 셀은 실제로는 별도 행이 아니라 **한 셀 안에 여러 줄로**
    "재질 라벨 : 두께범위" 항목이 나열되어 있다 (예: TR-FC-G01의 G열 =
    "~E36\\n: 3~50\\n\\nEO420 (For Dissimilar)\\n:25~38\\n\\nEW420\\n:13~50\\n...").
    이 함수는 그 텍스트를 (재질 라벨, 두께범위 텍스트) 목록으로 분리를 시도한다.

    실제 WPS 27개를 전수 확인한 결과 셀 서식이 완전히 자유 텍스트라 100% 모든
    변형(중첩 조건 "[1pole]" 등, "All" 단일 텍스트, 라벨 없는 단일 범위)을
    안전하게 다 구조화할 수는 없다 — 그런 경우 이 함수는 빈 리스트를 반환하고,
    호출부(_c3_thickness)가 기존 방식(전체 텍스트에서 범위만 추출)으로 안전하게
    폴백한다. 즉 이 함수가 실패해도 결함을 못 잡는 방향으로만 안전하게 후퇴하며,
    잘못된 재질 매칭으로 새로 오류를 만들어내지는 않는다.
    """
    entries: list[tuple[str, str]] = []
    pending_label = ''
    for raw_line in text.split('\n'):
        line = raw_line.strip()
        if not line:
            continue
        if ':' in line:
            label_part, _, range_part = line.partition(':')
            label_part = label_part.strip()
            label = label_part if label_part else pending_label
            if label and re.search(r'\d', range_part):
                entries.append((label, range_part))
            pending_label = ''
        elif not re.match(r'^[\d\s~\-.]+$', line):
            # 콜론 없는 줄 = 다음 콜론 줄과 짝지어질 재질 라벨 후보.
            # 순수 숫자/범위 기호만 있는 줄은 라벨 후보에서 제외.
            pending_label = line
    return entries

def _label_matches_material(material_key: str, label: str) -> bool:
    """G열의 재질 라벨 한 조각이 주어진 표준 재질 키를 가리키는지 판정."""
    if _material_covered_by_wps(material_key, label):
        return True
    # "~E36", "A(AW)~E(EW)36", "NV E36 and lower grade" 같은 축약 표기는
    # E36 계열(AH36/DH36/EH36/E36) 전체를 통칭하는 조선업계 관용 표기.
    if material_key in _E36_FAMILY:
        label_up = label.upper()
        if re.search(r'E\s*\(?\s*E?W?\)?\s*36', label_up) or '~E36' in label_up.replace(' ', ''):
            return True
    # 충격시험 면제강 그룹명 라벨 ↔ 개별 면제강 재질
    if material_key in _IMPACT_EXEMPT_KEYS and _IMPACT_EXEMPT_LABEL_RE.search(label):
        return True
    return False

# ─── 데이터 로더 ──────────────────────────────────────────────────────────────
class QCDataLoader:
    def __init__(self) -> None:
        self.wps_table: dict[str, dict] = {}
        self.welder_qual: dict[str, dict[str, set[str]]] = defaultdict(
            lambda: {'process': set(), 'position': set()}
        )
        self.retired_welders: set[str] = set()  # 퇴사 상태이나 자격은 유지 포함(11-6)
        # 자격 DB의 부가 정보 — 판정에는 쓰지 않고 화면/리포트 표시용.
        # 용접사 번호만으로는 관리자가 누구인지 특정하기 어려워 이름을 함께 보여준다.
        self.welder_names: dict[str, str] = {}          # 번호 -> 이름
        self.welder_certs: dict[str, dict[str, Any]] = {}  # 번호 -> 자격 상세
        self.qmg_rows: list[tuple[int, tuple]] = []
        # 승인 용접봉 리스트의 Lot No. 집합(대문자·공백 제거). **비어 있으면
        # Check 28이 한 행도 판정하지 않는다** — 그 0건은 «문제 없음»이 아니라
        # «대조할 목록이 없다»이고, `_scope`가 그 둘을 구분해 준다.
        self.consumable_lots: set[str] = set()
        # 용접사 번호 -> {"expire": date|None, "disq": date|None, "effective": date}
        # **자격 DB와 별개 파일이다.** 비어 있으면 Check 7이 한 행도 판정하지 않고,
        # `_scope`가 그 사실을 «대상 없음»으로 말한다.
        self.welder_expiry: dict[str, dict] = {}

    # 승인 용접봉 리스트의 «모양». 현업이 준 양식에 고정돼 있다 —
    # 25열 · 머리말 3~4행 · 데이터 5행부터 · **3열이 Lot No.**
    # 여기를 바꾸면 실제 파일과 어긋난다. 열 위치는 `Col`과 같은 성격의 상수다.
    CONSUMABLE_HEADER_ROWS = 4
    CONSUMABLE_LOT_COL     = 3

    def load_consumables(self, path: str | Path) -> int:
        """승인 용접봉 리스트에서 Lot No.를 걷는다. 걷은 개수를 돌려준다.

        **시트 이름을 보지 않는다.** 첫 시트를 쓴다 — 이름을 박아 두면 현업이
        시트 이름을 바꾸는 순간 «목록을 못 읽는다»가 되고, 원인이 시트 이름이라는
        것은 알기 어렵다. WPS 참조 파일을 확장자로 찾는 것과 같은 이유다.

        빈 칸과 머리말 잔재를 걸러 낸다. 파일 끝에 빈 행이 붙어 있는 것이 흔하다.
        """
        p = Path(path)
        wb = load_workbook(str(p), data_only=True, read_only=True,
                           keep_vba=(p.suffix.lower() == ".xlsm"))
        try:
            ws = wb[wb.sheetnames[0]]
            lots: set[str] = set()
            for row in ws.iter_rows(min_row=self.CONSUMABLE_HEADER_ROWS + 1,
                                    values_only=True):
                v = _clean(_row_val(row, self.CONSUMABLE_LOT_COL))
                if v:
                    lots.add(v.upper())
            self.consumable_lots = lots
        finally:
            wb.close()
        logger.info("승인 용접봉 %d개 로드 완료: %s", len(self.consumable_lots), p.name)
        return len(self.consumable_lots)

    def load_consumables_from_list(self, lots: list[str]) -> None:
        """캐시 JSON에서 되살린다. 업로드 없이도 검증이 돌아야 한다."""
        self.consumable_lots = {str(x).strip().upper() for x in lots if str(x).strip()}

    def load_wps(self, xlsm_path: str | Path,
                 progress: Callable[[int, str], None] | None = None) -> None:
        p = Path(xlsm_path)
        wb = _open_workbook(p, data_only=True,
                            keep_vba=(p.suffix.lower() == '.xlsm'))
        if 'Hull & Topside WPS List' not in wb.sheetnames:
            logger.warning("'Hull & Topside WPS List' 시트를 찾을 수 없음")
            wb.close()
            return
        ws = wb['Hull & Topside WPS List']
        current: str | None = None
        for row in ws.iter_rows(min_row=6, values_only=True):
            wps_no = _clean(_row_val(row, WPSCol.WPS_NO))
            bm     = _clean(_row_val(row, WPSCol.BASE_METAL))
            thk    = _clean(_row_val(row, WPSCol.THICKNESS))
            if wps_no:
                current = wps_no
                self.wps_table[current] = {
                    'process':      _normalize_process(_row_val(row, WPSCol.PROCESS)),
                    'position':     _clean(_row_val(row, WPSCol.POSITION)),
                    'joint_detail': _clean(_row_val(row, WPSCol.JOINT_DETAIL)),
                    'materials':    [{'base_metal': bm, 'thk_range': thk}],
                }
            elif current and (bm or thk):
                # 동일 WPS의 재질별 두께 범위 연속 행
                self.wps_table[current]['materials'].append(
                    {'base_metal': bm, 'thk_range': thk}
                )
        wb.close()
        wps_rules.apply_corrections(self.wps_table)
        logger.info("WPS %d개 로드 완료", len(self.wps_table))
        if progress:
            progress(20, f"WPS 참조 로드 완료 ({len(self.wps_table)}개)")

    def load_wps_from_dict(self, wps_data: dict,
                           progress: Callable[[int, str], None] | None = None) -> None:
        """캐시 JSON dict에서 WPS 테이블 로드."""
        self.wps_table = wps_data
        wps_rules.apply_corrections(self.wps_table)
        logger.info("WPS 캐시 %d개 로드 완료", len(self.wps_table))
        if progress:
            progress(20, f"WPS 캐시 로드 완료 ({len(self.wps_table)}개)")

    def load_welders(self, welder_path: str | Path,
                     progress: Callable[[int, str], None] | None = None) -> str:
        """용접사 파일을 읽는다. **어느 형식으로 읽었는지**를 돌려준다.

        ## 한 파일에서 셋을 얻는다

            번호 + Process   -> Check 6(자격 미등록·Process 부적합) · Check 19(자격자 미투입)
            만료일 · 박탈일   -> Check 7(승인기간 이후 작업)          <- 새 형식에만 있다
            이름             -> 용접사 탭 표시 (판정에는 안 쓴다)

        예전에는 자격 DB와 만료일을 **따로** 올렸다. 두 파일에 같은 사람이 있어도
        서로 몰라서, 한쪽에만 있는 사람이 Check 6과 7에서 **따로 지적**됐다.
        하나로 합치면 그 문제가 원천적으로 사라진다.

        ## 형식을 자동으로 가린다 — 조용히 틀리는 것을 막으려고

        옛 파일을 새 형식으로 읽으면 B열에서 번호를 못 찾아 **전원이 «자격
        미등록»으로 잡힌다.** 오류가 아니라 «갑자기 결함이 수천 건»으로만 보여서
        원인을 짐작할 단서가 없다. 그래서 둘 다 시도해 보고 **사람이 나오는 쪽**을
        쓰고, 어느 쪽이었는지 로그와 업로드 응답에 남긴다.

        ## 퇴사 상태(옛 형식 CB열)는 자격 제외 사유가 아니다

        만료일이 전량 공란이라 «용접 시점에 이미 퇴사 후였는지»를 소급 검증할 수
        없었기 때문이다(§11-6). 새 형식에는 만료일이 있으므로 그 판정은 Check 7이
        정식으로 한다 — 퇴사 여부를 볼 이유가 없어졌다.
        """
        wb = load_workbook(str(welder_path), data_only=True, read_only=True)
        try:
            ws = wb.active
            rows = list(ws.iter_rows(values_only=True))
        finally:
            wb.close()

        # 어느 형식인가 — 실제로 «번호 + 그럴듯한 Process»가 나오는 쪽을 쓴다.
        #
        # **그럴듯함 조건이 필요하다.** `_normalize_process()`는 비어 있지만
        # 않으면 무엇이든 통과시켜서, 새 형식 파일의 머리말(「머리6」·「단위6」)이
        # 옛 형식 자리에서 Process로 읽힌다 — 그러면 머리말 두 줄 때문에 옛
        # 형식으로 판정되어 **파일 전체를 잘못 읽는다**(실제로 그랬다).
        #
        # 용접 프로세스는 표준 코드라 전부 ASCII 대문자다(FCAW·GTAW·SMFC…).
        # 여기 조건은 **판별에만** 쓴다 — 실제 적재는 `_normalize_process()`를
        # 그대로 쓰므로 특이 표기를 걸러 버리지 않는다.
        best: tuple[int, tuple] | None = None
        for layout in WelderLayout.ALL:
            _, header, cols = layout
            n = 0
            for r in rows[header:]:
                if not r or not _clean(_row_val(r, cols["no"])):
                    continue
                prc = _normalize_process(_row_val(r, cols["process"]))
                if _looks_like_process(prc):
                    n += 1
            # 같은 점수면 **새 형식이 이긴다** — 지금 쓰는 형식이고, 잘못 골랐을
            # 때 잃는 것이 더 크다(옛 형식으로 읽으면 만료일이 통째로 빠진다).
            if n and (best is None or n > best[0]):
                best = (n, layout)
        if best is None:
            logger.warning("용접사 파일에서 번호+Process를 한 건도 찾지 못했다: %s",
                           welder_path)
            return ""

        _, layout = best
        name, header, cols = layout
        loaded = retired = 0
        for row in rows[header:]:
            if not row:
                continue
            welder_no = _clean(_row_val(row, cols["no"]))
            process   = _normalize_process(_row_val(row, cols["process"]))
            if not welder_no or not process:
                continue
            self.welder_qual[welder_no]['process'].add(process)
            if "position" in cols:
                pos = _clean(_row_val(row, cols["position"]))
                if pos:
                    self.welder_qual[welder_no]['position'].add(pos)
            if "status" in cols:
                status = _clean(_row_val(row, cols["status"]))
                if '퇴사' in status:
                    retired += 1
                    self.retired_welders.add(welder_no)

            # ── 만료일 (새 형식에만 있다) ──
            #
            # **날짜가 비어도 담는다.** 그 사람은 «무기한 유효»가 아니라
            # «만료일이 누락된» 것이고, 그것 자체가 Check 7이 잡는 결함이다.
            if "expire" in cols:
                exp = _parse_date(_row_val(row, cols["expire"]))
                disq = _parse_date(_row_val(row, cols["disq"]))
                dates = [d for d in (exp, disq) if d]
                cur = self.welder_expiry.get(welder_no)
                eff = min(dates) if dates else None
                # 같은 사람이 여러 줄에 나오면 **가장 이른 날**을 쓴다 —
                # 자격이 없던 기간을 놓치지 않으려면 그쪽이 맞다.
                if cur is None or (eff and (cur["effective"] is None
                                            or eff < cur["effective"])):
                    self.welder_expiry[welder_no] = {
                        "expire": exp, "disq": disq, "effective": eff}

            # ── 표시용 부가 정보 (판정에는 관여하지 않음) ──
            wname = _clean(_row_val(row, cols["name"])) if "name" in cols else ""
            if wname and welder_no not in self.welder_names:
                self.welder_names[welder_no] = wname
            cert = self.welder_certs.setdefault(welder_no, {
                'name': wname, 'specs': set(), 'classes': set(),
                'cert_nos': set(), 'first_cert_date': None, 'last_cert_date': None,
            })
            if wname and not cert['name']:
                cert['name'] = wname
            for key, ckey in (('specs', 'spec'), ('classes', 'cls'),
                              ('cert_nos', 'cert_no')):
                if ckey in cols:
                    v = _clean(_row_val(row, cols[ckey]))
                    if v:
                        cert[key].add(v)
            if "cert_date" in cols:
                cdate = _parse_date(_row_val(row, cols["cert_date"]))
                if cdate:
                    if cert['first_cert_date'] is None or cdate < cert['first_cert_date']:
                        cert['first_cert_date'] = cdate
                    if cert['last_cert_date'] is None or cdate > cert['last_cert_date']:
                        cert['last_cert_date'] = cdate
            loaded += 1

        n_exp = sum(1 for r in self.welder_expiry.values() if r["effective"])
        logger.info("용접사 파일 «%s» 형식으로 읽음 — %d명 / %d건"
                    "%s%s", name, len(self.welder_qual), loaded,
                    f" · 만료일 {n_exp}명" if "expire" in cols else " · 만료일 없음",
                    f" · 퇴사 인증행 {retired}건" if retired else "")
        if progress:
            progress(40, f"용접사 DB 로드 완료 ({name} · {len(self.welder_qual)}명)")
        return name

    def load_qmg(self, qmg_path: str | Path,
                 progress: Callable[[int, str], None] | None = None) -> None:
        wb = _open_workbook(Path(qmg_path), data_only=True, read_only=True)
        ws = wb.active
        self.qmg_rows = []
        for excel_row, row in enumerate(ws.iter_rows(min_row=6, values_only=True), start=6):
            if not any(v for v in row if v not in (None, '', ' ')):
                continue
            self.qmg_rows.append((excel_row, row))
        wb.close()
        logger.info("QMG %d행 로드 완료", len(self.qmg_rows))
        if progress:
            progress(60, f"QMG 데이터 로드 완료 ({len(self.qmg_rows):,}행)")

# ─── 플래그 ──────────────────────────────────────────────────────────────────
class Flag:
    __slots__ = ('check_no', 'col', 'color', 'msg', 'welder_no', 'expected', 'actual')

    def __init__(self, check_no: int | str, col: int, color: str, msg: str,
                 welder_no: str = "", expected: str = "", actual: str = "") -> None:
        # **식별자는 문자열이다.** 공통은 `"3"`, 프로젝트는 `"RUYA1"`.
        # 여기서 정규화하므로 `Flag(3, ...)` 호출 30곳을 그대로 둘 수 있다 —
        # 공통 번호를 문자열로 바꿔도 검토 기록 키(`…|3`)는 f-string이라 같다.
        self.check_no  = str(check_no).strip()
        self.col       = col
        self.color     = color   # "Red" | "Green" | "Blue" | "Yellow" | "Orange" | "Black"
        self.msg       = msg
        self.welder_no = welder_no
        self.expected   = expected   # 기준값 (원본 매크로의 셀 주석에 해당)
        self.actual     = actual     # 실제값

# ─── 검사 엔진 ────────────────────────────────────────────────────────────────
def _team_bucket() -> dict:
    """부서 하위 팀(BG열) 단위 집계 — 부서 버킷과 동일한 지표를 한 단계 더 세분화해서 쌓는다."""
    return {
        'total_rows':     0,   # 판정 대상 행수 (미작업 제외)
        # 그중 임시부재(도면번호 1C*) 행수. 판정에서 빼지는 않고, 대시보드가
        # «임시부재 제외» 토글을 켤 때 **분모를 줄이는 데** 쓴다. 깨끗한 행은
        # flag 테이블에 없어 나중에 셀 수 없으므로 판정하면서 여기서 센다.
        'temp_rows':      0,
        'unworked_rows':  0,   # 미작업(Check 0) 행수 — 결함률 분모에 넣지 않음
        'defect_rows':    0,
        'check_stats':    defaultdict(int),
        'welder_totals':  defaultdict(int),
        'welder_defects': defaultdict(int),
        'defects':        [],
        'defect_by_date': defaultdict(int),  # 부서/팀별 "용접 날짜별 결함 발생 추이" (AM열 기준)
    }

def _dept_bucket() -> dict:
    d = _team_bucket()
    d['teams'] = defaultdict(_team_bucket)
    return d

def _is_unworked(row: tuple) -> bool:
    """
    아직 용접이 수행되지 않은 계획 물량인지 판정.

    실제 데이터 전수 확인 결과, WPS No(AJ)가 비어 있는 행은 그 우측의 작업 실적
    컬럼(AK 프로세스 / AM 용접일 / AO NDT계획일 / AP~AW 용접사)이 100% 비어 있고,
    반대로 WPS가 기재된 행 중 용접일이 없는 행은 0건이었다. 즉 WPS 기재 여부가
    '작업 수행 여부'의 정확한 기준이다. 좌측 계획 정보(두께·재질·Groove·NDT Cat)는
    채워져 있으므로 '계획됐지만 아직 미시공'인 물량이다.
    """
    if _clean(_row_val(row, Col.WPS_NO)):
        return False
    for c in (Col.WPS_PROCESS, Col.WELD_DATE, Col.NDT_DATE,
              Col.WELDER1_NO, Col.WELDER2_NO, Col.WELDER3_NO, Col.WELDER4_NO):
        if _clean(_row_val(row, c)):
            return False   # 실적이 일부라도 있으면 미작업으로 단정하지 않는다
    return True

# 「대조 대상」을 세는 검사들. 여기 없는 검사는 **판정 대상 전체**를 본다
# (Check 1·2·3·4·6·11·18·19) — 그건 «대상이 없다»가 아니라 «전부가 대상»이다.
#
# 검사를 추가하면서 관문이 좁으면 여기에도 넣어라. 안 넣으면 그 검사의 0건이
# «검사했고 문제없음»인지 «한 번도 안 돌았는지» 구분되지 않는다.
def check_name(check_id: str) -> str:
    """식별자로 이름을 찾는다. 공통 카탈로그는 **정수 키**를 그대로 둔다 —
    전부 문자열로 바꾸면 정본 문서·테스트·에이전트 정의의 표기가 함께 낡는다."""
    cid = str(check_id).strip()
    if cid.isdigit():
        return CHECK_NAMES.get(int(cid), "")
    return ""            # 프로젝트 규칙 이름은 규칙 정의가 들고 있다


def check_color(check_id: str) -> str:
    cid = str(check_id).strip()
    if cid.isdigit():
        return CHECK_COLORS.get(int(cid), "Gray")
    return "Gray"


_SCOPED_CHECKS: tuple[str, ...] = (
    "7", "8", "9", "12", "13", "14", "16", "17", "20", "21", "22", "23", "24",
    "25", "26", "27")


class QCChecker:
    def __init__(self, loader: QCDataLoader) -> None:
        self.loader        = loader
        self.row_flags:    dict[int, list[Flag]] = {}
        self.row_data:     dict[int, dict]       = {}
        # 상세 결과 화면 "원본 데이터" 패널용 — 행 번호 -> 엑셀 원문 스냅샷.
        # flags_list에 매 플래그마다 중복 저장하면 payload가 커지므로 행당 1회만 보관한다.
        self.row_raw:      dict[int, list[dict]] = {}
        self.stats:        dict[int, int]        = defaultdict(int)
        self.deleted_rows: int                   = 0
        self.unworked_rows: int                  = 0   # Check 0 (판정 대상 아님)
        self.unworked_by_dept: dict[str, int]    = defaultdict(int)
        self.unworked_list: list[dict]           = []  # Check 0 상세 목록 (조인트/블록/부서)
        self.welder_missing: dict[str, int]      = defaultdict(int)
        # 대시보드 "용접사별 결함 발생률" (AP열 기준, 전체 부서 통합)
        self.welder_totals:  dict[str, int]      = defaultdict(int)
        self.welder_defects: dict[str, int]      = defaultdict(int)
        # 용접사별 "결함 종류" 약식 표기용 — check_no(6 제외) 별 건수
        self.welder_check_stats: dict[str, dict[int, int]] = defaultdict(lambda: defaultdict(int))
        # "용접 날짜별 결함 발생 추이" (AM열 기준)
        self.defect_by_date: dict[str, int]      = defaultdict(int)
        # "부서별 결함 분류" (BF열 기준)
        self.dept_data: dict[str, dict]          = defaultdict(_dept_bucket)
        # Check 13(이상치)이 1차 판정 이후에 결함 목록에 새로 합류할 때, 기존 defect
        # 항목을 찾아 이어붙이기 위한 인덱스. (dept_data['defects']/teams['defects']에
        # 들어간 dict와 같은 객체를 참조하므로 이걸 통해 갱신하면 양쪽에 다 반영된다.)
        self._defect_entry_by_row: dict[int, dict] = {}
        # Check 13이 전체 분포를 봐야 하므로, 1차 판정 중 만난 판정대상 행을 캐시해둔다.
        self._judged_rows_cache: list[tuple[int, tuple]] = []
        # 이미 '작업성 결함(C6 제외)'으로 집계된 행. 2차 패스(Check 13/14)가
        # 같은 행을 중복 집계하거나, 반대로 C6만 있던 행을 누락하지 않게 한다.
        self._workmanship_rows: set[int] = set()
        # 용접사 -> {(부서, 팀): 행수}. 화면의 «자격 미등록» 목록을 업체에
        # 보낼 때 소속이 없으면 누구에게 물어야 할지 알 수 없다.
        self.welder_orgs: dict[str, Counter[tuple[str, str]]] = defaultdict(Counter)
        # **각 검사가 «무엇을 대조했는가».** 0건에는 두 종류가 있다:
        #
        #     대조했고 위반이 없다        -> 진짜 «문제 없음»
        #     대조할 대상이 아예 없었다    -> 한 번도 판정하지 않았다
        #
        # 화면에서는 둘 다 그냥 «0건»으로 보인다. 실제로 Check 25는 `Q01`로 끝나는
        # WPS가 한 행도 없어 한 번도 안 돌았는데 «통과»로 읽혔다. Check 15가 결번이
        # 된 것도 같은 상황을 뒤늦게 알아차렸기 때문이다.
        #
        # 그래서 검사마다 **적용 관문을 통과한 행 수**를 센다. 0이면
        # `rule_health`가 «대조 대상 없음»을 경고한다.
        #
        # **0으로 미리 채운다.** 관문을 한 번도 통과 못 한 검사는 `Counter`에 키가
        # 아예 안 생겨서, 순회하면 **정작 잡아야 할 «대상 0건»이 빠진다.**
        self._scope: Counter[str] = Counter({no: 0 for no in _SCOPED_CHECKS})
        self._enabled: dict[int, bool] | None = None   # 프로젝트 세팅(한 번만 읽는다)
        # 프로젝트 판정규칙. 회차 안에서 «한 기준»이어야 하므로 한 번만 읽는다.
        self._rules: list | None = None
        self._rule_problems: list[str] = []
        self._rule_matched: dict[str, int] = {}   # 규칙별 선점한 side 수
        self._mat_wps: dict[tuple[str, str], int] = {}  # 재질×WPS 분포(규칙 미리보기용)
        self._suppressed: dict[tuple[str, str], int] = {}  # (프로젝트, 공통) -> side 수
        # 임시부재(도면번호 1C*) 중 «판정 대상»인 행수. 대시보드 토글의 분모.
        self.temp_judged_rows: int = 0
        # Check 16·17의 기준일과 유예기간. run()이 데이터에서 채운다.
        self._ref_date: Optional[date] = None
        self._grace_days: int = wps_rules.inspection_grace_days()
        self.ml_meta: dict | None = None
        self.ml_detail: dict[int, dict] = {}
        # 임시부재(1C)를 **학습에서 빼고** 다시 돌린 것. 플래그를 만들지 않는다 —
        # `_detect_check13_excl_temp()` 참조.
        self.ml_excl_temp_meta: dict | None = None
        self.ml_excl_temp_detail: dict[int, dict] = {}
        self.ml_excl_temp_rows: int = 0
        # 용접사별 · 용접일별 시공량과 Check별 결함건수.
        # 결함 추이를 '건수'로만 그리면 많이 일한 날과 잘못한 날을 구분할 수 없어
        # 개선/악화 판단이 불가능하다. 분모(그날 시공량)가 있어야 결함률을 그릴 수 있다.
        self.welder_date_totals: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
        self.welder_date_checks: dict[str, dict[str, dict[int, int]]] = defaultdict(
            lambda: defaultdict(lambda: defaultdict(int)))

    def run(self, progress: Callable[[int, str], None] | None = None) -> None:
        self.row_flags      = {}
        self.row_data       = {}
        self.row_raw        = {}
        self.stats          = defaultdict(int)
        self.deleted_rows   = 0
        self.unworked_rows  = 0
        self.unworked_by_dept = defaultdict(int)
        self.unworked_list  = []
        self.welder_missing = defaultdict(int)
        self.welder_totals  = defaultdict(int)
        self.welder_defects = defaultdict(int)
        self.welder_check_stats = defaultdict(lambda: defaultdict(int))
        self.defect_by_date = defaultdict(int)
        self.dept_data      = defaultdict(_dept_bucket)
        self._defect_entry_by_row = {}
        self._judged_rows_cache   = []
        self._mat_wps             = {}
        self._workmanship_rows    = set()
        self.welder_orgs          = defaultdict(Counter)
        self.temp_judged_rows     = 0
        self.ml_meta              = None
        self.ml_detail            = {}
        self.ml_excl_temp_meta    = None
        self.ml_excl_temp_detail  = {}
        self.ml_excl_temp_rows    = 0
        self.welder_date_totals   = defaultdict(lambda: defaultdict(int))
        self.welder_date_checks   = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))

        # ── Check 16·17의 기준일 ────────────────────────────────────────────
        # "검사가 아직 안 끝난 것"과 "검사를 빠뜨린 것"을 가르려면 기준 시점이
        # 필요하다. **«오늘»을 쓰지 않는다** — 같은 파일을 내일 다시 돌리면 결과가
        # 달라져 재검증 비교가 성립하지 않기 때문이다. 데이터 안에서 가장 늦은
        # 용접일을 «이 데이터가 찍힌 시점»으로 삼는다.
        self._ref_date = None
        for _, r in self.loader.qmg_rows:
            if _is_deleted(r):
                continue
            d = _parse_date(_row_val(r, Col.WELD_DATE))
            if d and (self._ref_date is None or d > self._ref_date):
                self._ref_date = d
        self._grace_days = wps_rules.inspection_grace_days()

        total = len(self.loader.qmg_rows)
        for i, (row_num, row) in enumerate(self.loader.qmg_rows):
            if _is_deleted(row):
                self.deleted_rows += 1
                continue

            welder1_no   = _clean(_row_val(row, Col.WELDER1_NO))
            dept         = _clean(_row_val(row, Col.DEPARTMENT)) or '(부서 미기재)'
            team         = _clean(_row_val(row, Col.TEAM)) or '(팀 미기재)'
            is_temp      = wps_rules.is_temp_member(_row_val(row, Col.DRAWING_NO))
            weld_dt      = _parse_date(_row_val(row, Col.WELD_DATE))
            weld_date_str = weld_dt.isoformat() if weld_dt else ''

            # ── Check 0: 미작업 물량은 판정 자체를 하지 않는다 ──────────────────
            # '미작업'과 '결함'은 완전히 다른 영역이라, 결함률 분모(judged_rows)와
            # 용접사·부서·팀 통계 어디에도 섞이지 않도록 여기서 분리한다.
            if _is_unworked(row):
                self.unworked_rows += 1
                self.unworked_by_dept[dept] += 1
                self.dept_data[dept]['unworked_rows'] += 1
                self.dept_data[dept]['teams'][team]['unworked_rows'] += 1
                self.row_raw[row_num] = _row_snapshot(row)
                self.unworked_list.append({
                    'row':        row_num,
                    'drawing_no': _clean(_row_val(row, Col.DRAWING_NO)),
                    'joint_no':   _clean(_row_val(row, Col.JOINT_NO)),
                    'block':      _clean(_row_val(row, Col.BLOCK)),
                    'department': dept,
                    'team':       team,
                })
                continue

            self._judged_rows_cache.append((row_num, row))
            # 규칙 편집 화면이 «이 조건에 몇 행 걸리나»를 즉시 세는 데 쓴다.
            # J열과 K열의 재질이 다를 수 있으므로 양쪽을 다 센다.
            _wps_key = _clean(_row_val(row, Col.WPS_NO))
            for _c in (Col.MATERIAL1, Col.MATERIAL2):
                _m = _clean(_row_val(row, _c))
                if _m:
                    _k = (_m, _wps_key)
                    self._mat_wps[_k] = self._mat_wps.get(_k, 0) + 1
            flags = self._check_row(row)
            has_defect = bool(flags)
            # 용접사별 결함률은 실제 작업성 결함만 반영한다.
            # Check 6(미자격 용접사)·7(승인기간 이후 작업)은 **그 사람의 자격
            # 상태**이지 그 행의 용접 품질이 아니므로 제외한다. 넣으면 같은 행의
            # 다른 용접사 세 명에게 오귀속된다.
            has_workmanship_defect = any(f.check_no not in ("6", "7") for f in flags)

            # 검증 건수는 AP(1번 용접사)뿐 아니라 AR/AT/AV(2~4번 용접사)로 참여한 건도 모두 포함해야
            # 실제 총 용접 건수가 된다. 한 조인트에 여러 용접사가 있으면 전원에게 반영.
            row_welders = {
                _clean(_row_val(row, c))
                for c in (Col.WELDER1_NO, Col.WELDER2_NO, Col.WELDER3_NO, Col.WELDER4_NO)
            }
            row_welders.discard('')

            if has_workmanship_defect:
                self._workmanship_rows.add(row_num)

            # 용접사가 «어느 팀에서» 일했는가. 업체에 물어볼 때 번호만으로는
            # 누구에게 물어야 할지 모른다 — 한 사람이 여러 팀에 걸치기도 한다.
            org = (_clean(_row_val(row, Col.DEPARTMENT)),
                   _clean(_row_val(row, Col.TEAM)))
            for wno in row_welders:
                self.welder_orgs[wno][org] += 1
                self.welder_totals[wno] += 1
                if has_workmanship_defect:
                    self.welder_defects[wno] += 1
                # 날짜별 분모(그날 이 용접사가 시공한 판정대상 행 수)
                if weld_date_str:
                    self.welder_date_totals[wno][weld_date_str] += 1

            # 날짜별 Check 결함건수 (C6은 서류 문제라 작업성 추이에서 제외)
            if weld_date_str:
                for f in flags:
                    if f.check_no == "6":
                        continue
                    for wno in row_welders:
                        self.welder_date_checks[wno][weld_date_str][f.check_no] += 1

            d = self.dept_data[dept]
            t = d['teams'][team]
            d['total_rows'] += 1
            t['total_rows'] += 1
            if is_temp:
                self.temp_judged_rows += 1
                d['temp_rows'] += 1
                t['temp_rows'] += 1
            for wno in row_welders:
                d['welder_totals'][wno] += 1
                t['welder_totals'][wno] += 1
                if has_workmanship_defect:
                    d['welder_defects'][wno] += 1
                    t['welder_defects'][wno] += 1

            if flags:
                self.row_flags[row_num] = flags
                ndt_dt = _parse_date(_row_val(row, Col.NDT_DATE))
                self.row_data[row_num] = {
                    'drawing_no':  _clean(_row_val(row, Col.DRAWING_NO)),
                    'joint_no':    _clean(_row_val(row, Col.JOINT_NO)),
                    'block':       _clean(_row_val(row, Col.BLOCK)),
                    'material1':   _clean(_row_val(row, Col.MATERIAL1)),
                    'material2':   _clean(_row_val(row, Col.MATERIAL2)),
                    'thickness1':  _clean(_row_val(row, Col.THICKNESS1)),
                    'thickness2':  _clean(_row_val(row, Col.THICKNESS2)),
                    'wps_no':      _clean(_row_val(row, Col.WPS_NO)),
                    'wps_process': _clean(_row_val(row, Col.WPS_PROCESS)),
                    'ndt_report':  _clean(_row_val(row, Col.NDT_REPORT)),
                    'weld_date':   weld_date_str,
                    'ndt_date':    ndt_dt.isoformat() if ndt_dt else '',
                    'welder1_no':  welder1_no,
                    'department':  dept,
                    'team':        team,
                }
                self.row_raw[row_num] = _row_snapshot(row)
                counted: dict[int, int] = defaultdict(int)
                for f in flags:
                    counted[f.check_no] += 1
                    if f.check_no == "6" and f.welder_no:
                        self.welder_missing[f.welder_no] += 1
                    elif f.check_no != "6":
                        # Check 6(미자격)은 특정 용접사(f.welder_no)에게만 귀속.
                        # 그 외 체크는 조인트 단위 결함이므로 해당 조인트의 용접사 전원에게 반영.
                        for wno in row_welders:
                            self.welder_check_stats[wno][f.check_no] += 1
                for check_no, cnt in counted.items():
                    self.stats[check_no] += cnt

                if weld_date_str:
                    self.defect_by_date[weld_date_str] += 1
                    d['defect_by_date'][weld_date_str] += 1
                    t['defect_by_date'][weld_date_str] += 1

                d['defect_rows'] += 1
                t['defect_rows'] += 1
                check_entries = []
                for f in flags:
                    d['check_stats'][f.check_no] += 1
                    t['check_stats'][f.check_no] += 1
                    check_entries.append({
                        'check_no':   f.check_no,
                        'check_name': self._check_name(f.check_no),
                        'color':      f.color,
                        'msg':        f.msg,
                        'expected':   f.expected,
                        'actual':     f.actual,
                    })
                defect_entry = {
                    'row':        row_num,
                    'joint_no':   self.row_data[row_num]['joint_no'],
                    'block':      self.row_data[row_num]['block'],
                    'wps_no':     self.row_data[row_num]['wps_no'],
                    'ndt_report': self.row_data[row_num]['ndt_report'],
                    'weld_date':  weld_date_str,
                    'welder1_no': welder1_no,
                    'checks':     check_entries,
                }
                d['defects'].append(defect_entry)
                t['defects'].append(defect_entry)
                self._defect_entry_by_row[row_num] = defect_entry

            if progress and (i % 500 == 0 or i == total - 1):
                pct = 60 + int((i / max(total, 1)) * 35)
                progress(pct, f"검사 중… {i + 1:,}/{total:,}행")

        if progress:
            progress(95, "이상치(Check 13) 탐지 중…")
        self._detect_check13_anomalies()

        if progress:
            progress(97, "Joint 중복(Check 14) 탐지 중…")
        self._detect_check14_duplicates()

        if progress:
            progress(98, "NDT 적용 요율(Check 26) 대조 중…")
        self._detect_check26_ndt_rate()

        logger.info("검사 완료: %d행 플래그", len(self.row_flags))
        if progress:
            progress(100, "검사 완료")

    def _register_flag(self, row_num: int, row: tuple, flag: Flag,
                       dept: str, team: str, weld_date_str: str,
                       row_welders: set[str]) -> None:
        """
        1차 판정 루프가 끝난 뒤에야 알 수 있는 플래그(Check 13처럼 전체 데이터
        분포를 다 봐야 하는 경우)를 이미 끝난 집계(부서/팀/용접사/결함행수 등)에
        안전하게 합류시킨다.

        이 행이 1차 판정에서 이미 결함이었으면 플래그만 추가하고, 처음으로
        결함이 되는 것이면(전부 정상이었다가 이번에 이상치로만 걸리는 경우)
        결함행수·용접사 결함률·날짜별 추이·결함 리스트를 새로 반영해야 한다 —
        안 하면 대시보드 KPI(결함 행 수 등)와 Check별 합계가 서로 안 맞게 된다.
        """
        # **2차 패스도 프로젝트 세팅을 따라야 한다.**
        # 취사선택 필터를 `_check_row()` 끝에만 두었더니 Check 13·14가
        # 그 길을 지나지 않아 «껐는데 938건이 그대로» 나왔다. 2차 패스는
        # `_register_flag`로 뒤늦게 합류하므로 여기에도 같은 문을 둔다.
        # CLAUDE.md가 «2단계 패스가 가장 자주 깨지는 곳»이라고 적어 둔 자리다.
        if not self._rule_on(flag.check_no):
            return

        is_new_defect_row = not self.row_flags.get(row_num)

        if row_num not in self.row_data:
            ndt_dt = _parse_date(_row_val(row, Col.NDT_DATE))
            self.row_data[row_num] = {
                'drawing_no':  _clean(_row_val(row, Col.DRAWING_NO)),
                'joint_no':    _clean(_row_val(row, Col.JOINT_NO)),
                'block':       _clean(_row_val(row, Col.BLOCK)),
                'material1':   _clean(_row_val(row, Col.MATERIAL1)),
                'material2':   _clean(_row_val(row, Col.MATERIAL2)),
                'thickness1':  _clean(_row_val(row, Col.THICKNESS1)),
                'thickness2':  _clean(_row_val(row, Col.THICKNESS2)),
                'wps_no':      _clean(_row_val(row, Col.WPS_NO)),
                'wps_process': _clean(_row_val(row, Col.WPS_PROCESS)),
                'ndt_report':  _clean(_row_val(row, Col.NDT_REPORT)),
                'weld_date':   weld_date_str,
                'ndt_date':    ndt_dt.isoformat() if ndt_dt else '',
                'welder1_no':  _clean(_row_val(row, Col.WELDER1_NO)),
                'department':  dept,
                'team':        team,
            }
        if row_num not in self.row_raw:
            self.row_raw[row_num] = _row_snapshot(row)

        self.row_flags.setdefault(row_num, []).append(flag)
        self.stats[flag.check_no] += 1

        d = self.dept_data[dept]
        t = d['teams'][team]
        d['check_stats'][flag.check_no] += 1
        t['check_stats'][flag.check_no] += 1
        if flag.check_no != "6":
            for wno in row_welders:
                self.welder_check_stats[wno][flag.check_no] += 1

        check_entry = {
            'check_no':   flag.check_no,
            'check_name': self._check_name(flag.check_no),
            'color':      flag.color,
            'msg':        flag.msg,
            'expected':   flag.expected,
            'actual':     flag.actual,
        }

        # 용접사 결함행 수는 '이 행이 처음 결함이 되었는가(is_new_defect_row)'가 아니라
        # '이 행이 처음 작업성 결함이 되었는가'를 기준으로 세야 한다. 1차 판정에서
        # Check 6(서류 문제)만 있던 행이 2차 패스(Check 13/14)로 작업성 결함을 얻으면
        # is_new_defect_row는 False라, 예전에는 용접사 결함행 수에 반영되지 않았다.
        # 실데이터에서 257행이 이 경우였고, 자격 미등록 용접사의 결함률이 크게
        # 과소집계됐다(예: 5361이 52건으로 표시됐으나 실제 192건).
        if flag.check_no not in ("6", "7") and row_num not in self._workmanship_rows:
            self._workmanship_rows.add(row_num)
            for wno in row_welders:
                self.welder_defects[wno] += 1
                d['welder_defects'][wno] += 1
                t['welder_defects'][wno] += 1

        # 2차 패스 플래그도 날짜별 Check 추이에 반영해야 한다(1차와 같은 기준).
        if flag.check_no != "6" and weld_date_str:
            for wno in row_welders:
                self.welder_date_checks[wno][weld_date_str][flag.check_no] += 1

        if is_new_defect_row:
            d['defect_rows'] += 1
            t['defect_rows'] += 1
            if weld_date_str:
                self.defect_by_date[weld_date_str] += 1
                d['defect_by_date'][weld_date_str] += 1
                t['defect_by_date'][weld_date_str] += 1
            defect_entry = {
                'row':        row_num,
                'joint_no':   self.row_data[row_num]['joint_no'],
                'block':      self.row_data[row_num]['block'],
                'wps_no':     self.row_data[row_num]['wps_no'],
                'ndt_report': self.row_data[row_num]['ndt_report'],
                'weld_date':  weld_date_str,
                'welder1_no': self.row_data[row_num]['welder1_no'],
                'checks':     [check_entry],
            }
            d['defects'].append(defect_entry)
            t['defects'].append(defect_entry)
            self._defect_entry_by_row[row_num] = defect_entry
        else:
            entry = self._defect_entry_by_row.get(row_num)
            if entry is not None:
                entry['checks'].append(check_entry)

    def _detect_check13_anomalies(self) -> None:
        """
        Isolation Forest로 전체 판정대상 행의 분포에서 크게 벗어난 조합을 찾아
        Check 13으로 등록한다. 규칙 위반이 아니라 통계적 이례성이므로 반드시
        사람이 피드백(확정/오탐/확인중)으로 최종 판단해야 한다.
        """
        if not anomaly.is_available():
            return

        row_lookup = dict(self._judged_rows_cache)
        feats: list[tuple[int, dict]] = []
        for row_num, row in self._judged_rows_cache:
            weld_dt = _parse_date(_row_val(row, Col.WELD_DATE))
            ndt_dt  = _parse_date(_row_val(row, Col.NDT_DATE))
            gap = (ndt_dt - weld_dt).days if (weld_dt and ndt_dt) else None
            raw_mat = _clean(_row_val(row, Col.MATERIAL1))
            feats.append((row_num, {
                'material_key': _get_material_key(raw_mat) or raw_mat,
                'wps_no':       _clean(_row_val(row, Col.WPS_NO)),
                'groove':       _clean(_row_val(row, Col.GROOVE)),
                'ndt_cat':      _clean(_row_val(row, Col.NDT_CAT)),
                'department':   _clean(_row_val(row, Col.DEPARTMENT)),
                'team':         _clean(_row_val(row, Col.TEAM)),
                'thickness1':   _to_float(_row_val(row, Col.THICKNESS1)),
                'thickness2':   _to_float(_row_val(row, Col.THICKNESS2)),
                'weld_to_ndt_days': gap,
            }))

        self._scope["13"] += len(feats)
        detected = anomaly.detect_anomalies(feats)
        anomalies = detected.get('anomalies') or {}
        # 머신러닝 분석 탭이 쓰는 분포/투영 정보. 행수와 무관하게 크기가 일정하도록
        # 격자/히스토그램으로 요약돼 있어 결과 JSON을 크게 늘리지 않는다.
        self.ml_meta = detected.get('meta')

        self._detect_check13_excl_temp(feats, row_lookup)
        if not anomalies:
            logger.info("Check13: 이상치 없음(또는 비활성화)")
            return

        for row_num, info in anomalies.items():
            row = row_lookup[row_num]
            dept = _clean(_row_val(row, Col.DEPARTMENT)) or '(부서 미기재)'
            team = _clean(_row_val(row, Col.TEAM)) or '(팀 미기재)'
            weld_dt = _parse_date(_row_val(row, Col.WELD_DATE))
            weld_date_str = weld_dt.isoformat() if weld_dt else ''
            row_welders = {
                _clean(_row_val(row, c))
                for c in (Col.WELDER1_NO, Col.WELDER2_NO, Col.WELDER3_NO, Col.WELDER4_NO)
            }
            row_welders.discard('')

            flag = Flag(13, Col.DRAWING_NO, "Cyan",
                        f"이상치 확인 필요: 통계적으로 이례적인 조합 ({info['reason']})",
                        expected="정상 분포 범위 (참고용, 규칙 위반 아님 - 사람 확인 필요)",
                        actual=info['reason'])
            self._register_flag(row_num, row, flag, dept, team, weld_date_str, row_welders)
            # 상세(피처별 이탈도/동종그룹/좌표)는 '머신러닝 분석' 탭에서만 쓰므로
            # flags에 섞지 않고 행 번호로 찾는 별도 맵에 둔다 - flags는 5천 건이
            # 넘어가는데 거기에 매번 딸려가면 결과 JSON이 불필요하게 커진다.
            self.ml_detail[row_num] = {
                'score':      info['score'],
                'reason':     info['reason'],
                'deviations': info['deviations'],
                'peers':      info['peers'],
                'xy':         info['xy'],
                'drawing_no': _clean(_row_val(row, Col.DRAWING_NO)),
                'joint_no':   _clean(_row_val(row, Col.JOINT_NO)),
                'department': dept,
                'team':       team,
            }

        logger.info("Check13: 이상치 %d건 탐지", len(anomalies))

    def _detect_check13_excl_temp(self, feats: list[tuple[int, dict]],
                                  row_lookup: dict[int, dict]) -> None:
        """임시부재(1C 도면)를 **학습에서 빼고** 한 번 더 돌린다.

        현업 확인(2026-08-15): 1C는 임시 용접이라 작업도 결과 처리도 불완전하다.
        그래서 **학습 항목이 되어서는 안 된다** — 1C 포함은 참고용이고, 미포함이
        진짜 검토용·학습용이다.

        ## 왜 «화면에서 거르기»로는 안 되는가

        Check 13은 「전체 분포에서 드문 조합」을 찾는다. 그런데 이 물량은
        **판정 대상의 93%가 1C**다. 즉 지금의 «흔한 조합»은 임시 용접의 모양이고,
        본 작업은 그 기준에서 상대적으로 드물게 보인다 — 기준 자체가 뒤집혀 있다.
        결과만 걸러 내면 화면에서 1C 행이 사라질 뿐, **남은 행에 붙은 점수는
        여전히 1C가 만든 분포로 매긴 것**이다. 그건 «뺐다»가 아니라 «감췄다»다.

        그래서 거르는 것이 아니라 **다시 학습한다.**

        ## 판정(Check 13 플래그)은 건드리지 않는다

        §11-11에서 현업이 「1C 도면도 다른 행과 똑같이 판정한다」로 정했고,
        「임시부재 제외」는 보기 토글로만 존재한다. 여기서 판정을 바꾸면 그 결정과
        부딪히고, 결함 목록·부서 실적·Excel·메일이 전부 따라 움직인다.
        그래서 이 두 번째 학습은 **플래그를 만들지 않는다** — 비지도학습 탭이
        「이 기준으로는 무엇이 드문가」를 보여주는 데만 쓴다.

        건수가 다른 것은 정상이고, 화면이 그 이유를 함께 말한다. 말하지 않으면
        「탭에는 6건인데 결함은 81건」이 되어 **어느 쪽이 맞는지 보는 사람이 알
        방법이 없다.**
        """
        keep = [(rn, f) for rn, f in feats
                if not wps_rules.is_temp_member(
                    _row_val(row_lookup[rn], Col.DRAWING_NO))]
        self.ml_excl_temp_rows = len(keep)
        if len(keep) == len(feats):
            # 1C가 한 행도 없다. 같은 결과를 두 번 담으면 payload만 커지고,
            # 화면은 «두 기준이 있다»고 잘못 읽는다.
            logger.info("Check13(1C 제외): 임시부재가 없어 건너뜀")
            return

        detected = anomaly.detect_anomalies(keep)
        self.ml_excl_temp_meta = detected.get('meta')
        for row_num, info in (detected.get('anomalies') or {}).items():
            row = row_lookup[row_num]
            self.ml_excl_temp_detail[row_num] = {
                'score':      info['score'],
                'reason':     info['reason'],
                'deviations': info['deviations'],
                'peers':      info['peers'],
                'xy':         info['xy'],
                'drawing_no': _clean(_row_val(row, Col.DRAWING_NO)),
                'joint_no':   _clean(_row_val(row, Col.JOINT_NO)),
                'department': _clean(_row_val(row, Col.DEPARTMENT)) or '(부서 미기재)',
                'team':       _clean(_row_val(row, Col.TEAM)) or '(팀 미기재)',
            }
        logger.info("Check13(1C 제외): %d행 학습 · 이상치 %d건",
                    len(keep), len(self.ml_excl_temp_detail))

    def _detect_check14_duplicates(self) -> None:
        """
        같은 도면(Drawing No) 안에서 같은 Joint No로 등록된 행이 2개 이상이면서
        재질/두께/WPS 중 하나라도 서로 다르면, 동일 물리적 조인트에 모순되는 값이
        중복 등록된 것으로 보고 Check14로 표시한다.

        Joint No(D열)는 도면 내에서만 유일하다 — 실제 데이터로 직접 확인한 결과,
        같은 Joint No 문자열이 서로 다른 도면에서 정상적으로 반복 등장한다(도면마다
        조인트 번호를 1번부터 새로 매김). 그래서 반드시 (도면번호, Joint No) 쌍으로
        묶어야 하며, 도면번호 없이 Joint No만으로 묶으면 무관한 행들이 대량으로
        오탐 처리된다.
        """
        groups: dict[tuple[str, str], list[int]] = defaultdict(list)
        for row_num, row in self._judged_rows_cache:
            dn = _clean(_row_val(row, Col.DRAWING_NO))
            jn = _clean(_row_val(row, Col.JOINT_NO))
            if dn and jn:
                groups[(dn, jn)].append(row_num)

        row_lookup = dict(self._judged_rows_cache)
        self._scope["14"] += sum(1 for rows in groups.values() if len(rows) >= 2)
        flagged = 0
        for (dn, jn), rows in groups.items():
            if len(rows) < 2:
                continue
            mats = {_clean(_row_val(row_lookup[r], Col.MATERIAL1)) for r in rows}
            thks = {_clean(_row_val(row_lookup[r], Col.THICKNESS1)) for r in rows}
            wpss = {_clean(_row_val(row_lookup[r], Col.WPS_NO)) for r in rows}
            if len(mats) <= 1 and len(thks) <= 1 and len(wpss) <= 1:
                continue

            diffs = []
            if len(mats) > 1: diffs.append(f"재질 {sorted(mats)}")
            if len(thks) > 1: diffs.append(f"두께 {sorted(thks)}")
            if len(wpss) > 1: diffs.append(f"WPS {sorted(wpss)}")
            diff_desc = ' / '.join(diffs)

            for row_num in rows:
                row = row_lookup[row_num]
                dept = _clean(_row_val(row, Col.DEPARTMENT)) or '(부서 미기재)'
                team = _clean(_row_val(row, Col.TEAM)) or '(팀 미기재)'
                weld_dt = _parse_date(_row_val(row, Col.WELD_DATE))
                weld_date_str = weld_dt.isoformat() if weld_dt else ''
                row_welders = {
                    _clean(_row_val(row, c))
                    for c in (Col.WELDER1_NO, Col.WELDER2_NO, Col.WELDER3_NO, Col.WELDER4_NO)
                }
                row_welders.discard('')
                other_rows = [r for r in rows if r != row_num]

                flag = Flag(14, Col.JOINT_NO, "Brown",
                            f"Joint 중복 등록 의심: 동일 도면·Joint No인데 {diff_desc}가 다른 행이 있음 "
                            f"(관련 행: {other_rows})",
                            expected="동일 Joint(도면번호+Joint No)는 재질/두께/WPS가 모든 행에서 일치해야 함",
                            actual=diff_desc)
                self._register_flag(row_num, row, flag, dept, team, weld_date_str, row_welders)
                flagged += 1

        if flagged:
            logger.info("Check14: 중복/모순 Joint %d행 탐지", flagged)

    def _detect_check26_ndt_rate(self) -> None:
        """리포트 «묶음»의 실제 촬영율이 요구 요율에 못 미치는가. **2차 패스다.**

        ## 왜 행 하나로는 판정할 수 없는가

        NDT 리포트 번호는 한 장이 여러 조인트를 덮는다. 그중 실제로 촬영한 것과
        안 한 것을 **번호 끝의 `*`**로 구분한다(현업 확인 2026-08-13):

            MSOU00001   2건   <- 촬영함
            MSOU00001*  8건   <- 촬영 안 함
            -------------------
            묶음 촬영율 = 2 / 10 = 20%

        그래서 «이 행이 찍혔는가»가 아니라 «이 묶음이 요구 요율을 채웠는가»가
        판정 단위다. `*`를 뗀 번호가 같으면 한 묶음이다.

        ## 요구 요율이 섞이면 **가장 높은 것**을 쓴다

        한 묶음에 20%와 10%가 함께 오는 경우가 실데이터에 9묶음 있다. 현업 확인
        (2026-08-13)으로 **최댓값** 기준이다 — 20%를 요구하는 조인트가 하나라도
        들어 있으면 그 묶음은 20%를 채워야 한다. 최솟값으로 하면 낮은 요율
        조인트를 한 건 끼워 넣는 것만으로 요구가 내려간다.

        실데이터: 519묶음 중 **1묶음**(`MT MSOM09316`, 149행 중 20행만 촬영 =
        13.4% < 20%)이 미달이다.

        ## 2차 패스라 소급 갱신이 필요하다

        `_register_flag()`를 거치므로 `stats`·`row_flags`·부서/팀 버킷·
        `welder_defects`가 함께 갱신된다. 직접 `row_flags`에 넣지 마라.
        """
        # (검사종류, `*` 뗀 번호) -> {전체, 촬영, 요구 요율들, 행 목록}
        groups: dict[tuple[str, str], dict[str, Any]] = defaultdict(
            lambda: {"total": 0, "shot": 0, "reqs": set(), "rows": []})
        row_lookup = dict(self._judged_rows_cache)
        for row_num, row in self._judged_rows_cache:
            for ext_col, rep_col, tag in self._NDT_REPORT_COLS:
                rep = _clean(_row_val(row, rep_col))
                if not rep:
                    continue
                g = groups[(tag, rep.rstrip("*"))]
                g["total"] += 1
                if not rep.endswith("*"):
                    g["shot"] += 1
                req = _to_float(_clean(_row_val(row, ext_col)))
                if req is not None:
                    g["reqs"].add(req)
                g["rows"].append((row_num, rep_col))

        # 대상은 «요구 요율이 잡힌 묶음»이다. 요율이 없는 묶음은 대조할 것이 없다.
        self._scope["26"] += sum(1 for g in groups.values() if g["reqs"] and g["total"])
        flagged = 0
        for (tag, base), g in groups.items():
            if not g["reqs"] or not g["total"]:
                continue
            need = max(g["reqs"])
            rate = 100.0 * g["shot"] / g["total"]
            if rate + 1e-9 >= need:
                continue
            for row_num, rep_col in g["rows"]:
                row = row_lookup[row_num]
                dept = _clean(_row_val(row, Col.DEPARTMENT)) or '(부서 미기재)'
                team = _clean(_row_val(row, Col.TEAM)) or '(팀 미기재)'
                weld_dt = _parse_date(_row_val(row, Col.WELD_DATE))
                row_welders = {
                    _clean(_row_val(row, c))
                    for c in (Col.WELDER1_NO, Col.WELDER2_NO, Col.WELDER3_NO, Col.WELDER4_NO)
                }
                row_welders.discard('')
                flag = Flag(26, rep_col, "Navy",
                            f"{tag} 리포트 '{base}' 묶음의 촬영율 {rate:.1f}% "
                            f"(요구 {need:g}%) — {g['total']}건 중 {g['shot']}건만 촬영",
                            expected=f"{tag} 촬영율 {need:g}% 이상 (묶음 '{base}')",
                            actual=f"{rate:.1f}% ({g['shot']}/{g['total']})")
                self._register_flag(row_num, row, flag, dept, team,
                                    weld_dt.isoformat() if weld_dt else '', row_welders)
                flagged += 1

        if flagged:
            logger.info("Check26: NDT 요율 미달 %d행 탐지", flagged)

    def _check_row(self, row: tuple) -> list[Flag]:
        flags: list[Flag] = []
        wps_no  = _clean(_row_val(row, Col.WPS_NO))
        wps_prc = _normalize_process(_row_val(row, Col.WPS_PROCESS))
        repair  = _is_repair_wps(wps_no)

        f1 = self._c1_schedule(row)
        if f1: flags.append(f1)

        f2 = self._c2_wps_process(row, wps_no, wps_prc, repair)
        if f2: flags.append(f2)

        f3 = self._c3_thickness(row, wps_no)
        if f3: flags.append(f3)

        f4 = self._c4_groove(row, wps_no, repair)
        if f4: flags.append(f4)

        # Check 5(NDT Cat A/B -> TR-FC-G03)는 현업 확인(2026-08-10, §11-2)으로
        # **규칙 자체가 불필요**하다고 확인돼 제거했다. 그에 딸린 Check 7(중복 2+5)도
        # 성립하지 않으므로 함께 뺐다.
        #
        # 번호 5·7은 **재사용하지 않는다** — 검토 기록 키가 `…|Check No`라서
        # 재사용하면 과거 검토 의견이 무관한 항목에 붙는다(§11-7과 같은 사고).
        # 두 번호의 색/이름 정의는 남겨 둔다. 이미 붙은 라벨 426건이 화면에서
        # 읽히려면 필요하다.
        flags.extend(self._c6_welders(row, wps_prc))

        # 6과 같은 용접사 열을 본다 — 6은 «자격이 있는가», 7은 «그 자격이 아직
        # 살아 있는가»다. 만료일 파일이 없으면 7은 한 행도 판정하지 않는다.
        flags.extend(self._c7_welder_expired(row))

        f8 = self._c8_tr_fc_g03(row, wps_no)
        if f8: flags.append(f8)

        f9 = self._c9_tr_smfc_g01(row, wps_no)
        if f9: flags.append(f9)

        # 두께 플래그는 이제 공통 Check 3일 수도, 프로젝트 규칙(101~199)일 수도
        # 있다. `f3.check_no == 3`으로 좁히면 프로젝트 규칙이 선점한 행에서
        # **Check 10이 조용히 0건**이 된다.
        if f3 and f8:
            flags.append(Flag(10, Col.THICKNESS1, "Black", "복합 오류: 두께 범위 초과 + TR-FC-G03 특수 동시 발생",
                              expected=f"{f3.expected} / {f8.expected}",
                              actual=f"{f3.actual} / {f8.actual}"))

        f11 = self._c11_material_not_allowed(row, wps_no, repair)
        if f11: flags.append(f11)

        f12 = self._c12_tubular_dia_review(row)
        if f12: flags.append(f12)

        f18 = self._c18_consumable_lot(row)
        if f18: flags.append(f18)

        flags.extend(self._c16_ndt_extent(row))

        f17 = self._c17_vt_missing(row)
        if f17: flags.append(f17)

        f21 = self._c21_mixed_consumables(row, wps_prc)
        if f21: flags.append(f21)

        f22 = self._c22_ndt_report_pending(row)
        if f22: flags.append(f22)

        f23 = self._c23_repair_wps_mark(row, wps_no)
        if f23: flags.append(f23)

        f24 = self._c24_tky_wps(row, wps_no)
        if f24: flags.append(f24)

        f25 = self._c25_q01_joint_type(row, wps_no)
        if f25: flags.append(f25)

        f27 = self._c27_dissimilar_grade(row, wps_no)
        if f27: flags.append(f27)

        flags.extend(self._project_row_rules(row, wps_no))

        f19 = self._c19_wps_process_welder(row, wps_prc)
        if f19: flags.append(f19)

        f20 = self._c20_api_groove_process(row, wps_prc)
        if f20: flags.append(f20)

        # 프로젝트 세팅에서 끈 항목은 **판정하지 않는다.** 화면 필터가 아니라
        # 판정 설정이라, 끄면 플래그가 애초에 생기지 않고 결함/클린 행수도
        # 그 기준으로 다시 계산된다. 그래서 바꾸면 재검증이 필요하다.
        return [f for f in flags if self._rule_on(f.check_no)]

    def _project_rules(self) -> list:
        """이 회차가 쓰는 프로젝트 규칙. 행마다 파일을 읽지 않도록 한 번만."""
        if self._rules is None:
            self._rules, self._rule_problems = project_checks.parse(
                rule_catalog.active_checks())
        return self._rules

    def _check_name(self, check_id: str) -> str:
        """공통이면 `CHECK_NAMES`, 프로젝트면 **규칙 정의의 이름**.

        공통 표에만 물으면 프로젝트 규칙의 이름이 **빈 문자열로 나간다** —
        결과 표·Excel·부서 메일에 이름 없는 결함이 실린다. 예외는 나지 않는다.
        """
        cid = str(check_id).strip()
        name = check_name(cid)
        if name:
            return name
        for r in (self._rules or []):
            if r.no == cid:
                return r.name
        return ""

    def _rule_on(self, check_no: int | str) -> bool:
        """켜져 있는 항목인가. 행마다 파일을 읽지 않도록 한 번만 읽어 둔다.

        **키는 문자열이다.** `Flag`가 정규화하므로 여기서도 맞춰야 한다 —
        정수로 물으면 `{"3": True}`에서 못 찾아 «설정에 없으면 켬»으로 빠진다.
        꺼 둔 항목이 조용히 다시 켜진다.
        """
        if self._enabled is None:
            self._enabled = rule_catalog.enabled_map()
        return self._enabled.get(str(check_no).strip(), True)

    def _c19_wps_process_welder(self, row: tuple, wps_prc: str) -> Optional[Flag]:
        """AK열 WPS Process 자격자가 그 이음에 **최소 한 명**은 있었는가.

        Check 6과 축이 다르다:

            Check 6   각 용접사가 «자기가 시공한 프로세스»(AQ/AS/AU/AW) 자격을
                      가졌는가 — 개인의 서류 문제
            Check 19  «WPS가 요구하는 프로세스»(AK)를 아는 사람이 그 이음에
                      있었는가 — 이음의 시공 적합성

        용접사는 AP~AW에 최대 4명까지 들어간다. 넷 중 **아무도** WPS Process
        자격이 없을 때만 결함이다. 전원에게 요구하면 보조 용접사까지 걸려
        실제로 시정할 수 없는 지적이 대량으로 나온다.

        SMFC 자격자의 FCAW 시공은 허용한다(`_process_covers`) — Check 6과 같은
        기준을 써야 «6에서는 통과인데 19에서는 결함»이 되지 않는다.
        """
        if not wps_prc:
            return None
        pairs = [Col.WELDER1_NO, Col.WELDER2_NO, Col.WELDER3_NO, Col.WELDER4_NO]
        nos = [_clean(_row_val(row, c)) for c in pairs]
        nos = [n for n in nos if n]
        if not nos:
            return None            # 용접사가 아예 없는 행은 Check 6이 볼 몫이 아니다
        held: set[str] = set()
        known = False
        for no in nos:
            qual = self.loader.welder_qual.get(no)
            if qual is None:
                continue           # 자격 DB에 없는 사람은 판단 근거가 없다 -> Check 6
            known = True
            held |= set(qual['process'])
            if any(_process_covers(q, wps_prc) for q in qual['process']):
                return None
        if not known:
            # 넷 다 자격 DB에 없으면 «자격이 없다»가 아니라 «알 수 없다»이다.
            # 그건 Check 6이 이미 «자격 DB 미등록»으로 지적한다. 여기서 또
            # 지적하면 같은 원인에 플래그가 둘 붙는다.
            return None
        return Flag(19, Col.WPS_PROCESS, "Maroon",
                    f"WPS Process '{wps_prc}' 자격자 미투입 "
                    f"(용접사 {','.join(nos)} 보유: {','.join(sorted(held)) or '없음'})",
                    expected=f"{wps_prc} 자격 보유자 1명 이상 투입",
                    actual=f"투입 {len(nos)}명 보유자격: {','.join(sorted(held)) or '없음'}")

    def _c20_api_groove_process(self, row: tuple, wps_prc: str) -> Optional[Flag]:
        """API 재질은 Groove에 따라 허용 프로세스가 다르다.

        현업 확인(2026-08-11 · 2026-08-13 보완): **M열 또는 N열** 재질이 `API`로
        시작하면
          - R열 Groove가 **FL 또는 FW** -> FCAW 적용
          - 그 외 Groove(SB 등)         -> **SMFC 또는 GTFC** 적용
        예를 들어 SB에 FCAW를 쓰면 결함이다.

        2026-08-13에 둘을 넓혔다:
          · `FW`(Fillet Weld 표기 변형)를 FL과 같이 본다. 실데이터에 FW가 0건이라
            지금은 결과가 안 바뀌지만, 들어오는 순간 SMFC를 요구해 오탐이 된다.
          · 재질을 **M·N 둘 다** 본다. 한쪽만 API인 이종재 이음이 빠져 있었다.

        실데이터 6건(SB/SMFC 4 · FL/FCAW 2)은 전부 규칙에 맞아 위반 0건이다.
        지금 안 걸린다고 지울 검사가 아니다 — 걸리는 순간이 문제다.
        """
        if not wps_prc:
            return None
        mats = [_clean(_row_val(row, c)).upper() for c in (Col.MATERIAL1, Col.MATERIAL2)]
        api = next((m for m in mats if m.startswith("API")), None)
        if api is None:
            return None
        self._scope["20"] += 1
        mat = api
        groove = _clean(_row_val(row, Col.GROOVE)).upper()
        if not groove:
            return None
        allowed = (["FCAW"] if groove in ("FL", "FW") else ["SMFC", "GTFC"])
        if any(a in wps_prc for a in allowed):
            return None
        return Flag(20, Col.WPS_PROCESS, "Indigo",
                    f"API 재질 Groove '{groove}'에는 {'/'.join(allowed)} 적용 "
                    f"(입력 Process={wps_prc}, 재질={mat})",
                    expected=f"{'/'.join(allowed)} (API 재질 · Groove={groove})",
                    actual=f"{wps_prc}")

    def _c18_consumable_lot(self, row: tuple) -> Optional[Flag]:
        """용접봉 Lot 번호(AL열)를 본다 — **기재됐는가, 그리고 승인된 것인가.**

        ## 원래 취지로 돌아온 검사다

        처음 의도는 «WPS가 지정한 용접봉과 다른 것을 썼는가»였는데, **Lot 번호와
        대조할 목록이 없어서** «누락만 본다»로 범위를 줄여 두었다. 현업이 승인
        용접봉 리스트를 확보해(2026-08-20) 그 대조가 가능해졌다.

        ## 왜 번호를 나누지 않았나

        잠깐 Check 28로 따로 두었다가 합쳤다. 실측이 결정했다 —
        **38만 행에서 기재 누락이 2건**이다. 그 2건을 위해 번호를 하나 더 쓰면
        화면·문서·검토 기록이 둘로 갈라지는데, 정작 사람이 보는 것은 «용접봉이
        제대로인가» 하나다. (Check 28은 결번으로 남긴다 — 번호를 재사용하면
        검토 기록 키가 과거 의견을 무관한 항목에 붙인다.)

        ## 두 가지를 본다

            AL이 비었는가          -> 기재 누락
            AL의 각 Lot이 승인 목록에 있는가 -> 미승인

        **둘이 동시에 걸리지 않는다.** 비어 있으면 대조할 것이 없다.

        ## 승인 목록이 없으면 «미승인» 쪽은 돌지 않는다

        그때 이 검사는 «기재 누락»만 본다. 그 상태의 0건은 «승인된 것만 썼다»가
        아니다 — `run_verification()`이 `rule_health`에 경고를 남기고, 업로드
        화면도 「한 행도 대조하지 않습니다」라고 말한다. 그 두 자리가 없으면
        목록을 안 올린 프로젝트가 «용접봉 문제 없음»으로 읽힌다.

        ## 쉼표 다중값

        혼합 프로세스는 재료를 둘 쓴다. 실데이터에 `F902A5C5A7,10005625BB23EA2`와
        **쉼표 뒤에 공백이 있는** `F902A12L4H4, 10006714BB24KA1`이 둘 다 있다.
        나눈 뒤 반드시 `strip()` 해야 한다 — 안 하면 공백이 붙은 쪽이 «목록에
        없다»로 걸려 오탐이 된다. 나누는 방식은 Check 21과 같아야 한다.
        """
        # 켬/끔 스위치는 `rule_catalog` **하나뿐**이다(`_check_row()` 끝 게이트).
        # 예전에는 `wps_rules.check18_enabled()`가 두 번째 스위치였고, JSON이 UI를
        # 이겼다 — '프로젝트 세팅'에서 켰는데 아무 일도 안 일어나고, 결과의
        # `rules` 스냅샷에는 «18 = 켬»으로 기록되어 **결과가 거짓말을 했다.**
        lot = _clean(_row_val(row, Col.CONSUMABLE_LOT))
        if not lot:
            return Flag(18, Col.CONSUMABLE_LOT, "Orange",
                        "용접봉 Lot 미기재 (AL열 공란)",
                        expected="용접봉 Lot 번호 기재 필요",
                        actual="공란")

        approved = self.loader.consumable_lots
        if not approved:
            return None                  # 대조할 목록이 없다 (rule_health가 알린다)
        parts = [p.strip().strip('"\'') for p in lot.split(',')]
        parts = [p for p in parts if p]
        unknown = [p for p in parts if p.upper() not in approved]
        if not unknown:
            return None
        return Flag(18, Col.CONSUMABLE_LOT, "Orange",
                    f"승인 목록에 없는 용접봉 Lot ({', '.join(unknown)})",
                    expected=f"승인 용접봉 리스트에 등재된 Lot (등재 {len(approved)}종)",
                    actual=f"AL열='{lot}'" +
                           (f" 중 {len(unknown)}종 미승인" if len(parts) > 1 else ""))

    def _project_row_rules(self, row: tuple, wps_no: str) -> list[Flag]:
        """행 단위 프로젝트 규칙(`forbid` · `require_wps`).

        두께 규칙(`thickness_range`)과 평가 지점이 다르다 — 그쪽은 `_c3_side()`가
        공통 Check 3을 **선점**하며 부르고, 여기는 대체할 공통 검사가 없어 그냥
        추가 판정이다. 그래서 `_suppressed`를 건드리지 않는다.

        `_rule_matched`는 갱신한다 — «이 규칙이 몇 행에 걸렸는가»는 0행 경고
        (`rule_health`)의 근거이고, 통과한 행도 세어야 «대상이 있었는데 전부
        통과»와 «대상이 아예 없다»를 구분할 수 있다.
        """
        rules = self._project_rules()
        if not rules or not wps_no:
            return []
        materials = [_clean(_row_val(row, c)) for c in (Col.MATERIAL1, Col.MATERIAL2)]
        ndt_cat = _clean(_row_val(row, Col.NDT_CAT))
        out: list[Flag] = []
        for r in project_checks.row_rules(rules, materials, wps_no, ndt_cat):
            if not self._rule_on(r.no):
                continue
            self._rule_matched[r.no] = self._rule_matched.get(r.no, 0) + 1
            if r.judge_row(wps_no):
                continue
            if r.kind == "require_wps":
                msg = (f"{r.name}: WPS에 '{r.required_wps_text}'가 있어야 함 "
                       f"(WPS={wps_no})")
                exp, act = f"WPS에 '{r.required_wps_text}' 포함", f"'{wps_no}'"
            else:
                msg = f"{r.name}: 이 조합은 사용할 수 없음 (WPS={wps_no})"
                exp, act = f"{r.name} 대상이 아닐 것", f"WPS={wps_no}, 재질={'/'.join(m for m in materials if m)}"
            out.append(Flag(r.no, Col.WPS_NO, r.color or "Blue", msg,
                            expected=exp, actual=act))
        return out

    def _c21_mixed_consumables(self, row: tuple, wps_prc: str) -> Optional[Flag]:
        """혼합 프로세스 이음은 용접재료를 **둘** 적어야 한다 (AL열).

        GTFC·SMFC는 한 이음에서 두 프로세스를 쓰므로 소모품도 둘이다. AL열에
        쉼표로 구분해 둘을 적는다(예: `F902A4L5D7, K71TG-1`).

        Check 18과 축이 다르다 — 18은 «비었는가», 21은 «몇 개인가»다. AL이 아예
        비면 18이 지적하므로 여기서는 값이 있을 때만 개수를 센다. 둘 다 걸면
        같은 원인에 플래그가 둘 붙는다.

        실데이터: 혼합 프로세스 40행 중 **2행**이 재료 하나뿐이다
        (`TR-GTFC-G01`, AL=`F902A4L5D7`).
        """
        if not _is_mixed_process(wps_prc):
            return None
        self._scope["21"] += 1
        lot = _clean(_row_val(row, Col.CONSUMABLE_LOT))
        if not lot:
            return None                      # 공란은 Check 18의 몫이다
        # 쉼표로 나눈 뒤 빈 조각을 버린다. 따옴표는 엑셀 표기라 벗겨 낸다.
        parts = [p.strip().strip('"\'') for p in lot.split(',')]
        parts = [p for p in parts if p]
        if len(parts) >= 2:
            return None
        return Flag(21, Col.CONSUMABLE_LOT, "Rose",
                    f"혼합 프로세스({wps_prc})인데 용접재료가 {len(parts)}종 "
                    f"(AL열='{lot}')",
                    expected=f"용접재료 2종 (쉼표로 구분) — {wps_prc}는 프로세스가 둘",
                    actual=f"{len(parts)}종: {lot}")

    # NDT 종류별 (요구 요율 열, 리포트 번호 열, 이름). 리포트는 수행일 바로 오른쪽이다.
    _NDT_REPORT_COLS = (
        (Col.NDT_EXT_RT, Col.RT_REPORT, "RT"),
        (Col.NDT_EXT_UT, Col.UT_REPORT, "UT"),
        (Col.NDT_EXT_MT, Col.MT_REPORT, "MT"),
        (Col.NDT_EXT_PT, Col.PT_REPORT, "PT"),
    )

    def _c22_ndt_report_pending(self, row: tuple) -> Optional[Flag]:
        """NDT 100% 구간인데 리포트 번호가 확정되지 않았다.

        현업 확인(2026-08-13): 요구 요율이 **100**인 구간은 전수 검사라 리포트가
        반드시 나와야 한다. 그런데 계획/신청일(BD)까지 잡혀 있으면서
          · 리포트 번호가 **공란**이거나
          · 번호가 **`*`로 끝나면**(예: `MSOM03084*` — 촬영하지 않은 수량 표기)
        그 구간은 «검사를 걸어 놓고 결과가 없는» 상태다.

        **요율이 100인 구간만 본다.** 20%·10% 구간의 별표는 정상이다 — 애초에
        전수를 찍지 않기 때문이다. 그 구간의 실제 촬영율은 Check 26이 묶음
        단위로 본다.

        실데이터 위반 0건이다. 100% 구간에는 별표가 하나도 없다 —
        **«문제가 없다»가 맞는 쪽**이고, 100%가 아닌 구간에는 248행이 있다.
        """
        if not _clean(_row_val(row, Col.NDT_PLAN_DATE)):
            return None                      # 계획 자체가 없으면 볼 것이 없다
        for ext_col, rep_col, tag in self._NDT_REPORT_COLS:
            if _clean(_row_val(row, ext_col)) != "100":
                continue
            self._scope["22"] += 1
            rep = _clean(_row_val(row, rep_col))
            if rep and not rep.endswith("*"):
                continue
            why = "공란" if not rep else f"미촬영 표기 '{rep}'"
            return Flag(22, rep_col, "Olive",
                        f"{tag} 100% 구간인데 리포트 번호가 확정되지 않음 ({why})",
                        expected=f"{tag} 리포트 번호 (100% 구간은 전수 검사)",
                        actual=why)
        return None

    def _c23_repair_wps_mark(self, row: tuple, wps_no: str) -> Optional[Flag]:
        """수리 시공(E열)인데 WPS가 수리용이 아니다.

        E열(헤더 `RE`)에 값이 있으면 수리 시공이다. 값은 `RE`·`R1`·`U1`·`M1`처럼
        다양하고 **비어 있지 않기만 하면 해당**이다(현업 확인 2026-08-13).
        그때 WPS No는 끝에서 **세 번째 문자가 `R`**이어야 한다(예: `TR-FC-R01`).

        `_is_repair_wps()`(접두사 기반)와 축이 다르다:

            _is_repair_wps   그 WPS가 수리용인가        -> Check 2·4·11을 건너뛴다
            Check 23         수리인데 수리 WPS를 썼는가  -> 기재 자체를 지적한다

        접두사 판정은 «어떤 WPS가 수리용인가»를 프로젝트 설정으로 정하고, 여기는
        «이 행이 수리인가»를 원본 표기로 본다. 둘이 갈라지면 이 검사가 드러낸다.

        실데이터: E열에 값이 있는 판정 대상 **3행**이 전부 `TR-FC-G01`(끝 세 글자
        `G01`)이라 3건 위반이다.
        """
        mark = _clean(_row_val(row, Col.REPAIR_MARK))
        if not mark or not wps_no:
            return None
        self._scope["23"] += 1
        third_last = wps_no[-3] if len(wps_no) >= 3 else ""
        if third_last.upper() == "R":
            return None
        return Flag(23, Col.WPS_NO, "Gray",
                    f"수리 시공(E열='{mark}')인데 수리 WPS가 아님 (WPS={wps_no})",
                    expected="WPS No 끝에서 세 번째 문자가 'R' (예: TR-FC-R01)",
                    actual=f"'{wps_no}' (끝 세 번째='{third_last or '없음'}')")

    def _c24_tky_wps(self, row: tuple, wps_no: str) -> Optional[Flag]:
        """TKY 이음(Q열 `TT`)은 전용 WPS를 써야 한다.

        현업 확인(2026-08-13): Q열이 `TT`면 TKY 이음(관재 교차부)이라 WPS의
        **마지막 구분자 뒤가 `GK`로 시작**해야 한다 — `TR-SMFC-GK01` 형태다.

        마지막 토큰만 본다. 앞의 프로세스 표기(`FC`·`SMFC`·`GTFC`)는 프로젝트마다
        다르고, 여기서 볼 것은 «이음 종류»를 나타내는 끝자리이기 때문이다.

        실데이터: `TT` 8행이 전부 `TR-SMFC-G01`(마지막 토큰 `G01`)이라 8건 위반이다.
        """
        if _clean(_row_val(row, Col.JOINT_TYPE)).upper() != "TT":
            return None
        if not wps_no:
            return None
        self._scope["24"] += 1
        last = wps_no.replace("_", "-").split("-")[-1].strip().upper()
        if last.startswith("GK"):
            return None
        return Flag(24, Col.WPS_NO, "Cyan",
                    f"TKY 이음(Q열='TT')에 전용 WPS 미적용 (WPS={wps_no})",
                    expected="WPS 마지막 구분이 GK로 시작 (예: TR-SMFC-GK01)",
                    actual=f"'{wps_no}' (마지막 구분='{last}')")

    def _c25_q01_joint_type(self, row: tuple, wps_no: str) -> Optional[Flag]:
        """`Q01` WPS는 Q열 Type이 `B`인 이음에만 쓴다.

        현업 확인(2026-08-13). Q열 분포는 `T` 9,626 · `B` 361 · `TT` 8이다.

        실데이터: `Q01`로 끝나는 WPS가 0건이라 위반 0건이다 —
        **«대조할 대상이 0건»**이지 «문제가 없다»가 아니다.
        """
        if not wps_no:
            return None
        last = wps_no.replace("_", "-").split("-")[-1].strip().upper()
        if last != "Q01":
            return None
        self._scope["25"] += 1
        jt = _clean(_row_val(row, Col.JOINT_TYPE)).upper()
        if not jt or jt == "B":
            return None
        return Flag(25, Col.JOINT_TYPE, "Teal",
                    f"Q01 WPS는 Type 'B'만 가능 (Q열='{jt}', WPS={wps_no})",
                    expected="Q열 Type = B",
                    actual=f"'{jt}'")

    def _c27_dissimilar_grade(self, row: tuple, wps_no: str) -> Optional[Flag]:
        """이종재 이음은 **상위 그레이드** 재질 기준으로 WPS를 골라야 한다.

        ## [보류] — 등급표가 아직 없다

        현업 확인(2026-08-13): 지금은 **두 가지만** 비교할 수 있다.

            · 재질명 끝의 시험온도 — 낮을수록 상위 (`-40` > `-20`)
            · S355 < S420

        그 외 조합(`ASTM-A36` + `SM355A` 등)은 상하를 판단할 근거가 없다.
        **전체 등급표는 현업이 별도로 만들어 주기로 했고, 받으면 여기를 채운다.**
        그때까지는 판단 가능한 조합만 보고 나머지는 조용히 지나간다 — 근거 없이
        찍으면 오탐이 되고, 오탐은 «이 검사는 못 믿는다»로 이어진다.

        실데이터: 재질 2종 조합 20건이 **전부** 온도 표기도 S355/S420도 없어
        위반 0건이다. 등급표가 오기 전까지는 이 검사가 도는 대상이 0건이다.
        """
        raw1 = _clean(_row_val(row, Col.MATERIAL1))
        raw2 = _clean(_row_val(row, Col.MATERIAL2))
        if not raw1 or not raw2 or raw1 == raw2 or not wps_no:
            return None
        hi = _higher_material_grade(raw1, raw2)
        if hi is None:
            return None                      # 등급표가 오기 전까지 판단 불가
        self._scope["27"] += 1
        wps = self.loader.wps_table.get(wps_no)
        if not wps:
            return None                      # WPS를 모르면 Check 2의 몫이다
        # 상위 그레이드 재질이 이 WPS의 허용 재질에 들어 있는가
        hi_key = _get_material_key(hi)
        if hi_key is None:
            return None
        base_metals = [m.get('base_metal', '') for m in (wps.get('materials') or [])]
        if not base_metals:
            return None
        f = self._c11_check_one_material(wps, wps_no, hi_key, hi,
                                         base_metals, Col.MATERIAL1, 'M')
        if f is None:
            return None
        lo = raw2 if hi == raw1 else raw1
        return Flag(27, Col.MATERIAL1, "Purple",
                    f"이종재 이음의 상위 그레이드({hi})가 WPS 허용 재질이 아님 "
                    f"(하위={lo}, WPS={wps_no})",
                    expected=f"상위 그레이드 '{hi}'를 허용하는 WPS",
                    actual=f"{wps_no} (상위={hi}, 하위={lo})")

    # ── 검사 이행 여부 (Check 16·17) ─────────────────────────────────────────
    #
    # Check 1~12는 «기재된 값이 규칙에 맞는가»를 본다. 16·17은 성격이 다르다 —
    # **«해야 할 검사를 했는가»**를 본다. 원본 매크로에 없던 축이고, 실제로
    # 놓치면 선급 검사에서 걸리는 쪽은 이쪽이다.
    #
    # 둘 다 유예기간(_grace_days)을 둔다. 용접 직후 검사가 아직 안 끝난 것은
    # 정상이므로, 유예 없이 «공란=미수행»으로 보면 최근 용접분이 통째로 결함이
    # 되어 지표가 못 쓰게 된다.

    def _overdue_days(self, row: tuple) -> Optional[int]:
        """기준일까지 며칠 지났는지. 유예 안이거나 판단 불가면 None."""
        if self._ref_date is None:
            return None
        weld_dt = _parse_date(_row_val(row, Col.WELD_DATE))
        if weld_dt is None:
            return None                  # 용접일이 없으면 Check 1의 영역이다
        days = (self._ref_date - weld_dt).days
        return days if days >= self._grace_days else None

    def _c16_ndt_extent(self, row: tuple) -> list[Flag]:
        """NDT Extent(S~V열)에 비율이 잡혀 있는데 해당 검사 수행일이 공란인 경우.

        Extent는 «이 조인트에 요구되는 NDT 비율(%)»이다. 값이 있다는 것은 그 검사가
        요구된다는 뜻이므로, 대응하는 NDT Inspection Result 날짜(BM/BP/BS/BV)가
        비어 있으면 요구된 검사를 수행하지 않은 것이다.

        **숫자로 읽히는 값만 요구로 본다.** 실데이터의 RT Extent 열에는 담당자가
        메모로 적어 넣은 문자열이 1건 섞여 있었다("리페어WPS구분?"). 공란이 아니라는
        이유로 요구로 세면 오탐이 된다.

        실데이터 기준 0건이다(UT 1,085/1,085, MT 5,516/5,516 전량 수행). 지금 걸리는
        게 없다고 지울 검사가 아니다 — 이건 «앞으로 빠지면 잡는» 쪽이다.
        """
        days = self._overdue_days(row)
        if days is None:
            return []
        flags: list[Flag] = []
        for name, ext_col, date_col in _NDT_EXTENT_PAIRS:
            pct = _to_float(_row_val(row, ext_col))
            if pct is None or pct <= 0:
                continue
            self._scope["16"] += 1
            if _clean(_row_val(row, date_col)):
                continue
            flags.append(Flag(16, date_col, "Olive",
                              f"NDT 미수행: {name} Extent={_clean(_row_val(row, ext_col))}% 요구 "
                              f"— 수행일 공란 (용접 후 {days}일 경과)",
                              expected=f"{name} 수행일 기재 필요 (요구 Extent {pct:g}%)",
                              actual=f"{name} 수행일 공란"))
        return flags

    def _c17_vt_missing(self, row: tuple) -> Optional[Flag]:
        """육안검사(VT) 수행일(BI열)이 공란인 경우.

        VT는 Extent 열이 없다 — **모든 용접부에 요구되는 기본 검사**라 별도로 비율을
        지정하지 않기 때문이다. 그래서 «용접했으면 VT는 있어야 한다»가 판정 규칙이다.

        실데이터: 판정대상 5,516행 중 VT 공란 265행, 그중 유예 30일을 넘긴 것이 99건.
        """
        days = self._overdue_days(row)
        if days is None:
            return None                      # 유예 안이거나 용접일이 없다
        self._scope["17"] += 1
        if _clean(_row_val(row, Col.VT_DATE)):
            return None
        return Flag(17, Col.VT_DATE, "Navy",
                    f"VT 미수행: 용접 후 {days}일 경과했으나 육안검사일 공란",
                    expected=f"육안검사(VT) 수행일 기재 (유예 {self._grace_days}일)",
                    actual="VT 수행일 공란")

    def _c1_schedule(self, row: tuple) -> Optional[Flag]:
        weld_dt = _parse_date(_row_val(row, Col.WELD_DATE))
        ndt_dt  = _parse_date(_row_val(row, Col.NDT_DATE))
        if weld_dt and ndt_dt and ndt_dt < weld_dt:
            return Flag(1, Col.NDT_DATE, "Red",
                        f"일정오류: 용접일({weld_dt}) > NDT계획일({ndt_dt})",
                        expected=f"NDT계획일 ≥ 용접일({weld_dt})",
                        actual=f"NDT계획일={ndt_dt}")
        if weld_dt is None and ndt_dt is not None:
            return Flag(1, Col.WELD_DATE, "Red",
                        f"일정오류: 용접일 미기재 (NDT계획일={ndt_dt} 설정됨)",
                        expected="용접일 기재 필요",
                        actual="용접일 미기재")
        return None

    def _c2_wps_process(self, row: tuple, wps_no: str, wps_prc: str,
                        repair: bool) -> Optional[Flag]:
        if not wps_no or repair:
            return None
        wps = self.loader.wps_table.get(wps_no)
        if wps is None:
            return Flag(2, Col.WPS_NO, "Green", f"WPS '{wps_no}' WPS List에 없음",
                        expected="WPS List에 등록된 WPS No",
                        actual=f"'{wps_no}' (WPS List에 없음)")
        reg_prc = wps['process']
        if wps_prc and reg_prc and wps_prc != reg_prc:
            if not (('SMFC' in wps_prc and 'SMFC' in reg_prc) or
                    ('GTFC' in wps_prc and 'GTFC' in reg_prc) or
                    ('FCSA' in wps_prc and 'FCSA' in reg_prc)):
                return Flag(2, Col.WPS_NO, "Green",
                            f"Process 불일치: 입력={wps_prc}, 등록={reg_prc} (WPS={wps_no})",
                            expected=f"{reg_prc} (WPS={wps_no} 등록 프로세스)",
                            actual=f"{wps_prc} (입력값)")
        return None

    def _c3_thickness(self, row: tuple, wps_no: str) -> Optional[Flag]:
        if not wps_no:
            return None
        wps = self.loader.wps_table.get(wps_no)
        if not wps:
            return None
        thk1 = _to_float(_row_val(row, Col.THICKNESS1))
        if thk1 is None:
            return None
        raw1 = _clean(_row_val(row, Col.MATERIAL1))
        if _is_tubular_material(raw1):
            # 관재는 J열 두께가 아니라 I열 Out Dia 규격이 기준이므로 여기서 판정하지
            # 않는다. 대신 Check 12가 '수동 확인 필요'로 표시한다.
            return None

        # K열(두께2)이 채워진 행은 이음부 반대쪽 부재도 있다는 뜻이다.
        # N열(재질2)이 비어 있으면 이음 반대쪽도 J와 같은 모재로 본다.
        thk2 = _to_float(_row_val(row, Col.THICKNESS2))
        raw2 = _clean(_row_val(row, Col.MATERIAL2))

        # ── 이종재 이음은 «낮은 두께»만 본다 (현업 확인 2026-08-13) ──────────
        #
        # M·N 재질이 **서로 다르면** WPS를 상위 그레이드 재질과 **낮은 두께**
        # 기준으로 고른다. 그래서 높은 쪽 두께가 WPS 범위를 벗어나도 부적합이
        # 아니다 — 실측 12행이 여기 해당한다(전부 `ASTM-A36` 20~15T 정상 +
        # `SM355A` 25T 범위 밖).
        #
        # **같은 재질이면 지금 그대로 J·K를 각각 본다.** ASME IX QW-451의 두께
        # 자격범위는 이음을 구성하는 각 부재에 대해 성립해야 하고, 감사에서
        # «J는 정상인데 K만 초과» 8건을 실제로 찾아낸 판정이 이것이다.
        # 범위를 이종재로 좁힌 것은 현업이 «그때는 낮은 쪽으로 WPS를 고른다»고
        # 확인해 준 만큼이다 — 더 넓히면 그 8건 유형을 통째로 놓친다.
        # **표기 흔들림은 이종재가 아니다.** `ASTM-A36`과 `ASTMA36`은 같은 강재인데
        # 문자열만 다르다 — 그대로 비교하면 이종재로 보고 낮은 두께만 판정해서
        # **K열 판정이 조용히 사라진다.** 하이픈·공백·대소문자를 지우고 본다.
        #
        # 재질 «키»(`_get_material_key`)로 비교하면 안 된다. 그건 두께 범위를 고르는
        # 키라 `NV-E36`(-40℃)과 `NV-DW36`(-20℃)이 둘 다 `E36`으로 뭉개진다 —
        # 그 둘은 등급이 달라 **진짜 이종재**다(실데이터 4행).
        if (thk2 is not None and raw2
                and _material_token(raw2) != _material_token(raw1)
                and not _is_tubular_material(raw2)):
            lo_thk, lo_raw, lo_lbl, lo_col = min(
                ((thk1, raw1, 'J', Col.THICKNESS1), (thk2, raw2, 'K', Col.THICKNESS2)),
                key=lambda s: s[0])
            return self._c3_side(wps, wps_no, lo_thk, lo_raw, lo_lbl, lo_col)

        f1 = self._c3_side(wps, wps_no, thk1, raw1, 'J', Col.THICKNESS1)
        if f1:
            return f1
        if thk2 is None:
            return None
        raw2 = raw2 or raw1
        if _is_tubular_material(raw2):
            return None
        return self._c3_side(wps, wps_no, thk2, raw2, 'K', Col.THICKNESS2)

    def _c3_side(self, wps: dict, wps_no: str, thk: float, raw_material: str,
                 side_label: str, col: int) -> Optional[Flag]:
        """이 side를 누가 판정하는가 — 프로젝트 규칙이 먼저 묻는다.

        **선점을 재질 키 조회보다 앞에 둔다.** 프로젝트 규칙은 원문 표기를 보고
        (`S355KT-40`처럼 등급이 재질명에 붙어 온다) 공통 판정은 표준 키를 본다.
        순서를 반대로 하면 **매핑표에 없는 프로젝트 재질이 선점에 닿지도 못하고**
        조용히 판정에서 빠진다 — 실제로 `S355KT-40`·`S355KL-0` 둘 다
        `_get_material_key()`가 None을 준다.
        """
        rule = project_checks.claim_thickness(self._project_rules(),
                                              raw_material, wps_no)
        if rule is not None and self._rule_on(rule.no):
            self._rule_matched[rule.no] = self._rule_matched.get(rule.no, 0) + 1
            for common in rule.overrides:
                k = (rule.no, common)
                self._suppressed[k] = self._suppressed.get(k, 0) + 1
            if rule.judge_thickness(thk):
                return None
            return Flag(rule.no, col, rule.color,
                        f"두께범위 초과({side_label}열): {thk}mm, "
                        f"{rule.name} 허용 {rule.range_text}mm "
                        f"(공통 Check 3 대신 판정)",
                        expected=f"{rule.range_text}mm (프로젝트 규칙 · {rule.name}, "
                                 f"{side_label}열)",
                        actual=f"{thk}mm")

        # 선점이 없으면 지금까지와 똑같다.
        # 매핑표에 없는 재질은 'E36'으로 임의 폴백하면 무관한 재질에 느슨한 범위가
        # 잘못 적용될 수 있어(감사 결과) 검사하지 않고 건너뛴다.
        mat_key = _get_material_key(raw_material)
        if mat_key is None:
            return None
        return self._c3_thickness_side(wps, wps_no, thk, mat_key,
                                       side_label, col, raw_material)

    def _c3_thickness_side(self, wps: dict, wps_no: str, thk: float, mat_key: str,
                           side_label: str, col: int,
                           raw_material: str = "") -> Optional[Flag]:
        # 프로젝트 규칙 선점은 `_c3_side()`가 이미 물었다. 여기는 «선점이 없을
        # 때»만 도달하므로 WPS List G열 판정만 한다.
        for mat_entry in wps.get('materials', []):
            thk_range_text = mat_entry.get('thk_range', '')
            base_metal_text = mat_entry.get('base_metal', '')
            if not thk_range_text:
                continue

            # 1) G열 셀 내부를 "재질별 항목"으로 분리 시도(실제 셀 구조 반영).
            #    성공하면 이 재질에 해당하는 항목의 범위로만 정확히 판정한다 —
            #    예: TR-FC-G01에서 EO420은 25~38mm 전용 범위로만 검사되고,
            #    "~E36"(3~50) 같은 다른 재질의 범위와 섞이지 않는다.
            parsed = _parse_material_thickness_entries(thk_range_text)
            matched = [(lbl, rng) for lbl, rng in parsed if _label_matches_material(mat_key, lbl)]
            if matched:
                # §11-1은 현업 확인(2026-08-10)으로 종결됐다 — **G열의 값이 맞다.**
                # 한동안 PQR 승인범위(12.5~50)로 덮어쓰고 있었는데, WPS가 PQR보다
                # 좁게 제한한 경우였고 그건 표준상 허용된다(WPS 범위 ⊆ PQR 범위).
                # 오버라이드를 걷어냈으므로 여기서는 G열 그대로 판정한다.
                if not any(_thickness_in_range(thk, rng) for _, rng in matched):
                    allowed = ', '.join(f"{lbl}:{rng.strip()}" for lbl, rng in matched)
                    return Flag(3, col, "Blue",
                                f"두께범위 초과({side_label}열): {thk}mm, WPS={wps_no}, 재질={mat_key}, 허용범위={allowed[:80]}",
                                expected=f"{allowed[:80]}mm (WPS={wps_no}, 재질={mat_key}, {side_label}열)",
                                actual=f"{thk}mm")
                return None  # 재질 전용 범위 안에 있음 → 정상

            # 2) 셀 구조를 재질별로 분리하지 못했을 때만(자유 서식 WPS) 기존 방식으로
            #    안전하게 폴백 — base_metal 전체가 이 재질을 포함하면 셀 전체
            #    범위(여러 재질이 섞여 느슨할 수 있음, 기존과 동일한 한계)로 판정.
            if not parsed and _material_covered_by_wps(mat_key, base_metal_text):
                if not _thickness_in_range(thk, thk_range_text):
                    return Flag(3, col, "Blue",
                                f"두께범위 초과({side_label}열): {thk}mm, WPS={wps_no}, "
                                f"재질={mat_key}, 허용범위={thk_range_text[:60]}",
                                expected=f"{thk_range_text[:60]}mm (WPS={wps_no}, 재질={mat_key}, {side_label}열)",
                                actual=f"{thk}mm")
                return None
        # 매칭되는 재질 항목 없음 → 건너뜀 (재질 불일치는 Check 3 범위 밖)
        return None

    def _c4_groove(self, row: tuple, wps_no: str, repair: bool) -> Optional[Flag]:
        if not wps_no or repair:
            return None
        groove = _clean(_row_val(row, Col.GROOVE))
        if not groove:
            return None
        wps = self.loader.wps_table.get(wps_no)
        if not wps or not wps['joint_detail']:
            return None
        if not _groove_in_joint_detail(groove, wps['joint_detail']):
            allowed = ', '.join(sorted(_joint_detail_tokens(wps['joint_detail'])))
            return Flag(4, Col.GROOVE, "Yellow",
                        f"Groove 불일치: '{groove}' not in [{allowed}]",
                        expected=f"{allowed} 중 하나 (WPS={wps_no})",
                        actual=f"'{groove}'")
        return None

    def _c7_welder_expired(self, row: tuple) -> list[Flag]:
        """용접일이 **그 용접사의 자격 만료일/박탈일 이후**인가.

        ## §11-6이 예고한 검사다

        「자격 DB에 만료일 데이터가 없어 소급 검증할 수 없다. **향후 만료일
        컬럼이 채워지면 «용접일 > 만료일»만 별도로 걸러내는 정식 검사로 전환할
        것**」 — 현업이 만료일 파일을 확보해(2026-08-20) 그 전환을 했다.

        ## 번호 7을 되살린 근거

        7은 「중복 오류 (2+5)」였다가 현업 답변으로 규칙이 걷혔다. 번호 재사용은
        원칙적으로 금지인데(검토 기록 키가 `…|Check No`라 과거 의견이 무관한
        항목에 붙는다), **실측으로 Check 7 검토 기록이 0건**이라 붙을 자리가
        없었다. Check 5는 337건이라 절대 재사용하면 안 된다.

        ## 유효 만료일은 «이른 쪽»이다

        M(만료)과 N(박탈)이 둘 다 있으면 이른 쪽을 쓴다(`load_welder_expiry`).
        늦은 쪽을 쓰면 «자격이 없던 기간»을 놓친다.

        ## 용접사 결함률에서는 뺀다 — Check 6과 같은 이유

        이건 «그 행의 작업 품질»이 아니라 **그 사람의 자격 상태**다. 넣으면 같은
        행의 다른 용접사 세 명에게 오귀속된다 — 판정 엔진은 한 행을 용접사 4명
        전원에게 귀속시키기 때문이다.

        ## 세 가지를 잡는다

            표에 없는 사람          -> 「만료일 자료에 미등재」
            표에 있는데 M·N 공란    -> 「만료일 누락」
            용접일 > 유효 만료일    -> 「자격 만료/박탈 이후 작업」

        앞의 둘은 **승인기간을 확인할 수 없다**는 같은 결과인데 할 일이 다르다 —
        하나는 자료의 빈칸을 채우는 일이고, 하나는 명단에 넣는 일이다.

        ## 만료일 파일이 없으면 한 행도 판정하지 않는다

        그 0건은 «전원 유효»가 아니라 «대조하지 않았다»다. `_scope["7"]`이 0으로
        남아 화면에 「대상 없음」이 붙는다.
        """
        table = self.loader.welder_expiry
        if not table:
            # **동작이 아니라 비용을 위한 조기 반환이다.** 표가 비면 아래에서
            # `table.get(no)`가 전부 None이라 결과는 같다 — 다만 38만 행 x 4칸의
            # 날짜 파싱을 건너뛴다. 지워도 판정은 안 바뀐다(돌연변이로 확인).
            return []
        # 용접일이 없으면 «이후»는 물을 수 없지만, **만료일 누락은 그와 무관하다.**
        # 여기서 되돌아가면 용접일이 빈 행의 누락을 놓친다.
        wdate = _parse_date(_row_val(row, Col.WELD_DATE))

        flags: list[Flag] = []
        seen: set[str] = set()
        for no_col in (Col.WELDER1_NO, Col.WELDER2_NO,
                       Col.WELDER3_NO, Col.WELDER4_NO):
            no = _clean(_row_val(row, no_col))
            # 같은 사람이 두 칸에 적힌 행이 있다. 한 번만 지적한다 —
            # 두 번 세면 그 한 명 때문에 건수가 부푼다.
            if not no or no in seen:
                continue
            seen.add(no)
            self._scope["7"] += 1
            rec = table.get(no)
            # ── «승인기간을 확인할 수 없다»도 결함이다 (현업 확인 2026-08-20) ──
            #
            # 예전에는 둘 다 조용히 넘겼다. 그러면 만료일이 빠진 사람이 «문제
            # 없음»으로 읽힌다 — 정작 확인해야 할 사람이 결과에서 사라진다.
            # 원인이 다르므로 **메시지를 구분한다**: 자료의 빈칸인지, 아예
            # 명단에 없는지에 따라 할 일이 다르다.
            if rec is None:
                flags.append(Flag(7, no_col, "Yellow",
                                  f"용접사 '{no}' 만료일 자료에 미등재",
                                  welder_no=no,
                                  expected="만료일 자료에 등재된 용접사",
                                  actual=f"'{no}' 미등재 — 승인기간 확인 불가"))
                continue
            eff = rec["effective"]
            if eff is None:
                flags.append(Flag(7, no_col, "Yellow",
                                  f"용접사 '{no}' 만료일 누락 (M·N열 공란)",
                                  welder_no=no,
                                  expected="자격 만료일 또는 박탈일 기재 필요",
                                  actual="공란 — 승인기간 확인 불가"))
                continue
            if not wdate or wdate <= eff:
                continue
            # 만료인지 박탈인지 구분해 말한다 — 조치가 다르다.
            # 박탈(기능불량 계약해지)이 만료보다 무겁고, 둘 다면 이른 쪽이 사유다.
            why = ("자격 박탈" if rec["disq"] and rec["disq"] == eff else "자격 만료")
            flags.append(Flag(7, no_col, "Yellow",
                              f"용접사 '{no}' {why}일({eff}) 이후 작업 "
                              f"(용접일 {wdate})",
                              welder_no=no,
                              expected=f"{why}일 {eff} 이전 시공",
                              actual=f"용접일 {wdate} ({(wdate - eff).days}일 초과)"))
        return flags

    def _c6_welders(self, row: tuple, wps_prc: str = "") -> list[Flag]:
        pairs = [
            (Col.WELDER1_NO, Col.WELDER1_PROC),
            (Col.WELDER2_NO, Col.WELDER2_PROC),
            (Col.WELDER3_NO, Col.WELDER3_PROC),
            (Col.WELDER4_NO, Col.WELDER4_PROC),
        ]
        # ── 혼합 프로세스는 «4명 중 1명»이면 된다 (현업 확인 2026-08-13) ──────
        #
        # GTFC·SMFC 같은 혼합 프로세스 이음은 그 자격자가 **한 명만** 있으면 되고,
        # 나머지 인원은 FCAW로 시공해도 된다. 그래서 자격자가 한 명이라도 있으면
        # 나머지에게 «혼합 프로세스 자격 없음»을 묻지 않는다.
        #
        # **자격자가 아무도 없으면 완화하지 않는다** — 그건 Check 19가 «자격자
        # 미투입»으로 따로 지적하지만, 여기서도 개인별 사실은 그대로 남겨야 한다.
        # 완화를 무조건 걸면 «자격 없는 사람이 혼자 시공한 경우»까지 통과한다.
        relaxed = _is_mixed_process(wps_prc) and any(
            (self.loader.welder_qual.get(_clean(_row_val(row, c))) or {}).get('process')
            and any(_process_covers(q, wps_prc)
                    for q in self.loader.welder_qual[_clean(_row_val(row, c))]['process'])
            for c, _ in pairs if _clean(_row_val(row, c)))

        flags: list[Flag] = []
        for no_col, pr_col in pairs:
            no  = _clean(_row_val(row, no_col))
            prc = _normalize_process(_row_val(row, pr_col))
            if not no or not prc:
                continue
            qual = self.loader.welder_qual.get(no)
            # 자격 DB에 아예 없음(협력사 미등록 등)과, DB엔 있지만 시공 프로세스 자격이
            # 없는 경우는 원인이 다르므로 메시지를 구분한다(11-5). 퇴사자는 자격에서
            # 제외하지 않으므로(11-6) 여기서 별도 분기가 필요 없다 — qual이 존재하면
            # 재직/퇴사 여부와 무관하게 프로세스만 검사한다.
            if qual is None:
                flags.append(Flag(6, no_col, "Orange",
                                  f"용접사 '{no}' 자격 DB 미등록 (협력사 등 DB 미등재 추정)",
                                  welder_no=no,
                                  expected="자격 DB에 등록된 용접사",
                                  actual=f"'{no}' 미등록"))
            elif relaxed and _is_mixed_process(prc) and any(
                    _process_covers(q, "FCAW") for q in qual['process']):
                # 혼합 프로세스로 기재됐지만 FCAW 자격이 있고, 같은 이음에 혼합
                # 자격자가 이미 있다 -> 허용. 이 분기가 없으면 «보조 인원»이 전부
                # 지적되어 실제로 시정할 수 없는 건이 대량으로 나온다.
                continue
            elif not any(_process_covers(q, prc) for q in qual['process']):
                retired_note = " [퇴사자]" if no in self.loader.retired_welders else ""
                flags.append(Flag(6, no_col, "Orange",
                                  f"용접사 '{no}'{retired_note} 프로세스 '{prc}' 자격 없음 "
                                  f"(보유: {','.join(sorted(qual['process']))})",
                                  welder_no=no,
                                  expected=f"{prc} 자격 보유",
                                  actual=f"보유자격: {','.join(sorted(qual['process']))}"))
        return flags

    def _c8_tr_fc_g03(self, row: tuple, wps_no: str) -> Optional[Flag]:
        """대상 WPS에 «충격시험 온도가 낮은» 재질을 쓸 때의 두께 상한.

        **상한값과 온도 임계도 설정에서 읽는다.** 예전에는 `target_wps`만 설정이고
        12mm·-40℃는 소스에 박혀 있었다. 설정 파일에 `max_thickness`를 써도 판정이
        안 바뀌는데 **예외도 경고도 나지 않았다** — 이 모듈이 경계하던 «조용히
        죽는» 패턴이 설정값 쪽에서 재현된 것이다.

        선급 룰에 따라 값이 달라지는 항목이라, 프로젝트마다 코드를 고칠 수는 없다.
        """
        cfg = wps_rules.check8()
        target = (cfg.get('target_wps') or '').upper()
        # 맨 앞 «TR»은 프로젝트 번호라 빼고 맞춘다(현업 확인 2026-08-14).
        # 통째로 비교하면 프로젝트가 바뀌는 순간 이 검사가 조용히 0건이 된다.
        if not target or not _same_wps(wps_no, target):
            return None
        self._scope["8"] += 1
        limit = _to_float(cfg.get('max_thickness'))
        if limit is None:
            limit = 12.0
        temp_c = _to_float(cfg.get('impact_temp_c'))
        if temp_c is None:
            temp_c = -40.0
        mat1 = _clean(_row_val(row, Col.MATERIAL1)).upper()
        mat2 = _clean(_row_val(row, Col.MATERIAL2)).upper()
        temp1 = _material_impact_temp_c(mat1)
        temp2 = _material_impact_temp_c(mat2) if mat2 else None
        has_low = ((temp1 is not None and temp1 <= temp_c)
                   or (temp2 is not None and temp2 <= temp_c))
        thk1 = _to_float(_row_val(row, Col.THICKNESS1)) or 0
        thk2 = _to_float(_row_val(row, Col.THICKNESS2)) or 0
        thk  = min(thk1, thk2) if thk2 else thk1
        if has_low and 0 < thk <= limit:
            return Flag(8, Col.THICKNESS1, "Blue",
                        f"{target} 특수: {temp_c:g}℃급 재질({mat1}) + "
                        f"두께({thk}mm)≤{limit:g}mm",
                        expected=f"두께 > {limit:g}mm (또는 {temp_c:g}℃급 재질 아님)",
                        actual=f"재질={mat1}, 두께={thk}mm")
        return None

    def _c9_tr_smfc_g01(self, row: tuple, wps_no: str) -> Optional[Flag]:
        """대상 WPS에 **API 재질일 때 쓸 수 없는 두께**가 들어왔는가.

        현업 확인(2026-08-13)으로 규칙이 바뀌었다:

            예전  대상 WPS + 두께 12.7 -> «확인 필요» (재질 조건 없음)
            지금  대상 WPS + M·N에 API 재질 + 두께 12.7·8.2·6 -> **사용 불가**

        «확인 필요»에서 «금지»로 성격이 바뀌었지만 **번호는 9를 그대로 쓴다** —
        검토 기록 키가 `도면번호|Joint No|WPS No|Check No`라 번호를 옮기면 과거
        의견이 고아가 된다. 두께 목록과 대상 WPS는 프로젝트 값이라 설정에서 읽는다.

        실데이터: 대상(API + `TR-SMFC-G01`) 4건이 전부 9.5T라 위반 0건이다.
        **«문제가 없다»가 아니라 «금지 두께가 안 들어왔다»**이다.
        """
        cfg = wps_rules.check9()
        target = (cfg.get('target_wps') or '').upper()
        # 맨 앞 «TR»은 프로젝트 번호라 빼고 맞춘다(현업 확인 2026-08-14).
        # 통째로 비교하면 프로젝트가 바뀌는 순간 이 검사가 조용히 0건이 된다.
        if not target or not _same_wps(wps_no, target):
            return None
        self._scope["9"] += 1
        # M·N 중 하나라도 API면 대상이다. 이종재 이음에서 한쪽만 API인 경우가 빠진다.
        mats = [_clean(_row_val(row, c)).upper() for c in (Col.MATERIAL1, Col.MATERIAL2)]
        api = next((m for m in mats if m.startswith("API")), None)
        if api is None:
            return None
        banned = [t for t in (_to_float(x) for x in (cfg.get('banned_thickness') or ()))
                  if t is not None]
        if not banned:
            banned = [12.7, 8.2, 6.0]
        tol = _to_float(cfg.get('tolerance'))
        if tol is None:
            tol = 0.05
        for col, label in ((Col.THICKNESS1, 'J'), (Col.THICKNESS2, 'K')):
            thk = _to_float(_row_val(row, col))
            if thk is None or thk <= 0:
                continue
            hit = next((b for b in banned if abs(thk - b) < tol), None)
            if hit is None:
                continue
            return Flag(9, col, "Green",
                        f"{target}은 API 재질({api})에 두께 {hit:g}mm 사용 불가 "
                        f"({label}열={thk:g}mm)",
                        expected=f"{', '.join(f'{b:g}' for b in banned)}mm 외의 두께 "
                                 f"(API 재질 + {target})",
                        actual=f"{label}열 두께={thk:g}mm, 재질={api}")
        return None

    def _c11_material_not_allowed(self, row: tuple, wps_no: str,
                                  repair: bool) -> Optional[Flag]:
        """
        해당 WPS의 허용 재질 목록(F열)에 없는 재질로 용접한 경우를 감지한다.
        두께 범위 문제(Check 3)와 달리 "이 WPS로는 이 재질을 용접할 자격이 없다"는
        더 근본적인 부적합이므로 별도 항목으로 표시한다.

        오탐을 막기 위해 아래 경우는 검사하지 않는다:
          - WPS 미기재 / WPS List에 없는 WPS (각각 다른 Check의 관할)
          - 수리 WPS(TR-FC-R*) — 임시 절차라 재질 목록이 관리되지 않음
          - 재질 표기를 표준 키로 인식하지 못한 경우 (근거 없이 단정하지 않음)
        """
        if not wps_no or repair:
            return None
        wps = self.loader.wps_table.get(wps_no)
        if not wps:
            return None
        raw1 = _clean(_row_val(row, Col.MATERIAL1))
        if not raw1:
            return None
        key1 = _get_material_key(raw1)
        if key1 is None:
            return None

        base_metals = [me.get('base_metal', '') for me in wps.get('materials', [])]
        if not any(bm.strip() for bm in base_metals):
            return None  # WPS에 허용 재질 정보 자체가 없으면 판단 불가

        f1 = self._c11_check_one_material(wps, wps_no, key1, raw1, base_metals, Col.MATERIAL1, 'M')
        if f1:
            return f1

        # N열(재질2)이 있으면 이음 반대쪽 부재도 이 WPS의 허용 재질이어야 한다
        # (Check 3 K열 확장과 같은 이유 — ASME IX QW-451은 이음을 구성하는 각
        # 부재에 대해 자격이 성립해야 한다고 본다).
        raw2 = _clean(_row_val(row, Col.MATERIAL2))
        if not raw2:
            return None
        key2 = _get_material_key(raw2)
        if key2 is None:
            return None
        return self._c11_check_one_material(wps, wps_no, key2, raw2, base_metals, Col.MATERIAL2, 'N')

    def _c11_check_one_material(self, wps: dict, wps_no: str, mat_key: str, raw_material: str,
                                base_metals: list[str], col: int, side_label: str) -> Optional[Flag]:
        for bm in base_metals:
            if _material_covered_by_wps(mat_key, bm):
                return None

        # F열(허용 재질)에 빠져 있어도 G열(두께범위)에 그 재질의 전용 항목이
        # 명시돼 있으면 실질적으로 허용된 재질로 본다 — 실제 WPS에 F열 기재가
        # 누락된 사례가 있다(TR-FC-G01은 F열에 EW420이 없는데 G열에는
        # 'EW420 : 13~50' 항목이 있음). 이 보정이 없으면 오탐이 발생한다.
        for me in wps.get('materials', []):
            for label, _rng in _parse_material_thickness_entries(me.get('thk_range', '')):
                if _label_matches_material(mat_key, label):
                    return None

        allowed = ' / '.join(bm.replace('\n', ' ').strip() for bm in base_metals if bm.strip())
        return Flag(11, col, "Purple",
                    f"재질 부적합({side_label}열): '{raw_material}'({mat_key})은 WPS={wps_no}의 허용 재질이 아님",
                    expected=f"{allowed[:80]} (WPS={wps_no} 허용 재질, {side_label}열)",
                    actual=f"'{raw_material}'")

    def _c12_tubular_dia_review(self, row: tuple) -> Optional[Flag]:
        """
        관재(A500 등 각관·강관)는 철판이 아니므로 두께 판정 기준이 J열(Thickness)이
        아니라 I열(Out Dia)의 형상 규격이다. 그런데 I열 값이 'SHS80X6'처럼 숫자가
        아닌 규격 표기라 자동 판정이 불가능하고, 기준값과 실측값에 차이가 있어
        사람이 직접 확인해야 한다 → '결함 확정'이 아니라 '확인 필요'로 분류한다.
        """
        if not _is_tubular_material(_clean(_row_val(row, Col.MATERIAL1))):
            return None
        self._scope["12"] += 1
        out_dia = _clean(_row_val(row, Col.OUT_DIA))
        thk     = _clean(_row_val(row, Col.THICKNESS1))
        return Flag(12, Col.OUT_DIA, "Teal",
                    f"관재 확인 필요: 재질={_clean(_row_val(row, Col.MATERIAL1))}, "
                    f"Out Dia='{out_dia}' (두께가 아닌 DIA 기준이라 수동 확인 필요)",
                    expected=f"I열 Out Dia 규격 기준 확인 (J열 두께 {thk}mm 기준 아님)",
                    actual=f"Out Dia='{out_dia}'")

# ─── 진입점 ──────────────────────────────────────────────────────────────────
def _scope_map(checker: "QCChecker") -> dict[str, int]:
    """**각 검사가 대조한 대상 수.** 0건에는 두 종류가 있다 —

        대조했고 위반이 없다        -> 진짜 «문제 없음»
        대조할 대상이 아예 없었다    -> 한 번도 판정하지 않았다

    화면에서는 둘 다 그냥 «0건»으로 보인다. **여기 없는 번호는 판정 대상 전체를
    본 검사다**(Check 1·2·3·4·6·11·18·19).

    프로젝트 규칙은 `_SCOPED_CHECKS`에 못 박을 수 없다 — 규칙마다 번호가 다르다.
    그런데 이쪽이야말로 **항상 관문이 좁다**(`when`이 재질·WPS·NDT Category를
    지목한다). 키가 없으면 화면이 「없으면 전부가 대상」을 적용해 **대조 대상이
    0건인 규칙에 「대상 없음」이 안 붙는다** — 그 구분이 가장 필요한 쪽에서
    빠지는 셈이다. 대조한 수는 `_rule_matched`가 이미 세고 있으므로 합쳐 준다.

    **한 번도 안 걸린 규칙은 0으로 채운다.** 채우지 않으면 키가 아예 안 생겨서
    정작 잡아야 할 «대상 0건»이 빠진다 — `_scope`를 0으로 미리 채우는 것과 같은
    이유다.
    """
    out = {str(k): int(v) for k, v in checker._scope.items()}
    for r in checker._project_rules():
        if r.no:
            out[r.no] = int(checker._rule_matched.get(r.no, 0))
    return out


def _noscope_findings(checker: "QCChecker",
                      enabled: dict[int, bool]) -> list[dict[str, Any]]:
    """켜져 있는데 **대조할 대상이 하나도 없었던** 검사를 경고한다.

    이 저장소에서 「0건」은 두 가지 뜻이다:

        대조했고 위반이 없다        -> 진짜 «문제 없음»
        대조할 대상이 아예 없었다    -> 한 번도 판정하지 않았다

    화면에서는 둘 다 그냥 «0건»으로 보인다. 실제로 Check 25는 `Q01`로 끝나는
    WPS가 한 행도 없어 한 번도 안 돌았는데 «통과»로 읽혔다. Check 15가 결번이
    된 것도 「위반 0건」을 뒤늦게 「대조 조합 0건」으로 정정한 결과다.

    프로젝트 규칙(101~199)은 `project_checks.health()`가 이미 같은 경고를 낸다.
    여기는 **공통 Check** 몫이다.

    계측하지 않은 검사(판정 대상 전체를 보는 것들 — Check 1·2·3·4·6·11·18·19)는
    `_scope`에 아예 없다. 그건 «대상이 없다»가 아니라 «전부가 대상»이라 뺀다.
    """
    out: list[dict[str, Any]] = []
    for no in sorted(checker._scope, key=project_checks.sort_key):
        if checker._scope[no] > 0:
            continue
        if not enabled.get(no, True):
            continue                 # 꺼 둔 검사가 0인 것은 당연하다
        name = check_name(no)
        out.append({"level": "noscope", "check_no": no,
                    "msg": f"Check {project_checks.label(no)}({name})이 대조한 대상이 0건이다 — "
                           f"«위반이 없다»가 아니라 «한 번도 판정하지 않았다»이다. "
                           f"대상이 생기는 순간이 확인할 때다"})
    return out


def run_verification(
    qmg_path: str | Path,
    welder_path: str | Path,
    wps_ref_path: str | Path,
    qmg_filename: str = "",
    welder_filename: str = "",
    wps_cache: dict | None = None,
    consumable_lots: list[str] | None = None,
    project: str | None = None,
    progress: Callable[[int, str], None] | None = None,
) -> dict:
    """검증 실행 → JSON 직렬화 가능한 dict 반환.

    `project`는 **이 회차를 어느 프로젝트 기준으로 판정할지**다. 주지 않으면
    지금 활성인 프로파일을 쓴다.

    판정에 쓴 항목 목록(`rules`)을 결과에 **함께 박아 넣는다.** 이름만 남기면
    같은 이름 안에서 항목을 켜고 껐을 때 «이 결과가 무엇으로 판정됐는지»를
    되짚을 수 없다. 실제로 다음이 가능했다:

        A 프로젝트로 검증 -> 세팅에서 B로 전환 -> 화면은 A의 숫자인데
        보는 사람은 B 결과로 읽는다 (오류도 경고도 없다)
    """
    if project:
        rule_catalog.switch_profile(project)
    active_project = rule_catalog.active_profile_name()
    rules_snapshot = rule_catalog.enabled_map()
    loader = QCDataLoader()
    if wps_cache:
        loader.load_wps_from_dict(wps_cache, progress)
    else:
        loader.load_wps(wps_ref_path, progress)
    loader.load_welders(welder_path, progress)
    # 승인 용접봉 목록. **없어도 검증은 돈다** — Check 28만 «대상 없음»이 된다.
    # 없다고 막으면 목록을 아직 못 받은 프로젝트가 아무 검증도 못 한다.
    if consumable_lots:
        loader.load_consumables_from_list(consumable_lots)
    loader.load_qmg(qmg_path, progress)

    # 규칙이 지목하는 WPS가 실제로 존재/사용되는지 확인한다.
    # 접두사가 다른 프로젝트가 들어오면 Check 5/8/9가 조용히 0건이 되는데,
    # 그걸 "문제가 없다"로 읽지 않도록 여기서 경고를 남긴다 (§11-9, 개선계획 12번).
    # qmg_rows는 (엑셀 행번호, 행 튜플) 형태다 — 행 튜플만 꺼내 써야 한다.
    used_wps = {
        _clean(_row_val(row, Col.WPS_NO)).upper()
        for _, row in loader.qmg_rows if _clean(_row_val(row, Col.WPS_NO))
    }
    rule_findings = wps_rules.check_rules_alive(set(loader.wps_table), used_wps)

    # **승인 용접봉 목록이 없으면 Check 18의 «미승인» 쪽이 돌지 않는다.**
    # 번호를 나누지 않기로 했으므로(위 `_c18_consumable_lot` 참조) `_scope`로는
    # 그 사실을 말할 수 없다 — 18은 모든 판정 행에서 «기재 누락»을 보기 때문이다.
    # 그래서 여기에 남긴다. 없으면 목록을 안 올린 프로젝트가 «용접봉 문제 없음»
    # 으로 읽힌다. 「0건」이 «대조했고 위반 없음»인지 «대조하지 않음»인지는
    # 결과만 봐서는 알 수 없다.
    if not loader.consumable_lots:
        rule_findings.append({
            "wps": "", "level": "missing",
            "msg": "승인 용접봉 리스트가 없다 — Check 18이 «미승인 용접봉»을 "
                   "한 행도 대조하지 않았다. 기재 누락만 본 결과다 "
                   "('업로드' 탭에서 승인 목록을 올려라)"})

    checker = QCChecker(loader)
    # 판정 중에 설정이 바뀌어도 회차 안에서는 «한 기준»이어야 한다.
    # 행마다 파일을 다시 읽으면 앞뒤 행이 다른 기준으로 판정될 수 있다.
    checker._enabled = dict(rules_snapshot)
    checker.run(progress)

    flags_list: list[dict] = []
    for row_num in sorted(checker.row_flags):
        rd = checker.row_data.get(row_num, {})
        for f in checker.row_flags[row_num]:
            flags_list.append({
                "row":        row_num,
                "check_no":   f.check_no,
                "check_name": checker._check_name(f.check_no),
                "col":        f.col,
                "col_letter": get_column_letter(f.col),
                "color":      f.color,
                "msg":        f.msg,
                "expected":   f.expected,
                "actual":     f.actual,
                "drawing_no":  rd.get('drawing_no', ''),
                "joint_no":    rd.get('joint_no', ''),
                "block":       rd.get('block', ''),
                "material1":   rd.get('material1', ''),
                "material2":   rd.get('material2', ''),
                "thickness1":  rd.get('thickness1', ''),
                "thickness2":  rd.get('thickness2', ''),
                "wps_no":      rd.get('wps_no', ''),
                "wps_process": rd.get('wps_process', ''),
                # 산출물의 추적 키 — 현업은 도면번호가 아니라 이 번호로 원본을 찾는다
                "ndt_report":  rd.get('ndt_report', ''),
                "weld_date":   rd.get('weld_date', ''),
                "ndt_date":    rd.get('ndt_date', ''),
                # Check 14 중복 그룹 비교 시 "누가 각 중복행을 시공했는지"가 판단 근거가 된다
                "welder1_no":  rd.get('welder1_no', ''),
                "department":  rd.get('department', ''),
                "team":        rd.get('team', ''),
            })

    def _check_breakdown(wno: str, check_stats: dict, missing: dict) -> dict[str, int]:
        """'C1: 0, C6: 74' 형태 약식 표기용 — check_no(1~10)별 건수. Check 6은 미자격(서류) 건수."""
        breakdown = {str(n): 0 for n in CHECK_NAMES}
        for check_no, cnt in check_stats.get(wno, {}).items():
            breakdown[str(check_no)] = cnt
        breakdown["6"] = missing.get(wno, 0)
        return breakdown

    # 용접사별 결함 발생률 (AP/AR/AT/AV열 전체 참여 건 기준) — 교육 참고용, 결함 발생률 높은 순
    welder_defect_rate: list[dict] = []
    for wno, tot in checker.welder_totals.items():
        defect = checker.welder_defects.get(wno, 0)
        if defect == 0:
            continue
        welder_defect_rate.append({
            "welder_no": wno,
            "total":     tot,
            "defect":    defect,
            "rate":      round(defect / tot * 100, 1) if tot else 0.0,
            "check_breakdown": _check_breakdown(wno, checker.welder_check_stats, checker.welder_missing),
        })
    welder_defect_rate.sort(key=lambda w: (-w["rate"], -w["defect"], w["welder_no"]))
    # 동점자까지 정렬 키에 넣는 이유: 앞의 두 값만 쓰면 남는 순서가 «먼저 들어온
    # 순»이 되는데, 그 삽입 순서가 `row_welders`(set) 순회에 좌우돼 파이썬
    # 프로세스마다 달라진다. 같은 파일을 두 번 돌려도 같은 결과가 나와야
    # 검증 이력 비교(개선계획 9번)가 성립한다.

    # 용접사 부가 정보 (이름 + 자격 상세) — 번호만으로는 관리자가 대상자를 특정할 수 없어
    # 화면/리포트에서 이름과 보유 자격을 함께 보여주기 위한 조회용 맵.
    # 각 목록(결함발생률/미등록/반복패턴)에 이름을 중복 저장하지 않고 여기서 조회해 쓴다.
    # 자격 DB에 없는 용접사(협력사 등)는 registered=False로만 남는다.
    def _fmt_d(d) -> str:
        return d.isoformat() if d else ""

    welder_info: dict[str, dict] = {}
    for wno in set(checker.welder_totals) | set(checker.welder_missing):
        cert = loader.welder_certs.get(wno)
        qual = loader.welder_qual.get(wno)
        # 실적 수치도 함께 담아 welder_info 하나만으로 용접사 관리 화면을 구성할 수 있게
        # 한다. 예전에는 welder_defect_rate(결함 있는 용접사만)와 welder_missing(C6
        # 대상만) 두 목록을 따로 써서 같은 사람이 양쪽에 다른 숫자로 나타났고, 결함이
        # 0건인 용접사는 어느 쪽에도 없어 "결함 없이 많이 시공한 사람"을 볼 수 없었다.
        total  = checker.welder_totals.get(wno, 0)
        defect = checker.welder_defects.get(wno, 0)   # C6 제외(실제 작업성 결함)
        welder_info[wno] = {
            "name":       loader.welder_names.get(wno, ""),
            "registered": qual is not None,
            "retired":    wno in loader.retired_welders,
            "processes":  sorted(qual['process']) if qual else [],
            "positions":  sorted(qual['position']) if qual else [],
            "specs":      sorted(cert['specs']) if cert else [],
            "classes":    sorted(cert['classes']) if cert else [],
            "cert_count": len(cert['cert_nos']) if cert else 0,
            "first_cert_date": _fmt_d(cert['first_cert_date']) if cert else "",
            "last_cert_date":  _fmt_d(cert['last_cert_date']) if cert else "",
            # ── 실적 ──
            "total":          total,
            "defect":         defect,
            "rate":           round(defect / total * 100, 1) if total else 0.0,
            # 소속 — 건수 많은 순. 한 사람이 여러 팀에 걸치면 전부 싣는다.
            "orgs": [{"department": d, "team": t, "rows": n}
                     for (d, t), n in checker.welder_orgs.get(wno, Counter()).most_common()],
            "missing_flags":  checker.welder_missing.get(wno, 0),   # C6 건수
            "check_breakdown": _check_breakdown(wno, checker.welder_check_stats,
                                                checker.welder_missing),
            # 날짜별 추이 — [{date, total, checks:{check_no: 건수}}] (용접일 오름차순).
            # total(그날 시공량)이 함께 있어야 결함률로 그릴 수 있고, 그래야
            # "많이 일한 날"과 "잘못한 날"이 구분된다.
            "date_stats": [
                {
                    "date":   dt,
                    "total":  cnt,
                    "checks": {str(k): v for k, v in
                               sorted(checker.welder_date_checks.get(wno, {}).get(dt, {}).items())},
                }
                for dt, cnt in sorted(checker.welder_date_totals.get(wno, {}).items())
            ],
        }

    # 용접 날짜별 결함 발생 추이 (AM열 기준) — 날짜 오름차순
    defect_trend_by_date = [
        {"date": d, "count": c}
        for d, c in sorted(checker.defect_by_date.items())
    ]

    def _welder_rate_list(bucket: dict) -> list[dict]:
        rate_list: list[dict] = []
        for wno, tot in bucket['welder_totals'].items():
            defect = bucket['welder_defects'].get(wno, 0)
            if defect == 0:
                continue
            rate_list.append({
                "welder_no": wno,
                "total":     tot,
                "defect":    defect,
                "rate":      round(defect / tot * 100, 1) if tot else 0.0,
            })
        # 위 welder_defect_rate와 같은 이유로 welder_no까지 넣는다.
        rate_list.sort(key=lambda w: (-w["rate"], -w["defect"], w["welder_no"]))
        return rate_list

    def _trend_list(bucket: dict) -> list[dict]:
        return [{"date": d, "count": c} for d, c in sorted(bucket['defect_by_date'].items())]

    # 부서별 결함 분류 (BF열 기준) — 그 아래 팀(BG열) 단위로 한 번 더 집계해 "부서별 대시보드"
    # 탭에서 부서 -> 팀 순으로 드릴다운해 볼 수 있게 한다.
    departments: dict[str, dict] = {}
    for dept, d in checker.dept_data.items():
        teams: dict[str, dict] = {}
        for team, t in d['teams'].items():
            teams[team] = {
                "total_rows":          t['total_rows'],
                "unworked_rows":       t['unworked_rows'],
                "defect_rows":         t['defect_rows'],
                "check_stats":         {str(k): v for k, v in t['check_stats'].items()},
                "welder_defect_rate":  _welder_rate_list(t),
                "defects":             t['defects'],
                "defect_trend_by_date": _trend_list(t),
                "temp_rows":           t['temp_rows'],
            }
        departments[dept] = {
            "total_rows":          d['total_rows'],      # 판정 대상 (미작업 제외)
            "unworked_rows":       d['unworked_rows'],   # 미작업 (Check 0, 결함률 분모 아님)
            "defect_rows":         d['defect_rows'],
            "check_stats":         {str(k): v for k, v in d['check_stats'].items()},
            "welder_defect_rate":  _welder_rate_list(d),
            "defects":             d['defects'],
            "defect_trend_by_date": _trend_list(d),
            "temp_rows":           d['temp_rows'],
            "teams":               teams,
            # 6번 서브에이전트: 같은 용접사가 같은 Check에서 서로 다른 날짜에 반복
            # 발생하는 패턴 (부서별 결함 탭 + 부서 리포트 메일에서 참고용으로 노출).
            "recurring_patterns":  recurrence.detect_recurring_patterns(d['defects']),
        }

    active = len(loader.qmg_rows) - checker.deleted_rows
    # 판정 대상 = 삭제도 미작업도 아닌 행. 결함률 통계의 분모는 항상 이 값을 쓴다.
    judged = active - checker.unworked_rows
    return {
        "run_at":          datetime.now().strftime('%Y-%m-%d %H:%M'),
        # 이 회차를 «무엇으로» 판정했는가. 이름과 항목 목록을 함께 남긴다.
        "project":         active_project,
        "rules":           {str(k): bool(v) for k, v in rules_snapshot.items()},
        # **잠정 표식** — 「이 항목은 다른 프로젝트 값을 빌려 쓰는 중이라 재확인이
        # 필요하다」. 켬/끔과 같은 이유로 **결과에 박는다** — 나중에 설정을 고쳐도
        # «이 회차가 무슨 상태에서 나온 숫자인가»는 변하지 않아야 한다.
        # 표식이 없으면 빌려 온 값으로 나온 숫자를 확정된 판정으로 읽게 된다.
        "provisional":     {str(k): str(v) for k, v in
                            (wps_rules.load().get("provisional") or {}).items()},
        "scope":           _scope_map(checker),
        # 규칙의 **정의**도 함께 박는다. 번호와 켬/끔만 남기면 옛 회차의
        # «허용 12~50»이 어디서 왔는지 복원할 수 없다.
        "project_checks":  [r.as_dict() for r in checker._project_rules()],
        # 프로젝트 규칙이 공통 Check를 대신 판정한 side 수. **통과해서 플래그가
        # 없는 경우는 이 카운터가 아니면 어디에도 안 보인다.**
        "suppression":     [{"project_check": pno, "common_check": cno, "sides": n}
                            for (pno, cno), n in sorted(checker._suppressed.items())],
        "qmg_filename":    qmg_filename,
        "welder_filename": welder_filename,
        "total_rows":      len(loader.qmg_rows),
        "deleted_rows":    checker.deleted_rows,
        "active_rows":     active,
        "unworked_rows":   checker.unworked_rows,
        "judged_rows":     judged,
        # 임시부재(§11-11). 판정에는 그대로 들어가고, 대시보드의 «임시부재 제외»
        # 토글이 분모에서 뺄 때 쓴다.
        "temp_judged_rows": checker.temp_judged_rows,
        "flagged_rows":    len(checker.row_flags),
        "clean_rows":      judged - len(checker.row_flags),
        "total_flags":     sum(checker.stats.values()),
        "stats":           {str(k): v for k, v in checker.stats.items()},
        "flags":           flags_list,
        # 상세 결과 화면 "원본 데이터" 패널용 — 행 번호(문자열 키) -> 엑셀 원문 스냅샷.
        "row_raw":         {str(k): v for k, v in checker.row_raw.items()},
        # Check 0(미작업) 드릴다운용 — 결함이 아니므로 기준값/실제값은 없다.
        "unworked_list":   checker.unworked_list,
        "welder_missing":  {
            wno: {
                "flag_count": cnt,
                "total":      checker.welder_totals.get(wno, 0),
                # C6(미자격) 제외 — 실제 작업성 결함 건수/발생률
                "workmanship_defect": checker.welder_defects.get(wno, 0),
                "workmanship_rate": (
                    round(checker.welder_defects.get(wno, 0) / checker.welder_totals[wno] * 100, 1)
                    if checker.welder_totals.get(wno, 0) else 0.0
                ),
                "check_breakdown": _check_breakdown(wno, checker.welder_check_stats, checker.welder_missing),
            }
            for wno, cnt in sorted(checker.welder_missing.items(), key=lambda x: -x[1])
        },
        "welder_defect_rate":    welder_defect_rate,
        "welder_info":           welder_info,
        "defect_trend_by_date":  defect_trend_by_date,
        "departments":           departments,
        # 규칙이 죽어 있는지 점검한 결과. 화면(설정/에이전트 탭)에서 확인할 수 있게 싣는다.
        # WPS 규칙 경고 + **프로젝트 규칙 경고**를 한 자리에 모은다.
        # 0행에 걸리는 규칙은 «문제 없음»이 아니라 «표기가 안 맞을 수 있다»이다 —
        # F03·G05·S355KT 계열이 지금 물량에서 정확히 그 상태다.
        # 판정 대상의 «재질 × WPS» 분포. 화면에서 규칙을 넣을 때 «지금 데이터에
        # 몇 행 걸리는가»를 즉시 세는 데 쓴다 — 0행이면 그 자리에서 표기 문제를
        # 알 수 있다(「S355KL -40」이 실데이터 표기와 안 맞아 한 번 막혔다).
        #
        # 행수가 아니라 **조합 수**에 비례한다(이 물량은 재질 16 × WPS 5).
        # 30만 행이어도 크기가 거의 같다.
        "material_wps":          [
            {"material": m, "wps": w, "rows": n}
            for (m, w), n in sorted(checker._mat_wps.items(), key=lambda x: -x[1])],
        "rule_health":           rule_findings + project_checks.health(
            checker._project_rules(), checker._rule_matched,
            checker._rule_problems) + _noscope_findings(checker, rules_snapshot),
        # 머신러닝(비지도) 분석 화면용. meta는 격자/히스토그램으로 요약돼 있고
        # detail은 이상치 행(수십~수천)만 담으므로 결과 JSON 크기에 큰 영향이 없다.
        "ml": {
            "unsupervised": {
                "available": checker.ml_meta is not None,
                "meta":      checker.ml_meta,
                "detail":    {str(k): v for k, v in checker.ml_detail.items()},
                # 임시부재(1C)를 **학습에서 빼고** 다시 돌린 것. 이쪽이 검토용
                # 기본값이고, 위(1C 포함)는 참고용이자 Check 13 플래그의 근거다.
                # 1C가 한 행도 없으면 `available: False` — 같은 결과를 두 벌
                # 담으면 화면이 «두 기준이 있다»고 잘못 읽는다.
                "excl_temp": {
                    "available": checker.ml_excl_temp_meta is not None,
                    "meta":      checker.ml_excl_temp_meta,
                    "detail":    {str(k): v
                                  for k, v in checker.ml_excl_temp_detail.items()},
                    "rows":      checker.ml_excl_temp_rows,
                },
            },
        },
    }

def write_result_excel(qmg_path: str | Path, result: dict,
                       out_path: str | Path) -> None:
    """QMG 원본을 스트리밍으로 복사하여 플래그 색상 마킹 + 기준값/실제값 주석 후 저장.

    read_only=True 소스 + write_only=True 출력으로 메모리를 상수로 유지한다.
    헤더(1~5행)는 일반 모드로 서식을 캡처한 뒤 워크북을 닫아 해제한다.
    """
    from copy import copy as _copy
    from openpyxl import Workbook as _WB
    from openpyxl.cell import WriteOnlyCell

    qmg_path = Path(qmg_path)
    HEADER_ROWS = 5

    # ── best 맵 빌드 ──
    best: dict[int, dict[int, dict]] = defaultdict(dict)
    for f in result['flags']:
        row, col = f['row'], f['col']
        prev = best[row].get(col)
        if prev is None or _PRIORITY[f['color']] < _PRIORITY[prev['color']]:
            best[row][col] = f

    # DRM 변환은 한 번만 수행, 이후 두 워크북 모두 bytes 재사용
    _raw = drm_convert.convert_to_bytes(qmg_path) if drm_convert.is_drm(qmg_path) else None

    def _open_ro():
        if _raw is not None:
            return load_workbook(io.BytesIO(_raw), read_only=True, data_only=True)
        return load_workbook(str(qmg_path), read_only=True, data_only=True)

    def _open_full():
        if _raw is not None:
            return load_workbook(io.BytesIO(_raw), data_only=True)
        return load_workbook(str(qmg_path), data_only=True)

    # ── 헤더 서식·구조 캡처 (일반 모드, 이후 즉시 닫음) ──
    wb_hdr = _open_full()
    ws_hdr = wb_hdr.active
    header_snapshots = []
    for row in ws_hdr.iter_rows(min_row=1, max_row=HEADER_ROWS):
        snap = []
        for cell in row:
            snap.append({
                'value': cell.value,
                'fill': _copy(cell.fill)
                        if cell.fill and cell.fill.fill_type not in (None, 'none') else None,
                'font':      _copy(cell.font)      if cell.font else None,
                'border':    _copy(cell.border)    if cell.border else None,
                'alignment': _copy(cell.alignment) if cell.alignment else None,
                'number_format': cell.number_format,
            })
        header_snapshots.append(snap)
    col_widths     = {k: v.width for k, v in ws_hdr.column_dimensions.items()}
    autofilter_ref = ws_hdr.auto_filter.ref
    merged_ranges  = [str(mc) for mc in list(ws_hdr.merged_cells.ranges)
                      if mc.max_row <= HEADER_ROWS]
    wb_hdr.close()

    # ── 출력 워크북 (write_only) ──
    wb_w = _WB(write_only=True)
    ws_w = wb_w.create_sheet()
    for col_letter, width in col_widths.items():
        ws_w.column_dimensions[col_letter].width = width
    if autofilter_ref:
        ws_w.auto_filter.ref = autofilter_ref
    for mc_range in merged_ranges:
        ws_w.merge_cells(mc_range)

    # 헤더 5행 — 서식 포함
    for snap in header_snapshots:
        wrow = []
        for cd in snap:
            wc = WriteOnlyCell(ws_w, value=cd['value'])
            if cd['fill']:            wc.fill = cd['fill']
            if cd['font']:            wc.font = cd['font']
            if cd['border']:          wc.border = cd['border']
            if cd['alignment']:       wc.alignment = cd['alignment']
            if cd['number_format']:   wc.number_format = cd['number_format']
            wrow.append(wc)
        ws_w.append(wrow)

    # 본문 — read_only 스트리밍
    wb_r = _open_ro()
    ws_r = wb_r.active
    for row in ws_r.iter_rows(min_row=HEADER_ROWS + 1):
        row_num  = row[0].row
        col_map  = best.get(row_num, {})
        wrow = []
        for cell in row:
            wc = WriteOnlyCell(ws_w, value=cell.value)
            col_idx = cell.column
            if col_idx in col_map:
                f = col_map[col_idx]
                wc.fill = _FILLS[f['color']]
                if f['color'] == 'Black':
                    wc.font = Font(color='FFFFFF')
                comment_lines = [f"[Check {f['check_no']}] {f['check_name']}"]
                if f.get('expected') or f.get('actual'):
                    comment_lines.append(f"기준값: {f.get('expected', '')}")
                    comment_lines.append(f"실제값: {f.get('actual', '')}")
                else:
                    comment_lines.append(f['msg'])
                c = Comment('\n'.join(comment_lines), 'QC Verifier')
                c.width  = 320
                c.height = 110
                wc.comment = c
            wrow.append(wc)
        ws_w.append(wrow)
    wb_r.close()

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    # 임시 파일에 쓴 뒤 완료되면 rename — 중간에 프로세스가 죽어도 원본이 깨지지 않는다
    tmp_path = out_path.with_suffix('.tmp')
    try:
        wb_w.save(str(tmp_path))
        tmp_path.replace(out_path)
    except Exception:
        if tmp_path.exists():
            tmp_path.unlink()
        raise
    logger.info("Excel 결과 저장(스트리밍): %s", out_path)
