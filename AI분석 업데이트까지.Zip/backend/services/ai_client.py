"""Claude API를 부르는 **유일한 지점.**

## 왜 한 곳인가

호출이 흩어지면 모델별 분기·토큰 계량·비용 추정·오류 문구가 자리마다 달라진다.
RUYA가 그 상태다 — 브라우저 6곳 + 서버 2곳에서 각자 `fetch`/`requests`로 때리고,
모델 이름이 다섯 군데에 하드코딩돼 있으며, 토큰을 세는 곳이 하나도 없다.

여기를 거치지 않는 API 호출은 만들지 마라. `tests/test_ai_client.py`가 정적으로 본다.

## 모델군마다 «생각하기» 설정이 다르다 — 여기서만 분기한다

    Haiku 4.5           thinking={"type": "enabled", "budget_tokens": N}
                        effort를 주면 **오류**다
    4.6 이상 (Sonnet 4.6 · Sonnet 5 · Opus 4.6~4.8 · Opus 5 · Fable 5)
                        thinking={"type": "adaptive"} + output_config={"effort": …}
                        budget_tokens를 주면 **400**이다

기본은 Haiku 4.5다(현업 결정 2026-08-21) — 「결과값 분석이라 그 정도면 충분하다」.
**Haiku 4.5만 컨텍스트가 200K**이고 나머지는 1M이라, 상한 검사는 반드시
«선택된 모델의 창»을 기준으로 해야 한다.

## 자르지 않는다

입력이 상한을 넘으면 **거부하고 무엇을 줄일지 말한다.** 조용히 자르면 모델이
«없는 데이터»로 판단하는데, 그건 오류 없이 틀린 답이 나오는 길이다.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)

# `anthropic`이 없어도 **수집 단계가 깨지지 않아야 한다** — scikit-learn·pywin32와
# 같은 취급이다. 없으면 AI 기능만 꺼지고 나머지 화면은 그대로 뜬다.
try:
    import anthropic
    _AVAILABLE = True
except ImportError:                                    # pragma: no cover
    anthropic = None                                   # type: ignore[assignment]
    _AVAILABLE = False


def is_available() -> bool:
    """`anthropic` SDK가 설치돼 있는가."""
    return _AVAILABLE


# ── 고를 수 있는 모델 ────────────────────────────────────────────────────────
#
# 단가는 100만 토큰당 달러. **여기 값이 화면의 «예상 비용»이 된다** — 실제 청구와
# 어긋나면 사용자가 «얼마 나올지 모르는 버튼»을 누르게 되므로, 단가가 바뀌면
# 여기를 고쳐야 한다.
@dataclass(frozen=True)
class Model:
    id: str
    label: str
    context: int          # 입력 창 (토큰)
    in_price: float       # $ / 1M 입력
    out_price: float      # $ / 1M 출력
    adaptive: bool        # True면 4.6+ 계열 (adaptive + effort)


MODELS: tuple[Model, ...] = (
    Model("claude-haiku-4-5",  "Haiku 4.5 (기본 · 가장 쌈)", 200_000,  1.0,  5.0, False),
    Model("claude-sonnet-4-6", "Sonnet 4.6",              1_000_000,  3.0, 15.0, True),
    Model("claude-sonnet-5",   "Sonnet 5",                1_000_000,  3.0, 15.0, True),
    Model("claude-opus-4-6",   "Opus 4.6",                1_000_000,  5.0, 25.0, True),
    Model("claude-opus-4-7",   "Opus 4.7",                1_000_000,  5.0, 25.0, True),
    Model("claude-opus-4-8",   "Opus 4.8",                1_000_000,  5.0, 25.0, True),
    Model("claude-opus-5",     "Opus 5 (가장 깊음)",       1_000_000,  5.0, 25.0, True),
    Model("claude-fable-5",    "Fable 5 (최상위 · 가장 비쌈)", 1_000_000, 10.0, 50.0, True),
)

DEFAULT_MODEL = "claude-haiku-4-5"

# 「전체 진단」만 한 급 위를 쓴다. 이유는 비용이 아니라 **일의 성질**이다.
#
# 범위가 좁은 분석(부서 하나 · 용접사 하나 · 행 하나)은 재료가 작고 물음이
# 분명해서 Haiku로 충분하다. 반면 전체 AI분석 보고서는 38만 행에서 부서 12 x 팀 5 x
# 검사 27 = 1,620칸을 놓고 «어디에 무엇이 몰렸는가»를 골라내야 한다.
#
# 실측 비용 차이는 회차당 $0.16 -> $0.47이다. 30센트로 갈릴 일이 아니다.
DEEP_MODEL = "claude-sonnet-4-6"

_BY_ID = {m.id: m for m in MODELS}


def model_of(model_id: str | None) -> Model:
    """모델 하나. 모르는 이름이면 **기본으로 떨어지되 로그를 남긴다.**

    예외를 던지지 않는 이유: 설정 파일에 옛 모델 이름이 남아 있을 때 AI 기능만
    조용히 안 되는 것보다, 기본 모델로 돌면서 「이 이름을 모른다」를 남기는 편이
    고치기 쉽다.
    """
    m = _BY_ID.get((model_id or "").strip())
    if m is None:
        if model_id:
            logger.warning("모르는 모델 이름 %r — 기본(%s)으로 돈다", model_id, DEFAULT_MODEL)
        return _BY_ID[DEFAULT_MODEL]
    return m


def model_choices() -> list[dict]:
    """화면의 모델 선택 목록."""
    return [{"id": m.id, "label": m.label, "context": m.context,
             "in_price": m.in_price, "out_price": m.out_price} for m in MODELS]


# ── 오류 ─────────────────────────────────────────────────────────────────────
class AIError(RuntimeError):
    """화면에 그대로 보여도 되는 오류. **키는 절대 담지 않는다.**"""


class AITooLong(AIError):
    """입력이 모델의 창을 넘었다. 자르지 않고 여기서 멈춘다."""


def _client(api_key: str):
    if not _AVAILABLE:
        raise AIError("anthropic 패키지가 설치돼 있지 않습니다. "
                      "`pip install anthropic` 후 서버를 다시 띄우세요")
    if not (api_key or "").strip():
        raise AIError("Claude API 키가 설정돼 있지 않습니다. "
                      "'설정' 탭에서 관리자가 등록해야 합니다")
    return anthropic.Anthropic(api_key=api_key.strip())


def _explain(exc: Exception) -> str:
    """SDK 예외를 현업이 읽을 수 있는 한 문장으로.

    **원문을 그대로 내보내지 않는다** — 요청 본문이 섞여 나올 수 있고, 거기에는
    도면번호·용접사 번호가 들어 있다.
    """
    if not _AVAILABLE:
        return "anthropic 패키지가 없습니다"
    if isinstance(exc, anthropic.AuthenticationError):
        return "API 키가 올바르지 않습니다 (401)"
    if isinstance(exc, anthropic.PermissionDeniedError):
        return "이 키에 권한이 없습니다 (403)"
    if isinstance(exc, anthropic.NotFoundError):
        return "모델 이름을 찾을 수 없습니다 (404) — 설정에서 모델을 다시 고르세요"
    if isinstance(exc, anthropic.RateLimitError):
        return "요청이 몰려 잠시 거절되었습니다 (429). 잠시 뒤 다시 시도하세요"
    if isinstance(exc, anthropic.APIConnectionError):
        return ("api.anthropic.com에 연결하지 못했습니다. "
                "이 서버 PC가 외부로 나갈 수 있는지 IT에 확인이 필요합니다")
    if isinstance(exc, anthropic.APIStatusError):
        return f"API 오류 {exc.status_code}"
    return "호출에 실패했습니다"


# ── 토큰과 비용 ──────────────────────────────────────────────────────────────
def count_tokens(api_key: str, model_id: str, system: Any, messages: list[dict]) -> int:
    """보내기 «전»에 입력 토큰을 센다. 이 호출 자체는 무료다.

    화면의 «예상 비용»이 여기서 나온다. 재지 않고 부르면 사용자는 얼마가 나올지
    모르는 버튼을 누르게 된다.
    """
    m = model_of(model_id)
    try:
        r = _client(api_key).messages.count_tokens(
            model=m.id, system=system, messages=messages)
        return int(r.input_tokens)
    except AIError:
        raise
    except Exception as exc:                            # pragma: no cover
        logger.warning("토큰 계량 실패: %s", type(exc).__name__)
        raise AIError(_explain(exc)) from None


def estimate_cost(model_id: str, in_tokens: int, out_tokens: int) -> float:
    """달러. 출력은 «최대치»로 잡는다 — 적게 나오는 쪽으로 틀리는 편이 낫다."""
    m = model_of(model_id)
    return in_tokens / 1e6 * m.in_price + out_tokens / 1e6 * m.out_price


def check_input_fits(model_id: str, in_tokens: int, max_tokens: int) -> None:
    """창을 넘으면 **거부한다.** 자르지 않는다.

    자르면 모델이 «없는 데이터»로 판단하고, 그건 오류 없이 틀린 답이 나오는
    길이다. 대신 **무엇을 줄여야 하는지** 말해 준다.
    """
    m = model_of(model_id)
    need = in_tokens + max_tokens
    if need <= m.context:
        return
    raise AITooLong(
        f"입력이 {m.label}의 창을 넘습니다 "
        f"(입력 {in_tokens:,} + 출력 {max_tokens:,} > {m.context:,} 토큰). "
        f"범위를 좁혀서(부서·팀 단위로 나눠) 다시 실행하거나, "
        f"창이 더 큰 모델을 고르세요")


# ── 호출 ─────────────────────────────────────────────────────────────────────
def _thinking_params(m: Model, effort: str, budget: int) -> dict:
    """모델군에 맞는 «생각하기» 인자. **여기서만 분기한다.**

    섞어 보내면 400이 난다 — Haiku 4.5에 `effort`, 4.6+에 `budget_tokens`.
    """
    if m.adaptive:
        return {"thinking": {"type": "adaptive"},
                "output_config": {"effort": effort}}
    return {"thinking": {"type": "enabled", "budget_tokens": budget}}


def call(api_key: str, model_id: str, system: Any, messages: list[dict], *,
         max_tokens: int = 8000, effort: str = "high",
         thinking_budget: int = 4000,
         output_format: dict | None = None) -> dict:
    """한 번 부르고 `{text, usage}`를 돌려준다.

    `output_format`을 주면 구조화 출력으로 받는다 — 근거를 강제하려면 필수다.

    **스트리밍으로 받는다.** `max_tokens`가 크면 비스트리밍은 HTTP 타임아웃에
    걸린다. 화면에 조각을 흘리지 않더라도 `get_final_message()`로 받으면 된다.
    """
    m = model_of(model_id)
    client = _client(api_key)
    kwargs: dict[str, Any] = {
        "model": m.id,
        "max_tokens": max_tokens,
        "system": system,
        "messages": messages,
        **_thinking_params(m, effort, min(thinking_budget, max_tokens - 1)),
    }
    if output_format:
        # `output_config`가 이미 있을 수 있다(4.6+ 계열의 effort) — 합친다
        cfg = dict(kwargs.get("output_config") or {})
        cfg["format"] = output_format
        kwargs["output_config"] = cfg

    try:
        with client.messages.stream(**kwargs) as stream:
            msg = stream.get_final_message()
    except AIError:
        raise
    except Exception as exc:
        logger.warning("Claude 호출 실패: %s", type(exc).__name__)
        raise AIError(_explain(exc)) from None

    text = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
    u = msg.usage
    return {
        "text": text,
        "stop_reason": msg.stop_reason,
        "usage": {
            "input": int(getattr(u, "input_tokens", 0) or 0),
            "output": int(getattr(u, "output_tokens", 0) or 0),
            # 캐시가 먹고 있는지 화면이 보여 준다. 0이 계속 나오면 프리픽스를
            # 흔드는 무언가가 있다는 뜻이다(시각·UUID·정렬 안 된 dict).
            "cache_read": int(getattr(u, "cache_read_input_tokens", 0) or 0),
            "cache_write": int(getattr(u, "cache_creation_input_tokens", 0) or 0),
        },
        "model": m.id,
    }


def test_key(api_key: str) -> dict:
    """키가 실제로 먹는지 확인한다. **저장 시점에 한 번 부른다.**

    RUYA는 이게 없어서 「기능을 눌러야 키가 틀린 걸 알았다」. 여기서 확인하면
    «키가 틀렸다»와 «망이 막혔다»를 구분해 말해 줄 수 있다 — 둘은 전혀 다른
    문제이고 해결할 사람도 다르다.
    """
    try:
        ids = [m.id for m in _client(api_key).models.list(limit=1)]
        return {"ok": True, "message": "연결됐습니다", "sample": ids[:1]}
    except AIError as exc:
        return {"ok": False, "message": str(exc)}
    except Exception as exc:
        return {"ok": False, "message": _explain(exc)}
