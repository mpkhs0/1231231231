"""AI에게 줄 **재료를 모으는 유일한 곳.**

## 원칙 — AI는 숫자를 세지 않는다

집계는 전부 여기서(=기존 `result_store` 질의로) 끝낸다. 모델에게는 **해석만**
시킨다. 숫자를 모델이 세게 하면 그럴듯하게 틀린 값이 나오고, 그건 이 저장소가
가장 경계하는 실패 방식이다.

## 결정론적이어야 한다 — 프롬프트 캐싱이 여기 달려 있다

같은 회차면 **같은 바이트**가 나와야 한다. 캐싱은 프리픽스 일치라 dict 순서가
한 번만 흔들려도 캐시가 통째로 날아간다(입력비가 10배가 된다). 그래서:

- 모든 dict는 **정렬해서** 담는다
- 시각·UUID·난수를 넣지 않는다
- 목록은 «많은 순 → 이름 순»처럼 **동점까지 결정되는** 기준으로 정렬한다

## 행 원문은 보내지 않는다

집계와 «근거 행 번호»만 보낸다. 상세가 필요하면 채팅의 도구 호출이 그때
가져간다. 30만 행에서 행을 보내는 설계는 성립하지 않는다.
"""
from __future__ import annotations

import logging
from typing import Any

from .. import config
from . import rule_catalog, result_store

logger = logging.getLogger(__name__)

# 교차표에서 몇 줄까지 넣을 것인가. **자르는 것이 아니라 «상위 N»이다** —
# 꼬리는 원인 분석에 쓸모가 없고, 넣으면 입력만 커진다. 몇 줄을 봤는지는
# 함께 적어 보내므로 모델이 «전부 봤다»고 오해하지 않는다.
_CROSS_TOP = 25
_LIST_TOP = 20

# 조직 수는 프로젝트마다 다르다. 지금(부서 7)은 문제가 없지만 팀이 200개인
# 조직에서는 이쪽이 새 병목이 된다. 상위 N개만 싣고 **나머지는 합계로** 준다 —
# 빼 버리면 모델이 「이게 전부」라고 읽는다.
_DEPT_TOP = 15
_TEAM_TOP = 12

# 추세를 며칠까지 «일 단위»로 줄 것인가. 넘으면 주 -> 월로 묶는다.
#
# 실측(38만 행 · 2년 · 검사 27종): 일 단위 886,000토큰(어느 모델에도 안 들어간다)
# -> 주 단위 209,000 -> **월 단위 78,000**. 추세 블록이 payload의 95%를 먹는
# 유일한 자리이고, 나머지는 전부 행수와 무관한 집계다.
#
# 잃는 것도 거의 없다. 2년치를 일 단위로 주면 모델이 500개 점에서 «방향»을
# 읽어야 하는데 그건 사람도 못 한다.
_TREND_DAILY_MAX = 45
_TREND_WEEKLY_MAX = 200


def _check_sort_key(no: str) -> tuple:
    """공통(숫자)이 먼저, 프로젝트(문자 포함)가 뒤. 동점까지 결정돼야 한다 —
    순서가 흔들리면 프롬프트 캐시가 매번 날아간다."""
    s = str(no).strip()
    return (0, int(s), "") if s.isdigit() else (1, 0, s)


def _rate(n: int, d: int) -> float:
    return round(100.0 * n / d, 1) if d else 0.0


def _scope_block(r: dict) -> dict:
    """분석 범위 — **무엇을 안 보았는지**가 핵심이다.

    이것이 없으면 「9,995행을 검사했다」로 읽힌다. 실제 판정은 374행이다.
    """
    total = r.get("total_rows", 0)
    judged = r.get("judged_rows", 0)
    return {
        "원본_행수": total,
        "삭제": r.get("deleted_rows", 0),
        "임시부재_1C": r.get("temp_rows", 0),
        "미작업_WPS공란": r.get("unworked_rows", 0),
        "판정_대상": judged,
        "판정_대상_비율_퍼센트": _rate(judged, total),
        "결함_행": r.get("flagged_rows", 0),
        "정상_행": r.get("clean_rows", 0),
        "결함률_퍼센트": _rate(r.get("flagged_rows", 0), judged),
        "총_지적_건수": r.get("total_flags", 0),
        "프로젝트": r.get("project") or "",
        "검증_시각": r.get("run_at") or "",
    }


def _checks_block(r: dict) -> list[dict]:
    """검사 항목마다 «건수 · 관문 · 켜짐 · 판정 로직».

    `logic`(판정 근거 서술)을 함께 주는 것이 중요하다 — 없으면 모델이
    「Check 12」가 무엇인지 모른 채 건수만 보고 말을 지어낸다.
    """
    stats = r.get("stats") or {}
    scope = r.get("scope") or {}
    rules = r.get("rules") or {}
    catalog = rule_catalog.catalog()

    # 공통 항목은 `catalog()`에 `name`이 없다 — 이름은 판정 엔진이 갖고 있다.
    # 이름 없이 번호만 주면 모델이 「Check 12」가 무엇인지 모른 채 말을 만든다.
    from .verifier import CHECK_NAMES
    names = {str(k): v for k, v in CHECK_NAMES.items()}

    out: list[dict] = []
    for key in sorted(catalog, key=_check_sort_key):
        meta = catalog[key]
        enabled = rules.get(key, True)
        item = {
            "번호": key,
            "이름": meta.get("name") or names.get(key) or meta.get("summary", ""),
            "구분": meta.get("category", ""),
            "요약": meta.get("summary", ""),
            "판정_로직": meta.get("logic", ""),
            "지적_건수": int(stats.get(key, 0) or 0),
            "적용_대상_행수": scope.get(key),   # None이면 «전부가 대상»
            "켜짐": bool(enabled),
        }
        # **«대조 대상이 0건»과 «검사했고 위반 0»을 구분해 준다.**
        # 이걸 안 적으면 모델이 0건을 전부 «문제 없음»으로 읽는다.
        if item["적용_대상_행수"] == 0:
            item["주의"] = "대조할 대상이 0건 — 위반이 없는 것이 아니라 한 번도 판정하지 않았다"
        out.append(item)
    return out


def _departments_block(r: dict) -> list[dict]:
    depts = r.get("departments") or {}
    out: list[dict] = []
    for name in sorted(depts):
        d = depts[name] or {}
        judged = d.get("total_rows", 0)
        teams = []
        for tname in sorted(d.get("teams") or {}):
            t = (d["teams"] or {})[tname] or {}
            teams.append({
                "팀": tname,
                "판정_대상": t.get("total_rows", 0),
                "결함_행": t.get("defect_rows", 0),
                "결함률_퍼센트": _rate(t.get("defect_rows", 0), t.get("total_rows", 0)),
                "임시부재": t.get("temp_rows", 0),
                "미작업": t.get("unworked_rows", 0),
                "검사별_건수": {k: v for k, v in sorted((t.get("check_stats") or {}).items())},
            })
        out.append({
            "부서": name,
            "판정_대상": judged,
            "결함_행": d.get("defect_rows", 0),
            "결함률_퍼센트": _rate(d.get("defect_rows", 0), judged),
            "임시부재": d.get("temp_rows", 0),
            "미작업": d.get("unworked_rows", 0),
            "검사별_건수": {k: v for k, v in sorted((d.get("check_stats") or {}).items())},
            "팀": teams,
        })
    # 결함 많은 순 → 이름 순 (동점까지 결정된다)
    out.sort(key=lambda x: (-x["결함_행"], x["부서"]))

    # **상위만 싣되, 뺀 것을 합계로 말한다.** 그냥 빼면 모델이 「이게 전부」로
    # 읽고 「부서 3곳에서만 나왔다」 같은 문장을 쓴다.
    for d in out:
        teams = d.get("팀") or []
        if len(teams) > _TEAM_TOP:
            teams.sort(key=lambda t: (-t["결함_행"], t["팀"]))
            rest = teams[_TEAM_TOP:]
            d["팀"] = teams[:_TEAM_TOP]
            d["팀_나머지"] = {
                "팀_수": len(rest),
                "판정_대상": sum(t["판정_대상"] for t in rest),
                "결함_행": sum(t["결함_행"] for t in rest),
                "주의": f"결함 적은 팀 {len(rest)}개는 합계로만 실었다",
            }
    if len(out) > _DEPT_TOP:
        rest = out[_DEPT_TOP:]
        out = out[:_DEPT_TOP]
        out.append({
            "부서": f"(나머지 {len(rest)}개 부서 합계)",
            "판정_대상": sum(x["판정_대상"] for x in rest),
            "결함_행": sum(x["결함_행"] for x in rest),
            "결함률_퍼센트": _rate(sum(x["결함_행"] for x in rest),
                                  sum(x["판정_대상"] for x in rest)),
            "임시부재": sum(x["임시부재"] for x in rest),
            "미작업": sum(x["미작업"] for x in rest),
            "검사별_건수": {}, "팀": [],
            "주의": "결함 적은 부서를 묶은 줄이다. 개별 수치는 여기 없다.",
        })
    return out


def _capped(rows: list[dict]) -> dict:
    """상위 N줄 + **그 N줄이 전체의 몇 %인가.**

    커버리지를 안 주면 「NF130에 몰렸다」가 나온다 — 블록이 3,000개고 상위
    25개가 전체의 5%일 때도 똑같이 그렇게 쓴다. 「상위 25개 = 전체의 82%」와
    「= 5%」는 전혀 다른 이야기인데, 수치만 봐서는 구분할 수가 없다.
    """
    top = rows[:_CROSS_TOP]
    whole = sum(r.get("rows", 0) for r in rows)
    shown = sum(r.get("rows", 0) for r in top)
    out = {"전체_조합수": len(rows), "상위": top}
    if len(rows) > len(top):
        out["상위_N_비중_퍼센트"] = _rate(shown, whole)
        out["주의"] = (f"{len(rows)}개 중 상위 {len(top)}개만 실었다"
                       f"(전체 결함 행의 {_rate(shown, whole)}%). "
                       "여기 없는 것이 0이라는 뜻이 아니다.")
    return out


def _cross_block() -> dict:
    """근본 원인 분석의 재료. **어디에 몰리는가**를 축을 바꿔 가며 센다.

    ## 단일 축을 «먼저» 준다 — 모델에게 덧셈을 시키지 않는다

    실측으로 그렇게 틀렸다. 「블록별 결함」을 물었더니 모델이 `검사x블록`을 합쳐
    「NF130 26 · NF110 8」이라고 썼는데 실제는 **28 · 6**이었다(Check 13의
    NF130 2건을 빠뜨렸다). 이 설계의 원칙은 «AI는 숫자를 세지 않는다»인데,
    합계를 안 주면 결국 세게 만드는 셈이다.

    ## «행»과 «건»은 다르다

    `cross_stats`는 **결함 행**(중복 제거)을 센다. `검사_항목.지적_건수`는
    **지적 건수**다 — 한 행에 여러 Check가 걸리면 건수가 더 많다. 둘을 같은
    이름으로 부르면 합이 안 맞는 표가 나간다.
    """
    out: dict[str, Any] = {
        "읽는_법": "여기 수치는 모두 «결함 행» 수(한 행에 여러 지적이 있어도 1)다. "
                   "«지적 건수»는 검사_항목의 지적_건수를 보라 — 둘은 다르다.",
    }

    # ① 단일 축 — 합계를 그대로 준다
    for label, axes in (("블록별", ("block",)),
                        ("부서별", ("department",)),
                        ("팀별", ("team",)),
                        ("WPS별", ("wps",)),
                        ("재질별", ("material",)),
                        ("용접사별", ("welder",)),
                        ("검사별", ("check",))):
        try:
            rows = result_store.cross_stats(axes)
        except Exception:
            logger.warning("단일 축 집계 실패: %s", label)
            continue
        out[label] = _capped(rows)

    # ② 두 축 교차 — «어디에 몰리는가»
    for label, axes in (("검사x부서", ("check", "department")),
                        ("검사x블록", ("check", "block")),
                        ("검사x WPS", ("check", "wps")),
                        ("검사x재질", ("check", "material")),
                        ("검사x용접사", ("check", "welder")),
                        ("블록x용접사", ("block", "welder"))):
        try:
            rows = result_store.cross_stats(axes)
        except Exception:
            logger.warning("교차 집계 실패: %s", label)
            continue
        out[label] = _capped(rows)
    return out


def _bucket_of(date: str, unit: str) -> str:
    """날짜를 묶음 이름으로. 문자열만 만진다 — `date` 파싱은 형식이 흔들리면
    통째로 죽는데, 여기서 죽으면 추세가 조용히 빈다."""
    s = str(date or "")
    if unit == "month":
        return s[:7]                       # 2026-07
    if unit == "week":
        try:
            from datetime import date as _d
            y, m, dd = (int(x) for x in s[:10].split("-"))
            iso = _d(y, m, dd).isocalendar()
            return f"{iso[0]}-W{iso[1]:02d}"
        except Exception:
            return s[:7]
    return s


def _trend_unit(n_dates: int) -> tuple[str, str]:
    """`(묶음, 사람이 읽을 이름)`. **몇 날짜인가로 정한다.**"""
    if n_dates <= _TREND_DAILY_MAX:
        return "day", "일"
    if n_dates <= _TREND_WEEKLY_MAX:
        return "week", "주"
    return "month", "월"


def _trend_block(r: dict) -> dict:
    """**분모와 짝지어** 낸다. 건수만 주면 물량이 는 날이 «악화»로 읽힌다.

    ## 기간이 길면 묶는다

    38만 행 · 2년이면 날짜가 500개고 검사가 27종이라 점이 13,500개다. 실측
    886,000토큰 — **어느 모델의 창에도 안 들어간다**(Haiku 20만, Sonnet 100만).
    월 단위로 묶으면 78,000토큰이 된다.

    묶을 때 **결함률을 평균 내지 않는다.** 날짜별 비율의 평균은 그 달의 비율이
    아니다(물량이 적은 날이 같은 무게를 갖는다). 분자와 분모를 각각 더한 뒤
    나눈다.
    """
    judged = {x["date"]: x["count"] for x in (r.get("judged_trend_by_date") or [])}
    try:
        by_check = result_store.check_trends()
    except Exception:
        logger.warning("Check별 추이 조회 실패")
        by_check = {}

    unit, label = _trend_unit(len(judged))

    base: dict[str, int] = {}
    for d, n in judged.items():
        k = _bucket_of(d, unit)
        base[k] = base.get(k, 0) + n

    series: dict[str, list[dict]] = {}
    for chk in sorted(by_check):
        acc: dict[str, int] = {}
        for p in by_check[chk]:
            k = _bucket_of(p["date"], unit)
            acc[k] = acc.get(k, 0) + p["count"]
        series[chk] = [{"구간": k, "결함_행": acc[k],
                        "그_구간_판정_대상": base.get(k, 0),
                        "결함률_퍼센트": _rate(acc[k], base.get(k, 0))}
                       for k in sorted(acc)]

    return {
        "묶음_단위": label,
        "설명": f"가로축은 **{label} 단위**다. 결함률 = 그 구간의 결함 행 / "
                "그 구간의 판정 대상 행. 건수만 보면 물량이 는 구간이 «악화»로 보인다."
                + ("" if unit == "day" else
                   f" 원래 용접일은 {len(judged)}일치인데 {label} 단위로 묶었다 — "
                   "구간 안의 하루하루는 여기서 알 수 없다."),
        "구간별_판정_대상": [{"구간": k, "판정_대상": base[k]} for k in sorted(base)],
        "검사별": series,
    }


def _health_block(r: dict) -> dict:
    """규칙 건강 — «0건»이 어느 쪽 뜻인지, 빌려 온 값은 없는지."""
    scope = r.get("scope") or {}
    return {
        "경고": r.get("rule_health") or [],
        "적용_대상_0건인_검사": sorted(k for k, v in scope.items() if v == 0),
        "빌려온_값_확인필요": r.get("provisional") or {},
        "판정_근거_결손": (r.get("basis") or {}),
        "억제된_공통검사": r.get("suppression") or {},
    }


def _review_block(r: dict) -> dict:
    """현업 검토가 얼마나 진행됐는가. 안 적으면 모델이 «검토 끝난 결과»로 읽는다."""
    try:
        from . import feedback_store
        fb = feedback_store.load_feedback()
        counts = result_store.review_counts(fb)
    except Exception:
        logger.warning("검토 집계 실패")
        return {}
    return {
        "대조_대상_지적": counts.get("total", 0),
        "검토_완료": counts.get("reviewed", 0),
        "미검토": counts.get("unreviewed", 0),
        "이번_회차_판정별": {k: v for k, v in sorted((counts.get("by_result") or {}).items())},
        "기록_파일_전체_판정별": {k: v for k, v in
                                sorted((counts.get("by_result_all") or {}).items())},
    }


def _recurring_block(r: dict) -> list[dict]:
    """반복 패턴 — 이미 한국어 한 문장으로 만들어져 있다."""
    out: list[dict] = []
    for name in sorted(r.get("departments") or {}):
        d = (r["departments"] or {})[name] or {}
        for p in (d.get("recurring_patterns") or []):
            out.append({
                "부서": name,
                "용접사": p.get("welder_no", ""),
                "검사": str(p.get("check_no", "")),
                "건수": p.get("count", 0),
                "서로_다른_날짜": p.get("distinct_dates", 0),
                "기간": f"{p.get('first_date', '')} ~ {p.get('last_date', '')}",
                "요약": p.get("summary", ""),
            })
    out.sort(key=lambda x: (-x["건수"], x["부서"], x["용접사"]))
    return out[:_LIST_TOP]


def _anomaly_block(r: dict) -> dict:
    ml = ((r.get("ml") or {}).get("unsupervised") or {})
    meta = ml.get("meta") or {}
    if not meta:
        return {}
    return {
        "학습_행수": meta.get("total_rows", 0),
        "이상치_건수": meta.get("anomaly_count", 0),
        "임계_비율": meta.get("contamination"),
        "설명": (meta.get("model") or {}).get("note", ""),
        "주의": "이상치는 규칙 위반이 아니라 «드문 조합»이다. 사람이 확인할 후보다.",
    }


def _qual(w: dict) -> dict:
    """자격 정보. **키 이름은 `welder_info`가 실제로 내보내는 것이다.**

    한 번 틀렸다: `process` · `class` · `expire`로 읽었는데 실제 키는
    `processes` · `classes`이고 만료일은 아예 없다. `.get()`이 조용히 None을
    돌려주어 예외도 경고도 나지 않았고, AI가 「자격 정보 전무」라고 **자신 있게**
    썼다. `tests/test_ai_welder_fields.py`가 이 키들을 못 박는다.
    """
    cert = ""
    if w.get("first_cert_date"):
        cert = str(w["first_cert_date"])
        last = str(w.get("last_cert_date") or "")
        if last and last != cert:
            cert += f" ~ {last}"
    return {
        "이름": w.get("name", ""),
        "자격DB_등록": bool(w.get("registered")),
        "퇴사": bool(w.get("retired")),
        "보유_공정": list(w.get("processes") or []),
        "자세": list(w.get("positions") or []),
        "선급": list(w.get("classes") or []),
        "규격": list(w.get("specs") or []),
        "자격_취득": cert,
        "인증_건수": w.get("cert_count", 0),
    }


def _welder_block(r: dict) -> list[dict]:
    """결함률 상위 용접사. 자격도 함께 준다 — 자격과 결함의 관계가 재료다."""
    info = r.get("welder_info") or {}
    out: list[dict] = []
    for row in (r.get("welder_defect_rate") or []):
        wno = str(row.get("welder_no", ""))
        w = info.get(wno) or {}
        out.append({
            "용접사": wno,
            "시공_건수": row.get("total", 0),
            "결함_건수": row.get("defect", 0),
            "결함률_퍼센트": row.get("rate", 0),
            **_qual(w),
        })
    out.sort(key=lambda x: (-x["결함률_퍼센트"], -x["시공_건수"], x["용접사"]))
    return out[:_LIST_TOP]


def _load() -> dict:
    """**저장소를 거친 결과**를 쓴다 — 화면이 보는 것과 같은 숫자여야 한다."""
    r = result_store.load_latest(include_row_raw=False, include_unworked=False,
                                 include_flags=False)
    if not r:
        raise ValueError("검증 결과가 없습니다. 먼저 검증을 실행하세요")
    return r


def _checks_subset(r: dict, keys) -> list[dict]:
    """이 범위에 **실제로 걸린 검사**의 설명만 추린다.

    27개 항목의 판정 로직을 전부 실으면 부서 하나를 보는 데도 재료가 커진다.
    반대로 아예 빼면 모델이 「Check 12」가 무엇인지 모른 채 건수만 보고 말을
    지어낸다 — 그래서 «걸린 것»만 남긴다.
    """
    want = {str(k) for k in keys}
    return [c for c in _checks_block(r) if c["번호"] in want]


# ── 종류별 재료 ──────────────────────────────────────────────────────────────
def build_overall() -> dict:
    """대시보드 «전체 진단» — 가장 큰 재료."""
    r = _load()
    return {
        "분석_범위": _scope_block(r),
        "검사_항목": _checks_block(r),
        "부서": _departments_block(r),
        "교차_집계": _cross_block(),
        "추세": _trend_block(r),
        "반복_패턴": _recurring_block(r),
        "용접사_상위": _welder_block(r),
        "이상치": _anomaly_block(r),
        "규칙_건강": _health_block(r),
        "검토_진행": _review_block(r),
    }


def build_trend() -> dict:
    """Check별 결함 트렌드 — **분모와 짝지어** 준다."""
    r = _load()
    return {
        "분석_범위": _scope_block(r),
        "검사_항목": _checks_subset(r, (r.get("stats") or {}).keys()),
        "추세": _trend_block(r),
        "반복_패턴": _recurring_block(r),
    }


def build_dept(dept: str, team: str | None = None) -> dict:
    """부서 또는 팀 하나. **전체 평균을 함께 준다** — 없으면 비교가 안 된다.

    「결함률 9%」는 그 자체로 좋지도 나쁘지도 않다. 전체가 5%인지 20%인지에
    따라 뜻이 정반대인데, 모델에게 전체를 안 주면 그걸 알 수가 없다.
    """
    r = _load()
    depts = r.get("departments") or {}
    d = depts.get(dept)
    if not d:
        raise ValueError(f"그런 부서가 없습니다: {dept}")
    bucket = d
    if team:
        bucket = (d.get("teams") or {}).get(team)
        if not bucket:
            raise ValueError(f"{dept}에 그런 팀이 없습니다: {team}")

    judged = bucket.get("total_rows", 0)
    stats = {k: v for k, v in sorted((bucket.get("check_stats") or {}).items())}

    # 이 조직만의 추이. **분모가 없다** — `judged_trend_by_date`는 전사 값이다.
    # 그래서 건수만 주고 «방향을 단정하지 말라»고 함께 적는다.
    try:
        trend = result_store.check_trends(dept=dept, team=team)
    except Exception:
        logger.warning("조직 추이 조회 실패: %s / %s", dept, team)
        trend = {}

    whole = _scope_block(r)
    return {
        "대상": {"부서": dept, "팀": team or "", "단위": "팀" if team else "부서"},
        "전체_평균": {
            "판정_대상": whole["판정_대상"],
            "결함_행": whole["결함_행"],
            "결함률_퍼센트": whole["결함률_퍼센트"],
            "부서_수": len(depts),
        },
        "이_조직": {
            "판정_대상": judged,
            "결함_행": bucket.get("defect_rows", 0),
            "결함률_퍼센트": _rate(bucket.get("defect_rows", 0), judged),
            "임시부재": bucket.get("temp_rows", 0),
            "미작업": bucket.get("unworked_rows", 0),
            "검사별_지적_건수": stats,
        },
        "같은_부서의_팀들": ([
            {"팀": t, "판정_대상": v.get("total_rows", 0),
             "결함_행": v.get("defect_rows", 0),
             "결함률_퍼센트": _rate(v.get("defect_rows", 0), v.get("total_rows", 0))}
            for t, v in sorted((d.get("teams") or {}).items())
        ] if not team else []),
        "검사_항목": _checks_subset(r, stats.keys()),
        "용접사": [
            {"용접사": w.get("welder_no", ""), "시공_건수": w.get("total", 0),
             "결함_건수": w.get("defect", 0), "결함률_퍼센트": w.get("rate", 0)}
            for w in (bucket.get("welder_defect_rate") or [])[:_LIST_TOP]
        ],
        "반복_패턴": [p for p in _recurring_block(r) if p["부서"] == dept],
        "추세_건수만": {
            "주의": "이 표에는 **분모가 없다**(그날 이 조직이 몇 행을 판정했는지 모른다). "
                    "건수가 는 것을 «악화»라고 단정하지 마라.",
            "검사별": {k: trend[k] for k in sorted(trend)},
        },
        "부서_순위": [
            {"부서": x["부서"], "판정_대상": x["판정_대상"],
             "결함_행": x["결함_행"], "결함률_퍼센트": x["결함률_퍼센트"]}
            for x in _departments_block(r)
        ],
    }


def build_welder(welder_no: str) -> dict:
    """용접사 한 사람. **자격과 결함의 관계**가 재료다."""
    r = _load()
    wno = str(welder_no).strip()
    info = (r.get("welder_info") or {}).get(wno) or {}
    rate = next((w for w in (r.get("welder_defect_rate") or [])
                 if str(w.get("welder_no", "")) == wno), None)
    if not info and not rate:
        raise ValueError(f"그런 용접사가 없습니다: {wno}")

    # Check 6은 «그 사람의 등록 사무» 문제라 시공 품질과 성격이 다르다.
    # 결함률 계산에서 이미 빠져 있으므로 여기서도 갈라서 보여준다.
    got = result_store.query_flags(welder=wno, limit=config.MAX_FLAG_PAGE)
    by_check: dict[str, int] = {}
    dates: dict[str, int] = {}
    blocks: dict[str, int] = {}
    for f in got["items"]:
        c = str(f.get("check_no", ""))
        by_check[c] = by_check.get(c, 0) + 1
        if f.get("weld_date"):
            dates[str(f["weld_date"])] = dates.get(str(f["weld_date"]), 0) + 1
        if f.get("block"):
            blocks[str(f["block"])] = blocks.get(str(f["block"]), 0) + 1

    return {
        "대상": {"용접사": wno, "이름": info.get("name", "")},
        "자격": {
            **_qual(info),
            # 한 사람이 여러 조직에 걸치는 일이 있다 — 하나로 뭉개면 «어느 팀의
            # 문제인가»를 물었을 때 없는 팀 이름이 나온다.
            "소속": [{"부서": o.get("department", ""), "팀": o.get("team", ""),
                     "행수": o.get("rows", 0)}
                    for o in (info.get("orgs") or [])],
        },
        "시공과_결함": {
            "시공_건수": (rate or {}).get("total", 0),
            "결함_건수": (rate or {}).get("defect", 0),
            "결함률_퍼센트": (rate or {}).get("rate", 0),
            "주의": "결함률에서 Check 6(자격 미등록)은 빠져 있다 — 그 행의 시공 품질 "
                    "문제가 아니라 등록 사무의 문제이기 때문이다.",
        },
        "전체_평균": {
            "전체_결함률_퍼센트": _rate(r.get("flagged_rows", 0), r.get("judged_rows", 0)),
            "용접사_수": len(r.get("welder_defect_rate") or []),
        },
        "표본": {"읽은_지적": len(got["items"]), "전체_지적": got["total"],
                **({"주의": "상한에 걸려 일부만 읽었다 — 아래 수치는 표본이다"}
                   if got["total"] > len(got["items"]) else {})},
        "검사별_지적_건수": {k: by_check[k] for k in sorted(by_check, key=_check_sort_key)},
        "검사_항목": _checks_subset(r, by_check.keys()),
        # **분모가 있다.** `date_stats[].total`이 그날 이 사람의 시공 행수다.
        # 건수만 주면 많이 일한 날이 «악화»로 읽힌다 — 용접사 화면이 이미 같은
        # 이유로 결함률을 그린다.
        "날짜별": [
            {"날짜": e.get("date", ""),
             "시공_행수": e.get("total", 0),
             "지적_건수": sum((e.get("checks") or {}).values()),
             "결함률_퍼센트": _rate(sum((e.get("checks") or {}).values()),
                                  e.get("total", 0)),
             "검사별": {k: v for k, v in sorted((e.get("checks") or {}).items()) if v}}
            for e in (info.get("date_stats") or [])
        ],
        "날짜별_지적_건수_주의": "위 «날짜별»에는 분모가 있다. 아래 표만 보고 "
                                "방향을 말하지 마라." if dates else "",
        "블록별_지적_건수": [{"블록": b, "건수": blocks[b]}
                            for b in sorted(blocks, key=lambda x: (-blocks[x], x))][:_LIST_TOP],
        "반복_패턴": [p for p in _recurring_block(r) if p["용접사"] == wno],
    }


def build_anomaly() -> dict:
    """이상치 해설 — **규칙 위반이 아니라 «드문 조합»이다.**"""
    r = _load()
    ml = ((r.get("ml") or {}).get("unsupervised") or {})
    meta = ml.get("meta") or {}
    if not meta:
        raise ValueError(
            "이상치 결과가 없습니다 (scikit-learn 미설치이거나 Check 13이 꺼져 있습니다)")

    detail = ml.get("detail") or {}
    rows = []
    for key in sorted(detail, key=lambda x: str(x))[:_LIST_TOP]:
        d = detail[key] or {}
        rows.append({
            "행": key,
            "이유": d.get("reason", ""),
            "벗어난_항목": d.get("deviations") or [],
            "비슷한_행": (d.get("peers") or [])[:5],
        })
    return {
        "분석_범위": _scope_block(r),
        "모델": {
            "학습_행수": meta.get("total_rows", 0),
            "이상치_건수": meta.get("anomaly_count", 0),
            "임계_비율": meta.get("contamination"),
            "설명": (meta.get("model") or {}).get("note", ""),
            "사용_항목": meta.get("fields") or [],
            "주의": "임계는 **사람이 넣은 가정**이다. 모델이 「N건이 이상하다」고 판단한 "
                    "것이 아니라 점수 상위 몇 퍼센트를 자른 것이다. 매 검증마다 새로 "
                    "학습하므로 «이번 데이터 안에서 상대적으로 드문 것»이다.",
        },
        "이상치_행": rows,
        "교차_집계": _cross_block(),
    }


def build_falsepos() -> dict:
    """오탐 후보 선별 — **현업의 판단 근거(검토 의견)가 유일한 출처다.**"""
    r = _load()
    try:
        from . import feedback_store
        fb = feedback_store.load_feedback()
    except Exception:
        logger.warning("검토 기록 조회 실패")
        fb = {}

    # 이미 «오탐»으로 판정된 것들의 근거 문구. 같은 문구가 여러 건에 붙으므로
    # **문구 단위로 묶는다** — 수백 건을 그대로 실으면 재료만 커지고 읽을 것은 같다.
    by_remark: dict[tuple[str, str], dict] = {}
    for _key, rec in fb.items():
        if not isinstance(rec, dict) or (rec.get("result") or "") != "오탐":
            continue
        chk = str(rec.get("check_no", ""))
        note = (rec.get("remark") or "").strip()
        slot = by_remark.setdefault((chk, note), {"검사": chk, "근거": note,
                                                  "건수": 0, "예시_WPS": set()})
        slot["건수"] += 1
        if rec.get("wps_no"):
            slot["예시_WPS"].add(str(rec["wps_no"]))
    basis = sorted(
        ({"검사": v["검사"], "근거": v["근거"], "건수": v["건수"],
          "예시_WPS": sorted(v["예시_WPS"])[:5]} for v in by_remark.values()),
        key=lambda x: (-x["건수"], x["검사"], x["근거"]))[:_LIST_TOP]

    # 미검토 지적을 검사별로 묶어 «성격»만 보여준다. 행 원문은 보내지 않는다.
    got = result_store.query_flags(limit=config.MAX_FLAG_PAGE)
    pend: dict[str, dict] = {}
    for f in got["items"]:
        k = (f"{(f.get('drawing_no') or '').strip()}|{(f.get('joint_no') or '').strip()}"
             f"|{(f.get('wps_no') or '').strip()}|{f.get('check_no')}")
        if k in fb:
            continue
        chk = str(f.get("check_no", ""))
        slot = pend.setdefault(chk, {"검사": chk, "미검토_건수": 0,
                                     "WPS": {}, "예시_메시지": ""})
        slot["미검토_건수"] += 1
        w = str(f.get("wps_no") or "")
        if w:
            slot["WPS"][w] = slot["WPS"].get(w, 0) + 1
        if not slot["예시_메시지"]:
            slot["예시_메시지"] = str(f.get("msg") or "")
    pending = [
        {"검사": v["검사"], "미검토_건수": v["미검토_건수"],
         "예시_메시지": v["예시_메시지"],
         "WPS별": sorted(({"wps": w, "건수": n} for w, n in v["WPS"].items()),
                         key=lambda x: (-x["건수"], x["wps"]))[:10]}
        for v in sorted(pend.values(), key=lambda x: (-x["미검토_건수"], x["검사"]))
    ]

    # **잘렸으면 잘렸다고 말한다.** 이걸 빼면 「Check 4 미검토 1,200건」이
    # 실제로는 17,000건인데 그대로 나간다 — 오류도 경고도 없다. 실측 비율
    # (지적 ÷ 판정 ≈ 0.76)로 판정 26,000행부터 상한에 닿는다.
    read = len(got["items"])
    note = {"읽은_지적": read, "전체_지적": got["total"]}
    if got["total"] > read:
        note["주의"] = (f"전체 {got['total']:,}건 중 앞 {read:,}건만 읽었다"
                        f"(약 {_rate(read, got['total'])}%). 아래 «미검토 건수»는 "
                        "그 표본 안의 수치이므로 **전체 건수로 말하지 마라.**")

    return {
        "분석_범위": _scope_block(r),
        "검토_진행": _review_block(r),
        "표본": note,
        "기존_오탐_판정의_근거": basis,
        "미검토_지적": pending,
        "검사_항목": _checks_subset(r, [p["검사"] for p in pending]),
        "주의": "여기서 나오는 것은 «사람이 먼저 볼 후보»이지 판정이 아니다. "
                "기존 오탐 판정이 0건이면 후보를 만들어 내지 마라.",
    }


def build_rules() -> dict:
    """규칙 건강 — 검사가 **죽어 있지 않은가**를 본다."""
    r = _load()
    try:
        from . import wps_rules
        params = rule_catalog.active_params()
        param_health = wps_rules.check_params(params)
    except Exception:
        logger.warning("프로젝트 값 점검 실패")
        params, param_health = {}, []
    return {
        "분석_범위": _scope_block(r),
        "검사_항목": _checks_block(r),
        "규칙_건강": _health_block(r),
        "프로젝트_값": {k: params[k] for k in sorted(params)} if params else {},
        "값_점검": param_health,
        "프로젝트_규칙": rule_catalog.active_checks(),
        "활성_프로파일": rule_catalog.active_profile_name(),
    }


def build_quality() -> dict:
    """기록 품질 — **판정 대상은 아닌데 기록이 이상한** 것."""
    r = _load()
    got = result_store.query_flags(limit=config.MAX_FLAG_PAGE)
    items = got["items"]
    blank_report = sum(1 for f in items if not str(f.get("ndt_report") or "").strip())
    blank_date = sum(1 for f in items if not str(f.get("weld_date") or "").strip())
    blank_block = sum(1 for f in items if not str(f.get("block") or "").strip())
    return {
        "분석_범위": _scope_block(r),
        "지적된_행의_기록_공란": {
            "표본_지적_건수": len(items),
            "전체_지적_건수": got["total"],
            "NDT_REPORT_공란": blank_report,
            "용접일_공란": blank_date,
            "블록_공란": blank_block,
            "주의": "NDT REPORT 공란은 **NDT 계획이 없는 행에서 정상**이다"
                    "(실측 전체의 44.8%). 「채워야 한다」고 말하기 전에 비어 있는 것이 "
                    "정상인 자리인지 먼저 가려라.",
        },
        "미작업": {
            "행수": r.get("unworked_rows", 0),
            "판정_기준": "WPS No(AJ열) 공란. 실데이터 전수 확인 결과 WPS 공란 행은 "
                        "우측 실적 컬럼이 100% 공란이었다.",
        },
        "임시부재_1C": {
            "행수": r.get("temp_rows", 0),
            "판정_기준": "1C 도면. 임시 용접이라 작업도 결과 처리도 불완전해 "
                        "판정 대상이 아니다.",
        },
        "삭제": r.get("deleted_rows", 0),
        "규칙_건강": _health_block(r),
        "검토_진행": _review_block(r),
    }


def build_review(item_id: str) -> dict:
    """§11 미결 항목 하나 — **답변 «초안»이지 결론이 아니다.**"""
    r = _load()
    from . import review_items
    items = review_items.load_items()
    item = next((x for x in items if str(x.get("id")) == str(item_id)), None)
    if not item:
        raise ValueError(f"그런 항목이 없습니다: 11-{item_id}")
    return {
        "항목": {
            "번호": item.get("id", ""),
            "상태": item.get("status_label", ""),
            "제목": item.get("title", ""),
            "본문": item.get("body", ""),
            "기존_답변": item.get("answer") or {},
        },
        "분석_범위": _scope_block(r),
        "검사_항목": _checks_block(r),
        "규칙_건강": _health_block(r),
        "교차_집계": _cross_block(),
    }


def build_row(row_no: int | str) -> dict:
    """지적된 행 하나. **원문을 보내는 유일한 자리다** — 한 행뿐이라 성립한다."""
    r = _load()
    got = result_store.query_flags(rows=[int(row_no)], limit=200)
    if not got["items"]:
        raise ValueError(f"{row_no}행에 지적이 없습니다")
    first = got["items"][0]
    raw = result_store.get_row_raw(row_no) or []
    checks = {str(f.get("check_no", "")) for f in got["items"]}
    return {
        "행": int(row_no),
        "지적": [
            {"검사": str(f.get("check_no", "")), "이름": f.get("check_name", ""),
             "메시지": f.get("msg", ""), "기준값": f.get("expected", ""),
             "실제값": f.get("actual", ""), "마킹_열": f.get("col_letter", "")}
            for f in got["items"]
        ],
        "행_정보": {
            "도면번호": first.get("drawing_no", ""),
            "Joint No": first.get("joint_no", ""),
            "WPS No": first.get("wps_no", ""),
            "블록": first.get("block", ""),
            "부서": first.get("department", ""),
            "팀": first.get("team", ""),
            "용접일": first.get("weld_date", ""),
            "NDT REPORT": first.get("ndt_report", ""),
        },
        "원본_셀": [x for x in raw
                    if isinstance(x, dict) and str(x.get("value", "")).strip()],
        "검사_항목": _checks_subset(r, checks),
    }


# 종류 -> 재료 만드는 함수. 라우터는 이 표만 본다.
BUILDERS = {
    "overall":  lambda sc: (build_overall(), ""),
    "trend":    lambda sc: (build_trend(), ""),
    "dept":     lambda sc: (build_dept(sc["dept"], sc.get("team")),
                            sc["dept"] + (" / " + sc["team"] if sc.get("team") else "")),
    "welder":   lambda sc: (build_welder(sc["welder"]), "용접사 " + str(sc["welder"])),
    "anomaly":  lambda sc: (build_anomaly(), ""),
    "falsepos": lambda sc: (build_falsepos(), ""),
    "rules":    lambda sc: (build_rules(), ""),
    "quality":  lambda sc: (build_quality(), ""),
    "review":   lambda sc: (build_review(sc["item"]), "검증사항 " + str(sc["item"])),
    "row":      lambda sc: (build_row(sc["row"]), str(sc["row"]) + "행"),
}


def build(kind: str, scope: dict | None = None) -> tuple[dict, str]:
    """`(재료, 대상 설명)`.

    **모르는 종류는 거부한다.** 기본값으로 흘려보내면 「부서 진단을 눌렀는데
    전체 AI분석 보고서가 나오는」 상태가 되고, 그건 오류가 아니라 «틀린 글»이라
    아무도 눈치채지 못한다.
    """
    fn = BUILDERS.get(kind)
    if not fn:
        raise ValueError(f"모르는 분석 종류: {kind!r} (가능: {sorted(BUILDERS)})")
    try:
        return fn(scope or {})
    except KeyError as exc:
        raise ValueError(f"{kind} 분석에는 {exc.args[0]} 값이 필요합니다") from None
