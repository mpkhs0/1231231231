"""분석 «종류»마다의 프롬프트 · 출력 스키마 · **근거 검사.**

## 종류가 열이지만 «모양»은 하나다

대시보드 AI분석 보고서, 부서 진단, 용접사 코칭, 이상치 해설… 물음은 다르지만
돌려주는 모양은 전부 같다:

    {grade, headline, sections: [{id, title, claims: [{text, evidence}]}]}

그래서 **화면 부품이 하나**다. 종류마다 카드를 따로 만들면 근거 칩·비용 확인·
중복 클릭 잠금 같은 것을 열 벌 만들게 되고, 그중 하나는 반드시 빠진다.
종류가 바꾸는 것은 `KINDS`의 한 줄 — 절 이름과 물음뿐이다.

## 왜 AI분석 보고서 형식인가

지금 화면은 「Check 12가 22건」까지만 말한다. AI분석 보고서는 **범위 · 기준 ·
발견사항 · 근거 · 시정요구 · 한계**를 갖춘 글이다. 절을 그렇게 잡으면
모델이 «느낌»이 아니라 «보고»를 쓴다.

**1절과 마지막 절이 이 글을 «보고»로 만든다.** 1절이 없으면 「9,995행을
검사했다」로 읽히는데 실제 판정은 374행이다. 한계 절이 없으면 나머지가
전부 과신이 된다.

## 근거를 서버가 강제한다

현업 결정(2026-08-21): 「문장마다 수치 근거를 강제한다」.

프롬프트로만 부탁하면 지켜지지 않는 날이 온다. 그래서 **구조화 출력**으로
`evidence`를 필수 항목으로 받고, **비어 있는 주장은 서버가 버린다.**
버린 개수는 화면에 그대로 알린다 — 조용히 버리면 «AI가 그것밖에 말 안 했다»가
된다.
"""
from __future__ import annotations

import json
import logging
from typing import Any

logger = logging.getLogger(__name__)

# 중대성. **RUYA 양식에서 가져온 유일한 것**이고, 그럴 만하다 — 색 띠 하나로
# 「먼저 볼 것」이 눈에 들어온다. 우리 쪽에서는 여기에 규칙을 하나 더 건다:
# 등급(`grade`)과 어긋나면 안 된다. 「양호」인데 high가 셋이면 둘 중 하나가 틀렸다.
SEVERITIES = ("high", "medium", "low", "info")

# 근거의 종류. 화면이 이 값으로 «어디로 보낼지»를 정한다.
EVIDENCE_KINDS = ("check", "department", "team", "block", "wps",
                  "material", "welder", "trend", "health", "scope", "row")


# ── 분석 종류 ────────────────────────────────────────────────────────────────
# `sections`의 `id`가 화면·스키마·검사에서 같은 이름으로 쓰인다.
# `graded`가 거짓이면 등급을 묻지 않는다 — 행 하나를 설명하는 데 「양호/주의」는
# 뜻이 없고, 뜻 없는 칸을 두면 모델이 아무 값이나 채운다.
#
# `tier`는 **어느 급의 모델로 돌릴 것인가**다. `deep`은 전체 진단 하나뿐이다 —
# 범위가 좁은 분석은 재료가 작고 물음이 분명해서 기본 모델로 충분하지만, 전체
# AI분석 보고서는 조직 x 검사 격자에서 «어디에 몰렸는가»를 골라내는 일이라 성질이
# 다르다. **모델 이름을 여기 박지 않는다** — 급이 어느 모델인지는 설정에서
# 바꾼다(`model_deep` / `model_report`).
KINDS: dict[str, dict[str, Any]] = {
    "overall": {
        "title": "전체 진단 — AI분석 보고서",
        "graded": True,
        "tier": "deep",
        # **사고 토큰이 이 예산을 함께 먹는다.** 16,000으로 두었더니 Sonnet이
        # 절 여덟 개를 다 쓰기 전에 `stop_reason: max_tokens`로 잘렸다 —
        # 추정으로는 못 잡는다. `count_tokens`는 «입력»만 재고, 사고량은
        # 부르기 전에 알 수 없어서 **실제로 돌려 보고서야** 드러났다.
        "max_tokens": 32000,
        "focus": """이번 검증 회차 **전체**에 대한 AI분석 보고서를 씁니다.
개별 지적의 나열이 아니라 **어디에 무엇이 몰려 있고 무엇을 먼저 해야 하는가**를
쓰십시오. 교차 집계가 근본 원인 분석의 재료입니다.""",
        "sections": (
            ("scope",    "1. 분석 범위와 기준"),
            ("verdict",  "2. 종합 의견"),
            ("findings", "3. 발견사항"),
            ("cause",    "4. 근본 원인 분석"),
            ("trend",    "5. 추세"),
            ("action",   "6. 시정 요구"),
            ("prevent",  "7. 예방과 교육"),
            ("limits",   "8. 검증의 한계"),
        ),
    },
    "trend": {
        "title": "Check별 결함 트렌드 분석",
        "graded": True,
        "max_tokens": 8000,
        "focus": """검사 항목마다 **결함률**이 어떻게 움직였는지 읽습니다.

**건수로 판단하지 마십시오.** 물량이 는 날은 건수가 저절로 늘어납니다.
재료의 `결함률_퍼센트`(그날 결함 행 ÷ 그날 판정 대상)로만 방향을 말하고,
판정 대상이 아주 적은 날은 «표본이 작다»고 함께 적으십시오.""",
        "sections": (
            ("scope",     "1. 보는 범위"),
            ("direction", "2. 늘고 있는 검사 · 줄고 있는 검사"),
            ("volume",    "3. 물량 때문인가, 품질 때문인가"),
            ("turn",      "4. 꺾인 시점"),
            ("watch",     "5. 주시 대상"),
            ("limits",    "6. 한계"),
        ),
    },
    "dept": {
        "title": "부서·팀 진단",
        "graded": True,
        "max_tokens": 12000,
        "focus": """이 조직(부서 또는 팀) 하나를 봅니다.

**전체 평균과 비교하는 것이 핵심입니다** — 「결함률 9%」는 그 자체로 좋지도
나쁘지도 않고, 전체가 5%인지 20%인지에 따라 뜻이 정반대입니다. 재료의
`전체_평균`과 반드시 견주십시오.

교육계획은 **대상 · 주제 · 근거가 된 결함**을 갖춰야 합니다. 「품질 교육 실시」는
계획이 아닙니다. 재검사 대상은 **무엇을 다시 볼지**가 지목돼야 합니다.""",
        "sections": (
            ("standing", "1. 전체 평균 대비 위치"),
            ("findings", "2. 이 조직의 발견사항"),
            ("cause",    "3. 원인 가설"),
            ("priority", "4. 시정 우선순위"),
            ("training", "5. 교육계획 — 대상·주제·근거"),
            ("recheck",  "6. 재검사 대상"),
            ("limits",   "7. 한계"),
        ),
    },
    "welder": {
        "title": "용접사 코칭",
        "graded": True,
        "max_tokens": 8000,
        "focus": """용접사 한 사람을 봅니다. **개인을 평가하는 글이 아니라 코칭
자료입니다** — 무엇을 어떻게 바로잡을지 쓰십시오.

**자격과 결함의 관계**가 이 분석의 재료입니다: 보유 공정·자격 등급·만료일과
실제 지적된 항목을 견주십시오.

Check 6(용접사 자격 미등록)은 **그 행의 작업 품질 문제가 아니라 등록 사무의
문제**입니다. 시공 품질과 섞어 말하지 마십시오.""",
        "sections": (
            ("profile",  "1. 자격과 시공 현황"),
            ("pattern",  "2. 반복되는 패턴"),
            ("cause",    "3. 원인 가설"),
            ("coaching", "4. 코칭과 교육"),
            ("risk",     "5. 자격 위험"),
            ("limits",   "6. 한계"),
        ),
    },
    "anomaly": {
        "title": "이상치 해설",
        "graded": False,
        "max_tokens": 8000,
        "focus": """비지도학습(IsolationForest)이 찾은 **«드문 조합»**을 현장 말로
설명합니다.

**이상치는 규칙 위반이 아닙니다.** 「전체 분포에서 드물다」일 뿐이고, 드문 것이
곧 잘못은 아닙니다. 임계는 사람이 넣은 가정(`contamination`)이라 «모델이 N건이
이상하다고 판단한 것»이 아니라 **점수 상위 N%를 자른 것**입니다. 이 사실을
숨기지 마십시오.

쓸모 있는 답은 **«봐야 할 것»과 «볼 필요 없는 것»을 갈라 주는 것**입니다.""",
        "sections": (
            ("nature", "1. 이번 이상치의 성격"),
            ("groups", "2. 묶어서 볼 것"),
            ("worth",  "3. 사람이 확인할 것"),
            ("skip",   "4. 볼 필요가 적은 것"),
            ("limits", "5. 한계 — 무엇을 뜻하지 않는가"),
        ),
    },
    "falsepos": {
        "title": "오탐 후보 선별",
        "graded": False,
        "max_tokens": 12000,
        "focus": """현업이 이미 «오탐»으로 판정한 지적들의 **판단 근거(검토 의견)**를
읽고, **아직 검토되지 않은 지적** 중 성격이 같은 것을 골라 냅니다.

**단정하지 마십시오.** 결과는 「사람이 먼저 볼 후보」이지 판정이 아닙니다.
근거로는 반드시 **기존 검토 의견의 문구**를 인용하십시오 — 그 문구가 이 판단의
유일한 출처입니다.

기존 오탐 판정이 0건이면 **후보를 만들어 내지 말고** 그 사실을 말하십시오.""",
        "sections": (
            ("basis",      "1. 기존 오탐 판정의 근거"),
            ("candidates", "2. 오탐 후보"),
            ("real",       "3. 반대로 실제 결함일 가능성이 큰 것"),
            ("rulefix",    "4. 규칙 손질 제안"),
            ("limits",     "5. 한계"),
        ),
    },
    "rules": {
        "title": "규칙 건강 진단",
        "graded": True,
        "max_tokens": 8000,
        "focus": """판정 규칙 자체가 **제대로 돌고 있는지**를 봅니다. 결함이 아니라
«검사가 죽어 있지 않은가»가 물음입니다.

가장 중요한 구분: **「위반 0건」과 「대조 대상 0건」은 다릅니다.**
`적용_대상_행수`가 0이면 그 검사는 한 번도 판정하지 않은 것입니다.

빈 값(`params`)과 빌려 온 값(`provisional`)도 봅니다 — 실제로 `repair_prefix`가
비어 600건 규모의 오탐이 난 적이 있습니다.""",
        "sections": (
            ("zero",     "1. «0건»이 어느 쪽 뜻인가"),
            ("mismatch", "2. 표기 불일치 의심"),
            ("borrowed", "3. 빌려 온 값"),
            ("params",   "4. 비어 있는 값"),
            ("action",   "5. 해야 할 일"),
        ),
    },
    "quality": {
        "title": "기록 품질 진단",
        "graded": True,
        "max_tokens": 8000,
        "focus": """**판정 대상은 아니지만 기록이 이상한 것**을 봅니다.
공란·형식 오류·앞뒤가 안 맞는 값입니다.

**공란이 전부 문제는 아닙니다.** NDT REPORT 번호는 NDT 계획이 없는 행에서
비어 있는 것이 정상입니다(실측 44.8%). 「채워야 한다」고 말하기 전에 **비어
있는 것이 정상인 자리인지** 먼저 가리십시오.""",
        "sections": (
            ("blanks", "1. 공란"),
            ("suspect", "2. 값이 이상한 곳"),
            ("impact", "3. 판정에 미치는 영향"),
            ("action", "4. 해야 할 일"),
        ),
    },
    "review": {
        "title": "§11 답변 초안",
        "graded": False,
        "max_tokens": 6000,
        "focus": """현업 확인이 필요한 미결 항목 하나에 대해 **답변 초안**을 씁니다.

**이것은 결론이 아니라 초안입니다.** 저장은 사람이 합니다. 공개 표준으로
도출할 수 있는 데까지만 쓰고, 그 WPS 문서의 실제 의도처럼 **확인할 수 없는
것은 «남은 확인사항»에 남기십시오.**

실데이터 영향(몇 행이 걸리는가)을 반드시 수치로 적으십시오.""",
        "sections": (
            ("impact", "1. 실데이터 영향"),
            ("draft",  "2. 잠정 결론 초안"),
            ("open",   "3. 남은 확인사항"),
        ),
    },
    "row": {
        "title": "이 결함 설명",
        "graded": False,
        "max_tokens": 4000,
        "focus": """지적된 행 **하나**를 설명합니다. 짧게 쓰십시오 — 이 글은 모달
안에서 읽힙니다.

판정 로직(`판정_로직`)을 근거로 **왜 걸렸는지**, 기준값과 실제값이 **어떻게
다른지**, **무엇을 하면 되는지**를 각 1~3문장으로 씁니다.""",
        "sections": (
            ("why",    "1. 왜 걸렸는가"),
            ("gap",    "2. 기준과 실제"),
            ("action", "3. 조치"),
        ),
    },
}


def tier_of(kind: str) -> str:
    """`deep` | `std`. **적지 않은 종류는 `std`다** — 새 종류를 만들었는데
    표에 없다고 비싼 모델로 돌아가면 아무도 눈치채지 못한 채 비용이 는다."""
    return "deep" if kind_of(kind).get("tier") == "deep" else "std"


def kind_of(kind: str) -> dict[str, Any]:
    """모르는 종류는 **거부한다.**

    기본값으로 흘려보내면 「부서 진단을 눌렀는데 전체 AI분석 보고서가 나오는」
    상태가 되고, 그건 오류가 아니라 «틀린 글»이라 아무도 눈치채지 못한다.
    """
    got = KINDS.get(kind)
    if not got:
        raise ValueError(f"모르는 분석 종류: {kind!r} (가능: {sorted(KINDS)})")
    return got


def section_ids(kind: str) -> list[str]:
    return [s for s, _ in kind_of(kind)["sections"]]


def output_schema(kind: str) -> dict:
    """구조화 출력 스키마. **`evidence`가 필수다.**"""
    meta = kind_of(kind)
    evidence = {
        "type": "object",
        "additionalProperties": False,
        "required": ["kind", "label", "value"],
        "properties": {
            "kind":     {"type": "string", "enum": list(EVIDENCE_KINDS),
                         "description": "근거의 종류. 화면이 이 값으로 어디를 열지 정한다"},
            "label":    {"type": "string",
                         "description": "무엇에 대한 근거인가. 예: 'Check 26', 'NF130', 'Q520-해양내업생산부'"},
            "value":    {"type": "string",
                         "description": "재료에 실제로 있던 수치를 그대로. 예: '22.2% (20/90)', '22건'"},
            "check_no": {"type": "string", "description": "해당하면 검사 번호, 없으면 빈 문자열"},
            "dept":     {"type": "string", "description": "해당하면 부서명, 없으면 빈 문자열"},
        },
    }
    claim = {
        "type": "object",
        "additionalProperties": False,
        "required": ["text", "severity", "evidence"],
        "properties": {
            "text": {"type": "string", "description": "한 문장. 근거로 뒷받침되는 것만"},
            "severity": {"type": "string", "enum": list(SEVERITIES),
                         "description": "high=지금 조치, medium=계획에 넣을 것, "
                                        "low=지켜볼 것, info=사실 서술(문제가 아님)"},
            "evidence": evidence,
        },
    }
    section = {
        "type": "object",
        "additionalProperties": False,
        "required": ["id", "claims"],
        "properties": {
            "id": {"type": "string", "enum": section_ids(kind)},
            "claims": {"type": "array", "items": claim},
        },
    }
    # **두괄식.** 보고서는 결론이 먼저다. 절을 여덟 개 읽어야 요지를 알 수 있으면
    # 아무도 끝까지 안 읽는다 — 그러면 근거 칩도 안 눌린다.
    point = {
        "type": "object",
        "additionalProperties": False,
        "required": ["label", "value", "severity"],
        "properties": {
            "label":    {"type": "string", "description": "짧은 이름. 예: '결함 집중 블록'"},
            "value":    {"type": "string", "description": "재료에 있던 수치 그대로. 예: 'NF130 28행'"},
            "severity": {"type": "string", "enum": list(SEVERITIES)},
            "note":     {"type": "string", "description": "한 줄 설명. 없으면 빈 문자열"},
        },
    }
    props: dict[str, Any] = {
        "headline": {"type": "string", "description": "한 문장 총평"},
        "summary": {
            "type": "object",
            "additionalProperties": False,
            "required": ["verdict", "points"],
            "properties": {
                "verdict": {"type": "string",
                            "description": "2~3문장. 무엇이 문제이고 무엇을 먼저 해야 하는가"},
                "points": {"type": "array", "items": point,
                           "description": "핵심 수치 3~5개. 이것만 보고도 요지가 서야 한다"},
            },
        },
        "sections": {"type": "array", "items": section},
    }
    required = ["headline", "summary", "sections"]
    if meta["graded"]:
        props["grade"] = {"type": "string",
                          "enum": ["양호", "주의", "시정 필요", "판단 보류"],
                          "description": "종합 의견 등급"}
        required.insert(0, "grade")
    return {"type": "object", "additionalProperties": False,
            "required": required, "properties": props}


# **시스템 프롬프트는 종류가 달라도 같다** — 캐싱이 여기 달려 있다.
# 종류마다 문장을 섞어 넣으면 프리픽스가 흔들려 캐시가 매번 날아간다.
# 종류별 지시는 사용자 메시지 «맨 앞»에 둔다.
SYSTEM = """당신은 조선/해양 구조물 **용접 품질관리(QA/QC) 분석 전문가**입니다.
자동 검증 시스템이 낸 판정 결과를 받아 **AI분석 보고서 형식의 분석**을 씁니다.

## 지켜야 할 것

**① 숫자를 만들지 마십시오.** 주어진 재료에 있는 수치만 씁니다. 계산이 필요하면
재료에 이미 계산된 값을 쓰고, 없으면 그 말을 하지 마십시오. 재료의 표는 대부분
**상위 N줄**만 실려 있습니다 — 꼬리를 더해 전체를 말하지 마십시오.

**② 모든 문장에 근거를 답니다.** `evidence`에 재료에서 그대로 가져온 수치를
넣습니다. 근거를 댈 수 없는 문장은 **아예 쓰지 마십시오** — 서버가 버립니다.

**③ 「0건」을 «문제 없음»으로 읽지 마십시오.** 재료의 `적용_대상_행수`가 0이면
그 검사는 한 번도 판정하지 않은 것입니다. 위반이 없는 것과 전혀 다릅니다.

**④ 범위를 먼저 말하십시오.** 원본 행수와 판정 대상은 크게 다릅니다. 무엇을
보지 않았는지(삭제·임시부재·미작업·꺼진 검사)를 첫 절에 반드시 적습니다.

**⑤ 한계를 숨기지 마십시오.** 판단 근거가 없는 항목, 빌려 온 값, 검토가 안 된
지적은 마지막 절에 적습니다. 이 절이 없으면 나머지가 전부 과신이 됩니다.

**⑥ 추세는 «건수»가 아니라 «결함률»로 봅니다.** 건수는 물량을 따라 움직입니다.

## 현장 용어는 번역하지 마십시오

WPS · PQR · Joint No · Groove · NDT · NDE · CJP/PJP · 선급(DNV) · 블록 ·
용접사 번호 · 부서/팀은 그대로 씁니다.

## 두괄식으로 씁니다

`summary`가 맨 위에 옵니다. **결론이 먼저입니다.**

- `verdict` — 2~3문장. 무엇이 문제이고 **무엇을 먼저 해야 하는가**
- `points` — 핵심 수치 3~5개. 이것만 보고도 요지가 서야 합니다.
  `value`에는 재료의 수치를 **그대로** 넣습니다(예: `NF130 28행`, `83.3% (30/36)`)

## 중대성을 답니다

문장마다 `severity`를 답니다. **등급과 어긋나면 안 됩니다** —
「양호」라고 해 놓고 high가 여럿이면 둘 중 하나가 틀린 것입니다.

| | |
|---|---|
| `high` | 지금 조치해야 한다 |
| `medium` | 계획에 넣어야 한다 |
| `low` | 지켜볼 만하다 |
| `info` | 사실 서술 — **문제가 아닙니다.** 범위·한계·배경은 대개 여기입니다 |

## 표와 그래프는 쓰지 마십시오

도표는 **서버가 같은 재료에서 직접 만들어** 각 절에 붙입니다. 당신은 글만
씁니다. 숫자를 나열해 표를 흉내내지 말고, 그 숫자가 **무슨 뜻인지**를 쓰십시오.

## 쓰는 법

각 절은 **3~6문장**이면 충분합니다. 짧고 구체적으로 쓰십시오. 같은 말을 절마다
되풀이하지 마십시오. 재료에 없어서 말할 수 없는 절은 **그렇다고 한 문장으로**
적고 넘어가십시오 — 빈 절을 채우려 지어내지 마십시오."""


def build_messages(kind: str, context: dict,
                   scope_note: str = "") -> tuple[list, list[dict]]:
    """`(system, messages)`.

    **시스템 프롬프트를 캐싱한다.** 종류가 바뀌어도 이 부분은 같으므로,
    반복 호출의 입력비가 크게 준다. 캐시는 프리픽스 일치라 **바뀌는 것(종류별
    지시와 재료)이 반드시 뒤에** 와야 한다.
    """
    meta = kind_of(kind)
    system = [{"type": "text", "text": SYSTEM,
               "cache_control": {"type": "ephemeral"}}]

    titles = "\n".join(f"{i + 1}) {t}" for i, (_, t) in enumerate(meta["sections"]))
    head = f"# {meta['title']}\n"
    if scope_note:
        head += f"\n**분석 대상: {scope_note}**\n"
    body = (f"{head}\n{meta['focus']}\n\n## 절 구성\n\n{titles}\n\n"
            "## 재료\n\n아래 집계만 근거로 삼으십시오.\n\n```json\n"
            + json.dumps(context, ensure_ascii=False, indent=1, sort_keys=False)
            + "\n```")
    return system, [{"role": "user", "content": body}]


def _evidence_ok(ev: Any) -> bool:
    """근거가 «있다»고 할 수 있는가.

    빈 문자열만 채워 넣은 것은 근거가 아니다 — 스키마는 통과하지만 화면에서
    누를 것이 없고, 읽는 사람은 뒷받침된 문장으로 읽는다.
    """
    if not isinstance(ev, dict):
        return False
    return bool(str(ev.get("label", "")).strip()
                and str(ev.get("value", "")).strip())


def parse_and_check(kind: str, raw: str) -> dict:
    """모델 출력을 읽고 **근거 없는 주장을 버린다.**

    버린 수를 함께 돌려준다. 조용히 버리면 «AI가 그것밖에 말 안 했다»가 된다.
    """
    meta = kind_of(kind)
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        raise ValueError("AI 응답을 읽지 못했습니다 (JSON 형식이 아닙니다)") from None
    if not isinstance(data, dict):
        raise ValueError("AI 응답의 모양이 예상과 다릅니다")

    titles = dict(meta["sections"])
    ids = [s for s, _ in meta["sections"]]
    kept_sections: list[dict] = []
    dropped = 0

    by_id = {}
    for sec in data.get("sections") or []:
        if isinstance(sec, dict) and sec.get("id") in titles:
            by_id[sec["id"]] = sec

    # **절 순서는 우리가 정한다.** 모델이 순서를 바꿔 보내도 보고서 형식은
    # 유지돼야 한다.
    for sid in ids:
        sec = by_id.get(sid) or {}
        claims = []
        for c in (sec.get("claims") or []):
            if not isinstance(c, dict) or not str(c.get("text", "")).strip():
                dropped += 1
                continue
            if not _evidence_ok(c.get("evidence")):
                dropped += 1
                continue
            sev = str(c.get("severity") or "info")
            claims.append({"text": str(c["text"]).strip(),
                           "severity": sev if sev in SEVERITIES else "info",
                           "evidence": {k: str(v) for k, v in c["evidence"].items()}})
        kept_sections.append({"id": sid, "title": titles[sid], "claims": claims})

    if dropped:
        logger.info("[%s] 근거 없는 주장 %d건을 버렸다", kind, dropped)

    # 요약도 «근거 없는 것»은 버린다. 두괄식이라 가장 먼저 읽히는 자리인데,
    # 여기에 뒷받침 없는 숫자가 들어가면 나머지를 다 걸러도 소용이 없다.
    raw_sum = data.get("summary") if isinstance(data.get("summary"), dict) else {}
    points = []
    for p in (raw_sum.get("points") or []):
        if not isinstance(p, dict):
            dropped += 1
            continue
        label, value = str(p.get("label", "")).strip(), str(p.get("value", "")).strip()
        if not label or not value:
            dropped += 1
            continue
        sev = str(p.get("severity") or "info")
        points.append({"label": label, "value": value,
                       "severity": sev if sev in SEVERITIES else "info",
                       "note": str(p.get("note") or "").strip()})

    out = {
        "kind": kind,
        "title": meta["title"],
        "headline": str(data.get("headline") or ""),
        "summary": {"verdict": str(raw_sum.get("verdict") or "").strip(),
                    "points": points},
        "sections": kept_sections,
        "dropped_claims": dropped,
    }
    if meta["graded"]:
        out["grade"] = str(data.get("grade") or "판단 보류")
    return out
