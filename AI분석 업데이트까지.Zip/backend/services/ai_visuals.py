"""보고서에 들어가는 **도표를 서버가 만든다.**

## 왜 AI에게 그리게 하지 않는가

이 설계의 뼈대가 「AI는 숫자를 세지 않는다」이다. 표와 그래프는 숫자 덩어리라
모델에게 만들게 하면 그 규칙을 정면으로 깬다 — 실제로 두 축 교차표를 합산시켰다가
「NF130 26」(실제 28)이라고 쓴 적이 있다. **그림은 글보다 더 믿긴다.**
틀린 막대는 틀린 문장보다 오래 남는다.

그래서 도표는 **모델에게 보낸 것과 같은 재료 dict**에서 만든다. 같은 입력을
보므로 «그림과 글이 다른 숫자를 본다»가 원천적으로 생기지 않는다.

## 절에 매단다

`{절 id: [도표, ...]}`. 모델이 절 순서를 바꿔 보내도 서버가 절 순서를 정하므로
(`ai_report.parse_and_check`) 그림이 엉뚱한 절에 붙지 않는다.

## 도표는 다섯 가지뿐이다

| | |
|---|---|
| `kpi` | 큰 숫자 몇 개. 두괄식 요약 바로 아래 |
| `funnel` | 원본 -> 판정 대상까지 무엇이 얼마나 빠졌는가 |
| `bar` | 순위 (검사별·부서별·블록별) |
| `line` | 추이. **결함률**이다 — 건수는 물량을 따라 움직인다 |
| `table` | 나머지 전부 |

종류를 늘리면 화면 쪽 렌더러가 그만큼 늘고, 하나는 반드시 덜 다듬어진다.
"""
from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

_TOP = 12          # 막대·표에 몇 줄까지. 꼬리는 읽히지 않는다.


def _kpi(*items: dict) -> dict:
    return {"type": "kpi", "items": [i for i in items if i]}


def _bar(title: str, items: list[dict], unit: str = "건", note: str = "") -> dict | None:
    """상위 몇 개의 막대. **빈 것은 안 만든다** — 「데이터 없음」 상자만 남는다."""
    items = [i for i in items if i.get("value")]
    if not items:
        return None
    return {"type": "bar", "title": title, "unit": unit, "note": note,
            "items": items[:_TOP]}


def _table(title: str, columns: list[str], rows: list[list],
           note: str = "") -> dict | None:
    if not rows:
        return None
    return {"type": "table", "title": title, "columns": columns,
            "rows": rows[:_TOP], "note": note}


def _line(title: str, series: list[dict], unit: str = "%",
          note: str = "") -> dict | None:
    series = [s for s in series if len(s.get("points") or []) >= 2]
    if not series:
        return None
    return {"type": "line", "title": title, "unit": unit, "note": note,
            "series": series[:6]}


def _check_label(ctx: dict, no: str) -> str:
    for c in (ctx.get("검사_항목") or []):
        if str(c.get("번호")) == str(no):
            return c.get("이름", "")
    return ""


def _scope_visuals(ctx: dict) -> list[dict]:
    """행 회계. **이것이 1절을 «보고»로 만든다.**

    없으면 「9,995행을 검사했다」로 읽힌다. 실제 판정은 374행이다.
    """
    s = ctx.get("분석_범위") or {}
    total = s.get("원본_행수", 0)
    if not total:
        return []
    steps = [{"label": "원본", "value": total}]
    for label, key in (("삭제", "삭제"), ("임시부재(1C)", "임시부재_1C"),
                       ("미작업(WPS 공란)", "미작업_WPS공란")):
        v = s.get(key, 0)
        if v:
            steps.append({"label": label, "value": v, "drop": True})
    steps.append({"label": "판정 대상", "value": s.get("판정_대상", 0), "final": True})
    return [
        _kpi(
            {"label": "판정 대상", "value": s.get("판정_대상", 0), "unit": "행",
             "sub": f"원본의 {s.get('판정_대상_비율_퍼센트', 0)}%"},
            {"label": "결함 행", "value": s.get("결함_행", 0), "unit": "행",
             "tone": "warn"},
            {"label": "결함률", "value": s.get("결함률_퍼센트", 0), "unit": "%",
             "tone": "warn", "sub": "분모는 판정 대상"},
            {"label": "총 지적", "value": s.get("총_지적_건수", 0), "unit": "건",
             "sub": "한 행에 여러 건 가능"},
        ),
        {"type": "funnel", "title": "무엇을 보지 않았는가", "steps": steps,
         "note": "1C(임시부재)와 미작업은 판정 대상이 아니다. 결함률의 분모는 맨 오른쪽이다."},
    ]


def _checks_bar(ctx: dict, title: str = "검사 항목별 지적 건수") -> dict | None:
    items = []
    for c in (ctx.get("검사_항목") or []):
        n = c.get("지적_건수", 0)
        if not n:
            continue
        items.append({"label": f"C{c['번호']}", "value": n,
                      "sub": c.get("이름", ""), "check_no": str(c["번호"])})
    items.sort(key=lambda x: -x["value"])
    return _bar(title, items, note="색은 결과 Excel의 마킹 색과 같다")


def _zero_scope_table(ctx: dict) -> dict | None:
    """**«위반 0»과 «대조 대상 0»은 다르다.** 화면에서는 둘 다 «0»으로 보인다."""
    rows = []
    for c in (ctx.get("검사_항목") or []):
        if not c.get("켜짐", True):
            rows.append([f"C{c['번호']}", c.get("이름", ""), "꺼짐",
                         "판정하지 않았다 (세팅에서 껐다)"])
        elif c.get("적용_대상_행수") == 0:
            rows.append([f"C{c['번호']}", c.get("이름", ""), "대상 0건",
                         "한 번도 판정하지 않았다 — 위반이 없는 것이 아니다"])
        elif c.get("지적_건수", 0) == 0:
            rows.append([f"C{c['번호']}", c.get("이름", ""), "위반 0",
                         f"{c.get('적용_대상_행수') or '전체'}행을 대조했고 위반이 없었다"])
    return _table("«0건»의 두 가지 뜻", ["검사", "이름", "구분", "읽는 법"], rows)


def _trend_lines(ctx: dict) -> dict | None:
    """**가로축이 «일»이 아닐 수 있다.** 기간이 길면 재료가 주/월로 묶어서 온다
    (38만 행 · 2년이면 일 단위는 어느 모델의 창에도 안 들어간다). 축 이름을
    「날짜」로 박아 두면 월 단위 그래프를 일 단위로 읽게 된다."""
    t = ctx.get("추세") or {}
    unit = t.get("묶음_단위") or "일"
    series = []
    for no, pts in sorted((t.get("검사별") or {}).items(),
                          key=lambda kv: -sum(p.get("결함_행", 0) for p in kv[1])):
        series.append({
            "label": f"C{no} {_check_label(ctx, no)}".strip(),
            "check_no": str(no),
            "points": [{"x": p.get("구간", ""), "y": p.get("결함률_퍼센트", 0),
                        "n": p.get("결함_행", 0), "d": p.get("그_구간_판정_대상", 0)}
                       for p in pts],
        })
    return _line(f"검사별 결함률 추이 ({unit} 단위)", series,
                 note=f"가로축은 **{unit} 단위**다. 세로축은 «그 구간의 결함 행 / "
                      "그 구간의 판정 대상»이고, 건수로 그리면 물량이 는 구간이 "
                      "«악화»로 보인다.")


def _cross_tables(ctx: dict) -> list[dict]:
    """어디에 몰리는가. **이미 더한 값**을 그대로 쓴다."""
    x = ctx.get("교차_집계") or {}
    out = []
    for title, key, col in (("블록별 결함 행", "블록별", "block"),
                            ("WPS별 결함 행", "WPS별", "wps"),
                            ("재질별 결함 행", "재질별", "material"),
                            ("용접사별 결함 행", "용접사별", "welder")):
        rows = ((x.get(key) or {}).get("상위") or [])
        got = _bar(title, [{"label": str(r.get(col) or "(미기재)"),
                            "value": r.get("rows", 0)} for r in rows],
                   unit="행",
                   note="결함 «행» 수다 — 한 행에 여러 지적이 있어도 1이다")
        if got:
            out.append(got)
    return out


# ── 종류별 ──────────────────────────────────────────────────────────────────
def _overall(ctx: dict) -> dict:
    d = ctx.get("부서") or []
    return {
        "scope": _scope_visuals(ctx),
        "findings": [v for v in [_checks_bar(ctx)] if v],
        "cause": _cross_tables(ctx),
        "trend": [v for v in [_trend_lines(ctx)] if v],
        "action": [v for v in [_bar(
            "부서별 결함률", [{"label": x["부서"], "value": x["결함률_퍼센트"],
                              "sub": f"{x['결함_행']} / {x['판정_대상']}행"}
                             for x in sorted(d, key=lambda y: -y["결함률_퍼센트"])],
            unit="%")] if v],
        "limits": [v for v in [_zero_scope_table(ctx)] if v],
    }


def _trend(ctx: dict) -> dict:
    t = ctx.get("추세") or {}
    base = t.get("구간별_판정_대상") or []
    unit = t.get("묶음_단위") or "일"
    return {
        "scope": _scope_visuals(ctx),
        "direction": [v for v in [_trend_lines(ctx)] if v],
        "volume": [v for v in [_bar(
            f"{unit}별 판정 대상 (분모)",
            [{"label": p["구간"], "value": p["판정_대상"]} for p in base],
            unit="행",
            note="이 막대가 크게 흔들리면 «건수» 비교는 뜻이 없다")] if v],
    }


def _dept(ctx: dict) -> dict:
    me = ctx.get("이_조직") or {}
    whole = ctx.get("전체_평균") or {}
    target = (ctx.get("대상") or {})
    name = target.get("팀") or target.get("부서") or ""
    rank = ctx.get("부서_순위") or []
    stats = me.get("검사별_지적_건수") or {}
    checks = [{"label": f"C{k}", "value": v, "sub": _check_label(ctx, k),
               "check_no": str(k)} for k, v in stats.items() if v]
    checks.sort(key=lambda x: -x["value"])
    return {
        "standing": [
            _kpi(
                {"label": "판정 대상", "value": me.get("판정_대상", 0), "unit": "행"},
                {"label": "결함 행", "value": me.get("결함_행", 0), "unit": "행",
                 "tone": "warn"},
                {"label": "이 조직 결함률", "value": me.get("결함률_퍼센트", 0),
                 "unit": "%", "tone": "warn"},
                {"label": "전체 평균", "value": whole.get("결함률_퍼센트", 0),
                 "unit": "%", "sub": f"{whole.get('결함_행', 0)} / {whole.get('판정_대상', 0)}행"},
            ),
            _bar("부서별 결함률 — 이 조직의 자리",
                 [{"label": x["부서"], "value": x["결함률_퍼센트"],
                   "sub": f"{x['결함_행']} / {x['판정_대상']}행",
                   "me": x["부서"] == (target.get("부서") or "")}
                  for x in sorted(rank, key=lambda y: -y["결함률_퍼센트"])],
                 unit="%", note=f"진한 막대가 {name}이다"),
        ],
        "findings": [v for v in [_bar("이 조직의 검사별 지적", checks)] if v],
        "priority": [v for v in [_table(
            "같은 부서의 팀", ["팀", "판정 대상", "결함 행", "결함률"],
            [[t["팀"], t["판정_대상"], t["결함_행"], f"{t['결함률_퍼센트']}%"]
             for t in sorted(ctx.get("같은_부서의_팀들") or [],
                             key=lambda y: -y["결함률_퍼센트"])])] if v],
        "training": [v for v in [_table(
            "용접사별 결함률", ["용접사", "시공", "결함", "결함률"],
            [[w["용접사"], w["시공_건수"], w["결함_건수"], f"{w['결함률_퍼센트']}%"]
             for w in (ctx.get("용접사") or [])],
            note="교육 대상을 고르는 표다. 표본이 적으면 결함률만으로 판단하지 마라.")] if v],
        "recheck": [v for v in [_table(
            "반복 결함 패턴", ["용접사", "검사", "건수", "서로 다른 날짜", "기간"],
            [[p["용접사"], f"C{p['검사']}", p["건수"], p["서로_다른_날짜"], p["기간"]]
             for p in (ctx.get("반복_패턴") or [])],
            note="서로 다른 날짜에 되풀이된 것 — 우연이 아니라는 근거다")] if v],
    }


def _welder(ctx: dict) -> dict:
    me = ctx.get("시공과_결함") or {}
    q = ctx.get("자격") or {}
    whole = ctx.get("전체_평균") or {}
    stats = ctx.get("검사별_지적_건수") or {}
    daily = ctx.get("날짜별") or []
    return {
        "profile": [
            _kpi(
                {"label": "시공", "value": me.get("시공_건수", 0), "unit": "행"},
                {"label": "결함", "value": me.get("결함_건수", 0), "unit": "행",
                 "tone": "warn"},
                {"label": "결함률", "value": me.get("결함률_퍼센트", 0), "unit": "%",
                 "tone": "warn"},
                {"label": "전체 평균", "value": whole.get("전체_결함률_퍼센트", 0),
                 "unit": "%"},
            ),
            _table("자격", ["항목", "값"],
                   [["보유 공정", ", ".join(q.get("보유_공정") or []) or "—"],
                    ["자세", " ".join(q.get("자세") or []) or "—"],
                    ["선급", ", ".join(q.get("선급") or []) or "—"],
                    ["규격", ", ".join(q.get("규격") or []) or "—"],
                    ["자격 취득", q.get("자격_취득") or "—"],
                    ["자격 DB", "등록" + (" · 퇴사" if q.get("퇴사") else "")
                     if q.get("자격DB_등록") else "미등록 (협력사 등)"],
                    ["소속", ", ".join(f"{o['부서']} / {o['팀']} ({o['행수']}행)"
                                       for o in (q.get("소속") or [])) or "—"]]),
        ],
        "pattern": [
            v for v in [
                _bar("검사별 지적",
                     [{"label": f"C{k}", "value": v2, "sub": _check_label(ctx, k),
                       "check_no": str(k)} for k, v2 in stats.items() if v2]),
                _line("날짜별 결함률", [{
                    "label": "이 용접사",
                    "points": [{"x": d["날짜"], "y": d["결함률_퍼센트"],
                                "n": d["지적_건수"], "d": d["시공_행수"]}
                               for d in daily]}],
                      note="분모는 그날 이 사람의 시공 행수다. "
                           "건수만 보면 많이 일한 날이 «악화»로 보인다."),
            ] if v
        ],
        "coaching": [v for v in [_bar(
            "블록별 지적", ctx.get("블록별_지적_건수") and
            [{"label": b["블록"], "value": b["건수"]}
             for b in ctx["블록별_지적_건수"]] or [])] if v],
    }


def _anomaly(ctx: dict) -> dict:
    m = ctx.get("모델") or {}
    rows = ctx.get("이상치_행") or []
    return {
        "nature": [
            _kpi(
                {"label": "학습 행수", "value": m.get("학습_행수", 0), "unit": "행"},
                {"label": "이상치", "value": m.get("이상치_건수", 0), "unit": "건",
                 "tone": "warn"},
                {"label": "임계 비율",
                 "value": round((m.get("임계_비율") or 0) * 100, 2), "unit": "%",
                 "sub": "사람이 넣은 가정"},
            ),
        ],
        "worth": [v for v in [_table(
            "이상치 행", ["행", "왜 드문가"],
            [[r["행"], r.get("이유", "")] for r in rows],
            note="규칙 위반이 아니다 — 전체 분포에서 «드문 조합»일 뿐이다")] if v],
    }


def _falsepos(ctx: dict) -> dict:
    rv = ctx.get("검토_진행") or {}
    return {
        "basis": [
            _kpi(
                {"label": "대조 대상 지적", "value": rv.get("대조_대상_지적", 0),
                 "unit": "건"},
                {"label": "검토 완료", "value": rv.get("검토_완료", 0), "unit": "건"},
                {"label": "미검토", "value": rv.get("미검토", 0), "unit": "건",
                 "tone": "warn"},
            ),
            _table("이미 «오탐»으로 판정된 근거",
                   ["검사", "건수", "현업이 남긴 근거"],
                   [[f"C{b['검사']}", b["건수"], b["근거"] or "(근거 없음)"]
                    for b in (ctx.get("기존_오탐_판정의_근거") or [])],
                   note="이 문구가 후보 선별의 유일한 출처다"),
        ],
        "candidates": [v for v in [_table(
            "미검토 지적", ["검사", "건수", "예시 메시지"],
            [[f"C{p['검사']}", p["미검토_건수"], p["예시_메시지"]]
             for p in (ctx.get("미검토_지적") or [])])] if v],
    }


def _rules(ctx: dict) -> dict:
    h = ctx.get("규칙_건강") or {}
    return {
        "zero": [v for v in [_zero_scope_table(ctx)] if v],
        "borrowed": [v for v in [_table(
            "빌려 온 값 — 확인 필요", ["검사", "사유"],
            [[f"C{k}", v2] for k, v2 in sorted((h.get("빌려온_값_확인필요") or {}).items())],
            note="다른 프로젝트 값을 그대로 쓰고 있다는 표식이다")] if v],
        "params": [v for v in [_table(
            "프로젝트 값", ["키", "값"],
            [[k, str(v2)[:120]] for k, v2 in sorted((ctx.get("프로젝트_값") or {}).items())],
            note="비면 그 검사가 조용히 죽는다")] if v],
        "action": [v for v in [_table(
            "규칙 건강 경고", ["내용"],
            [[str(w) if not isinstance(w, dict) else
              " · ".join(f"{a}={b}" for a, b in w.items())]
             for w in (h.get("경고") or [])])] if v],
    }


def _quality(ctx: dict) -> dict:
    b = ctx.get("지적된_행의_기록_공란") or {}
    s = ctx.get("분석_범위") or {}
    return {
        "blanks": [
            _kpi(
                {"label": "NDT REPORT 공란", "value": b.get("NDT_REPORT_공란", 0),
                 "unit": "건", "sub": f"표본 {b.get('표본_지적_건수', 0)}건 중"},
                {"label": "용접일 공란", "value": b.get("용접일_공란", 0), "unit": "건"},
                {"label": "블록 공란", "value": b.get("블록_공란", 0), "unit": "건"},
            ),
        ],
        "impact": _scope_visuals(ctx),
        "action": [v for v in [_table(
            "판정 대상이 아닌 행", ["구분", "행수", "기준"],
            [["미작업", (ctx.get("미작업") or {}).get("행수", 0),
              (ctx.get("미작업") or {}).get("판정_기준", "")],
             ["임시부재(1C)", (ctx.get("임시부재_1C") or {}).get("행수", 0),
              (ctx.get("임시부재_1C") or {}).get("판정_기준", "")],
             ["삭제", s.get("삭제", 0), "원본에서 삭제 표시된 행"]])] if v],
    }


def _row(ctx: dict) -> dict:
    return {
        "gap": [v for v in [_table(
            "기준과 실제", ["검사", "이름", "기준값", "실제값"],
            [[f"C{f['검사']}", f.get("이름", ""), f.get("기준값", ""),
              f.get("실제값", "")] for f in (ctx.get("지적") or [])])] if v],
        "why": [v for v in [_table(
            "행 정보", ["항목", "값"],
            [[k, str(v2)] for k, v2 in (ctx.get("행_정보") or {}).items() if v2])] if v],
    }


def _review(ctx: dict) -> dict:
    return {
        "impact": _scope_visuals(ctx) + [v for v in [_checks_bar(ctx)] if v],
    }


_BY_KIND = {
    "overall": _overall, "trend": _trend, "dept": _dept, "welder": _welder,
    "anomaly": _anomaly, "falsepos": _falsepos, "rules": _rules,
    "quality": _quality, "row": _row, "review": _review,
}


def build(kind: str, ctx: dict) -> dict[str, list[dict]]:
    """`{절 id: [도표, ...]}`.

    **여기서 예외가 새면 보고서 전체가 안 나간다.** 그림이 없는 것보다 글이
    없는 것이 훨씬 나쁘므로 절 단위로 삼킨다.
    """
    fn = _BY_KIND.get(kind)
    if not fn:
        return {}
    try:
        raw = fn(ctx)
    except Exception:
        logger.exception("도표 생성 실패: %s", kind)
        return {}
    return {sid: [v for v in vs if v] for sid, vs in raw.items()
            if [v for v in vs if v]}
