"""AI 분석 엔드포인트.

## 누르지 않으면 나가지 않는다

현업 지시(2026-08-21): **버튼을 눌렀을 때만 실행된다.** 검증이 끝나고 자동으로,
탭에 들어가면 자동으로 도는 것이 하나도 없어야 한다. RUYA가 정확히 그 반대다 —
검증이 끝나면 300ms 뒤에 브리핑이 저절로 나가고, 사용자는 자기가 돈을 쓰고
있다는 것을 모른다.

여기에 **비용 확인 관문이 하나 더** 있으므로 실제로는 두 번 눌러야 나간다:

    [분석 실행]  ->  POST /api/ai/estimate  (무료 · 토큰과 예상 비용)
                 ->  [실행]  ->  POST /api/ai/report  (여기서 처음 과금된다)

**저장된 결과를 다시 보여주는 것은 자동 실행이 아니다.** 회차에 붙여 두므로
탭을 오가도 재과금이 없다. `GET /api/ai/report`는 **없으면 없다고 답할 뿐**
새로 만들지 않는다.

## 종류가 열이지만 길은 하나다

`kind`(무엇을) + `scope`(어디를)로 갈린다. 종류마다 엔드포인트를 만들면
중복 클릭 잠금·비용 관문·상한 거부를 열 벌 만들게 되고 그중 하나는 반드시
빠진다. 빠진 자리는 «돈이 두 번 나가는» 자리다.
"""
from __future__ import annotations

import logging
import threading

from fastapi import APIRouter, Header, HTTPException, Query
from pydantic import BaseModel

from backend.routers.auth import require_login
from backend.routers.settings import get_ai_models, get_api_key
from backend.services import (ai_client, ai_context, ai_report, ai_visuals,
                              result_store)

router = APIRouter(prefix="/api")
logger = logging.getLogger(__name__)

# 한 번에 하나만. 버튼 연타로 요청이 N개 나가면 그만큼 과금된다.
_lock = threading.Lock()
_running: set[str] = set()


class ReportIn(BaseModel):
    kind: str = "overall"
    # 「어디를」 — 부서·팀·용접사·행·§11 항목. 종류마다 필요한 키가 다르고,
    # 없으면 `ai_context.build()`가 무엇이 빠졌는지 말해 준다.
    scope: dict = {}
    # 화면에서 이 호출만 모델을 올려 다시 돌릴 수 있게 한다 — 같은 재료로
    # 모델만 바꿔 봐야 「Haiku로 충분한가」를 실제로 잴 수 있다.
    model: str | None = None


def _slot(kind: str, scope: dict) -> str:
    """저장 키. **범위까지 넣어야** 부서 둘의 진단이 서로를 덮어쓰지 않는다."""
    parts = [kind]
    for k in ("dept", "team", "welder", "item", "row"):
        v = str(scope.get(k) or "").strip()
        if v:
            parts.append(f"{k}={v}")
    return "|".join(parts)


def default_model(kind: str) -> str:
    """이 종류의 «기본» 모델. 화면의 선택 상자도 이걸 미리 골라 둔다.

    전체 진단만 한 급 위다. 나머지 아홉은 범위가 좁아 기본 모델로 충분하다 —
    실측으로 부서 진단 2,162토큰 · 행 설명 1,756토큰이다.
    """
    models = get_ai_models()
    return models["deep"] if ai_report.tier_of(kind) == "deep" else models["report"]


def _prepared(kind: str, scope: dict, model_id: str | None):
    key = get_api_key()
    if not key:
        raise HTTPException(400, "Claude API 키가 설정돼 있지 않습니다. "
                                 "'설정' 탭에서 관리자가 등록해야 합니다")
    try:
        meta = ai_report.kind_of(kind)
        ctx, note = ai_context.build(kind, scope)
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from None

    # 화면에서 넘긴 값이 있으면 그게 이긴다 — 같은 재료로 «모델만 올려» 다시
    # 돌려 봐야 「이 급으로 충분한가」를 실제로 잴 수 있다.
    model = ai_client.model_of(model_id or default_model(kind)).id
    system, messages = ai_report.build_messages(kind, ctx, note)
    return key, model, meta, ctx, note, system, messages


@router.get("/ai/models")
def ai_models(x_employee_id: str | None = Header(None)) -> dict:
    """모델 선택 목록과 **종류별 안내.** 관리자가 아니어도 본다 — 분석 실행 옆에서 고른다."""
    require_login(x_employee_id)
    return {
        "models": ai_client.model_choices(),
        "default": get_ai_models()["report"],
        "configured": bool(get_api_key()),
        "sdk_available": ai_client.is_available(),
        # **종류마다 기본 모델이 다르다.** 하나로 내려보내면 화면이 전체 진단에도
        # 기본급을 골라 두고, 사용자는 그게 설계된 급인 줄 안다.
        "kinds": {k: {"title": v["title"],
                      "graded": v["graded"],
                      "tier": ai_report.tier_of(k),
                      "model": default_model(k),
                      "sections": [t for _, t in v["sections"]]}
                  for k, v in ai_report.KINDS.items()},
    }


@router.post("/ai/estimate")
def estimate_report(body: ReportIn,
                    x_employee_id: str | None = Header(None)) -> dict:
    """**무료.** 얼마나 들지 먼저 보여준다. 여기서는 아무것도 과금되지 않는다."""
    require_login(x_employee_id)
    key, model, meta, _ctx, note, system, messages = _prepared(
        body.kind, body.scope, body.model)
    out_max = meta["max_tokens"]

    tokens = ai_client.count_tokens(key, model, system, messages)
    try:
        ai_client.check_input_fits(model, tokens, out_max)
        fits, why = True, ""
    except ai_client.AITooLong as exc:
        fits, why = False, str(exc)

    return {
        "kind": body.kind,
        "title": meta["title"],
        "target": note,
        "model": model,
        "input_tokens": tokens,
        "max_output_tokens": out_max,
        "estimated_usd": round(ai_client.estimate_cost(model, tokens, out_max), 4),
        "fits": fits,
        "message": why,
    }


@router.post("/ai/report")
def run_report(body: ReportIn,
               x_employee_id: str | None = Header(None)) -> dict:
    """분석을 만들고 **회차에 붙여 저장한다.**

    저장하므로 탭을 오가도 다시 부르지 않는다. 재검증하면 회차와 함께 사라지는데,
    그래서 «어느 회차의 무슨 숫자로 쓴 글인가»를 함께 박아 둔다.
    """
    require_login(x_employee_id)
    slot = _slot(body.kind, body.scope)

    with _lock:
        if slot in _running:
            raise HTTPException(409, "이미 분석이 진행 중입니다. 끝난 뒤 다시 눌러 주세요")
        _running.add(slot)
    try:
        key, model, meta, ctx, note, system, messages = _prepared(
            body.kind, body.scope, body.model)
        out_max = meta["max_tokens"]
        tokens = ai_client.count_tokens(key, model, system, messages)
        ai_client.check_input_fits(model, tokens, out_max)   # 자르지 않는다

        got = ai_client.call(key, model, system, messages,
                             max_tokens=out_max, effort="high",
                             output_format={"type": "json_schema",
                                            "schema": ai_report.output_schema(body.kind)})
        if got["stop_reason"] == "max_tokens":
            # **다시 눌러도 같은 자리에서 잘린다.** 예산이 모자란 것이지
            # 그때그때 다른 문제가 아니다. 사고 토큰이 이 예산을 함께 먹으므로
            # 「모델을 낮추거나 범위를 좁히라」가 실제로 통하는 조치다.
            raise HTTPException(500,
                f"응답이 출력 상한({out_max:,} 토큰)에 걸려 잘렸습니다. "
                "다시 눌러도 같은 자리에서 잘립니다 — 범위를 좁히거나"
                "(부서·팀 단위) 모델을 한 급 낮춰 보세요")

        report = ai_report.parse_and_check(body.kind, got["text"])
    except ai_client.AITooLong as exc:
        raise HTTPException(413, str(exc)) from None
    except ai_client.AIError as exc:
        raise HTTPException(502, str(exc)) from None
    except ValueError as exc:
        raise HTTPException(502, str(exc)) from None
    finally:
        with _lock:
            _running.discard(slot)

    scope_block = ctx.get("분석_범위") or {}
    payload = {
        **report,
        # **도표는 서버가 만든다.** 모델이 본 것과 «같은 재료»에서 만들므로
        # 그림과 글이 다른 숫자를 볼 수가 없다. 숫자를 모델에게 그리게 하면
        # 「AI는 숫자를 세지 않는다」가 정면으로 깨지고, 그림은 글보다 더 믿긴다.
        "visuals": ai_visuals.build(body.kind, ctx),
        "target": note,
        "model": got["model"],
        "usage": got["usage"],
        # **어느 회차의 숫자로 쓴 글인가** — 없으면 옛 글이 새 숫자 옆에 남는다
        "run_at": scope_block.get("검증_시각", ""),
        "judged_rows": scope_block.get("판정_대상", 0),
    }
    try:
        result_store.save_ai_report(slot, payload)
    except Exception:
        # 저장에 실패해도 방금 만든 글은 보여준다 — 다시 부르면 또 과금된다.
        logger.exception("AI 보고서 저장 실패: %s", slot)
        payload["saved"] = False

    logger.info("AI 분석 [%s]: %s · 입력 %d · 출력 %d · 캐시읽기 %d · 버린 주장 %d",
                slot, got["model"], got["usage"]["input"], got["usage"]["output"],
                got["usage"]["cache_read"], report["dropped_claims"])
    return payload


@router.get("/ai/saved")
def get_saved(kind: str = Query("overall"),
               dept: str = Query(""),
               team: str = Query(""),
               welder: str = Query(""),
               item: str = Query(""),
               row: str = Query(""),
               x_employee_id: str | None = Header(None)) -> dict:
    """저장된 분석. **없으면 빈 값** — 여기서 새로 만들지 않는다.

    ## 이름이 `report`가 아니라 `saved`인 이유

    화면 렌더 함수가 이것을 부른다 — 탭에 들어오면 «이미 만들어 둔 글»이 그대로
    보여야 하기 때문이다. 그건 과금이 아니라 DB 읽기다.

    그런데 이름이 `/api/ai/report`와 같으면 **«렌더 함수에 AI 호출이 없다»를
    정적으로 검사할 수가 없다.** 돈이 나가는 길(`estimate` · `report`)과 이름을
    갈라 두면 검사가 문자열 두 개를 보는 것으로 끝난다.
    `tests/test_ai_no_autorun.py`가 그 검사를 한다.

    **부서·팀은 질의 파라미터로 받는다.** 실데이터에 `Q530-SMR/ITER생산부`가
    있어 경로 세그먼트로 받으면 ASGI 서버가 라우팅 전에 `%2F`를 풀어 404가 된다.
    """
    require_login(x_employee_id)
    scope = {"dept": dept, "team": team, "welder": welder, "item": item, "row": row}
    try:
        got = result_store.load_ai_report(_slot(kind, scope))
    except Exception:
        logger.exception("AI 보고서 조회 실패")
        got = None
    return {"report": got}
